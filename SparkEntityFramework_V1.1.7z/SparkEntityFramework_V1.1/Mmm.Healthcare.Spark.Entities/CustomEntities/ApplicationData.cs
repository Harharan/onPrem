﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class ApplicationData
    {
        public OrgConfiguration OrganizationConfiguration { get; set; }

        public List<UserInformation> UserDetails { get; set; }

        public List<LocationViewModel> Locations { get; set; }

        public List<OrganizationCategoryMaster> CustomCategories { get; set; }

        public List<CustomParameterViewModel> CustomParameters { get; set; }

        public List<TestMethodViewModel> TestTypes { get; set; }
    }
}
