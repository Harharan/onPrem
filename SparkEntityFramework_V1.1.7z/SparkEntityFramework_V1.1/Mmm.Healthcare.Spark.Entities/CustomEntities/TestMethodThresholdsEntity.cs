﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class TestMethodThresholdsEntity
    {
        public int TestMethodId { get; set; }

        public string TestMethodName { get; set; }

        public int TestType { get; set; }

        public int ThresholdType { get; set; }

        public decimal? PassThreshold { get; set; }

        public decimal? FailThreshold { get; set; }
    }
}
