﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities
{
    public class ResultMeasurementView
    {
        public string TestPointName { get; set; }

        public string TestMethodName { get; set; }

        public DateTime? ResultDate { get; set; }

        public int MeasurementId { get; set; }

        public long ResultId { get; set; }

        public int OrganizationId { get; set; }

        public int EditMeasurementId { get; set; }

        public Nullable<int> OldTechnicianId { get; set; }

        public Nullable<int> NewTechnicianId { get; set; }

        public Nullable<short> OldResult { get; set; }

        public string OldResultStatus { get; set; }

        public Nullable<double> OldResultValue { get; set; }

        public Nullable<short> NewResult { get; set; }

        public Nullable<double> NewResultValue { get; set; }

        public string NewResultStatus { get; set; }

        public System.DateTime? EditDate { get; set; }

        public int? EditedBy { get; set; }

        public string Reason { get; set; }

        public string TechnicianName { get; set; }

        public string ResultEditedByName { get; set; }

        public string TestPlanName { get; set; }

        public string LocationName { get; set; }

        public string RoomName { get; set; }

        public string NewTechnicianName { get; set; }

        public string OldTechnicianName { get; set; }

    }
}
