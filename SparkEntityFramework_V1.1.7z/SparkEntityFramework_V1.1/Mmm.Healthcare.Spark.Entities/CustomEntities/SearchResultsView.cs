﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class SearchResultsView
    {
        public string LocationName { get; set; }

        public int TestPointId { get; set; }

        public string TestPointName { get; set; }

        public int TestMethodId { get; set; }

        public string TestMethodName { get; set; }

        public short? Result { get; set; }

        public double? ResultValue { get; set; }

        public long ResultId { get; set; }

        public int MeasurementId { get; set; }

        public DateTime? ResultDate { get; set; }

        public int TesterId { get; set; }

        public string TesterName { get; set; }

        public string ResultStatus { get; set; }

        public int ResultCommentId { get; set; }

        public string ResultComment { get; set; }

        public bool IsAdhoc { get; set; }

        public bool IsRetest { get; set; }

        public bool IsMapped { get; set; }

        public bool IsArchived { get; set; }

        public short ThresholdType { get; set; }

        public int? MinRange { get; set; }

        public int? MaxRange { get; set; }

        public string TimeZoneName { get; set; }

        public string TimeZoneShortName { get; set; }
    }
}
