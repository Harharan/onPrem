﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class CommonTaskPermissionEntity
    {
        public short MenuId { get; set; }

        public int CommonTaskId { get; set; }

        public string CommonTaskKey { get; set; }
        
        public short DisplayOrder { get; set; }

        public short Permission { get; set; }

        public string AddUrl { get; set; }

        public string ViewUrl { get; set; }

        public bool IsDisplay { get; set; }

        public string ImageName { get; set; }

        public short OpeningMode { get; set; }
    }
}
