﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class LuminometerViewModel
    {
        public int LuminometerId { get; set; }
        public int OrganizationId { get; set; }
        public string Name { get; set; }
        public string DeviceSerialNumber { get; set; }
        public string BuildVersion { get; set; }
        public string FirmwareVersion { get; set; }
        public string MacId { get; set; }
        public string HardwareVersion { get; set; }
        public string OSVersion { get; set; }
        public Nullable<System.DateTime> CalibrationDate { get; set; }
        public Nullable<System.DateTime> LastSyncTime { get; set; }
        public Nullable<short> SyncMode { get; set; }
        public string SyncBy { get; set; }
        public bool IsPlantMapped { get; set; }
        public List<int> MappedPlants { get; set; }
        public List<Tuple<int, string, bool>> PlantList { get; set; }
        public List<string> PlantNameList { get; set; }
        public string FirmwareVersion2 { get; set; }
        public string TimeZoneName { get; set; }
        public string TimeZoneShortName { get; set; }
       
        public string PlantListName { get; set; }

        public List<int> PlantListID { get; set; }
        
    }
}
