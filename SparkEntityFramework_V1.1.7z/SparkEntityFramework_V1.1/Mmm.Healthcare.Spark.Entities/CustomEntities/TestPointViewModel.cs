﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class TestPointViewModel
    {
        public int OrganizationId { get; set; }
        public int TestPointId { get; set; }
        public short TestPointVersion { get; set; }
        public int LocationId { get; set; }
        public string TestPointName { get; set; }
        public short Status { get; set; }
        public bool IsCurrent { get; set; }
        public string Description { get; set; }
        public byte[] TestPointImage { get; set; }
        public Nullable<bool> IsImported { get; set; }
        public Nullable<int> ImportId { get; set; }
        public System.DateTime CreatedDate { get; set; }
        public int CreatedBy { get; set; }
        public Nullable<System.DateTime> LastEditDate { get; set; }
        public Nullable<int> LastEditedBy { get; set; }
        public int ParameterMappingId { get; set; }
        public int CategoryId { get; set; }
        public int ParameterId { get; set; }
        public int ATPPassThreshold { get; set; }
        public int ATPFailThreshold { get; set; }
        public short PassFailType { get; set; }
        public short TestMethodId { get; set; }
        public int TestPointGroupId { get; set; }
        public List<int> SelectedLocationIds { get; set; }
        public List<int> SelectedTestTypes { get; set; }
        public Dictionary<string, string> SelectedParameterIds { get; set; }
        public string LocationName { get; set; }
        public Dictionary<string, string> SelectedTestTypePassValues { get; set; }
        public Dictionary<string, string> SelectedTestTypeFailValues { get; set; }
        public Dictionary<string, string> SelectedTestTypeMinValues { get; set; }
        public Dictionary<string, string> SelectedTestTypeMaxValues { get; set; }
        public Dictionary<string, string> SelectedTestTypePassThresholdMaxValues { get; set; }
        public Dictionary<string, string> SelectedTestTypeFailThresholdMinValues { get; set; }
        public bool ChangeTestPointThreshold { get; set; }
        public Nullable<System.DateTime> ImageLastEditedDate { get; set; }
        public List<int> InactiveLocationIds { get; set; }
        public List<int> ReplaceLocationIds { get; set; }
        public Dictionary<string, bool> IsThresholdOverridden { get; set; }
        public Dictionary<string, string> SelectedTestTypeMasterPassValues { get; set; }
        public Dictionary<string, string> SelectedTestTypeMasterFailValues { get; set; }
        public Dictionary<string, string> SelectedTestTypeMasterPassThresholdMaxValues { get; set; }
        public Dictionary<string, string> SelectedTestTypeMasterFailThresholdMinValues { get; set; }
        public Dictionary<string, string> SelectedTestTypeMasterMinRangeValues { get; set; }
        public Dictionary<string, string> SelectedTestTypeMasterMaxRangeValues { get; set; }
        public Dictionary<string, string> SelectedTestThresholdType { get; set; }
        public Dictionary<string, string> SelectedTestTypeShortName { get; set; }
        public short LocationStatus { get; set; }
        public string SamplePlanName { get; set; }
        public string HierarchicalLocationName { get; set; }
        public List<KeyValuePair<int, bool>> AssociatedToTestPlan { get; set; }
        public bool? IsDependent { get; set; }
        public bool IsAssociatedToTestPlan { get; set; }
        public string AssociatedTestTypeName { get; set; }
        public List<TestPointCustomParameterMapping> CustomParameterList { get; set; }
        public int FilteredTestPointCount { get; set; }
        public bool isInactiveTestPointAvailable { get; set; }
        public bool IsHavingImage { get; set; }
    }
}
