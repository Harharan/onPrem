﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
   public class CapaCommentsViewModel
    {
        public int OrganizationId { get; set; }

        public short CommentId { get; set; }

        public string CommentText { get; set; }

        public int CreatedBy { get; set; }

        public System.DateTime CreatedDate { get; set; }

        public Nullable<int> EditedBy { get; set; }

        public Nullable<System.DateTime> EditedDate { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public bool IsNew { get; set; }

        public int TotalPlantsCount { get; set; }

        public List<int> AssignedPlantIds { get; set; }

    }
}
