﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class DataArchivalViewModel
    {
        public int ArchivalId { get; set; }
        public int OrganizationId { get; set; }
        public System.DateTime StartDate { get; set; }
        public System.DateTime EndDate { get; set; }
        public string SamplePlan { get; set; }
        public System.DateTime ScheduleOn { get; set; }
        public Nullable<bool> ArchivalStatus { get; set; }
        public bool IsAlive { get; set; }
        public int CreatedBy { get; set; }
        public System.DateTime CreatedDate { get; set; }
        public string SamplePlanName { get; set; }
        public string UserName { get;set;}
    }
}
