﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class MissedScheduleDetailEntity
    {
        public int ScheduleId { get; set; }

        public int SamplePlanId { get; set; }

        public string SamplePlanName { get; set; }

        public DateTime ScheduleDate { get; set; }
    }
}
