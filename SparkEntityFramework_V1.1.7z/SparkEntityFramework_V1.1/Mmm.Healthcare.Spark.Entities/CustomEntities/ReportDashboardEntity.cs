﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class PdfReportCustomEntity
    {
        public List<DashBoardView> DashBoardView { get; set; }
        public List<string> LocationName { get; set; }
        public List<string> TesterName { get; set; }
        public FirstTestSummaryEntity FirstTestSummary { get; set; }
        public List<ResultOverviewEntity> ResultOverview { get; set; }
    }

    public class ReportDashBoardView
    {
        public int OrganizationId { get; set; }
        public Nullable<long> ResultId { get; set; }
        public int MeasurementId { get; set; }
        public int TestPlanId { get; set; }
        public string TestPlanName { get; set; }
        public string TestPointName { get; set; }
        public string TestPointUniqueId { get; set; }
        public short TestMethodId { get; set; }
        public string TestMethodName { get; set; }
        public Nullable<int> LocationId { get; set; }
        public string LocationName { get; set; }
        public Nullable<int> TesterId { get; set; }
        public Nullable<short> Result { get; set; }
        public Nullable<double> ResultValue { get; set; }
        public Nullable<System.DateTime> ResultDate { get; set; }
        public string CapaComments { get; set; }
        public Nullable<decimal> PassThreshold { get; set; }
        public Nullable<decimal> FailThreshold { get; set; }
        public bool Retest { get; set; }
        public Nullable<int> OriginalMeasurementId { get; set; }
        public bool Is3MSwab { get; set; }
        public string UnitName { get; set; }
        public Nullable<int> ReTestOrder { get; set; }
        public bool IsFinal{ get; set; }
        public Nullable<int> MinRange { get; set; }
        public Nullable<int> MaxRange { get; set; }
        public bool Adhoc { get; set; }
        public short? ThresholdType { get; set; }
        public string TimeZoneName { get; set; }
        public string TimeZoneShortName { get; set; }
        public string TestMethodShortName { get; set; }
    }

    public class CustomDashBoardView
    {
        public int OrganizationId { get; set; }
        public Nullable<long> ResultId { get; set; }
        public int MeasurementId { get; set; }
        public int TestPlanId { get; set; }
        public string TestPlanName { get; set; }
        public string TestPointName { get; set; }
        public string TestPointUniqueId { get; set; }
        public string TestMethodName { get; set; }
        public Nullable<int> LocationId { get; set; }
        public Nullable<int> TesterId { get; set; }
        public Nullable<short> Result { get; set; }
        public Nullable<System.DateTime> ResultDate { get; set; }
        public bool Retest { get; set; }
        public bool Is3MSwab { get; set; }

        public Nullable<int> ReTestOrder { get; set; }

        public  string HierarchicalLocationName { get; set; }

        public int TestTypeOrder { get; set; }
        public string LevelOneLocationName { get; set; }

    }

    public class FirstTestSummaryEntity
    {
        public int InitialTestsCount { get; set; }

        public int InitialPassTestsCount { get; set; }

        public int InitialCautionTestsCount { get; set; }

        public int InitialFailTestsCount { get; set; }

        public int RetestFailCount { get; set; }

        public int TotalTest { get; set; }

    }

    public class ResultOverviewEntity
    {
        public int TestOrder { get; set; }

        public int TestCount { get; set; }

        public int PassCount { get; set; }

        public int CautionCount { get; set; }

        public int FailCount { get; set; }

        public int UntestedCount { get; set; }

        public double CumulativePercentage { get; set; }

    }
}
