﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class RoleFeatureViewModel
    {
        public int FeatureId { get; set; }

        public string FeatureName { get; set; }

        public int FeatureGroupId { get; set; }

        public string FeatureGroupName { get; set; }

        public int FeatureGroupOrder { get; set; }

        public int FeatureOrder { get; set; }
    }
}
