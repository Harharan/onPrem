﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class ListSamplePlanEntity
    {
        public int OrganizationId { get; set; }

        public int TestPlanId { get; set; }

        public short TestPlanVersion { get; set; }

        public string TestPlanName { get; set; }

        public string TestPlanDescription { get; set; }

        public short TestPlanStatus { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime? NextScheduledDate { get; set; }

        public DateTime? LastSyncDate { get; set; }

        public List<ListAssignedUsersEntity> AssignedUsers { get; set; }

        public int AssignedUsersCount { get; set; }

        public List<ListTestPointEntity> TestPoints { get; set; }

        public ScheduleDefinitionMaster ScheduleForSamplePlan { get; set; }

        public List<DateTime> ScheduleDates { get; set; }

        public ScheduleDaysOfWeek ScheduleWeeklyPattern { get; set; }

        public bool IsRandomizationApplicable { get; set; }

        public bool IsScheduleApplicable { get; set; }

        public short RandomPointCount { get; set; }

        public bool IsNoRepeat { get; set; }

        public short TestPlanSchedulePattern { get; set; }

        public List<string> UserName { get; set; }

        public bool IsAssociatedToTestPoint { get; set; }

        public int AssignedTestPointsCount { get; set; }

        public List<int> UserIds { get; set; }
    }
}
