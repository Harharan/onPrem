﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class CustomParameterViewModel
    {
        public int OrganizationId { get; set; }
        public int ParameterId { get; set; }
        public string ParameterName { get; set; }
        public int ParameterVersion { get; set; }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }       
        public short UniqueId { get; set; }
        public bool IsApplicable { get; set; }
        public int? ParameterNumericValue { get; set; }
        public int CreatedBy { get; set; }
        public Nullable<short> Status { get; set; }
        public bool IsAssociatedToTestPlan { get; set; }
        public List<int> AssignedLocation { get; set; }
        public List<int> CleaningVariableLocationIdHasAssociatedTestPoint { get; set; }
    }
}
