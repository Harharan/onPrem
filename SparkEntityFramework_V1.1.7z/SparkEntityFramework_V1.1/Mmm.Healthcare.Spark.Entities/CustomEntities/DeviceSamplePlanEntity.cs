﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class DeviceSamplePlanEntity
    {
        public int TestPlanId { get; set; }

        public short TestPlanVersion { get; set; }

        public string TestPlanName { get; set; }

        public short TestPlanStatus { get; set; }

        public int TestPlanLocationId { get; set; }

        public string DatabaseId { get; set; }

        public int TotalRandomPoints { get; set; }

        public bool RandomPointNoRepeat { get; set; }

        public List<DeviceTestPointEntity> TestPoints { get; set; }

        public List<int> AssignedUsers { get; set; }
        public int AssignedPlants { get; set; }
    }
}
