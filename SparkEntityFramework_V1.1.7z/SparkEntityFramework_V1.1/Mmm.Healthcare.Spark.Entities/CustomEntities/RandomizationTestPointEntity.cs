﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class RandomizationTestPointEntity
    {
        public int OrganizationId { get; set; }

        public int TestPointId { get; set; }

        public int TestPointVersion { get; set; }

        public string TestPointName { get; set; }

        public string TestPointDescription { get; set; }

        public int TestPointLocationId { get; set; }

        public string TestPointLocationName { get; set; }

        public bool IsRandom { get; set; }
    }
}
