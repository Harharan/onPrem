﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class ListTestPointEntity
    {
        public int OrganizationId { get; set; }

        public int TestPointId { get; set; }
        
        public int TestPointVersion { get; set; }

        public int TestPointGroupId { get; set; }

        public string Description { get; set; }

        public string TestPointName { get; set; }

        public List<ListTestMethodEntity> TestMethods { get; set; }

        public int TestPointLocationId { get; set; }

        public string TestPointLocationName { get; set; }

        public short Status { get; set; }

        public int Order { get; set; }

        public bool IsRandom { get; set; }

        public short TestPointLocationStatus { get; set; }

        public string AssociatedSamplePlanName { get; set; }

        public int PlantId { get; set; }
    }

    public class TestMethodListEntity
    {
        public List<OrganizationTestMethodMaster> ApplicableTestMethods { get; set; }
        public List<CustomParameterViewModel> ApplicableCustomParameters { get; set; }
        public List<TestMethodMaster> TestMethodMaster { get; set; }
    }

    public class MappedTestPointsToSamplePlan
    {
        public int TestPointId { get; set; }
        public Int16 TestPointVersion { get; set; }
        public string TestPointName { get; set; }

        public string Description { get; set; }
        public Int16 Status { get; set; }
        public Int16 Order { get; set; }
        public int TestPointGroupId { get; set; }
        public int TestPointLocationId { get; set; }
        public bool IsRandom { get; set; }
        public Int16 TestPointLocationStatus { get; set; }
        public string SamplePlanName { get; set; }
        public string TestPointLocationName { get; set; }
        public string AssociatedTestTypeName { get; set; }
        public int PlantId { get; set; }

    }

    public class DashboardFetchArrayTwo
    {
        public List<KeyValuePair<int, string>> locationPlantList { get; set; }
        public List<KeyValuePair<int, string>> samplePlanList { get; set; }
        public List<KeyValuePair<int, string>> userList { get; set; }
    }
}
