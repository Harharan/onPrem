﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class UserListViewModel
    {
        public int UserId { get; set; }

        public string Title { get; set; }

        [Required]
        [StringLength(30)]
        [MinLength(1)]
        public string FirstName { get; set; }

        [StringLength(30)]
        [Required]
        [MinLength(1)]
        public string LastName { get; set; }

        public string Name { get; set; }
       
        [EmailAddress(ErrorMessage = "Not a valid email")]
        [MinLength(7)]
        [StringLength(30)]
        public string Email { get; set; }

        public short Status { get; set; }

        public int DefaultOrganization { get; set; }

        public string DefaultOrganizationName { get; set; }

     
        [StringLength(50)]
        [MinLength(6)]
        public string LoginName { get; set; }

        public string Password { get; set; }

        public DateTime? LastLoginDateTime { get; set; }

        [StringLength(30)]
        public string PhoneNo { get; set; }
        public Nullable<int> Pin { get; set; }

        public int? ContractOrganization { get; set; }

        public string ContractOrganizationName { get; set; }

        [StringLength(10000)]
        [MinLength(0)]
        public string Notes { get; set; }

        public short RoleId { get; set; } 

        public string RoleName { get; set; } 

        public short RoleLevel { get; set; }

        public int CreatedBy { get; set; }

        public int? LastEditedBy { get; set; }

        public DateTime? LastEditDate { get; set; }

        public IList<OrganizationRolesViewModel> UserOrganizationRoles { get; set; }

        public bool ResetPassword { get; set; }

        public int ReportingTo { get; set; }

        public bool CanEdit { get; set; }

        public string LanguagePreference { get; set; }

        public bool IsLoginRequired { get; set; }
        public bool IsEnableLuminometerPin { get; set; }

        public DateTime? LastChangePasswordDate { get; set; }
    }

    public class CreateDDlEntity
    {
        public List<KeyValuePair<short, string>> OrganizationRoles { get; set; }
        public List<KeyValuePair<int, string>> SamplePlans { get; set; }
    }
}
