﻿
namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class ResultModelEntity
    {
        public short MeasurementId { get; set; }

        public long ResultId { get; set; }
    }
}
