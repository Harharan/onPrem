﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class TestMethodViewModel
    {
        public int TestMethodId { get; set; }

        public string TestMethodName { get; set; }

        public short ThresholdType { get; set; }

        public bool IsApplicable { get; set; }

        public short TestType { get; set; }

        public int UnitId { get; set; }

        public string UnitName { get; set; }

        public int? Order { get; set; }
    }
}
