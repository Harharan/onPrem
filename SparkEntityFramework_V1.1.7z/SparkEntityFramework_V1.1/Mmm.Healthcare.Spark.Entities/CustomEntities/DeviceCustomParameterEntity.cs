﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class DeviceCustomParameterEntity
    {
        public int categoryId { get; set; }

        public short ParameterId { get; set; }
    }
}
