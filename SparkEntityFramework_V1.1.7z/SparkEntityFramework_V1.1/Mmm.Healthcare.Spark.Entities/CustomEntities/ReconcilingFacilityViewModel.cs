﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{

    public class ReconcilingFacilityViewModel
    {
        public int OrgnizationId { get; set; }

        public int LocationId { get; set; }

        public string LocationName { get; set; }

        public short CountryId { get; set; }

        public string Timezone { get; set; }

        public int StateId { get; set; }

        public int CityId { get; set; }

        public List<int> ChildLocationIds { get; set; }

        public List<OrganizationTestMethodViewModel> TestTypes { get; set; }

        public bool CriteriaChangeRequired { get; set; }
        public List<string> TestTypesToChangeCriteria { get; set; }

    }

}
