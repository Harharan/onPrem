﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class DashboardCustomEntity
    {
        public List<DashBoardView> DashBoardView { get; set; }
        public List<int> LocationHierarchy { get; set; }
    }
}
