﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class LocationViewModel
    {
        public int LocationId { get; set; }

        public string LocationName { get; set; }

        public short LocationStatus { get; set; }

        public string LocationDescription { get; set; }

        public short LocationVersion { get; set; }

        public int LocationParentId { get; set; }

        public string LocationTimeZone { get; set; }

        public string Country { get; set; }

        public string DateFormat { get; set; }

        public short? NumberFormat { get; set; }
      
        public bool? IsMilitaryTime { get; set; }
        
        public bool RequirePasswordForDevice { get; set; }

        public short MobileDataStoragePeriod { get; set; }
    }
}
