﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class ListTestMethodEntity
    {
        public int TestPointId { get; set; }

        public string TestPointName { get; set; }

        public int TestMethodId { get; set; }

        public string TestMethodName { get; set; }

        public short ThresholdType { get; set; }

        public bool IsApplicable { get; set; }

        public decimal? PassThreshold { get; set; }

        public decimal? FailThreshold { get; set; }

        public bool IsThresholdOverridden { get; set; }
    }
}
