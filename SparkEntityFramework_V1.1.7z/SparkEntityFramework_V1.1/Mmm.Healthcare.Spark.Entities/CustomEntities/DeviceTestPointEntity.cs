﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class DeviceTestPointEntity
    {
        public int TestPointId { get; set; }

        public short TestPointVersion { get; set; }

        public string TestPointName { get; set; }

        public int TestPointLocationId { get; set; }

        public string TestPointDescription { get; set; }

        public bool IsRandom { get; set; }

        public short Order { get; set; }

        public int TotalRandomPoints { get; set; }

        public bool RandomPointNoRepeat { get; set; }

        public DateTime ? ImageUpdatedTime { get; set; }

        public List<DeviceCustomParameterEntity> CustomParameters { get; set; }

        public List<TestMethodEntity> TestInfo { get; set; }

        public int ImportId { get; set; }
    }
}
