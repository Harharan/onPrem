﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class OrganizationRolesViewModel
    {
        public int OrganizationId { get; set; }
        public string OrganizationName { get; set; }
        public short RoleId { get; set; }
        public string PermissionXML { get; set; }

        [Required]
        [StringLength(30, ErrorMessage = "Max Length exceeded, should be 30 char. max")]
        public string RoleName { get; set; }
        public short RoleLevel { get; set; }
        public string RoleLevelName { get; set; } 
        public System.DateTime CreatedDate { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? LastEditDate { get; set; }
        public int? LastEditedBy { get; set; }
    }
}
