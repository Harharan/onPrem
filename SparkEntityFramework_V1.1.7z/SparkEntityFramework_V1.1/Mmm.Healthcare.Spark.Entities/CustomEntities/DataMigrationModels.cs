﻿using System.Collections.Generic;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class TestPointWithMapping
    {
        public TestPointWithMapping()
        {
            parameterMapping = new List<TestPointCustomParameterMapping>();
        }

        public TestPointTestMethodMapping methodMapping { get; set; }
        public List<TestPointCustomParameterMapping> parameterMapping { get; set; }
        public TestPlanMaster testPlan { get; set; }
        public TestPlanTestPointMapping testPlanTestPointMapping { get; set; }
        public TestPointMaster testPoint { get; set; }
    }
}