﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class TestPointTestPlanViewModel
    {
        public int OrganizationId { get; set; }
        public int TestPointId { get; set; }
        public string TestPointName { get; set; }
        public short Status { get; set; }
        public string SamplePlanName { get; set; }
        public string HierarchicalLocationName { get; set; }
        public string AssociatedTestTypeName { get; set; }
        public int LocationId { get; set; }
        public int PlantId { get; set; }
        public string PlantName { get; set; }
        public string TestPointDescription { get; set; }
    }
}
