﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class OrgConfiguration
    {
        public short MobileDataStoragePeriod { get; set; }

        public bool RequirePasswordForDevice { get; set; }

        public string TimezoneName { get; set; }

        public string DateFormat { get; set; }

        public short SyncType { get; set; }

        public string OrganizationName { get; set; }
    }
}
