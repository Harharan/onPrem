﻿
using System;
namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class ReportLocationMappingViewModel
    {
        public int LocationId { get; set; }

        public short LocationVersion { get; set; }

        public string LocationName { get; set; }

        public Nullable<int> ParentLocationId { get; set; }

        public int LocationTestPointCount { get; set; }

        public bool IsSelected { get; set; }

        public DateTime CreatedDate { get; set; }
    }
}
