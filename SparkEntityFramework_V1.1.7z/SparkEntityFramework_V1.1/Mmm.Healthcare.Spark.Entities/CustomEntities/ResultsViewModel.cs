﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class ResultsViewModel
    {
        public int LocationId { get; set; }

        public string LocationName { get; set; }

        public int TestMethodId { get; set; }
        public string TestMethodName { get; set; }

        public int TesterId { get; set; }

        public string TesterName { get; set; }

        public string ResultStatus { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public int TechnicianId { get; set; }

        public string TechnicianName { get; set; }

        public int SupervisorId { get; set; }

        public string SupervisorName { get; set; }

        public int LevelId { get; set; }

        public string LevelName { get; set; }

        public int TestPlanId { get; set; }

        public string TestPlanName { get; set; }
    }
}
