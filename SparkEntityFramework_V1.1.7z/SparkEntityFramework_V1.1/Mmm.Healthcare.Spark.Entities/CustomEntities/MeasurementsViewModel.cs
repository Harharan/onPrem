﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class MeasurementsViewModel
    {
        public int AuditorId { get; set; }
        public string AuditorName { get; set; }
    }
}
