﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
  public class NotificationViewModel
    {
        public int NotificationId { get; set; }

        public string TypeName { get; set; }

        public string Description { get; set; }

        public string StatusName { get; set; }

        public DateTime NotificationDate { get; set; }

        public DateTime ExpiryDate { get; set; }

        public short Type { get; set; }
        public short Status { get; set; }
        
    }
}
