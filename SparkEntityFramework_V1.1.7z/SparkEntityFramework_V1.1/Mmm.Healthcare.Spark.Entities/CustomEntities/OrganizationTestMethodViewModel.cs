﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class OrganizationTestMethodViewModel
    {
        public bool IsApplicable { get; set; }
        public bool? IsDeleted { get; set; }
        public int? LocationId { get; set; }
        public int? Order { get; set; }
        public int OrganizationId { get; set; }
        public OrganizationTestMethodVersions OrganizationTestMethodVersions { get; set; }
        public short TestMethodId { get; set; }
        public short TestType { get; set; }
        public string LocationName { get; set; }
        public string UnitName { get; set; }
        public Nullable<int> EditedBy { get; set; }
    }
}
