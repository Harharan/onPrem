﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class TestMethodEntity
    {
        public int TestMethodId { get; set; }

        public string TestMethodName { get; set; }

        public short ThresholdType { get; set; }

        public bool IsApplicable { get; set; }

        public decimal PassThreshold { get; set; }

        public decimal FailThreshold { get; set; }

        public int? Order { get; set; }

        public decimal FailThresholdMin { get; set; }

        public decimal PassThresholdMax { get; set; }

        public int? MinRange { get; set; }

        public int? MaxRange { get; set; }
    }
}
