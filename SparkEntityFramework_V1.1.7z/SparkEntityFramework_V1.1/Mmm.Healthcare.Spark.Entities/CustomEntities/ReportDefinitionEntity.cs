﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class ReportDefinitionEntity
    {
        public int OrganizationId { get; set; }

        public int UserId { get; set; }

        public int ReportId { get; set; }

        public string ReportName { get; set; }

        public string ReportTitle { get; set; }

        public short ReportType { get; set; }

        public short ChartType { get; set; }

        public short ChartDimension { get; set; }

        public short ReportDateSelection { get; set; }

        public Nullable<DateTime> FromDate { get; set; }

        public Nullable<DateTime> ToDate { get; set; }

        public short ReportTestPointSelection { get; set; }

        public short TestPointGroupBy { get; set; }

        public short DateGroupBy { get; set; }

        public short? DateGroupPeriod { get; set; }

        public short ResultCategory { get; set; }

        public short ScheduleType { get; set; }

        public short? ScheduleFrequency { get; set; }

        public DateTime CreatedDate { get; set; }

        public Nullable<DateTime> EditedDate { get; set; }

        public List<ReportLocationMappingViewModel> MappedLocations { get; set; }

        public List<int> SelectedLocationIds { get; set; }
    }
}