﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class UserViewModel
    {
        public int UserId { get; set; }

        public string Title { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Email { get; set; }

        public bool ResetPassword { get; set; }

        public byte[] OrganizationLogo { get; set; }

        public int DefaultOrganization { get; set; }

        public string DefaultOrganizationName { get; set; }

        public int DefaultOrganizationType { get; set; }

        public DateTime? DefaultOrganizationValidTill { get; set; }

        public int DefaultOrganizationConfigurationStep { get; set; }

        public short ApplicationId { get; set; }

        public bool IsConfigurationComplete { get; set; }

        public DateTime? LastLoginDateTime { get; set; }
              
        public List<OrganizationRolesViewModel> UserOrganizationRoles { get; set; }

        public OrganizationConfiguration OrganizationConfiguration { get; set; }

        public int ApplicationAuthenticationMode { get; set; }

        public int BaseOrganizationId { get; set; }

        public short DefaultOrganizationHierarchyLevel { get; set; }

        public string OrganizationLocale { get; set; }

        public UserPreferences Preferences { get; set; }

        public bool DisplayConfirmationMessage { get; set; }

        public bool PreferenceSet { get; set; }

        public short PExpireInDays { get; set; }

        public string PhoneNo { get; set; }

        public string ApplicationVersion { get; set; }

        public bool IsDashboardLoaded { get; set; }

        public int? ContractOrganization { get; set; }

    }
}
