﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class AuditLogDetailEntity
    {
        public DateTime Date { get; set; }

        public string EntityName { get; set; }

        public string FieldName { get; set; }

        public string OperationType { get; set; }

        public string OldValue { get; set; }

        public string NewValue { get; set; }

        public string RootField { get; set; }

        public string PrimaryField { get; set; }

        public bool Display { get; set; }
    }
}
