﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class ScheduleDefinition
    {
        public ScheduleDefinition()
        {
            DayOfWeek = new bool[7];            
        }

        public short? AllowedNoOfOccurrances { get; set; }      
        public short? DailyInterval { get; set; }
        public bool[] DayOfWeek { get; set; }
        public virtual ScheduleDaysOfWeek DaysOfWeek { get; set; }
        public DateTime? EndDate { get; set; }
        public TimeSpan ExecutionTime { get; set; }
        public bool IsEnabled { get; set; }       
        public short NumOfExecutions { get; set; }
        public int OrganizationId { get; set; }
        public short ScheduleFrequencyId { get; set; }
        public int ScheduleId { get; set; }        
        public DateTime StartDate { get; set; }
        public int OccuranceCount { get; set; }
    }
}
