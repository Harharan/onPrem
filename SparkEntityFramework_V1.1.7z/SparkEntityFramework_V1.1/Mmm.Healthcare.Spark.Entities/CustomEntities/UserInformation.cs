﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmm.Healthcare.Spark.Entities.CustomEntities
{
    public class UserInformation
    {
        public int UserId { get; set; }

        public string UserName { get; set; }

        public int UserPin { get; set; }

        public string Language { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public short Status { get; set; }

        public short UserRole { get; set; }

        public bool IsLoginRequired { get; set; }

        public List<int> AssignedLevelOneLocation { get; set; }

        public int LuminometerReset { get; set; }
        public int CommentsPermission { get; set; }
    }
}
