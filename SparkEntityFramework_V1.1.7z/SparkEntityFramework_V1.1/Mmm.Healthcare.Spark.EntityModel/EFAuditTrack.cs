﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Xml.Serialization;
using System.Reflection;
using System.IO;
using System.Data.Entity.Core.Objects;
using System.Data;
using System.Data.Entity.Core.EntityClient;
using System.Data.SqlClient;
using System.Data.Entity.Core.Metadata.Edm;
using System.Globalization;

namespace Mmm.Healthcare.Spark.Entities
{
    public static class DbContextExtensions
    {
        public static string[] GetKeyNames<TEntity>(this DbContext context)
            where TEntity : class
        {
            return context.GetKeyNames(typeof(TEntity));
        }

        public static string[] GetKeyNames(this DbContext context, Type entityType)
        {
            var metadata = ((IObjectContextAdapter)context).ObjectContext.MetadataWorkspace;

            // Get the mapping between CLR types and metadata OSpace
            var objectItemCollection = ((ObjectItemCollection)metadata.GetItemCollection(DataSpace.OSpace));

            // Get metadata for given CLR type
            var entityMetadata = metadata
                    .GetItems<EntityType>(DataSpace.OSpace)
                    .Single(e => objectItemCollection.GetClrType(e) == entityType);

            return entityMetadata.KeyProperties.Select(p => p.Name).ToArray();
        }
    }

    public partial class DataModelContainer : DbContext
    {
        public override int SaveChanges()
        {
            ChangeTrack<DataModelContainer> ct = new ChangeTrack<DataModelContainer>(this);
            ct.GetChanges();
            return base.SaveChanges();

        }
    }

    public class ChangeTrack<T> where T : DbContext
    {
        private AuditLogEntry XmlData;
        internal Dictionary<string, object> _entityKeyColumnValueDic = new Dictionary<string, object>();
        internal Dictionary<string, object> _userKeyColumnValueDic = new Dictionary<string, object>();
        internal Dictionary<string, string> _entityKeyColumnIdDic = new Dictionary<string, string>();
        internal Dictionary<string, string> _entityRootColumn = new Dictionary<string, string>();
        internal Dictionary<string, string> _entityLocationNames = new Dictionary<string, string>();
        internal Dictionary<string, string> _entityPrimaryColumn = new Dictionary<string, string>();
        internal int actionById;
        T context;
        public ChangeTrack(T ctx)
        {
            context = ctx;
        }

        public AuditLogEntry GetMasterAuditLogDictionary
        {
            get
            {
                if (XmlData == null)
                    return GenerateAuditLogModel();
                else return XmlData;
            }
        }
        private AuditLogEntry GenerateAuditLogModel()
        {
            string filename = AppDomain.CurrentDomain.BaseDirectory + "\\AuditLogConfig.xml";
            XmlSerializer deserializer = new XmlSerializer(typeof(AuditLogEntry), new XmlRootAttribute("AuditLog"));
            TextReader reader = new StreamReader(filename);
            object obj = deserializer.Deserialize(reader);
            XmlData = (AuditLogEntry)obj;
            reader.Close();
            return XmlData;
        }
        public void GetChanges()
        {
            var auditLogs = GetAuditLogData(context);
            if (auditLogs != null && auditLogs.Count() > 0)
            {
                var auditlogEntryTask = Task.Factory.StartNew((parms) =>
                {
                    var auditedData = parms as List<AuditLog>;
                    SaveAuditlogData(auditedData);
                }, auditLogs);
            }
        }

        private void SaveAuditlogData(List<AuditLog> data)
        {
            //write your save logic here;
            //Create new instance of entity context using reflection.
            T context = (T)Activator.CreateInstance(typeof(T));

            var x = (from d in data
                     join c in GetMasterAuditLogDictionary.Fields on new { Key1 = d.TableName, Key2 = d.ColumnName } equals new { Key1 = c.TableName, Key2 = c.FieldName } //into result
                     where !c.IsKey && !c.IsUserKey
                     select new
                     {
                         TableName = d.TableName,
                         ColumnName = d.ColumnName,
                         OldValue = d.OriginalValue,
                         NewValue = d.NewValue,
                         ColumnSource = c.Source,
                         ColumnType = c.Type,
                         RefPropertyName = c.RefPropertyName,
                         DisplayPropertyName = c.DisplayPropertyName,
                         retriveField = c.retriveField,
                         State = d.State,
                         ModuleName = c.ModuleName,
                         ParentEntityName = c.ParentEntity,
                         Display = c.Display,
                         IsRoot = c.IsRoot,
                         PrimaryFieldName = d.PrimaryFieldName,
                         PrimaryFieldValue = d.PrimaryFieldValue,
                         SPConditionValue = d.SPConditionValue,
                         SPName = c.SPName,
                         WhereCondition1 = c.WhereCondition1,
                         WhereCondition2 = c.WhereCondition2,
                         WhereCondition2Value = d.WhereCondition2Value,
                         joinLocation = c.joinLocation,
                     }).ToList();

            DataTable dt = new DataTable("AuditModel");
            dt.Columns.Add(new DataColumn("TableName", typeof(String)));
            dt.Columns.Add(new DataColumn("FieldName", typeof(String)));
            dt.Columns.Add(new DataColumn("OperationType", typeof(String)));
            dt.Columns.Add(new DataColumn("OldValue", typeof(String)));
            dt.Columns.Add(new DataColumn("NewValue", typeof(String)));
            dt.Columns.Add(new DataColumn("Display", typeof(bool)));
            dt.Columns.Add(new DataColumn("PrimaryField", typeof(String)));

            foreach (var item in x)
            {
                DataRow dr = dt.NewRow();
                dr["TableName"] = item.TableName;
                dr["OperationType"] = item.State;
                #region Handling referencial properties
                if (!String.IsNullOrEmpty(item.RefPropertyName))
                {

                    string className = string.Empty;
                    string retriveDataFromField = string.Empty;
                    string matchingColumnInDestTable = string.Empty;
                    string refOldValue = string.Empty;
                    string refNewValue = string.Empty;
                    className = item.ColumnType;
                    retriveDataFromField = item.retriveField;
                    matchingColumnInDestTable = item.RefPropertyName;
                    object KeyIdValue = null;
                    _entityKeyColumnValueDic.TryGetValue(item.TableName, out KeyIdValue);
                    string KeyId = string.Empty;
                    _entityKeyColumnIdDic.TryGetValue(item.TableName + "_" + item.ColumnName, out KeyId);
                    string oldQuery = string.Empty;
                    string newQuery = string.Empty;
                    string refPrimaryFieldValue = string.Empty;
                    string refPrimaryFieldName = string.Empty;

                    oldQuery = String.Format("SELECT {0} FROM {1} WHERE {1}.{2} = {3}", retriveDataFromField, className, matchingColumnInDestTable, item.OldValue);
                    newQuery = String.Format("SELECT {0} FROM {1} WHERE {1}.{2} = {3}", retriveDataFromField, className, matchingColumnInDestTable, item.NewValue);

                    if (!string.IsNullOrEmpty(item.SPConditionValue))
                    {
                        SqlParameter param1 = new SqlParameter("@OrganizationId", Convert.ToInt32(KeyIdValue));
                        SqlParameter param2 = new SqlParameter();
                        param2.ParameterName = "@MatchKey";
                        SqlParameter output = new SqlParameter();
                        output.ParameterName = "@Output";
                        output.DbType = DbType.String;
                        output.Size = 1000;
                        output.Direction = ParameterDirection.Output;

                        if (item.State.ToUpper() == "ADDED")
                        {
                            refOldValue = string.Empty;
                            if (item.SPName == "GetSamplePlan")
                            {
                                param2.DbType = DbType.String;
                                param2.Value = Convert.ToString(item.NewValue);
                            }
                            else
                            {
                                param2.DbType = DbType.Int32;
                                param2.Value = Convert.ToInt32(item.NewValue);

                            }
                            var resp = context.Database.SqlQuery<string>("exec dbo." + item.SPName + " @OrganizationId, @MatchKey, @Output", param1, param2, output).ToList();
                            refNewValue = resp.FirstOrDefault().ToString();
                        }
                        else if (item.State.ToUpper() == "MODIFIED")
                        {
                            if (item.SPName == "GetSamplePlan")
                            {
                                param2.DbType = DbType.String;
                                param2.Value = Convert.ToString(item.NewValue);
                            }
                            else
                            {
                                param2.DbType = DbType.Int32;
                                param2.Value = Convert.ToInt32(item.NewValue);

                            }
                            var resp = context.Database.SqlQuery<string>("exec dbo." + item.SPName + " @OrganizationId, @MatchKey, @Output", param1, param2, output).ToList();
                            refNewValue = resp.FirstOrDefault().ToString();

                            param1 = new SqlParameter("@OrganizationId", Convert.ToInt32(KeyIdValue));
                            param2 = new SqlParameter();
                            param2.ParameterName = "@MatchKey";
                            output = new SqlParameter();
                            output.ParameterName = "@Output";
                            output.DbType = DbType.String;
                            output.Size = 1000;
                            output.Direction = ParameterDirection.Output;

                            if (item.SPName == "GetSamplePlan")
                            {
                                param2.DbType = DbType.String;
                                param2.Value = Convert.ToString(item.OldValue);
                            }
                            else
                            {
                                param2.DbType = DbType.Int32;
                                param2.Value = Convert.ToInt32(item.OldValue);

                            }

                            resp = context.Database.SqlQuery<string>("exec dbo." + item.SPName + " @OrganizationId, @MatchKey, @Output", param1, param2, output).ToList();
                            refOldValue = resp.FirstOrDefault().ToString();
                        }
                        else if (item.State.ToUpper() == "DELETED")
                        {
                            refNewValue = string.Empty;
                            if (item.SPName == "GetSamplePlan")
                            {
                                param2.DbType = DbType.String;
                                param2.Value = Convert.ToString(item.OldValue);
                            }
                            else
                            {
                                param2.DbType = DbType.Int32;
                                param2.Value = Convert.ToInt32(item.OldValue);

                            }
                            var resp = context.Database.SqlQuery<string>("exec dbo." + item.SPName + " @OrganizationId, @MatchKey, @Output", param1, param2, output).ToList();
                            refOldValue = resp.FirstOrDefault().ToString();
                        }

                    }
                    else
                    {
                        switch (item.ColumnSource)
                        {
                            case FieldSouce.Class:
                                switch (item.State.ToUpper())
                                {
                                    case "ADDED":
                                        refOldValue = string.Empty;
                                        if (KeyId != null)
                                        {
                                            newQuery += String.Format(" and {0}.{1}={2}", className, KeyId, KeyIdValue);
                                        }
                                        if (!string.IsNullOrEmpty(item.WhereCondition1))
                                        {
                                            newQuery += String.Format(" and " + item.WhereCondition1);
                                        }
                                        if (!string.IsNullOrEmpty(item.WhereCondition2))
                                        {
                                            newQuery += String.Format(" and {0} = {1}", item.WhereCondition2, item.WhereCondition2Value);
                                        }
                                        if (item.WhereCondition2Value == "4" && className == "OrganizationCustomParameterVersions")
                                        {
                                            newQuery = newQuery.Replace("ParameterName", "Convert(NVARCHAR(MAX), ParameterNumericValue) ");
                                        }
                                        var result = context.Database.SqlQuery<string>(newQuery).ToList();
                                        if (result.Count() > 0)
                                        {
                                            refNewValue = result.FirstOrDefault().ToString();
                                        }
                                        if (!string.IsNullOrEmpty(refNewValue) && item.joinLocation)
                                        {
                                            refNewValue = refNewValue + "~" + GetMappedLocation(item.NewValue, context);
                                        }
                                        break;
                                    case "MODIFIED":
                                        if (KeyId != null)
                                        {
                                            newQuery += String.Format(" and {0}.{1}={2}", className, KeyId, KeyIdValue);
                                            oldQuery += String.Format(" and {0}.{1}={2}", className, KeyId, KeyIdValue);
                                        }
                                        if (!string.IsNullOrEmpty(item.WhereCondition1))
                                        {
                                            newQuery += String.Format(" and " + item.WhereCondition1);
                                            oldQuery += String.Format(" and " + item.WhereCondition1);
                                        }
                                        if (!string.IsNullOrEmpty(item.WhereCondition2))
                                        {
                                            newQuery += String.Format(" and {0} = {1}", item.WhereCondition2, item.WhereCondition2Value);
                                            oldQuery += String.Format(" and {0} = {1}", item.WhereCondition2, item.WhereCondition2Value);
                                        }
                                        refOldValue = context.Database.SqlQuery<string>(oldQuery).FirstOrDefault<string>();
                                        refNewValue = context.Database.SqlQuery<string>(newQuery).FirstOrDefault<string>();
                                        if (item.joinLocation)
                                        {
                                            refOldValue = refOldValue + "~" + GetMappedLocation(item.OldValue, context);
                                            refNewValue = refNewValue + "~" + GetMappedLocation(item.NewValue, context);
                                        }
                                        break;
                                    case "DELETED":
                                        if (KeyId != null)
                                        {
                                            oldQuery += String.Format(" and {0}.{1}={2}", className, KeyId, KeyIdValue);

                                        }
                                        if (!string.IsNullOrEmpty(item.WhereCondition1))
                                        {
                                            oldQuery += String.Format(" and " + item.WhereCondition1);
                                        }
                                        if (!string.IsNullOrEmpty(item.WhereCondition2))
                                        {
                                            oldQuery += String.Format(" and {0} = {1}", item.WhereCondition2, item.WhereCondition2Value);
                                        }
                                        refOldValue = context.Database.SqlQuery<string>(oldQuery).FirstOrDefault<string>();
                                        if (item.joinLocation)
                                        {
                                            refOldValue = refOldValue + "~" + GetMappedLocation(item.OldValue, context);
                                        }
                                        refNewValue = string.Empty;
                                        break;
                                    default:
                                        break;
                                }

                                //query = String.Format("SELECT {0} FROM {1} WHERE {1}.{2} = {3}", retriveDataFromField, className, matchingColumnInDestTable, item.OldValue);
                                //refOldValue = item.State.ToUpper().Equals("ADDED") ? String.Empty : context.Database.SqlQuery<string>(query).FirstOrDefault<string>();

                                //query = String.Format("SELECT {0} FROM {1} WHERE {1}.{2} = {3}", retriveDataFromField, className, matchingColumnInDestTable, item.NewValue);
                                //refNewValue = item.State.ToUpper().Equals("DELETED") ? String.Empty : context.Database.SqlQuery<string>(query).FirstOrDefault<string>();
                                break;
                            case FieldSouce.Enum:
                                className = item.ColumnType;
                                var entityItem = ((IObjectContextAdapter)context).ObjectContext.MetadataWorkspace.GetItems<EntityType>(DataSpace.OSpace).Where(xi => xi.Name.Equals(className)).FirstOrDefault().Properties.Where(p => p.Name.Equals(matchingColumnInDestTable)).FirstOrDefault();
                                if (entityItem != null)
                                {
                                    if (entityItem.GetType() != null)
                                    {
                                        var enumType = entityItem.GetType();
                                        if (enumType.IsEnum)
                                        {
                                            refOldValue = item.State.ToUpper().Equals("ADDED") ? String.Empty : Enum.Parse(enumType, item.OldValue).ToString();
                                            refNewValue = item.State.ToUpper().Equals("DELETED") ? String.Empty : Enum.Parse(enumType, item.NewValue).ToString();
                                        }
                                    }
                                }
                                break;
                            default:
                                break;
                        }
                    }
                    dr["FieldName"] = item.DisplayPropertyName;
                    dr["OldValue"] = refOldValue;
                    dr["NewValue"] = refNewValue;
                }
                #endregion
                else
                {
                    if (!string.IsNullOrEmpty(item.DisplayPropertyName))
                    {
                        dr["FieldName"] = item.DisplayPropertyName;
                    }
                    else
                    {
                        dr["FieldName"] = item.ColumnName;
                    }
                    dr["OldValue"] = item.OldValue;
                    dr["NewValue"] = item.NewValue;
                }

                dr["Display"] = item.Display;
                if (!string.IsNullOrEmpty(item.PrimaryFieldName))
                {
                    dr["PrimaryField"] = item.PrimaryFieldName + "~" + item.PrimaryFieldValue;
                }
                else
                {
                    dr["PrimaryField"] = string.Empty;
                }
                if (dr["OldValue"].ToString() != dr["NewValue"].ToString())
                {
                    dt.Rows.Add(dr);
                }

            }

            if (_entityKeyColumnValueDic.Keys.Contains("TestPlanUserMapping") && _entityKeyColumnValueDic.Keys.Contains("TestPlanMaster"))
            {
                _entityKeyColumnValueDic.Remove("TestPlanMaster");
            }
            if (_entityKeyColumnValueDic.Keys.Contains("OrganizationCustomParameterVersions") && _entityKeyColumnValueDic.Keys.Contains("OrganizationCustomParameterMaster"))
            {
                _entityKeyColumnValueDic.Remove("OrganizationCustomParameterMaster");
            }
            foreach (var item in _entityKeyColumnValueDic.Keys)
            {
                object actionById = null;
                if (!_userKeyColumnValueDic.TryGetValue(item, out actionById)) actionById = (object)0;

                if (dt.Rows.Count > 0 && actionById != null && Convert.ToString(actionById) != "0")
                {
                    if (dt.Select("TableName = 'TestPointTestMethodMapping' OR TableName = 'LocationLevelMaster' OR TableName = 'ArchivalMaster'").Count() > 0)
                    {
                        DataTable dtRsult = dt.Clone();

                        var uniqueRows = dt.AsEnumerable()
                               .GroupBy(y => new { FieldName = y.Field<string>("FieldName"), OldValue = y.Field<string>("OldValue"), NewValue = y.Field<string>("NewValue"), PrimaryField = y.Field<string>("PrimaryField") })
                               .Select(g => g.First());

                        if (uniqueRows.Count() > 0)
                        {
                            dt = uniqueRows.CopyToDataTable();
                        }

                        var distinctField = dt.AsEnumerable().Where(y => y.Field<string>("FieldName") == y.Field<string>("PrimaryField").Split('~')[0]).Select(z => z.Field<string>("FieldName")).ToArray();

                        var distinctRows = dt.DefaultView.ToTable(true, "FieldName").Rows.OfType<DataRow>().Select(k => k["FieldName"] + "").ToArray();
                        foreach (var field in distinctRows)
                        {
                            var rows = dt.Select("FieldName = '" + field + "'");
                            string newValue = "";
                            string operationType = "";
                            string primaryField = "";
                            string tableName = "";
                            string oldValue = "";
                            bool display = false;

                            foreach (DataRow row in rows)
                            {
                                tableName = row["TableName"].ToString();
                                operationType = row["OperationType"].ToString();
                                primaryField = row["PrimaryField"].ToString();
                                display = Convert.ToBoolean(row["Display"]);

                                if (distinctField.Contains(field))
                                {
                                    if (!string.IsNullOrEmpty(row["NewValue"].ToString()))
                                    {
                                        newValue += row["NewValue"] + ",";
                                    }
                                    if (!string.IsNullOrEmpty(row["OldValue"].ToString()))
                                    {
                                        oldValue += row["OldValue"] + ",";
                                    }

                                    primaryField = string.Empty;
                                }
                                else
                                {
                                    newValue = row["NewValue"].ToString();
                                    oldValue = row["OldValue"].ToString();

                                    dtRsult.Rows.Add(tableName, field, operationType, oldValue, newValue, display, primaryField);
                                }

                            }
                            newValue = newValue.Trim(',');
                            oldValue = oldValue.Trim(',');
                            if (distinctField.Contains(field))
                            {
                                dtRsult.Rows.Add(tableName, field, operationType, oldValue, newValue, display, primaryField);
                            }

                            oldValue = "";
                            newValue = "";
                            operationType = "";
                            primaryField = "";

                        }

                        dt = dtRsult;

                        dtRsult = dt.Clone();

                        var distinctRows1 = dt.DefaultView.ToTable(true, "FieldName", "PrimaryField").Rows.OfType<DataRow>().Select(k => new { fieldName = k["FieldName"] + "", primaryField = k["PrimaryField"] + "" }).ToArray();

                        foreach (var field in distinctRows1)
                        {
                            var rows = dt.Select("FieldName = '" + field.fieldName + "' and PrimaryField = '" + field.primaryField + "'");
                            string newValue = "";
                            string operationType = "";
                            string primaryField = "";
                            string tableName = "";
                            string oldValue = "";
                            bool display = false;

                            foreach (DataRow row in rows)
                            {
                                tableName = row["TableName"].ToString();
                                operationType = row["OperationType"].ToString();
                                primaryField = row["PrimaryField"].ToString();
                                display = Convert.ToBoolean(row["Display"]);

                                if (!string.IsNullOrEmpty(row["NewValue"].ToString()))
                                {
                                    newValue += row["NewValue"] + ",";
                                }
                                if (!string.IsNullOrEmpty(row["OldValue"].ToString()))
                                {
                                    oldValue += row["OldValue"] + ",";
                                }
                            }
                            newValue = newValue.Trim(',');
                            oldValue = oldValue.Trim(',');
                            if (oldValue != newValue)
                            {
                                dtRsult.Rows.Add(tableName, field.fieldName, operationType, oldValue, newValue, display, primaryField);
                            }


                            oldValue = "";
                            newValue = "";
                            operationType = "";
                            primaryField = "";

                        }

                        foreach (DataRow row in dtRsult.Rows)
                        {
                            if (!string.IsNullOrEmpty(row["OldValue"].ToString()) && !string.IsNullOrEmpty(row["NewValue"].ToString()))
                            {
                                row["OperationType"] = "Modified";
                            }
                        }
                        for (int i = dtRsult.Rows.Count - 1; i >= 0; i--)
                        {
                            DataRow dr = dtRsult.Rows[i];
                            if (dr["OldValue"].ToString() == dr["NewValue"].ToString())
                                dr.Delete();
                        }

                        dt = dtRsult;
                    }
                    if (dt.Rows.Count > 0)
                    {

                        object keyIdValue = null;
                        string rootField = null;
                        string locationNames = null;
                        if (!_entityKeyColumnValueDic.TryGetValue(item, out keyIdValue)) keyIdValue = (object)0;

                        if (!_entityRootColumn.TryGetValue(item, out rootField)) rootField = string.Empty;
                        if (!_entityLocationNames.TryGetValue(item, out locationNames)) locationNames = string.Empty;
                        if (!string.IsNullOrEmpty(rootField) && !string.IsNullOrEmpty(locationNames) && dt.Select("FieldName = 'LocationName'").Count() <= 0)
                        {
                            rootField = rootField + " ( For Locations " + locationNames + ")";
                        }
                        SqlParameter param1 = new SqlParameter("@KeyID", Convert.ToInt16(keyIdValue));
                        SqlParameter param2 = new SqlParameter("@Description", x.FirstOrDefault().ModuleName);
                        SqlParameter param3 = new SqlParameter("@ActionBy", Convert.ToString(actionById));
                        SqlParameter param4 = new SqlParameter("@AuditModel", dt);
                        SqlParameter param5 = new SqlParameter("@RootField", rootField);
                        param4.SqlDbType = SqlDbType.Structured;
                        param4.TypeName = "dbo.AuditDetails";

                        try
                        {
                            context.Database.ExecuteSqlCommand("AuditLogEntry @KeyID, @Description, @ActionBy, @RootField, @AuditModel", param1, param2, param3, param5, param4);
                            
                        }
                        catch (System.Exception ex)
                        {
                            throw;
                        }
                    }
                }
            }

        }

        private List<AuditLog> GetAuditLogData(T context)
        {
            List<AuditLog> AuditLogs = new List<AuditLog>();
            _userKeyColumnValueDic = new Dictionary<string, object>();
            var changeTrack = context.ChangeTracker.Entries().Where(p => p.State == EntityState.Added || p.State == EntityState.Deleted || p.State == EntityState.Modified);
            foreach (var entry in changeTrack)
            {
                if (entry.Entity != null)
                {
                    string entityName = ObjectContext.GetObjectType(entry.Entity.GetType()).Name;
                    if (!GetMasterAuditLogDictionary.KeyColumnDictionary.ContainsKey(entityName)) continue;
                    string state = entry.State.ToString();

                    if (!_entityKeyColumnValueDic.ContainsKey(entityName))
                    {
                        if (entry.State != EntityState.Deleted)
                            _entityKeyColumnValueDic.Add(entityName, entry.CurrentValues[GetMasterAuditLogDictionary.KeyColumnDictionary[entityName]]);
                        else
                            _entityKeyColumnValueDic.Add(entityName, entry.OriginalValues[GetMasterAuditLogDictionary.KeyColumnDictionary[entityName]]);
                    }

                    var userKeyColumn = GetMasterAuditLogDictionary.Fields.Where(f => f.TableName.Equals(entityName) && f.IsUserKey);

                    var entityKeyId = GetMasterAuditLogDictionary.Fields.Where(f => f.TableName.Equals(entityName) && f.MatchKeyColumn).ToList();
                    foreach (var field in entityKeyId)
                    {
                        if (entityKeyId.Count() > 0 && !_entityKeyColumnIdDic.ContainsKey(entityName + "_" + field.FieldName))
                        {
                            _entityKeyColumnIdDic.Add(entityName + "_" + field.FieldName, field.MatchKeyColumnId);
                        }
                    }

                    if (GetMasterAuditLogDictionary.EntityRootColumnDictionary.ContainsKey(entityName))
                    {
                        string[] entities = (GetMasterAuditLogDictionary.EntityRootColumnDictionary[entityName]).Split('^');
                        entities = entities.Select(entity => entity.Trim()).Where(entity => !string.IsNullOrEmpty(entity)).ToArray();
                        if (entities.Length <= 0)
                        {
                            entities = new string[1];
                            entities[0] = GetMasterAuditLogDictionary.EntityRootColumnDictionary[entityName];
                        }
                        foreach (string entity in entities)
                        {
                            string rootFieldId = string.Empty;
                            Field root = new Field();
                            if (entityKeyId.ToList().Where(x => x.FieldName == entity).Count() > 1)
                            {
                                root = entityKeyId.ToList().Where(x => x.FieldName == entity && x.Display).FirstOrDefault();
                            }
                            else
                            {
                                root = entityKeyId.ToList().Where(x => x.FieldName == entity).FirstOrDefault();
                            }
                            string rootFieldValue = string.Empty;

                            if (root != null && root.IsRoot)
                            {
                                if (entry.State != EntityState.Deleted)
                                {
                                    rootFieldValue = GetRootField(entityName, root.MatchKeyColumnId, root.retriveField, root.RefPropertyName, root.Type, Convert.ToString(entry.CurrentValues[entity]));
                                }
                                else
                                {
                                    rootFieldValue = GetRootField(entityName, root.MatchKeyColumnId, root.retriveField, root.RefPropertyName, root.Type, Convert.ToString(entry.OriginalValues[entity]));
                                }
                                rootFieldId = root.DisplayPropertyName;
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(entity))
                                {
                                    if (entry.State != EntityState.Deleted)
                                    {
                                        rootFieldValue = Convert.ToString(entry.CurrentValues[entity]);
                                    }
                                    else
                                    {
                                        rootFieldValue = Convert.ToString(entry.OriginalValues[entity]);
                                    }
                                }
                                if (!string.IsNullOrEmpty(entity))
                                {
                                    var displayName = GetMasterAuditLogDictionary.Fields.Where(f => f.TableName.Equals(entityName) && f.FieldName == entity && !string.IsNullOrEmpty(f.DisplayPropertyName));
                                    if (displayName.Count() > 0)
                                    {
                                        rootFieldId = displayName.FirstOrDefault().DisplayPropertyName;
                                    }
                                    else { rootFieldId = entity; }
                                }
                                else
                                {
                                    rootFieldId = entity;

                                }

                            }

                            if (!_entityRootColumn.ContainsKey(entityName) && !string.IsNullOrEmpty(rootFieldId))
                            {
                                _entityRootColumn.Add(entityName, rootFieldId + "~" + rootFieldValue);
                            }
                            else if (!_entityRootColumn.ContainsKey(entityName) && string.IsNullOrEmpty(rootFieldId))
                            {
                                _entityRootColumn.Add(entityName, string.Empty);
                            }
                            else if (_entityRootColumn.ContainsKey(entityName) && !(_entityRootColumn[entityName].Contains(rootFieldId)) && _entityRootColumn[entityName] != (rootFieldId + "~" + rootFieldValue) && !(_entityRootColumn[entityName].Contains('^')))
                            {
                                _entityRootColumn[entityName] = _entityRootColumn[entityName] + "^" + rootFieldId + "~" + rootFieldValue;
                            }

                        }
                    }

                    var entityPrimaryField = GetMasterAuditLogDictionary.Fields.Where(f => f.TableName.Equals(entityName) && !string.IsNullOrEmpty(f.PrimaryFieldName)).ToList();
                    var entityForceModify = GetMasterAuditLogDictionary.Fields.Where(f => f.TableName.Equals(entityName) && !string.IsNullOrEmpty(f.ForceModify)).ToList();
                    var entitiesToTrack = GetMasterAuditLogDictionary.Fields.Where(f => f.TableName.Equals(entityName) && f.Display).Select(name => name.FieldName).ToList();
                    var entitySP = GetMasterAuditLogDictionary.Fields.Where(f => f.TableName.Equals(entityName) && !string.IsNullOrEmpty(f.SPCondition)).ToList();
                    var entityMultiLocation = GetMasterAuditLogDictionary.Fields.Where(f => f.TableName.Equals(entityName) && !string.IsNullOrEmpty(f.MultiLocation)).ToList();

                    var entityWhereCondition2 = GetMasterAuditLogDictionary.Fields.Where(f => f.TableName.Equals(entityName) && !string.IsNullOrEmpty(f.WhereCondition2)).ToList();

                    
                    switch (entry.State)
                    {
                        case EntityState.Modified:
                            var userKeyWhenUpdate = userKeyColumn.FirstOrDefault(u => u.LogWhenUpdate);
                            if (userKeyWhenUpdate != null && !_userKeyColumnValueDic.ContainsKey(entityName))
                                _userKeyColumnValueDic.Add(entityName, entry.CurrentValues[userKeyWhenUpdate.FieldName]);

                            string primaryFieldValue = string.Empty;
                            string retriveField = string.Empty;
                            string retriveNumericValue = string.Empty;
                            string className = string.Empty;
                            string matchingColumn = string.Empty;
                            string whereCondition = string.Empty;
                            string dependantName = string.Empty;
                            string dependantValue = string.Empty;
                            string retriveColumn = string.Empty;
                            string whereCondition1 = string.Empty;
                            string whereCondition2 = string.Empty;
                            string spConditionValue = string.Empty;
                            string multiLocationValue = string.Empty;
                            string KeyId = string.Empty;

                            object KeyIdValue = null;
                            _entityKeyColumnValueDic.TryGetValue(entityName, out KeyIdValue);

                            // Test point locations
                            if (entityMultiLocation.Count() > 0)
                            {
                                if (!_entityLocationNames.ContainsKey(entityName) && entry.CurrentValues.PropertyNames.Contains(entityMultiLocation.FirstOrDefault().MultiLocation))
                                {
                                    multiLocationValue = GetMultipleLocationsOfTestPoint(Convert.ToString(entry.CurrentValues[entityMultiLocation.FirstOrDefault().MultiLocation]));
                                    _entityLocationNames.Add(entityName, multiLocationValue);
                                }
                            }
                            foreach (string prop in entry.OriginalValues.PropertyNames)
                            {
                                string currentValue = entry.CurrentValues[prop] == null ? string.Empty : Convert.ToString(entry.CurrentValues[prop]);
                                string originalValue = entry.OriginalValues[prop] == null ? string.Empty : Convert.ToString(entry.OriginalValues[prop]);

                                if (entityPrimaryField.Count() > 0 && entityPrimaryField.FirstOrDefault().PrimaryFieldName == prop)
                                {
                                    primaryFieldValue = currentValue;
                                    retriveField = entityPrimaryField.FirstOrDefault().retriveField;
                                    className = entityPrimaryField.FirstOrDefault().Type;
                                    matchingColumn = entityPrimaryField.FirstOrDefault().PrimaryFieldName;
                                    whereCondition1 = entityPrimaryField.FirstOrDefault().WhereCondition1;
                                    whereCondition2 = entityPrimaryField.FirstOrDefault().WhereCondition2;
                                    _entityKeyColumnIdDic.TryGetValue(entityName + "_" + matchingColumn, out KeyId);
                                    whereCondition = whereCondition1;
                                    if (whereCondition2 != null)
                                    {
                                        whereCondition = whereCondition + " and " + whereCondition2 + " = " + Convert.ToString(entry.CurrentValues[whereCondition2]);
                                        if (Convert.ToString(entry.CurrentValues[whereCondition2]) == "4") // Organization Category Cleaning Frequency.
                                        {
                                            retriveNumericValue = "Convert(NVARCHAR(MAX), ParameterNumericValue ) ";
                                        }
                                    }
                                }

                                if (entitySP.Count() > 0 && (entitySP.FirstOrDefault().SPCondition == prop))
                                {
                                    spConditionValue = currentValue;
                          
                                }

                                if (currentValue != null && originalValue != null && !currentValue.Equals(originalValue))
                                {
                                    AuditLogs.Add(new AuditLog
                                    {
                                        TableName = entityName,
                                        State = state,
                                        ColumnName = prop,
                                        OriginalValue = originalValue,
                                        NewValue = currentValue,
                                    });

                                    if (!string.IsNullOrEmpty(spConditionValue))
                                    {
                                        AuditLogs[AuditLogs.Count() - 1].SPConditionValue = spConditionValue;
                                    }
                                    if (entityWhereCondition2.Count() > 0 && entityWhereCondition2.FirstOrDefault().FieldName == prop)
                                    {
                                        string whrCondition = entityWhereCondition2.FirstOrDefault().WhereCondition2;
                                        if (!entry.CurrentValues.PropertyNames.Contains(whrCondition))
                                        {
                                            if (entry.CurrentValues.PropertyNames.Contains(whrCondition.Replace("Organization", "")))
                                            {
                                                AuditLogs[AuditLogs.Count() - 1].WhereCondition2Value = Convert.ToString(entry.CurrentValues[whrCondition.Replace("Organization", "")]);
                                            }
                                            else
                                            {
                                                AuditLogs[AuditLogs.Count() - 1].WhereCondition2Value = "0";
                                            }
                                        }
                                        else
                                        {
                                            AuditLogs[AuditLogs.Count() - 1].WhereCondition2Value = Convert.ToString(entry.CurrentValues[whrCondition]);
                                        }
                                    }
                                    if (!string.IsNullOrEmpty(primaryFieldValue))
                                    {
                                        if (!string.IsNullOrEmpty(retriveField))
                                        {
                                            var primaryFieldQuery = string.Empty;
                                            if (!string.IsNullOrEmpty(retriveNumericValue))
                                            {
                                                primaryFieldQuery = String.Format("SELECT {0} FROM {1} WHERE {1}.{2} = {3}", retriveNumericValue, className, matchingColumn, primaryFieldValue);
                                            }
                                            else
                                            {
                                                primaryFieldQuery = String.Format("SELECT {0} FROM {1} WHERE {1}.{2} = {3}", retriveField, className, matchingColumn, primaryFieldValue);
                                            }
                                            if (KeyId != null)
                                            {
                                                primaryFieldQuery += String.Format(" and {0}.{1}={2}", className, KeyId, KeyIdValue);
                                            }
                                            if (!string.IsNullOrEmpty(whereCondition))
                                            {
                                                primaryFieldQuery += String.Format(" and {0}.{1}", className, whereCondition);
                                            }
                                            AuditLogs[AuditLogs.Count() - 1].PrimaryFieldValue = context.Database.SqlQuery<string>(primaryFieldQuery).FirstOrDefault<string>();
                                            AuditLogs[AuditLogs.Count() - 1].PrimaryFieldName = retriveField;
                                        }
                                        else
                                        {
                                            AuditLogs[AuditLogs.Count() - 1].PrimaryFieldValue = primaryFieldValue;
                                            AuditLogs[AuditLogs.Count() - 1].PrimaryFieldName = matchingColumn;
                                        }

                                    }
                                }
                            }

                            break;
                        case EntityState.Added:
                            var userKeyWhenAdd = userKeyColumn.FirstOrDefault(u => u.LogWhenAdd);
                            if (userKeyWhenAdd != null && !_userKeyColumnValueDic.ContainsKey(entityName))
                                _userKeyColumnValueDic.Add(entityName, entry.CurrentValues[userKeyWhenAdd.FieldName]);

                            dependantName = string.Empty;
                            dependantValue = string.Empty;
                            primaryFieldValue = string.Empty;
                            retriveField = string.Empty;

                            KeyId = string.Empty;
                            whereCondition = string.Empty;
                            whereCondition1 = string.Empty;
                            whereCondition2 = string.Empty;
                            spConditionValue = string.Empty;
                            className = string.Empty;
                            matchingColumn = string.Empty;
                            multiLocationValue = string.Empty;

                            string whereConditionColumnValue1 = string.Empty;
                            string whereConditionColumnValue2 = string.Empty;

                            _entityKeyColumnValueDic.TryGetValue(entityName, out KeyIdValue);

                            if (entityForceModify.Count() > 0)
                            {
                                dependantName = entityForceModify.FirstOrDefault().ForceModify;
                                whereCondition1 = entityForceModify.FirstOrDefault().OldWhereCondition1;
                                whereCondition2 = entityForceModify.FirstOrDefault().OldWhereCondition2;
                                dependantValue = Convert.ToString((Convert.ToInt16(entry.CurrentValues[entityForceModify.FirstOrDefault().ForceModify])) - 1);
                                KeyId = entityForceModify.FirstOrDefault().MatchKeyColumnId;
                                whereConditionColumnValue1 = Convert.ToString(entry.CurrentValues[whereCondition1]);
                                whereCondition1 = whereCondition1 + "=" + whereConditionColumnValue1;
                                whereCondition = whereCondition1;
                                if (!string.IsNullOrEmpty(whereCondition) && !string.IsNullOrEmpty(whereCondition2))
                                {
                                    whereConditionColumnValue2 = Convert.ToString(entry.CurrentValues[whereCondition2]);
                                    whereCondition2 = whereCondition2 + "=" + whereConditionColumnValue2;
                                    whereCondition = whereCondition + " and " + whereCondition2;
                                }
                            }

                            // Test point locations
                            if (entityMultiLocation.Count() > 0)
                            {
                                if (!_entityLocationNames.ContainsKey(entityName) && entry.CurrentValues.PropertyNames.Contains(entityMultiLocation.FirstOrDefault().MultiLocation))
                                {
                                    multiLocationValue = GetMultipleLocationsOfTestPoint(Convert.ToString(entry.CurrentValues[entityMultiLocation.FirstOrDefault().MultiLocation]));
                                    _entityLocationNames.Add(entityName, multiLocationValue);
                                }
                            }


                            foreach (string prop in entry.CurrentValues.PropertyNames)
                            {
                                string oldValue = string.Empty;
                                if (!string.IsNullOrEmpty(dependantName) && entitiesToTrack.Count() > 0 && entitiesToTrack.Exists(x => x == prop))
                                {

                                    oldValue = GetOriginalValue(prop, entityName, dependantName, dependantValue, whereCondition, KeyId, Convert.ToString(KeyIdValue));
                                    state = "Modified";
                                }

                                string currentValue = "";
                                if (entry.CurrentValues[prop] == null)
                                {
                                    currentValue = string.Empty;
                                }
                                else
                                {
                                    if (prop == "ATPPassThreshold" || prop == "ATPFailThreshold" || prop == "PassThreshold" || prop == "FailThreshold")
                                    {
                                        string NumberFormat = GetCurrentNumberFormat(entityName,"NumberFormat");
                                        if (string.IsNullOrEmpty(NumberFormat))
                                        {
                                            if (entry.CurrentValues.PropertyNames.Contains("NumberFormat"))
                                            {
                                                NumberFormat = entry.CurrentValues["NumberFormat"].ToString();
                                            }
                                            else
                                            {
                                                NumberFormat = "1";
                                            }
                                        }
                                        if (Convert.ToDecimal(entry.CurrentValues[prop]) == 0)
                                        {
                                            currentValue = Convert.ToDecimal(entry.CurrentValues[prop], CultureInfo.InvariantCulture).ToString("0.00", CultureInfo.InvariantCulture);
                                        }
                                        else
                                        {
                                            currentValue = Convert.ToDecimal(entry.CurrentValues[prop], CultureInfo.InvariantCulture).ToString("#.00", CultureInfo.InvariantCulture);
                                        }

                                        if (NumberFormat == "1")
                                        { 
                                            currentValue = currentValue.Replace(",", "."); 
                                        }
                                        else
                                        {
                                            currentValue = currentValue.Replace(".", ",");
                                        }
                                    }
                                    else if (prop == "StartDate" || prop == "EndDate" || prop == "ScheduleOn")
                                    {
                                        string DateFormat = GetCurrentNumberFormat(entityName, "DateFormat");
                                        currentValue = Convert.ToDateTime(entry.CurrentValues[prop], CultureInfo.InvariantCulture).ToString();

                                    }
                                    else
                                    {
                                        currentValue = Convert.ToString(entry.CurrentValues[prop]);
                                    }
                                }
                                if (entityPrimaryField.Count() > 0 && entityPrimaryField.FirstOrDefault().PrimaryFieldName == prop)
                                {
                                    className = entityPrimaryField.FirstOrDefault().Type;

                                    if (entityName == className)
                                    {
                                        primaryFieldValue = currentValue;
                                        retriveField = entityPrimaryField.FirstOrDefault().retriveField;
                                    }
                                    else
                                    {
                                        primaryFieldValue = currentValue;
                                        retriveField = entityPrimaryField.FirstOrDefault().retriveField;
                                        matchingColumn = entityPrimaryField.FirstOrDefault().PrimaryFieldName;
                                        whereCondition1 = entityPrimaryField.FirstOrDefault().WhereCondition1;
                                        whereCondition2 = entityPrimaryField.FirstOrDefault().WhereCondition2;
                                        _entityKeyColumnIdDic.TryGetValue(entityName + "_" + matchingColumn, out KeyId);
                                        whereCondition = whereCondition1;
                                        if (whereCondition2 != null)
                                        {
                                            whereCondition = whereCondition + " and " + whereCondition2 + " = " + Convert.ToString(entry.CurrentValues[whereCondition2]);
                                        }
                                    }

                                }
                                if (entitySP.Count() > 0 && (entitySP.FirstOrDefault().SPCondition == prop))
                                {
                                    spConditionValue = currentValue;
                                }

                                if ((state == "Modified" && !currentValue.Equals(oldValue)) || (state == "Added"))
                                {
                                    AuditLogs.Add(new AuditLog
                                    {
                                        TableName = entityName,
                                        State = state,
                                        ColumnName = prop,
                                        OriginalValue = oldValue,
                                        NewValue = currentValue,
                                    });

                                    if (entityWhereCondition2.Count() > 0 && entityWhereCondition2.FirstOrDefault().FieldName == prop)
                                    {
                                        string whrCondition = entityWhereCondition2.FirstOrDefault().WhereCondition2;

                                        if (!entry.CurrentValues.PropertyNames.Contains(whrCondition))
                                        {
                                            if (entry.CurrentValues.PropertyNames.Contains(whrCondition.Replace("Organization", "")))
                                            {
                                                AuditLogs[AuditLogs.Count() - 1].WhereCondition2Value = Convert.ToString(entry.CurrentValues[whrCondition.Replace("Organization", "")]);
                                            }
                                            else
                                            {
                                                AuditLogs[AuditLogs.Count() - 1].WhereCondition2Value = "0";
                                            }
                                        }
                                        else
                                        {
                                            AuditLogs[AuditLogs.Count() - 1].WhereCondition2Value = Convert.ToString(entry.CurrentValues[whrCondition]);
                                        }

                                    }

                                    if (!string.IsNullOrEmpty(spConditionValue))
                                    {
                                        AuditLogs[AuditLogs.Count() - 1].SPConditionValue = spConditionValue;
                                    }
                                    if (!string.IsNullOrEmpty(primaryFieldValue))
                                    {
                                        if (!string.IsNullOrEmpty(retriveField))
                                        {
                                            var primaryFieldQuery = String.Format("SELECT {0} FROM {1} WHERE {1}.{2} = {3}", retriveField, className, matchingColumn, primaryFieldValue);
                                            if (KeyId != null)
                                            {
                                                primaryFieldQuery += String.Format(" and {0}.{1}={2}", className, KeyId, KeyIdValue);
                                            }
                                            if (!string.IsNullOrEmpty(whereCondition))
                                            {
                                                primaryFieldQuery += String.Format(" and {0}.{1}", className, whereCondition);
                                            }
                                            AuditLogs[AuditLogs.Count() - 1].PrimaryFieldValue = context.Database.SqlQuery<string>(primaryFieldQuery).FirstOrDefault<string>();
                                            AuditLogs[AuditLogs.Count() - 1].PrimaryFieldName = retriveField;
                                        }
                                        else
                                        {
                                            AuditLogs[AuditLogs.Count() - 1].PrimaryFieldValue = primaryFieldValue;
                                            AuditLogs[AuditLogs.Count() - 1].PrimaryFieldName = entityPrimaryField.FirstOrDefault().PrimaryFieldName;
                                        }
                                    }
                                }

                            }
                            break;
                        case EntityState.Deleted:
                            var userKeyWhenDelete = userKeyColumn.FirstOrDefault(u => u.LogWhenUpdate);
                            if (userKeyWhenDelete != null && !_userKeyColumnValueDic.ContainsKey(entityName))
                                _userKeyColumnValueDic.Add(entityName, entry.OriginalValues[userKeyWhenDelete.FieldName]);

                            primaryFieldValue = string.Empty;
                            KeyId = string.Empty;
                            whereCondition = string.Empty;
                            KeyIdValue = null;
                            className = string.Empty;
                            matchingColumn = string.Empty;
                            retriveField = string.Empty;
                            _entityKeyColumnValueDic.TryGetValue(entityName, out KeyIdValue);

                            foreach (string prop in entry.OriginalValues.PropertyNames)
                            {
                                if (entityPrimaryField.Count() > 0 && entityPrimaryField.FirstOrDefault().PrimaryFieldName == prop)
                                {
                                    className = entityPrimaryField.FirstOrDefault().Type;

                                    if (entityName == className)
                                    {
                                        primaryFieldValue = Convert.ToString(entry.OriginalValues[prop]);
                                        retriveField = entityPrimaryField.FirstOrDefault().retriveField;
                                    }
                                    else
                                    {
                                        primaryFieldValue = Convert.ToString(entry.OriginalValues[prop]);
                                        retriveField = entityPrimaryField.FirstOrDefault().retriveField;
                                        matchingColumn = entityPrimaryField.FirstOrDefault().PrimaryFieldName;
                                        whereCondition1 = entityPrimaryField.FirstOrDefault().WhereCondition1;
                                        whereCondition2 = entityPrimaryField.FirstOrDefault().WhereCondition2;
                                        _entityKeyColumnIdDic.TryGetValue(entityName + "_" + matchingColumn, out KeyId);
                                        whereCondition = whereCondition1;
                                        if (whereCondition2 != null)
                                        {
                                            whereCondition = whereCondition + " and " + whereCondition2 + " = " + Convert.ToString(entry.OriginalValues[whereCondition2]);
                                        }
                                    }
                                }

                                AuditLogs.Add(new AuditLog
                                {
                                    TableName = entityName,
                                    State = state,
                                    ColumnName = prop,
                                    OriginalValue = Convert.ToString(entry.OriginalValues[prop]),
                                    NewValue = string.Empty,
                                });

                                if (entityWhereCondition2.Count() > 0 && entityWhereCondition2.FirstOrDefault().FieldName == prop)
                                {
                                    string whrCondition = entityWhereCondition2.FirstOrDefault().WhereCondition2;
                                    if (!entry.OriginalValues.PropertyNames.Contains(whrCondition))
                                    {
                                        if (entry.OriginalValues.PropertyNames.Contains(whrCondition.Replace("Organization", "")))
                                        {
                                            AuditLogs[AuditLogs.Count() - 1].WhereCondition2Value = Convert.ToString(entry.OriginalValues[whrCondition.Replace("Organization", "")]);
                                        }
                                        else
                                        {
                                            AuditLogs[AuditLogs.Count() - 1].WhereCondition2Value = "0";
                                        }
                                    }
                                    else
                                    {
                                        AuditLogs[AuditLogs.Count() - 1].WhereCondition2Value = Convert.ToString(entry.OriginalValues[whrCondition]);
                                    }
                                }

                                if (!string.IsNullOrEmpty(primaryFieldValue))
                                {
                                    if (!string.IsNullOrEmpty(retriveField))
                                    {
                                        var primaryFieldQuery = String.Format("SELECT {0} FROM {1} WHERE {1}.{2} = {3}", retriveField, className, matchingColumn, primaryFieldValue);
                                        if (KeyId != null)
                                        {
                                            primaryFieldQuery += String.Format(" and {0}.{1}={2}", className, KeyId, KeyIdValue);
                                        }
                                        if (!string.IsNullOrEmpty(whereCondition))
                                        {
                                            primaryFieldQuery += String.Format(" and {0}.{1}", className, whereCondition);
                                        }
                                        AuditLogs[AuditLogs.Count() - 1].PrimaryFieldValue = context.Database.SqlQuery<string>(primaryFieldQuery).FirstOrDefault<string>();
                                        AuditLogs[AuditLogs.Count() - 1].PrimaryFieldName = retriveField;
                                    }
                                    else
                                    {
                                        AuditLogs[AuditLogs.Count() - 1].PrimaryFieldValue = primaryFieldValue;
                                        AuditLogs[AuditLogs.Count() - 1].PrimaryFieldName = entityPrimaryField.FirstOrDefault().PrimaryFieldName;
                                    }
                                }

                            }
                            break;
                        default:
                            break;
                    }
                }
            }

            return AuditLogs;
        }
        public static Type GetClassType(string className)
        {
            foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                var type = assembly.GetType(className);
                if (type == null)
                    continue;
                if (type.IsClass)
                    return type;
            }
            return null;
        }

        string GetMappedLocation(string matchingField, T context)
        {
            object KeyIdValue = null;
            _entityKeyColumnValueDic.TryGetValue("TestPlanTestPointMapping", out KeyIdValue);

            var query = "select Convert(NVarchar(max),LocationId) FROM TestPointMaster WHERE TestPointId = " + matchingField + " and OrganizationId = " + KeyIdValue;
            var locations = context.Database.SqlQuery<string>(query).ToList();
            string LocationId = locations.FirstOrDefault().ToString();

            SqlParameter param1 = new SqlParameter("@OrganizationId", Convert.ToInt32(KeyIdValue));
            SqlParameter output = new SqlParameter();
            output.ParameterName = "@Output";
            output.DbType = DbType.String;
            output.Size = 1000;
            output.Direction = ParameterDirection.Output;

            SqlParameter param2 = new SqlParameter();
            param2.ParameterName = "@MatchKey";
            param2.Value = LocationId;
            var resp = context.Database.SqlQuery<string>("exec dbo.GetLocationName @OrganizationId, @MatchKey, @Output", param1, param2, output).ToList();
            return resp.FirstOrDefault().ToString();

        }

        string GetOriginalValue(string retriveColumn, string className, string dependantName, string dependantValue, string whereCondition, string KeyId, string KeyIdValue)
        {
            var versionQuery = String.Format("SELECT CONVERT(nvarchar(max), {0} ) as {0} FROM {1} WHERE {1}.{2} = {3}", retriveColumn, className, dependantName, dependantValue);
            if (KeyId != null)
            {
                versionQuery += String.Format(" and {0}.{1}={2}", className, KeyId, KeyIdValue);
            }
            if (!string.IsNullOrEmpty(whereCondition))
            {
                versionQuery += String.Format(" and {0}.{1}", className, whereCondition);
            }
            var result = context.Database.SqlQuery<string>(versionQuery).ToList();
            return result.FirstOrDefault();

        }
        string GetMultipleLocationsOfTestPoint(string grpId)
        {
            object KeyIdValue = null;
            _entityKeyColumnValueDic.TryGetValue("TestPointMaster", out KeyIdValue);

            var query = "Select CONVERT(nvarchar(max), LocationId) as LocationId from TestPointMaster where IsCurrent=1 and OrganizationId = " + KeyIdValue.ToString() + " and TestPointGroupId = " + grpId;
            var result = context.Database.SqlQuery<string>(query).ToList();


            string LocationNames = "";

            foreach (var location in result.ToList())
            {
                SqlParameter param1 = new SqlParameter("@OrganizationId", Convert.ToInt32(KeyIdValue));
                SqlParameter output = new SqlParameter();
                output.ParameterName = "@Output";
                output.DbType = DbType.String;
                output.Size = 1000;
                output.Direction = ParameterDirection.Output;

                SqlParameter param2 = new SqlParameter();
                param2.ParameterName = "@MatchKey";
                param2.Value = location;
                var resp = context.Database.SqlQuery<string>("exec dbo.GetLocationName @OrganizationId, @MatchKey, @Output", param1, param2, output).ToList();
                if (!string.IsNullOrEmpty(LocationNames))
                {
                    LocationNames = LocationNames + ", " + resp.FirstOrDefault().ToString();
                }
                else
                {
                    LocationNames = resp.FirstOrDefault().ToString();

                }
            }
            return LocationNames;
        }

        string GetRootField(string TableName, string keyColumn, string retriveField, string matchingColumn, string className, string fieldValue)
        {
            object KeyIdValue = null;
            _entityKeyColumnValueDic.TryGetValue(TableName, out KeyIdValue);
            string KeyId = string.Empty;
            _entityKeyColumnIdDic.TryGetValue(TableName + "_" + matchingColumn, out KeyId);

            string query = String.Format("SELECT {0} FROM {1} WHERE {1}.{2} = {3}", retriveField, className, matchingColumn, fieldValue);

            if (KeyId != null)
            {
                query += String.Format(" and {0}.{1}={2}", className, KeyId, KeyIdValue);
            }
            string rootFieldValue = context.Database.SqlQuery<string>(query).FirstOrDefault<string>();

            return rootFieldValue;
        }

        string GetCurrentNumberFormat(string TableName,string retriveValue)
        {
            object KeyIdValue = null;
            _entityKeyColumnValueDic.TryGetValue(TableName, out KeyIdValue);
            string query="";
            if (retriveValue == "NumberFormat")
            {
                query = String.Format("select Convert(NVARCHAR(MAX), NumberFormat ) from organizationconfiguration where OrganizationId = {0}", KeyIdValue);
            }
            else if (retriveValue == "DateFormat")
            {
                query = String.Format("select Convert(NVARCHAR(MAX), DateFormat ) from organizationconfiguration where OrganizationId = {0}", KeyIdValue);
            }

            string currentNumberFormat = context.Database.SqlQuery<string>(query).FirstOrDefault<string>();

            return currentNumberFormat;
        }

    }

    public class AuditLog
    {
        public string State { get; set; }
        public string TableName { get; set; }
        public string RecordID { get; set; }
        public string ColumnName { get; set; }
        public string NewValue { get; set; }
        public string OriginalValue { get; set; }
        public string PrimaryFieldName { get; set; }
        public string PrimaryFieldValue { get; set; }
        public string SPConditionValue { get; set; }
        public string WhereCondition2Value { get; set; }
    }

    public class Parent
    {
        public string Name { get; set; }

        public string RefPropertyName { get; set; }

        public bool IsPartOfEntityKey { get; set; }
        public string EntityKeyName { get; set; }

        public string ValueKey { get; set; }
    }

    public enum FieldSouce
    {
        Class,
        Enum
    }

    public class Field
    {
        public string FieldName { get; set; }
        public string TableName { get; set; }
        public FieldSouce Source { get; set; }
        public string Type { get; set; }
        public string RefPropertyName { get; set; }
        public string DisplayPropertyName { get; set; }
        public string SQLQuery { get; set; }
        public string ModuleName { get; set; }
        public List<Parent> Parents { get; set; }

        public bool IsKey { get; set; }

        public bool IsUserKey { get; set; }

        public bool LogWhenUpdate { get; set; }

        public bool LogWhenAdd { get; set; }

        public string ParentEntity { get; set; }

        public bool MatchKeyColumn { get; set; }

        public string MatchKeyColumnId { get; set; }

        public bool Display { get; set; }

        public bool IsRoot { get; set; }
        public string retriveField { get; set; }

        public string PrimaryFieldName { get; set; }
        public string WhereCondition1 { get; set; }
        public string WhereCondition2 { get; set; }
        public string WhereCondition2Value { get; set; }
        public string ForceModify { get; set; }
        public string OldWhereCondition1 { get; set; }
        public string OldWhereCondition2 { get; set; }
        public string SPCondition { get; set; }
        public string SPName { get; set; }
        public string MultiLocation { get; set; }
        public bool joinLocation { get; set; }

    }

    public class AuditLogEntry : IXmlSerializable
    {
        const string TABLE = "TABLE";
        const string FIELD = "FIELD";
        const string PARENT = "PARENT";
        Dictionary<string, Type> propertyTypeDic;
        Dictionary<string, PropertyInfo> propertyInfoDic;
        Dictionary<string, string> keyColumnDic;
        Dictionary<string, string> entityRootColumnDic = new Dictionary<string, string>();
        List<Field> _fields;
        public AuditLogEntry()
        {
            propertyTypeDic = new Dictionary<string, Type>();
            propertyInfoDic = new Dictionary<string, PropertyInfo>();
            _fields = new List<Field>();
            keyColumnDic = new Dictionary<string, string>();
            entityRootColumnDic = new Dictionary<string, string>();
        }

        public Dictionary<string, string> KeyColumnDictionary { get { return keyColumnDic; } private set { } }

        public Dictionary<string, string> EntityRootColumnDictionary { get { return entityRootColumnDic; } private set { } }        public List<Field> Fields { get { return _fields; } private set { } }

        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {

            GeneratePropertyDictionary();

            //Check the root's tag is empty or not. <Product/> mean empty.            
            bool isEmpty = reader.IsEmptyElement;
            //Go into the root content.
            reader.Read();
            if (isEmpty)
                return;
            //Counter.In order to count the start tag.
            int _tagCount = 0;
            try
            {
                GenerateAuditLogModel(reader);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        string tableName;
        string moduleName;
        string parentEntityName;
        string ForceModifyBy;
        string MatchKeyColumnId;
        bool MatchKeyColumn;
        string oldWhereCondition1;
        string oldWhereCondition2;

        private void GenerateAuditLogModel(System.Xml.XmlReader reader)
        {
            while (!reader.EOF)
            {
                if (reader.IsStartElement() && reader.NodeType == System.Xml.XmlNodeType.Element)
                {
                    string nodeName = reader.Name;
                    switch (nodeName.ToUpper(System.Globalization.CultureInfo.InvariantCulture))
                    {
                        case TABLE:
                            tableName = reader.GetAttribute("Name");
                            moduleName = reader.GetAttribute("Module");
                            ForceModifyBy = reader.GetAttribute("ForceModifyBy");
                            oldWhereCondition1 = reader.GetAttribute("OldWhereCondition1");
                            oldWhereCondition2 = reader.GetAttribute("OldWhereCondition2");
                            MatchKeyColumn = !String.IsNullOrEmpty(reader.GetAttribute("MatchKeyColumn"));
                            MatchKeyColumnId = reader.GetAttribute("MatchKeyColumn");
                            parentEntityName = reader.GetAttribute("ParentEntity");
                            if (!keyColumnDic.ContainsKey(tableName))
                                keyColumnDic.Add(tableName, string.Empty);
                            if (!entityRootColumnDic.ContainsKey(tableName))
                                entityRootColumnDic.Add(tableName, string.Empty);
                            break;
                        case FIELD:
                            Field f = new Field()
                            {
                                DisplayPropertyName = reader.GetAttribute("DisplayPropertyName"),
                                FieldName = reader.GetAttribute("Name"),
                                RefPropertyName = reader.GetAttribute("RefPropertyName"),
                                Source = GetFieldSourceEnum(reader.GetAttribute("Source")),
                                SQLQuery = reader.GetAttribute("SQLQuery"),
                                TableName = tableName,
                                Type = reader.GetAttribute("Type"),
                                ModuleName = moduleName,
                                IsKey = !String.IsNullOrEmpty(reader.GetAttribute("IsKey")),
                                IsUserKey = !String.IsNullOrEmpty(reader.GetAttribute("IsUserKey")),
                                LogWhenAdd = !String.IsNullOrEmpty(reader.GetAttribute("LogWhenAdd")),
                                LogWhenUpdate = !String.IsNullOrEmpty(reader.GetAttribute("LogWhenUpdate")),
                                ParentEntity = parentEntityName,
                                MatchKeyColumn = String.IsNullOrEmpty(reader.GetAttribute("MatchKeyColumn")) ? MatchKeyColumn : !String.IsNullOrEmpty(reader.GetAttribute("MatchKeyColumn")),
                                MatchKeyColumnId = String.IsNullOrEmpty(reader.GetAttribute("MatchKeyColumn")) ? MatchKeyColumnId : reader.GetAttribute("MatchKeyColumn"),
                                IsRoot = !String.IsNullOrEmpty(reader.GetAttribute("IsRoot")),
                                Display = String.IsNullOrEmpty(reader.GetAttribute("Display")),
                                retriveField = reader.GetAttribute("retriveField"),
                                PrimaryFieldName = reader.GetAttribute("PrimaryField"),
                                WhereCondition1 = reader.GetAttribute("WhereCondition1"),
                                WhereCondition2 = reader.GetAttribute("WhereCondition2"),
                                ForceModify = ForceModifyBy,
                                OldWhereCondition1 = oldWhereCondition1,
                                OldWhereCondition2 = oldWhereCondition2,
                                SPCondition = reader.GetAttribute("SPCondition"),
                                SPName = reader.GetAttribute("SPName"),
                                MultiLocation = reader.GetAttribute("MultiLocation"),
                                joinLocation = !String.IsNullOrEmpty(reader.GetAttribute("joinLocation")),
                            };
                            if (f.IsKey && keyColumnDic.ContainsKey(tableName))
                                keyColumnDic[tableName] = f.FieldName;
                            if (f.IsRoot && entityRootColumnDic.ContainsKey(tableName))
                            {
                                if (!string.IsNullOrEmpty(entityRootColumnDic[tableName]))
                                {
                                    entityRootColumnDic[tableName] = entityRootColumnDic[tableName] + "^" + f.FieldName;
                                }
                                else
                                {
                                    entityRootColumnDic[tableName] = f.FieldName;
                                }
                            }
                            _fields.Add(f);
                            break;
                        case PARENT:
                            Field lastf = _fields.LastOrDefault();
                            if (lastf != null)
                            {
                                Parent p = new Parent()
                                {
                                    EntityKeyName = reader.GetAttribute("EntityKeyName"),
                                    IsPartOfEntityKey = Convert.ToBoolean(reader.GetAttribute("IsPartOfEntityKey").ToLower()),
                                    Name = reader.GetAttribute("Name"),
                                    RefPropertyName = reader.GetAttribute("RefPropertyName"),
                                    ValueKey = reader.GetAttribute("ValueKey")
                                };
                                lastf.Parents.Add(p);
                            }
                            break;
                        default:
                            //For attributes
                            break;
                    }
                }
                reader.Read();
            }
        }

        private FieldSouce GetFieldSourceEnum(string p)
        {
            if (String.IsNullOrEmpty(p))
                return FieldSouce.Class;
            return (FieldSouce)Enum.Parse(typeof(FieldSouce), p);
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            throw new NotImplementedException();
        }

        void GeneratePropertyDictionary()
        {
            PropertyInfo[] propertyArray = this.GetType().GetProperties(BindingFlags.Public | BindingFlags.IgnoreCase | BindingFlags.Instance | BindingFlags.SetProperty);
            if (propertyArray != null)
            {
                foreach (PropertyInfo property in propertyArray)
                {
                    propertyTypeDic[property.Name] = property.PropertyType;
                    propertyInfoDic[property.Name] = property;
                }
            }
        }
    }
}
