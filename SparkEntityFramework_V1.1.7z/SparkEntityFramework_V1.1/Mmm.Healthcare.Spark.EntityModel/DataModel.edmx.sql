
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 06/16/2016 11:49:02
-- Generated from EDMX file: D:\Spark_SourceCode\SparkEntityFramework_V1.1\Mmm.Healthcare.Spark.EntityModel\DataModel.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [Spark];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_OrganizationMasterOrganizationRoleMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[OrganizationRoleMaster] DROP CONSTRAINT [FK_OrganizationMasterOrganizationRoleMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_TestPlanTestPlanType]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TestPlanMaster] DROP CONSTRAINT [FK_TestPlanTestPlanType];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganizationID]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TestPointMaster] DROP CONSTRAINT [FK_OrganizationID];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganizationMasterTestPlanMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TestPlanMaster] DROP CONSTRAINT [FK_OrganizationMasterTestPlanMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganizationMasterAreaMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[LocationMaster] DROP CONSTRAINT [FK_OrganizationMasterAreaMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganizationRoleUserMapping_OrganizationRoleMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[OrganizationRoleUserMapping] DROP CONSTRAINT [FK_OrganizationRoleUserMapping_OrganizationRoleMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganizationRoleUserMapping_UserMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[OrganizationRoleUserMapping] DROP CONSTRAINT [FK_OrganizationRoleUserMapping_UserMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganizationConfigurationId]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[OrganizationConfiguration] DROP CONSTRAINT [FK_OrganizationConfigurationId];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganizationImage]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[OrganizationImageMaster] DROP CONSTRAINT [FK_OrganizationImage];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganizationMasterOrganizationComments]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[OrganizationComments] DROP CONSTRAINT [FK_OrganizationMasterOrganizationComments];
GO
IF OBJECT_ID(N'[dbo].[FK_UserMasterUserPreferences]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserPreferences] DROP CONSTRAINT [FK_UserMasterUserPreferences];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganizationMasterDeviceSyncDetails]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DeviceSyncDetails] DROP CONSTRAINT [FK_OrganizationMasterDeviceSyncDetails];
GO
IF OBJECT_ID(N'[dbo].[FK_ApplicationMasterFeatureMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FeatureMaster] DROP CONSTRAINT [FK_ApplicationMasterFeatureMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_ApplicationMasterTestMethodMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TestMethodMaster] DROP CONSTRAINT [FK_ApplicationMasterTestMethodMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_ApplicationMasterSwabTypeMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[SwabTypeMaster] DROP CONSTRAINT [FK_ApplicationMasterSwabTypeMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_ApplicationMasterOrganizationTypeMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[OrganizationTypeMaster] DROP CONSTRAINT [FK_ApplicationMasterOrganizationTypeMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_ApplicationMasterTestPlanTypeMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TestPlanTypeMaster] DROP CONSTRAINT [FK_ApplicationMasterTestPlanTypeMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_TestPlanMasterTestPlanTestPointMapping]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TestPlanTestPointMapping] DROP CONSTRAINT [FK_TestPlanMasterTestPlanTestPointMapping];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganizationMasterScheduleDefinitionMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ScheduleDefinitionMaster] DROP CONSTRAINT [FK_OrganizationMasterScheduleDefinitionMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_ScheduleDaysOfWeekScheduleDefinitionMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ScheduleDaysOfWeek] DROP CONSTRAINT [FK_ScheduleDaysOfWeekScheduleDefinitionMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_ScheduleWeeksOfMonthScheduleDefinitionMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ScheduleWeeksOfMonth] DROP CONSTRAINT [FK_ScheduleWeeksOfMonthScheduleDefinitionMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_ScheduleMonthsOfYearScheduleDefinitionMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ScheduleMonthsOfYear] DROP CONSTRAINT [FK_ScheduleMonthsOfYearScheduleDefinitionMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_ScheduleDefinitionMasterScheduleDaysOfMonth]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ScheduleDaysOfMonth] DROP CONSTRAINT [FK_ScheduleDefinitionMasterScheduleDaysOfMonth];
GO
IF OBJECT_ID(N'[dbo].[FK_RegionMasterCountryMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[CountryMaster] DROP CONSTRAINT [FK_RegionMasterCountryMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_UserMasterUserCountryMapping]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserCountryMapping] DROP CONSTRAINT [FK_UserMasterUserCountryMapping];
GO
IF OBJECT_ID(N'[dbo].[FK_CountryMasterUserCountryMapping]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserCountryMapping] DROP CONSTRAINT [FK_CountryMasterUserCountryMapping];
GO
IF OBJECT_ID(N'[dbo].[FK_ApplicationMasterOrganizationTestMethodMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[OrganizationTestMethodMaster] DROP CONSTRAINT [FK_ApplicationMasterOrganizationTestMethodMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganizationMasterOrganizationTestMethodMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[OrganizationTestMethodMaster] DROP CONSTRAINT [FK_OrganizationMasterOrganizationTestMethodMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganizationMasterCapaComments]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[CapaComments] DROP CONSTRAINT [FK_OrganizationMasterCapaComments];
GO
IF OBJECT_ID(N'[dbo].[FK_TestPointMasterTestPointCustomParameterMapping]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TestPointCustomParameterMapping] DROP CONSTRAINT [FK_TestPointMasterTestPointCustomParameterMapping];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganizationMasterOrganizationCategoryMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[OrganizationCategoryMaster] DROP CONSTRAINT [FK_OrganizationMasterOrganizationCategoryMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganizationCategoryMasterOrganizationCustomParameterMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[OrganizationCustomParameterMaster] DROP CONSTRAINT [FK_OrganizationCategoryMasterOrganizationCustomParameterMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganizationMasterLuminometerMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[LuminometerMaster] DROP CONSTRAINT [FK_OrganizationMasterLuminometerMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_LocationMasterTestPointMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TestPointMaster] DROP CONSTRAINT [FK_LocationMasterTestPointMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_TestPointMasterTestPointTestMethodMapping]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TestPointTestMethodMapping] DROP CONSTRAINT [FK_TestPointMasterTestPointTestMethodMapping];
GO
IF OBJECT_ID(N'[dbo].[FK_UserMasterTestPlanUserMapping]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TestPlanUserMapping] DROP CONSTRAINT [FK_UserMasterTestPlanUserMapping];
GO
IF OBJECT_ID(N'[dbo].[FK_TestPlanMasterTestPlanUserMapping]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TestPlanUserMapping] DROP CONSTRAINT [FK_TestPlanMasterTestPlanUserMapping];
GO
IF OBJECT_ID(N'[dbo].[FK_TestPointMasterTestPlanTestPointMapping]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TestPlanTestPointMapping] DROP CONSTRAINT [FK_TestPointMasterTestPlanTestPointMapping];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganizationMasterLocationLevelMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[LocationLevelMaster] DROP CONSTRAINT [FK_OrganizationMasterLocationLevelMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_EditMeasurementEditTestResultCustomParameterMapping]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[EditTestResultCustomParameterMapping] DROP CONSTRAINT [FK_EditMeasurementEditTestResultCustomParameterMapping];
GO
IF OBJECT_ID(N'[dbo].[FK_AdhocTestPlanResultAdhocTestPointResult]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AdhocTestPointResult] DROP CONSTRAINT [FK_AdhocTestPlanResultAdhocTestPointResult];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganizationMasterUserDashboardPreferences1]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserDashboardPreferences] DROP CONSTRAINT [FK_OrganizationMasterUserDashboardPreferences1];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganizationTestMethodMasterOrganizationTestMethodVersions]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[OrganizationTestMethodVersions] DROP CONSTRAINT [FK_OrganizationTestMethodMasterOrganizationTestMethodVersions];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganizationTestMethodMasterTestPointTestMethodMapping]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TestPointTestMethodMapping] DROP CONSTRAINT [FK_OrganizationTestMethodMasterTestPointTestMethodMapping];
GO
IF OBJECT_ID(N'[dbo].[FK_UnitMasterOrganizationTestMethodVersionMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[OrganizationTestMethodVersions] DROP CONSTRAINT [FK_UnitMasterOrganizationTestMethodVersionMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganizationCustomParameterMasterTestPointCustomParameterMapping]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TestPointCustomParameterMapping] DROP CONSTRAINT [FK_OrganizationCustomParameterMasterTestPointCustomParameterMapping];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganizationMasterUserReportPreferences]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserReportPreferences] DROP CONSTRAINT [FK_OrganizationMasterUserReportPreferences];
GO
IF OBJECT_ID(N'[dbo].[FK_UserMasterUserReportPreferences]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserReportPreferences] DROP CONSTRAINT [FK_UserMasterUserReportPreferences];
GO
IF OBJECT_ID(N'[dbo].[FK_UserReportPreferencesReportLocationMapping]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ReportLocationMapping] DROP CONSTRAINT [FK_UserReportPreferencesReportLocationMapping];
GO
IF OBJECT_ID(N'[dbo].[FK_UserDashboardPreferencesDashboardSPMapping]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DashboardSPMapping] DROP CONSTRAINT [FK_UserDashboardPreferencesDashboardSPMapping];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganizationCustomParameterMasterOrganizationCustomParameterVersions]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[OrganizationCustomParameterVersions] DROP CONSTRAINT [FK_OrganizationCustomParameterMasterOrganizationCustomParameterVersions];
GO
IF OBJECT_ID(N'[dbo].[FK_ScheduleDefinitionMasterSamplePlanSchedule]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[SamplePlanSchedule] DROP CONSTRAINT [FK_ScheduleDefinitionMasterSamplePlanSchedule];
GO
IF OBJECT_ID(N'[dbo].[FK_CommonTasksRolePermissions]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[RolePermissions] DROP CONSTRAINT [FK_CommonTasksRolePermissions];
GO
IF OBJECT_ID(N'[dbo].[FK_MenuRolePermissions]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[RolePermissions] DROP CONSTRAINT [FK_MenuRolePermissions];
GO
IF OBJECT_ID(N'[dbo].[FK_AuditLogMasterAuditLogDetails]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AuditLogDetails] DROP CONSTRAINT [FK_AuditLogMasterAuditLogDetails];
GO
IF OBJECT_ID(N'[dbo].[FK_ScheduleMaster_OrganizationMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ScheduleMaster] DROP CONSTRAINT [FK_ScheduleMaster_OrganizationMaster];
GO
IF OBJECT_ID(N'[dbo].[FK_TestPlanResultTestPointResult]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TestPointResult] DROP CONSTRAINT [FK_TestPlanResultTestPointResult];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[OrganizationMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[OrganizationMaster];
GO
IF OBJECT_ID(N'[dbo].[CountryMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CountryMaster];
GO
IF OBJECT_ID(N'[dbo].[OrganizationRoleMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[OrganizationRoleMaster];
GO
IF OBJECT_ID(N'[dbo].[UserMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[UserMaster];
GO
IF OBJECT_ID(N'[dbo].[RoleMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[RoleMaster];
GO
IF OBJECT_ID(N'[dbo].[ApplicationMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ApplicationMaster];
GO
IF OBJECT_ID(N'[dbo].[LicenseTypeMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[LicenseTypeMaster];
GO
IF OBJECT_ID(N'[dbo].[FeatureMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FeatureMaster];
GO
IF OBJECT_ID(N'[dbo].[TestMethodMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TestMethodMaster];
GO
IF OBJECT_ID(N'[dbo].[TestPointMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TestPointMaster];
GO
IF OBJECT_ID(N'[dbo].[TestPlanTypeMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TestPlanTypeMaster];
GO
IF OBJECT_ID(N'[dbo].[TestPlanMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TestPlanMaster];
GO
IF OBJECT_ID(N'[dbo].[LocationMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[LocationMaster];
GO
IF OBJECT_ID(N'[dbo].[TestPointResult]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TestPointResult];
GO
IF OBJECT_ID(N'[dbo].[TimezoneMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TimezoneMaster];
GO
IF OBJECT_ID(N'[dbo].[OrganizationTypeMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[OrganizationTypeMaster];
GO
IF OBJECT_ID(N'[dbo].[SwabTypeMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[SwabTypeMaster];
GO
IF OBJECT_ID(N'[dbo].[OrganizationConfiguration]', 'U') IS NOT NULL
    DROP TABLE [dbo].[OrganizationConfiguration];
GO
IF OBJECT_ID(N'[dbo].[OrganizationImageMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[OrganizationImageMaster];
GO
IF OBJECT_ID(N'[dbo].[ScheduleDefinitionMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ScheduleDefinitionMaster];
GO
IF OBJECT_ID(N'[dbo].[OrganizationComments]', 'U') IS NOT NULL
    DROP TABLE [dbo].[OrganizationComments];
GO
IF OBJECT_ID(N'[dbo].[UserPreferences]', 'U') IS NOT NULL
    DROP TABLE [dbo].[UserPreferences];
GO
IF OBJECT_ID(N'[dbo].[TestPlanTestPointMapping]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TestPlanTestPointMapping];
GO
IF OBJECT_ID(N'[dbo].[DeviceSyncDetails]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DeviceSyncDetails];
GO
IF OBJECT_ID(N'[dbo].[FailedLoginAttempts]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FailedLoginAttempts];
GO
IF OBJECT_ID(N'[dbo].[ReportMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ReportMaster];
GO
IF OBJECT_ID(N'[dbo].[ScheduleDaysOfWeek]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ScheduleDaysOfWeek];
GO
IF OBJECT_ID(N'[dbo].[ScheduleMonthsOfYear]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ScheduleMonthsOfYear];
GO
IF OBJECT_ID(N'[dbo].[ScheduleWeeksOfMonth]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ScheduleWeeksOfMonth];
GO
IF OBJECT_ID(N'[dbo].[ScheduleDaysOfMonth]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ScheduleDaysOfMonth];
GO
IF OBJECT_ID(N'[dbo].[UserDashboardPreferences]', 'U') IS NOT NULL
    DROP TABLE [dbo].[UserDashboardPreferences];
GO
IF OBJECT_ID(N'[dbo].[RegionMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[RegionMaster];
GO
IF OBJECT_ID(N'[dbo].[EditMeasurement]', 'U') IS NOT NULL
    DROP TABLE [dbo].[EditMeasurement];
GO
IF OBJECT_ID(N'[dbo].[UserCountryMapping]', 'U') IS NOT NULL
    DROP TABLE [dbo].[UserCountryMapping];
GO
IF OBJECT_ID(N'[dbo].[CustomCategory]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CustomCategory];
GO
IF OBJECT_ID(N'[dbo].[CapaComments]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CapaComments];
GO
IF OBJECT_ID(N'[dbo].[OrganizationTestMethodMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[OrganizationTestMethodMaster];
GO
IF OBJECT_ID(N'[dbo].[TestPointCustomParameterMapping]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TestPointCustomParameterMapping];
GO
IF OBJECT_ID(N'[dbo].[OrganizationCategoryMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[OrganizationCategoryMaster];
GO
IF OBJECT_ID(N'[dbo].[OrganizationCustomParameterMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[OrganizationCustomParameterMaster];
GO
IF OBJECT_ID(N'[dbo].[SupportedVersionMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[SupportedVersionMaster];
GO
IF OBJECT_ID(N'[dbo].[LuminometerMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[LuminometerMaster];
GO
IF OBJECT_ID(N'[dbo].[WorkFlowMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[WorkFlowMaster];
GO
IF OBJECT_ID(N'[dbo].[TestPointTestMethodMapping]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TestPointTestMethodMapping];
GO
IF OBJECT_ID(N'[dbo].[TestPlanUserMapping]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TestPlanUserMapping];
GO
IF OBJECT_ID(N'[dbo].[TestResultCustomParameterMapping]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TestResultCustomParameterMapping];
GO
IF OBJECT_ID(N'[dbo].[LocationLevelMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[LocationLevelMaster];
GO
IF OBJECT_ID(N'[dbo].[EditTestResultCustomParameterMapping]', 'U') IS NOT NULL
    DROP TABLE [dbo].[EditTestResultCustomParameterMapping];
GO
IF OBJECT_ID(N'[dbo].[AdhocTestPointResult]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AdhocTestPointResult];
GO
IF OBJECT_ID(N'[dbo].[AdhocTestPlanResult]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AdhocTestPlanResult];
GO
IF OBJECT_ID(N'[dbo].[Menu]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Menu];
GO
IF OBJECT_ID(N'[dbo].[FeatureGroup]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FeatureGroup];
GO
IF OBJECT_ID(N'[dbo].[CommonTasks]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CommonTasks];
GO
IF OBJECT_ID(N'[dbo].[OrganizationTestMethodVersions]', 'U') IS NOT NULL
    DROP TABLE [dbo].[OrganizationTestMethodVersions];
GO
IF OBJECT_ID(N'[dbo].[UnitMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[UnitMaster];
GO
IF OBJECT_ID(N'[dbo].[OrganizationCustomParameterVersions]', 'U') IS NOT NULL
    DROP TABLE [dbo].[OrganizationCustomParameterVersions];
GO
IF OBJECT_ID(N'[dbo].[UserReportPreferences]', 'U') IS NOT NULL
    DROP TABLE [dbo].[UserReportPreferences];
GO
IF OBJECT_ID(N'[dbo].[ReportLocationMapping]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ReportLocationMapping];
GO
IF OBJECT_ID(N'[dbo].[DashboardSPMapping]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DashboardSPMapping];
GO
IF OBJECT_ID(N'[dbo].[ServiceRunLog]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ServiceRunLog];
GO
IF OBJECT_ID(N'[dbo].[SamplePlanSchedule]', 'U') IS NOT NULL
    DROP TABLE [dbo].[SamplePlanSchedule];
GO
IF OBJECT_ID(N'[dbo].[ResultScheduleMapping]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ResultScheduleMapping];
GO
IF OBJECT_ID(N'[dbo].[RolePermissions]', 'U') IS NOT NULL
    DROP TABLE [dbo].[RolePermissions];
GO
IF OBJECT_ID(N'[dbo].[AdhocEditMeasurement]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AdhocEditMeasurement];
GO
IF OBJECT_ID(N'[dbo].[AuditLogMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AuditLogMaster];
GO
IF OBJECT_ID(N'[dbo].[AuditLogDetails]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AuditLogDetails];
GO
IF OBJECT_ID(N'[dbo].[ArchivalMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ArchivalMaster];
GO
IF OBJECT_ID(N'[dbo].[ApplicationInformation]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ApplicationInformation];
GO
IF OBJECT_ID(N'[dbo].[ReportFilterMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ReportFilterMaster];
GO
IF OBJECT_ID(N'[dbo].[RolePermissionsForAudit]', 'U') IS NOT NULL
    DROP TABLE [dbo].[RolePermissionsForAudit];
GO
IF OBJECT_ID(N'[dbo].[ScheduleMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ScheduleMaster];
GO
IF OBJECT_ID(N'[dbo].[DashBoardView]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DashBoardView];
GO
IF OBJECT_ID(N'[dbo].[TestPlanResult]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TestPlanResult];
GO
IF OBJECT_ID(N'[dbo].[OrganizationRoleUserMapping]', 'U') IS NOT NULL
    DROP TABLE [dbo].[OrganizationRoleUserMapping];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'OrganizationMaster'
CREATE TABLE [dbo].[OrganizationMaster] (
    [OrganizationId] int IDENTITY(1,1) NOT NULL,
    [OrganizationTypeId] int  NULL,
    [ApplicationId] smallint  NULL,
    [OrganizationName] nvarchar(50)  NOT NULL,
    [IsLicensed] bit  NULL,
    [Status] smallint  NULL,
    [Address] nvarchar(50)  NULL,
    [ZipCode] nvarchar(30)  NULL,
    [CountryId] smallint  NULL,
    [LicenseID] smallint  NULL,
    [ValidTill] datetime  NULL,
    [HierarchyLevel] smallint  NULL,
    [PrimaryContact] int  NULL,
    [SecondaryContact] int  NULL,
    [ConfigurationComplete] bit  NULL,
    [CurrentStep] smallint  NULL,
    [CreatedDate] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [LastEditDate] datetime  NULL,
    [LastEditedBy] int  NULL,
    [DomainName] nvarchar(30)  NULL,
    [OrganizationKey] nvarchar(100)  NULL,
    [Fax] nvarchar(25)  NULL,
    [OrganizationLocale] nvarchar(10)  NULL
);
GO

-- Creating table 'CountryMaster'
CREATE TABLE [dbo].[CountryMaster] (
    [CountryId] smallint IDENTITY(1,1) NOT NULL,
    [CountryName] nvarchar(30)  NOT NULL,
    [RegionId] smallint  NOT NULL
);
GO

-- Creating table 'OrganizationRoleMaster'
CREATE TABLE [dbo].[OrganizationRoleMaster] (
    [OrganizationId] int  NOT NULL,
    [RoleId] smallint  NOT NULL,
    [RoleName] nvarchar(30)  NOT NULL,
    [RoleLevel] smallint  NOT NULL,
    [CreatedDate] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [PermissionXML] nvarchar(max)  NULL,
    [LastEditDate] datetime  NULL,
    [LastEditedBy] int  NULL,
    [InheritedFromParent] bit  NULL,
    [ParentOrganizationId] int  NULL,
    [ParentRoleId] smallint  NULL
);
GO

-- Creating table 'UserMaster'
CREATE TABLE [dbo].[UserMaster] (
    [UserId] int IDENTITY(1,1) NOT NULL,
    [Title] nvarchar(30)  NULL,
    [FirstName] nvarchar(30)  NOT NULL,
    [LastName] nvarchar(30)  NOT NULL,
    [Email] nvarchar(50)  NULL,
    [Status] smallint  NOT NULL,
    [DefaultOrganization] int  NOT NULL,
    [PreferencesSet] bit  NOT NULL,
    [ResetPassword] bit  NOT NULL,
    [LoginName] nvarchar(50)  NULL,
    [Password] nvarchar(100)  NULL,
    [LastLoginDateTime] datetime  NULL,
    [PhoneNo] nvarchar(30)  NULL,
    [ContractOrganization] int  NULL,
    [Notes] nvarchar(max)  NULL,
    [Pin] int  NULL,
    [LastChangePasswordDate] datetime  NULL,
    [DomainName] nvarchar(30)  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedDate] datetime  NOT NULL,
    [LastEditedBy] int  NULL,
    [LastEditDate] datetime  NULL,
    [IsUserNotifiedForPasswordExpiry] bit  NOT NULL,
    [CurrentRole] smallint  NOT NULL,
    [IsLoginRequired] bit  NOT NULL
);
GO

-- Creating table 'RoleMaster'
CREATE TABLE [dbo].[RoleMaster] (
    [RoleId] smallint IDENTITY(1,1) NOT NULL,
    [ApplicationId] smallint  NOT NULL,
    [RoleName] nvarchar(30)  NOT NULL,
    [RoleLevel] smallint  NOT NULL,
    [Only3M] bit  NOT NULL,
    [DisplayLevelText] nvarchar(30)  NOT NULL
);
GO

-- Creating table 'ApplicationMaster'
CREATE TABLE [dbo].[ApplicationMaster] (
    [ApplicationId] smallint IDENTITY(1,1) NOT NULL,
    [ApplicationName] nvarchar(30)  NOT NULL
);
GO

-- Creating table 'LicenseTypeMaster'
CREATE TABLE [dbo].[LicenseTypeMaster] (
    [LicenseId] smallint IDENTITY(1,1) NOT NULL,
    [LicenseType] nvarchar(50)  NOT NULL
);
GO

-- Creating table 'FeatureMaster'
CREATE TABLE [dbo].[FeatureMaster] (
    [FeatureId] smallint IDENTITY(1,1) NOT NULL,
    [ApplicationId] smallint  NOT NULL,
    [FeatureName] nvarchar(50)  NOT NULL,
    [FeatureCategory] smallint  NOT NULL,
    [AccessType] smallint  NOT NULL,
    [Url] nvarchar(250)  NULL,
    [ParentFeatureId] smallint  NOT NULL,
    [IsMenuItem] bit  NOT NULL
);
GO

-- Creating table 'TestMethodMaster'
CREATE TABLE [dbo].[TestMethodMaster] (
    [TestMethodId] smallint IDENTITY(1,1) NOT NULL,
    [ApplicationId] smallint  NOT NULL,
    [TestMethodName] nvarchar(30)  NOT NULL,
    [ShortName] nvarchar(8)  NOT NULL,
    [SwabTypeRequired] bit  NOT NULL,
    [PassThreshold] int  NULL,
    [FailThreshold] int  NULL,
    [ThresholdType] smallint  NOT NULL,
    [TestType] smallint  NOT NULL
);
GO

-- Creating table 'TestPointMaster'
CREATE TABLE [dbo].[TestPointMaster] (
    [OrganizationId] int  NOT NULL,
    [TestPointId] int  NOT NULL,
    [TestPointVersion] smallint  NOT NULL,
    [LocationId] int  NOT NULL,
    [TestPointName] nvarchar(53)  NOT NULL,
    [Status] smallint  NOT NULL,
    [IsCurrent] bit  NOT NULL,
    [PassThreshold] int  NULL,
    [FailThreshold] int  NULL,
    [Description] nvarchar(250)  NULL,
    [TestPointImage] varbinary(max)  NULL,
    [IsImported] bit  NULL,
    [ImportId] int  NULL,
    [TestPointGroupId] int  NOT NULL,
    [ImageLastEditedDate] datetime  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedDate] datetime  NOT NULL,
    [LastEditedBy] int  NULL,
    [LastEditDate] datetime  NULL
);
GO

-- Creating table 'TestPlanTypeMaster'
CREATE TABLE [dbo].[TestPlanTypeMaster] (
    [TestPlanTypeId] smallint IDENTITY(1,1) NOT NULL,
    [ApplicationId] smallint  NOT NULL,
    [TestPlanTypeName] nvarchar(30)  NOT NULL,
    [ForReports] bit  NOT NULL
);
GO

-- Creating table 'TestPlanMaster'
CREATE TABLE [dbo].[TestPlanMaster] (
    [OrganizationId] int  NOT NULL,
    [TestPlanId] int  NOT NULL,
    [TestPlanVersion] smallint  NOT NULL,
    [TestPlanTypeId] smallint  NOT NULL,
    [TestPlanName] nvarchar(53)  NOT NULL,
    [LocationId] int  NULL,
    [Status] smallint  NOT NULL,
    [IsCurrent] bit  NOT NULL,
    [LockedBy] int  NULL,
    [IsImported] bit  NULL,
    [ImportId] int  NULL,
    [RandomPointCount] smallint  NOT NULL,
    [IsNoRepeat] bit  NOT NULL,
    [DBId] uniqueidentifier  NULL,
    [Description] nvarchar(250)  NULL,
    [IsRandomizationApplicable] bit  NOT NULL,
    [IsScheduleApplicable] bit  NOT NULL,
    [LastResultSyncDate] datetime  NULL,
    [CreatedDate] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [LastEditDate] datetime  NULL,
    [LastEditedBy] int  NULL
);
GO

-- Creating table 'LocationMaster'
CREATE TABLE [dbo].[LocationMaster] (
    [OrganizationId] int  NOT NULL,
    [LocationId] int  NOT NULL,
    [LocationVersion] smallint  NOT NULL,
    [LocationName] nvarchar(53)  NOT NULL,
    [Level] smallint  NOT NULL,
    [ParentLocationId] int  NULL,
    [Status] smallint  NOT NULL,
    [IsCurrent] bit  NOT NULL,
    [Description] nvarchar(1000)  NULL,
    [Notes] nvarchar(max)  NULL,
    [LastEditDate] datetime  NULL,
    [LastEditedBy] int  NULL,
    [CreatedDate] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL
);
GO

-- Creating table 'TestPointResult'
CREATE TABLE [dbo].[TestPointResult] (
    [ResultId] bigint  NOT NULL,
    [MeasurementId] int  NOT NULL,
    [TestPointId] int  NOT NULL,
    [TestPointVersion] smallint  NOT NULL,
    [TestPointName] nvarchar(53)  NOT NULL,
    [TestPointLocationId] int  NOT NULL,
    [LocationName] nvarchar(50)  NOT NULL,
    [TestMethodId] smallint  NOT NULL,
    [TestMethodVersion] smallint  NOT NULL,
    [TestMethodName] nvarchar(50)  NOT NULL,
    [TestType] smallint  NOT NULL,
    [IsRetest] bit  NOT NULL,
    [IsAdhoc] bit  NOT NULL,
    [Status] smallint  NOT NULL,
    [Result] smallint  NULL,
    [ResultValue] float  NULL,
    [ResultDate] datetime  NULL,
    [IsEdited] bit  NULL,
    [ResultTakenBy] int  NULL,
    [ResultTakenByName] nvarchar(100)  NULL,
    [OriginalMeasurementId] int  NULL,
    [CapaComments] nvarchar(1000)  NULL,
    [CreatedDate] datetime  NULL,
    [CreatedBy] int  NULL,
    [LastEditDate] datetime  NULL,
    [LastEditedBy] int  NULL,
    [ATPPassThreshold] decimal(10,2)  NULL,
    [ATPFailThreshold] decimal(10,2)  NULL,
    [ThresholdType] smallint  NULL,
    [UnitId] int  NULL,
    [UnitName] nvarchar(10)  NULL,
    [ReasonToAdd] nvarchar(1000)  NULL,
    [Is3MSwab] bit  NOT NULL
);
GO

-- Creating table 'TimezoneMaster'
CREATE TABLE [dbo].[TimezoneMaster] (
    [TimezoneId] smallint IDENTITY(1,1) NOT NULL,
    [Timezone] nvarchar(50)  NOT NULL,
    [DisplayTimezone] nvarchar(100)  NOT NULL
);
GO

-- Creating table 'OrganizationTypeMaster'
CREATE TABLE [dbo].[OrganizationTypeMaster] (
    [OrganizationTypeId] smallint IDENTITY(1,1) NOT NULL,
    [ApplicationId] smallint  NOT NULL,
    [OrganizationTypeName] nvarchar(30)  NOT NULL
);
GO

-- Creating table 'SwabTypeMaster'
CREATE TABLE [dbo].[SwabTypeMaster] (
    [SwabTypeId] smallint IDENTITY(1,1) NOT NULL,
    [ApplicationId] smallint  NOT NULL,
    [SwabTypeName] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'OrganizationConfiguration'
CREATE TABLE [dbo].[OrganizationConfiguration] (
    [OrganizationId] int  NOT NULL,
    [ChangeTestPointThreshold] bit  NOT NULL,
    [MobileDataStoragePeriod] smallint  NOT NULL,
    [ATPPassThreshold] int  NULL,
    [ATPFailThreshold] int  NULL,
    [TimezoneName] nvarchar(100)  NOT NULL,
    [RequireStrongPassword] bit  NOT NULL,
    [DateFormat] nvarchar(30)  NULL,
    [RequirePasswordForDevice] bit  NOT NULL,
    [SyncType] smallint  NOT NULL,
    [NumberFormat] smallint  NULL,
    [TemperatureUnit] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedDate] datetime  NOT NULL,
    [LastEditedBy] int  NULL,
    [LastEditDate] datetime  NULL
);
GO

-- Creating table 'OrganizationImageMaster'
CREATE TABLE [dbo].[OrganizationImageMaster] (
    [OrganizationId] int  NOT NULL,
    [Logo] varbinary(max)  NOT NULL
);
GO

-- Creating table 'ScheduleDefinitionMaster'
CREATE TABLE [dbo].[ScheduleDefinitionMaster] (
    [OrganizationId] int  NOT NULL,
    [ScheduleId] int  NOT NULL,
    [ScheduleName] nvarchar(50)  NOT NULL,
    [ScheduleType] smallint  NOT NULL,
    [ScheduleFrequencyId] smallint  NOT NULL,
    [StartDate] datetime  NOT NULL,
    [ExecutionTime] time  NOT NULL,
    [IsEnabled] bit  NOT NULL,
    [NextScheduleDateTime] datetime  NOT NULL,
    [ScheduleSourceId] bigint  NOT NULL,
    [ScheduleSourceSubId] int  NULL,
    [IsOneTimeOnly] bit  NOT NULL,
    [CreatedDate] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [AreaId] int  NULL,
    [RoomId] int  NULL,
    [EndDate] datetime  NULL,
    [NoOfOccurrances] smallint  NULL,
    [NoOfExecutions] smallint  NOT NULL,
    [DailyInterval] smallint  NULL,
    [LastEditDate] datetime  NULL,
    [LastEditedBy] int  NULL,
    [OccuranceCount] smallint  NULL
);
GO

-- Creating table 'OrganizationComments'
CREATE TABLE [dbo].[OrganizationComments] (
    [OrganizationId] int  NOT NULL,
    [CommentId] smallint  NOT NULL,
    [Comment] nvarchar(250)  NOT NULL,
    [CommentDate] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL
);
GO

-- Creating table 'UserPreferences'
CREATE TABLE [dbo].[UserPreferences] (
    [UserId] int  NOT NULL,
    [PreferredLocale] nvarchar(10)  NULL,
    [SecretQuestion] smallint  NULL,
    [SecretAnswer] nvarchar(150)  NULL,
    [CreatedDate] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [LastEditDate] datetime  NULL,
    [LastEditedBy] int  NULL
);
GO

-- Creating table 'TestPlanTestPointMapping'
CREATE TABLE [dbo].[TestPlanTestPointMapping] (
    [OrganizationId] int  NOT NULL,
    [TestPlanId] int  NOT NULL,
    [TestPlanVersion] smallint  NOT NULL,
    [TestPointId] int  NOT NULL,
    [TestPointVersion] smallint  NOT NULL,
    [Order] smallint  NULL,
    [IsRandom] bit  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [LastEditedBy] int  NULL
);
GO

-- Creating table 'DeviceSyncDetails'
CREATE TABLE [dbo].[DeviceSyncDetails] (
    [SyncId] int IDENTITY(1,1) NOT NULL,
    [DeviceSerialNumber] nvarchar(50)  NOT NULL,
    [OrganizationId] int  NOT NULL,
    [LastSyncTime] datetime  NOT NULL,
    [DeviceName] nvarchar(30)  NULL,
    [SyncMode] smallint  NOT NULL,
    [SyncManagerIdentifier] nvarchar(50)  NULL,
    [SyncBy] int  NULL,
    [IsAdminNotified] bit  NOT NULL
);
GO

-- Creating table 'FailedLoginAttempts'
CREATE TABLE [dbo].[FailedLoginAttempts] (
    [AttemptId] int IDENTITY(1,1) NOT NULL,
    [OrganizationId] int  NOT NULL,
    [LoginName] nvarchar(50)  NOT NULL,
    [LoginDateTime] datetime  NOT NULL
);
GO

-- Creating table 'ReportMaster'
CREATE TABLE [dbo].[ReportMaster] (
    [ReportId] smallint IDENTITY(1,1) NOT NULL,
    [ApplicationId] smallint  NOT NULL,
    [ReportName] nvarchar(30)  NOT NULL
);
GO

-- Creating table 'ScheduleDaysOfWeek'
CREATE TABLE [dbo].[ScheduleDaysOfWeek] (
    [OrganizationId] int  NOT NULL,
    [ScheduleId] int  NOT NULL,
    [Monday] bit  NULL,
    [Tuesday] bit  NULL,
    [Wednesday] bit  NULL,
    [Thursday] bit  NULL,
    [Friday] bit  NULL,
    [Saturday] bit  NULL,
    [Sunday] bit  NULL
);
GO

-- Creating table 'ScheduleMonthsOfYear'
CREATE TABLE [dbo].[ScheduleMonthsOfYear] (
    [OrganizationId] int  NOT NULL,
    [ScheduleId] int  NOT NULL,
    [January] bit  NULL,
    [February] bit  NULL,
    [March] bit  NULL,
    [April] bit  NULL,
    [May] bit  NULL,
    [June] bit  NULL,
    [July] bit  NULL,
    [August] bit  NULL,
    [September] bit  NULL,
    [October] bit  NULL,
    [November] bit  NULL,
    [December] bit  NULL
);
GO

-- Creating table 'ScheduleWeeksOfMonth'
CREATE TABLE [dbo].[ScheduleWeeksOfMonth] (
    [OrganizationId] int  NOT NULL,
    [ScheduleId] int  NOT NULL,
    [First] bit  NULL,
    [Second] bit  NULL,
    [Third] bit  NULL,
    [Forth] bit  NULL,
    [Last] bit  NULL
);
GO

-- Creating table 'ScheduleDaysOfMonth'
CREATE TABLE [dbo].[ScheduleDaysOfMonth] (
    [OrganizationId] int  NOT NULL,
    [ScheduleId] int  NOT NULL,
    [Day1] bit  NULL,
    [Day2] bit  NULL,
    [Day3] bit  NULL,
    [Day4] bit  NULL,
    [Day5] bit  NULL,
    [Day6] bit  NULL,
    [Day7] bit  NULL,
    [Day8] bit  NULL,
    [Day9] bit  NULL,
    [Day10] bit  NULL,
    [Day11] bit  NULL,
    [Day12] bit  NULL,
    [Day13] bit  NULL,
    [Day14] bit  NULL,
    [Day15] bit  NULL,
    [Day16] bit  NULL,
    [Day17] bit  NULL,
    [Day18] bit  NULL,
    [Day19] bit  NULL,
    [Day20] bit  NULL,
    [Day21] bit  NULL,
    [Day22] bit  NULL,
    [Day23] bit  NULL,
    [Day24] bit  NULL,
    [Day25] bit  NULL,
    [Day26] bit  NULL,
    [Day27] bit  NULL,
    [Day28] bit  NULL,
    [Day29] bit  NULL,
    [Day30] bit  NULL,
    [Day31] bit  NULL,
    [Last] bit  NULL
);
GO

-- Creating table 'UserDashboardPreferences'
CREATE TABLE [dbo].[UserDashboardPreferences] (
    [OrganizationId] int  NOT NULL,
    [PreferenceId] int IDENTITY(1,1) NOT NULL,
    [UserId] nvarchar(max)  NOT NULL,
    [DateSelection] smallint  NOT NULL,
    [FromDate] datetime  NULL,
    [ToDate] datetime  NULL,
    [TestTypeSelection] smallint  NOT NULL
);
GO

-- Creating table 'RegionMaster'
CREATE TABLE [dbo].[RegionMaster] (
    [RegionId] smallint IDENTITY(1,1) NOT NULL,
    [RegionName] nvarchar(30)  NOT NULL
);
GO

-- Creating table 'EditMeasurement'
CREATE TABLE [dbo].[EditMeasurement] (
    [OrganizationId] int  NOT NULL,
    [Id] bigint IDENTITY(1,1) NOT NULL,
    [ResultId] bigint  NOT NULL,
    [MeasurementId] smallint  NOT NULL,
    [ReasonForChange] nvarchar(1000)  NOT NULL,
    [OldResult] smallint  NULL,
    [OldResultValue] float  NULL,
    [NewResult] smallint  NULL,
    [NewResultValue] float  NULL,
    [OldCapaComments] nvarchar(1000)  NULL,
    [NewCapaComments] nvarchar(1000)  NULL,
    [OldTester] int  NULL,
    [NewTester] int  NULL,
    [EditDate] datetime  NOT NULL,
    [EditedBy] int  NOT NULL
);
GO

-- Creating table 'UserCountryMapping'
CREATE TABLE [dbo].[UserCountryMapping] (
    [UserId] int  NOT NULL,
    [CountryId] smallint  NOT NULL
);
GO

-- Creating table 'CustomCategory'
CREATE TABLE [dbo].[CustomCategory] (
    [CategoryId] smallint IDENTITY(1,1) NOT NULL,
    [Category] nvarchar(50)  NOT NULL,
    [IsUserDefine] bit  NOT NULL,
    [IsNumericType] bit  NOT NULL
);
GO

-- Creating table 'CapaComments'
CREATE TABLE [dbo].[CapaComments] (
    [OrganizationId] int  NOT NULL,
    [CommentId] smallint IDENTITY(1,1) NOT NULL,
    [CommentText] nvarchar(1000)  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedDate] datetime  NOT NULL,
    [EditedBy] int  NULL,
    [EditedDate] datetime  NULL
);
GO

-- Creating table 'OrganizationTestMethodMaster'
CREATE TABLE [dbo].[OrganizationTestMethodMaster] (
    [OrganizationId] int  NOT NULL,
    [TestMethodId] smallint  NOT NULL,
    [ApplicationId] smallint  NOT NULL,
    [TestType] smallint  NOT NULL,
    [IsApplicable] bit  NOT NULL,
    [EditedBy] int  NULL,
    [EditedDate] datetime  NULL,
    [CreatedDate] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL
);
GO

-- Creating table 'TestPointCustomParameterMapping'
CREATE TABLE [dbo].[TestPointCustomParameterMapping] (
    [OrganizationId] int  NOT NULL,
    [TestPointId] int  NOT NULL,
    [TestPointVersion] smallint  NOT NULL,
    [CategoryId] int  NOT NULL,
    [ParameterId] int  NOT NULL
);
GO

-- Creating table 'OrganizationCategoryMaster'
CREATE TABLE [dbo].[OrganizationCategoryMaster] (
    [OrganizationCategoryId] int  NOT NULL,
    [OrganizationId] int  NOT NULL,
    [CategoryName] nvarchar(50)  NOT NULL,
    [IsUserDefine] bit  NOT NULL,
    [IsNumericType] bit  NOT NULL
);
GO

-- Creating table 'OrganizationCustomParameterMaster'
CREATE TABLE [dbo].[OrganizationCustomParameterMaster] (
    [OrganizationId] int  NOT NULL,
    [OrganizationCategoryId] int  NOT NULL,
    [ParameterId] int  NOT NULL,
    [IsApplicable] bit  NOT NULL,
    [LastEditDate] datetime  NULL,
    [LastEditedBy] int  NULL,
    [CreatedDate] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL
);
GO

-- Creating table 'SupportedVersionMaster'
CREATE TABLE [dbo].[SupportedVersionMaster] (
    [VersionId] int IDENTITY(1,1) NOT NULL,
    [ApplicationId] smallint  NOT NULL,
    [Type] smallint  NOT NULL,
    [BuildVersion] nvarchar(10)  NOT NULL,
    [IsSupported] bit  NOT NULL,
    [IsCurrent] bit  NOT NULL,
    [ReleaseDate] datetime  NOT NULL,
    [CreatedDate] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [LastEditedDate] datetime  NOT NULL,
    [LastEditedBy] int  NOT NULL
);
GO

-- Creating table 'LuminometerMaster'
CREATE TABLE [dbo].[LuminometerMaster] (
    [LuminometerId] int IDENTITY(1,1) NOT NULL,
    [OrganizationId] int  NOT NULL,
    [Name] nvarchar(50)  NOT NULL,
    [DeviceSerialNumber] nvarchar(50)  NOT NULL,
    [BuildVersion] nvarchar(10)  NOT NULL,
    [FirmwareVersion] nvarchar(10)  NOT NULL,
    [MacId] nvarchar(50)  NULL,
    [HardwareVersion] nvarchar(10)  NULL,
    [OSVersion] nvarchar(10)  NULL,
    [CalibrationDate] datetime  NULL
);
GO

-- Creating table 'WorkFlowMaster'
CREATE TABLE [dbo].[WorkFlowMaster] (
    [WorkFlowId] uniqueidentifier  NOT NULL,
    [IsAuthenticated] bit  NOT NULL,
    [RequestorIdentifier] nvarchar(50)  NULL,
    [OrganizationName] nvarchar(50)  NULL,
    [OrganizationId] int  NULL,
    [UserId] int  NULL,
    [DeviceModelNumber] nvarchar(20)  NULL,
    [CreatedDate] datetime  NOT NULL,
    [LastUsedDate] datetime  NOT NULL,
    [ConsumerSource] nvarchar(20)  NOT NULL
);
GO

-- Creating table 'TestPointTestMethodMapping'
CREATE TABLE [dbo].[TestPointTestMethodMapping] (
    [OrganizationId] int  NOT NULL,
    [TestPointId] int  NOT NULL,
    [TestPointVersion] smallint  NOT NULL,
    [TestMethodId] smallint  NOT NULL,
    [IsThresholdOverridden] bit  NOT NULL,
    [ATPPassThreshold] decimal(10,2)  NULL,
    [ATPFailThreshold] decimal(10,2)  NULL,
    [ThresholdType] smallint  NOT NULL
);
GO

-- Creating table 'TestPlanUserMapping'
CREATE TABLE [dbo].[TestPlanUserMapping] (
    [OrganizationId] int  NOT NULL,
    [UserId] int  NOT NULL,
    [TestPlanId] int  NOT NULL,
    [TestPlanVersion] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [LastEditedBy] int  NULL
);
GO

-- Creating table 'TestResultCustomParameterMapping'
CREATE TABLE [dbo].[TestResultCustomParameterMapping] (
    [ResultId] bigint  NOT NULL,
    [MeasurementId] int  NOT NULL,
    [OrganizationCategoryId] int  NOT NULL,
    [ParameterId] smallint  NOT NULL,
    [ParameterVersion] smallint  NOT NULL,
    [EditedBy] int  NULL,
    [EditedDate] datetime  NULL
);
GO

-- Creating table 'LocationLevelMaster'
CREATE TABLE [dbo].[LocationLevelMaster] (
    [OrganizationId] int  NOT NULL,
    [LevelId] smallint  NOT NULL,
    [LevelName] nvarchar(50)  NOT NULL,
    [Order] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedDate] datetime  NOT NULL,
    [EditedBy] int  NOT NULL,
    [EditedDate] datetime  NOT NULL
);
GO

-- Creating table 'EditTestResultCustomParameterMapping'
CREATE TABLE [dbo].[EditTestResultCustomParameterMapping] (
    [EditId] bigint IDENTITY(1,1) NOT NULL,
    [Id] bigint  NOT NULL,
    [OldOrganizationCategoryId] int  NOT NULL,
    [NewOrganizationCategoryId] int  NOT NULL,
    [OldParameterId] smallint  NOT NULL,
    [NewParameterId] smallint  NOT NULL,
    [EditedBy] int  NULL,
    [EditedDate] datetime  NULL
);
GO

-- Creating table 'AdhocTestPointResult'
CREATE TABLE [dbo].[AdhocTestPointResult] (
    [AdhocResultId] bigint  NOT NULL,
    [AdhocMeasurementId] smallint  NOT NULL,
    [TestPointId] int  NULL,
    [TestPointVersion] smallint  NULL,
    [TestPointName] nvarchar(53)  NOT NULL,
    [TestPointLocationId] int  NULL,
    [LocationName] nvarchar(53)  NOT NULL,
    [TestMethodId] smallint  NOT NULL,
    [TestMethodVersion] smallint  NOT NULL,
    [TestMethodName] nvarchar(50)  NULL,
    [TestType] smallint  NOT NULL,
    [IsAdhoc] bit  NOT NULL,
    [IsRetest] bit  NOT NULL,
    [Status] smallint  NOT NULL,
    [Result] smallint  NULL,
    [ResultValue] float  NOT NULL,
    [ResultDate] datetime  NULL,
    [IsEdited] bit  NOT NULL,
    [ResultTakenBy] int  NULL,
    [ResultTakenByName] nvarchar(100)  NULL,
    [OriginalAdhocMeasurementId] bigint  NULL,
    [CapaComments] nvarchar(1000)  NULL,
    [CreatedBy] int  NULL,
    [CreatedDate] datetime  NULL,
    [LastEditDate] datetime  NULL,
    [LastEditedBy] int  NULL,
    [ATPPassThreshold] decimal(10,2)  NULL,
    [ATPFailThreshold] decimal(10,2)  NULL,
    [ThresholdType] smallint  NULL,
    [UnitId] int  NULL,
    [UnitName] nvarchar(10)  NULL,
    [IsMapped] bit  NOT NULL,
    [Is3MSwab] bit  NOT NULL
);
GO

-- Creating table 'AdhocTestPlanResult'
CREATE TABLE [dbo].[AdhocTestPlanResult] (
    [AdhocResultId] bigint IDENTITY(1,1) NOT NULL,
    [OrganizationId] int  NOT NULL,
    [TestPlanId] int  NOT NULL,
    [TestPlanVersion] smallint  NOT NULL,
    [TestPlanName] nvarchar(50)  NOT NULL,
    [LocationId] int  NULL,
    [LocationVersion] smallint  NULL,
    [Status] smallint  NOT NULL,
    [OpenedDate] datetime  NULL,
    [OpenedBy] int  NULL,
    [DeviceId] nvarchar(50)  NOT NULL,
    [LastEditedBy] int  NULL,
    [LastEditedDate] datetime  NULL
);
GO

-- Creating table 'Menu'
CREATE TABLE [dbo].[Menu] (
    [MenuId] smallint IDENTITY(1,1) NOT NULL,
    [MenuKey] nvarchar(30)  NOT NULL,
    [Url] nvarchar(50)  NOT NULL,
    [ImageName] nvarchar(15)  NOT NULL
);
GO

-- Creating table 'FeatureGroup'
CREATE TABLE [dbo].[FeatureGroup] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [FeatureKey] nvarchar(30)  NOT NULL,
    [PermissionType] smallint  NOT NULL,
    [FeatureGroupKey] smallint  NOT NULL
);
GO

-- Creating table 'CommonTasks'
CREATE TABLE [dbo].[CommonTasks] (
    [CommonTaskId] int IDENTITY(1,1) NOT NULL,
    [CommonTaskKey] nvarchar(30)  NOT NULL,
    [FeatureGroupKey] smallint  NOT NULL,
    [AddUrl] nvarchar(100)  NOT NULL,
    [ViewUrl] nvarchar(100)  NULL,
    [ImageName] nvarchar(15)  NOT NULL
);
GO

-- Creating table 'OrganizationTestMethodVersions'
CREATE TABLE [dbo].[OrganizationTestMethodVersions] (
    [OrganizationId] int  NOT NULL,
    [TestMethodId] smallint  NOT NULL,
    [TestMethodVersion] smallint  NOT NULL,
    [TestMethodName] nvarchar(50)  NOT NULL,
    [IsCurrent] bit  NOT NULL,
    [ShortName] nvarchar(8)  NULL,
    [PassThreshold] decimal(10,2)  NULL,
    [FailThreshold] decimal(10,2)  NULL,
    [ThresholdType] smallint  NOT NULL,
    [UnitId] int  NOT NULL,
    [CreatedDate] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL
);
GO

-- Creating table 'UnitMaster'
CREATE TABLE [dbo].[UnitMaster] (
    [ApplicationId] smallint  NOT NULL,
    [UnitId] int IDENTITY(1,1) NOT NULL,
    [UnitName] nvarchar(50)  NOT NULL
);
GO

-- Creating table 'OrganizationCustomParameterVersions'
CREATE TABLE [dbo].[OrganizationCustomParameterVersions] (
    [OrganizationId] int  NOT NULL,
    [OrganizationCategoryId] int  NOT NULL,
    [ParameterId] int  NOT NULL,
    [ParameterVersion] smallint  NOT NULL,
    [IsCurrent] bit  NOT NULL,
    [ParameterName] nvarchar(50)  NULL,
    [ParameterNumericValue] int  NULL,
    [CreatedDate] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL
);
GO

-- Creating table 'UserReportPreferences'
CREATE TABLE [dbo].[UserReportPreferences] (
    [ReportId] int IDENTITY(1,1) NOT NULL,
    [OrganizationId] int  NOT NULL,
    [UserId] int  NOT NULL,
    [ReportName] nvarchar(50)  NOT NULL,
    [Title] nvarchar(50)  NULL,
    [Type] smallint  NOT NULL,
    [ChartType] smallint  NOT NULL,
    [ChartDimension] smallint  NOT NULL,
    [DateSelection] smallint  NOT NULL,
    [FromDate] datetime  NULL,
    [ToDate] datetime  NULL,
    [TestPointSelection] smallint  NOT NULL,
    [DateGrouping] smallint  NOT NULL,
    [TestPointGrouping] smallint  NOT NULL,
    [GroupPeriod] smallint  NULL,
    [ResultCategory] smallint  NOT NULL,
    [SchedulingType] smallint  NOT NULL,
    [ScheduleFrequency] smallint  NULL,
    [CreatedDate] datetime  NOT NULL,
    [EditedDate] datetime  NULL
);
GO

-- Creating table 'ReportLocationMapping'
CREATE TABLE [dbo].[ReportLocationMapping] (
    [ReportId] int  NOT NULL,
    [LocationId] int  NOT NULL,
    [LocationVersion] smallint  NOT NULL
);
GO

-- Creating table 'DashboardSPMapping'
CREATE TABLE [dbo].[DashboardSPMapping] (
    [MappingId] int IDENTITY(1,1) NOT NULL,
    [PreferenceId] int  NOT NULL,
    [SamplePlanId] int  NOT NULL,
    [SamplePlanVersion] smallint  NOT NULL
);
GO

-- Creating table 'ServiceRunLog'
CREATE TABLE [dbo].[ServiceRunLog] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [ServiceIdentifier] nvarchar(100)  NOT NULL,
    [FirstRundate] datetime  NULL,
    [LastRunDate] datetime  NULL
);
GO

-- Creating table 'SamplePlanSchedule'
CREATE TABLE [dbo].[SamplePlanSchedule] (
    [ReportScheduleId] int  NOT NULL,
    [OrganizationId] int  NOT NULL,
    [ScheduleDefinitionMasterId] int  NOT NULL,
    [ScheduleDate] datetime  NOT NULL,
    [IsMissingNotificationSend] bit  NOT NULL,
    [IsScheduledNotificationSend] bit  NOT NULL
);
GO

-- Creating table 'ResultScheduleMapping'
CREATE TABLE [dbo].[ResultScheduleMapping] (
    [ReportScheduleId] int  NOT NULL,
    [OrganizationId] int  NOT NULL,
    [ResultId] bigint  NOT NULL
);
GO

-- Creating table 'RolePermissions'
CREATE TABLE [dbo].[RolePermissions] (
    [Id] int  NOT NULL,
    [OrganizationId] int  NOT NULL,
    [RoleId] smallint  NOT NULL,
    [MenuId] smallint  NOT NULL,
    [CommonTaskId] int  NOT NULL,
    [FeatureGroupKey] smallint  NOT NULL,
    [Permission] smallint  NOT NULL,
    [Order] smallint  NOT NULL,
    [Display] bit  NOT NULL,
    [OpeningMode] smallint  NOT NULL
);
GO

-- Creating table 'AdhocEditMeasurement'
CREATE TABLE [dbo].[AdhocEditMeasurement] (
    [OrganizationId] int  NOT NULL,
    [Id] bigint IDENTITY(1,1) NOT NULL,
    [AdhocResultId] bigint  NOT NULL,
    [AdhocMeasurementId] smallint  NOT NULL,
    [ReasonForChange] nvarchar(1000)  NOT NULL,
    [OldResult] smallint  NULL,
    [OldResultValue] float  NULL,
    [NewResult] smallint  NULL,
    [NewResultValue] float  NULL,
    [OldCapaComments] nvarchar(1000)  NULL,
    [NewCapaComments] nvarchar(1000)  NULL,
    [OldTester] int  NULL,
    [NewTester] int  NULL,
    [EditDate] datetime  NOT NULL,
    [EditedBy] int  NOT NULL
);
GO

-- Creating table 'AuditLogMaster'
CREATE TABLE [dbo].[AuditLogMaster] (
    [AuditLogId] bigint IDENTITY(1,1) NOT NULL,
    [ActionDate] datetime  NOT NULL,
    [ActionBy] int  NULL,
    [Description] nvarchar(max)  NULL,
    [KeyId] int  NULL,
    [RootField] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'AuditLogDetails'
CREATE TABLE [dbo].[AuditLogDetails] (
    [AuditLogDetailId] bigint IDENTITY(1,1) NOT NULL,
    [AuditLogId] bigint  NOT NULL,
    [TableName] nvarchar(200)  NOT NULL,
    [FieldName] nvarchar(200)  NOT NULL,
    [OperationType] nvarchar(50)  NOT NULL,
    [OldValue] nvarchar(max)  NULL,
    [NewValue] nvarchar(max)  NULL,
    [Display] bit  NOT NULL,
    [PrimaryField] nvarchar(max)  NULL
);
GO

-- Creating table 'ArchivalMaster'
CREATE TABLE [dbo].[ArchivalMaster] (
    [ArchivalId] int IDENTITY(1,1) NOT NULL,
    [OrganizationId] int  NOT NULL,
    [StartDate] datetime  NOT NULL,
    [EndDate] datetime  NOT NULL,
    [SamplePlan] nvarchar(max)  NOT NULL,
    [ScheduleOn] datetime  NOT NULL,
    [ArchivalStatus] bit  NULL,
    [IsAlive] bit  NOT NULL,
    [ArchivedOn] datetime  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedDate] datetime  NOT NULL
);
GO

-- Creating table 'ApplicationInformation'
CREATE TABLE [dbo].[ApplicationInformation] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [ApplicationUrl] nvarchar(200)  NOT NULL,
    [HostName] nvarchar(100)  NOT NULL,
    [CommonServicePort] smallint  NOT NULL,
    [WebServicePort] smallint  NOT NULL,
    [DeviceServicePort] smallint  NOT NULL,
    [InstallationDate] datetime  NOT NULL,
    [DBServerName] nvarchar(100)  NOT NULL,
    [PackageVersion] nvarchar(50)  NOT NULL,
    [Comments] nvarchar(500)  NULL,
    [IsUninstall] bit  NULL,
    [IpAddress] nvarchar(200)  NOT NULL
);
GO

-- Creating table 'ReportFilterMaster'
CREATE TABLE [dbo].[ReportFilterMaster] (
    [ReportFilterId] int  NOT NULL,
    [OrganizationId] int  NOT NULL,
    [FilterName] nvarchar(50)  NOT NULL,
    [ReportId] smallint  NOT NULL,
    [IsFavorite] bit  NOT NULL,
    [TimePeriod] smallint  NOT NULL,
    [StartDate] datetime  NULL,
    [EndDate] datetime  NULL,
    [SamplePlans] varchar(max)  NULL,
    [ResultFilter] smallint  NOT NULL,
    [TestTypes] varchar(max)  NULL,
    [IncludeRetest] bit  NOT NULL,
    [Locations] varchar(max)  NULL,
    [Parameters] nvarchar(max)  NULL,
    [AdditionalResultFilter] nvarchar(max)  NULL,
    [ResultValueMax] float  NULL,
    [ResultValueMin] float  NULL,
    [Testers] nvarchar(max)  NULL,
    [CreatedDate] datetime  NOT NULL,
    [CreatedBy] int  NOT NULL
);
GO

-- Creating table 'RolePermissionsForAudit'
CREATE TABLE [dbo].[RolePermissionsForAudit] (
    [Id] int  NOT NULL,
    [OrganizationId] int  NOT NULL,
    [RoleId] smallint  NOT NULL,
    [FeatureGroupKey] smallint  NOT NULL,
    [Permission] smallint  NOT NULL,
    [CreatedBy] int  NOT NULL,
    [LastEditedBy] int  NULL,
    [SrNo] int IDENTITY(1,1) NOT NULL
);
GO

-- Creating table 'ScheduleMaster'
CREATE TABLE [dbo].[ScheduleMaster] (
    [OrganizationId] int  NOT NULL,
    [ScheduleId] int  NOT NULL,
    [ReportFilterId] int  NOT NULL,
    [PeriodType] smallint  NOT NULL,
    [DaysOfWeek] varbinary(7)  NULL,
    [DayOfMonth] smallint  NULL,
    [TimeOfDay] time  NULL,
    [LastRunDate] datetime  NULL,
    [CreatedBy] int  NOT NULL,
    [CreatedDate] datetime  NOT NULL
);
GO

-- Creating table 'DashBoardView'
CREATE TABLE [dbo].[DashBoardView] (
    [RowNo] bigint  NOT NULL,
    [OrganizationId] int  NOT NULL,
    [ResultId] bigint  NULL,
    [MeasurementId] int  NOT NULL,
    [TestPlanId] int  NOT NULL,
    [TestPlanName] nvarchar(50)  NOT NULL,
    [OpenedDate] datetime  NULL,
    [TestPointId] int  NULL,
    [TestPointName] nvarchar(53)  NOT NULL,
    [TestPointUniqueId] nvarchar(57)  NULL,
    [TestMethodId] smallint  NOT NULL,
    [TestMethodVersion] smallint  NOT NULL,
    [TestMethodName] nvarchar(50)  NULL,
    [LocationId] int  NULL,
    [LocationName] nvarchar(50)  NOT NULL,
    [TesterId] int  NULL,
    [TesterName] nvarchar(100)  NULL,
    [Result] smallint  NULL,
    [ResultValue] float  NULL,
    [ResultDate] datetime  NULL,
    [CapaComments] nvarchar(1000)  NULL,
    [PassThreshold] decimal(10,2)  NULL,
    [FailThreshold] decimal(10,2)  NULL,
    [Adhoc] bit  NOT NULL,
    [Retest] bit  NOT NULL,
    [Mapped] bit  NOT NULL,
    [Edited] bit  NULL,
    [OriginalMeasurementId] int  NULL,
    [CreatedDate] datetime  NULL,
    [LastEditedBy] int  NULL,
    [LastEditDate] datetime  NULL,
    [Is3MSwab] bit  NOT NULL,
    [UnitName] nvarchar(10)  NULL,
    [ReTestOrder] bigint  NULL,
    [Archived] varchar(1)  NOT NULL
);
GO

-- Creating table 'TestPlanResult'
CREATE TABLE [dbo].[TestPlanResult] (
    [ResultId] bigint IDENTITY(1,1) NOT NULL,
    [OrganizationId] int  NOT NULL,
    [TestPlanId] int  NOT NULL,
    [TestPlanVersion] smallint  NOT NULL,
    [TestPlanName] nvarchar(50)  NOT NULL,
    [LocationId] int  NULL,
    [LocationVersion] smallint  NOT NULL,
    [Status] smallint  NOT NULL,
    [OpenedDate] datetime  NOT NULL,
    [OpenedBy] int  NOT NULL,
    [DeviceId] nvarchar(50)  NOT NULL,
    [LastEditDate] datetime  NULL,
    [LastEditedBy] int  NULL,
    [ImportId] nvarchar(50)  NULL
);
GO

-- Creating table 'OrganizationRoleUserMapping'
CREATE TABLE [dbo].[OrganizationRoleUserMapping] (
    [OrganizationRoleMaster_OrganizationId] int  NOT NULL,
    [OrganizationRoleMaster_RoleId] smallint  NOT NULL,
    [OrganizationRoleUserMapping_OrganizationRoleMaster_UserId] int  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [OrganizationId] in table 'OrganizationMaster'
ALTER TABLE [dbo].[OrganizationMaster]
ADD CONSTRAINT [PK_OrganizationMaster]
    PRIMARY KEY CLUSTERED ([OrganizationId] ASC);
GO

-- Creating primary key on [CountryId] in table 'CountryMaster'
ALTER TABLE [dbo].[CountryMaster]
ADD CONSTRAINT [PK_CountryMaster]
    PRIMARY KEY CLUSTERED ([CountryId] ASC);
GO

-- Creating primary key on [OrganizationId], [RoleId] in table 'OrganizationRoleMaster'
ALTER TABLE [dbo].[OrganizationRoleMaster]
ADD CONSTRAINT [PK_OrganizationRoleMaster]
    PRIMARY KEY CLUSTERED ([OrganizationId], [RoleId] ASC);
GO

-- Creating primary key on [UserId] in table 'UserMaster'
ALTER TABLE [dbo].[UserMaster]
ADD CONSTRAINT [PK_UserMaster]
    PRIMARY KEY CLUSTERED ([UserId] ASC);
GO

-- Creating primary key on [RoleId] in table 'RoleMaster'
ALTER TABLE [dbo].[RoleMaster]
ADD CONSTRAINT [PK_RoleMaster]
    PRIMARY KEY CLUSTERED ([RoleId] ASC);
GO

-- Creating primary key on [ApplicationId] in table 'ApplicationMaster'
ALTER TABLE [dbo].[ApplicationMaster]
ADD CONSTRAINT [PK_ApplicationMaster]
    PRIMARY KEY CLUSTERED ([ApplicationId] ASC);
GO

-- Creating primary key on [LicenseId] in table 'LicenseTypeMaster'
ALTER TABLE [dbo].[LicenseTypeMaster]
ADD CONSTRAINT [PK_LicenseTypeMaster]
    PRIMARY KEY CLUSTERED ([LicenseId] ASC);
GO

-- Creating primary key on [FeatureId] in table 'FeatureMaster'
ALTER TABLE [dbo].[FeatureMaster]
ADD CONSTRAINT [PK_FeatureMaster]
    PRIMARY KEY CLUSTERED ([FeatureId] ASC);
GO

-- Creating primary key on [TestMethodId] in table 'TestMethodMaster'
ALTER TABLE [dbo].[TestMethodMaster]
ADD CONSTRAINT [PK_TestMethodMaster]
    PRIMARY KEY CLUSTERED ([TestMethodId] ASC);
GO

-- Creating primary key on [TestPointId], [TestPointVersion] in table 'TestPointMaster'
ALTER TABLE [dbo].[TestPointMaster]
ADD CONSTRAINT [PK_TestPointMaster]
    PRIMARY KEY CLUSTERED ([TestPointId], [TestPointVersion] ASC);
GO

-- Creating primary key on [TestPlanTypeId] in table 'TestPlanTypeMaster'
ALTER TABLE [dbo].[TestPlanTypeMaster]
ADD CONSTRAINT [PK_TestPlanTypeMaster]
    PRIMARY KEY CLUSTERED ([TestPlanTypeId] ASC);
GO

-- Creating primary key on [TestPlanId], [TestPlanVersion], [OrganizationId] in table 'TestPlanMaster'
ALTER TABLE [dbo].[TestPlanMaster]
ADD CONSTRAINT [PK_TestPlanMaster]
    PRIMARY KEY CLUSTERED ([TestPlanId], [TestPlanVersion], [OrganizationId] ASC);
GO

-- Creating primary key on [LocationId], [OrganizationId] in table 'LocationMaster'
ALTER TABLE [dbo].[LocationMaster]
ADD CONSTRAINT [PK_LocationMaster]
    PRIMARY KEY CLUSTERED ([LocationId], [OrganizationId] ASC);
GO

-- Creating primary key on [MeasurementId], [ResultId] in table 'TestPointResult'
ALTER TABLE [dbo].[TestPointResult]
ADD CONSTRAINT [PK_TestPointResult]
    PRIMARY KEY CLUSTERED ([MeasurementId], [ResultId] ASC);
GO

-- Creating primary key on [TimezoneId] in table 'TimezoneMaster'
ALTER TABLE [dbo].[TimezoneMaster]
ADD CONSTRAINT [PK_TimezoneMaster]
    PRIMARY KEY CLUSTERED ([TimezoneId] ASC);
GO

-- Creating primary key on [OrganizationTypeId] in table 'OrganizationTypeMaster'
ALTER TABLE [dbo].[OrganizationTypeMaster]
ADD CONSTRAINT [PK_OrganizationTypeMaster]
    PRIMARY KEY CLUSTERED ([OrganizationTypeId] ASC);
GO

-- Creating primary key on [SwabTypeId] in table 'SwabTypeMaster'
ALTER TABLE [dbo].[SwabTypeMaster]
ADD CONSTRAINT [PK_SwabTypeMaster]
    PRIMARY KEY CLUSTERED ([SwabTypeId] ASC);
GO

-- Creating primary key on [OrganizationId] in table 'OrganizationConfiguration'
ALTER TABLE [dbo].[OrganizationConfiguration]
ADD CONSTRAINT [PK_OrganizationConfiguration]
    PRIMARY KEY CLUSTERED ([OrganizationId] ASC);
GO

-- Creating primary key on [OrganizationId] in table 'OrganizationImageMaster'
ALTER TABLE [dbo].[OrganizationImageMaster]
ADD CONSTRAINT [PK_OrganizationImageMaster]
    PRIMARY KEY CLUSTERED ([OrganizationId] ASC);
GO

-- Creating primary key on [ScheduleId], [OrganizationId] in table 'ScheduleDefinitionMaster'
ALTER TABLE [dbo].[ScheduleDefinitionMaster]
ADD CONSTRAINT [PK_ScheduleDefinitionMaster]
    PRIMARY KEY CLUSTERED ([ScheduleId], [OrganizationId] ASC);
GO

-- Creating primary key on [CommentId], [OrganizationId] in table 'OrganizationComments'
ALTER TABLE [dbo].[OrganizationComments]
ADD CONSTRAINT [PK_OrganizationComments]
    PRIMARY KEY CLUSTERED ([CommentId], [OrganizationId] ASC);
GO

-- Creating primary key on [UserId] in table 'UserPreferences'
ALTER TABLE [dbo].[UserPreferences]
ADD CONSTRAINT [PK_UserPreferences]
    PRIMARY KEY CLUSTERED ([UserId] ASC);
GO

-- Creating primary key on [TestPlanId], [TestPlanVersion], [OrganizationId], [TestPointId], [TestPointVersion] in table 'TestPlanTestPointMapping'
ALTER TABLE [dbo].[TestPlanTestPointMapping]
ADD CONSTRAINT [PK_TestPlanTestPointMapping]
    PRIMARY KEY CLUSTERED ([TestPlanId], [TestPlanVersion], [OrganizationId], [TestPointId], [TestPointVersion] ASC);
GO

-- Creating primary key on [SyncId], [OrganizationId] in table 'DeviceSyncDetails'
ALTER TABLE [dbo].[DeviceSyncDetails]
ADD CONSTRAINT [PK_DeviceSyncDetails]
    PRIMARY KEY CLUSTERED ([SyncId], [OrganizationId] ASC);
GO

-- Creating primary key on [AttemptId] in table 'FailedLoginAttempts'
ALTER TABLE [dbo].[FailedLoginAttempts]
ADD CONSTRAINT [PK_FailedLoginAttempts]
    PRIMARY KEY CLUSTERED ([AttemptId] ASC);
GO

-- Creating primary key on [ReportId] in table 'ReportMaster'
ALTER TABLE [dbo].[ReportMaster]
ADD CONSTRAINT [PK_ReportMaster]
    PRIMARY KEY CLUSTERED ([ReportId] ASC);
GO

-- Creating primary key on [OrganizationId], [ScheduleId] in table 'ScheduleDaysOfWeek'
ALTER TABLE [dbo].[ScheduleDaysOfWeek]
ADD CONSTRAINT [PK_ScheduleDaysOfWeek]
    PRIMARY KEY CLUSTERED ([OrganizationId], [ScheduleId] ASC);
GO

-- Creating primary key on [ScheduleId], [OrganizationId] in table 'ScheduleMonthsOfYear'
ALTER TABLE [dbo].[ScheduleMonthsOfYear]
ADD CONSTRAINT [PK_ScheduleMonthsOfYear]
    PRIMARY KEY CLUSTERED ([ScheduleId], [OrganizationId] ASC);
GO

-- Creating primary key on [ScheduleId], [OrganizationId] in table 'ScheduleWeeksOfMonth'
ALTER TABLE [dbo].[ScheduleWeeksOfMonth]
ADD CONSTRAINT [PK_ScheduleWeeksOfMonth]
    PRIMARY KEY CLUSTERED ([ScheduleId], [OrganizationId] ASC);
GO

-- Creating primary key on [OrganizationId], [ScheduleId] in table 'ScheduleDaysOfMonth'
ALTER TABLE [dbo].[ScheduleDaysOfMonth]
ADD CONSTRAINT [PK_ScheduleDaysOfMonth]
    PRIMARY KEY CLUSTERED ([OrganizationId], [ScheduleId] ASC);
GO

-- Creating primary key on [PreferenceId] in table 'UserDashboardPreferences'
ALTER TABLE [dbo].[UserDashboardPreferences]
ADD CONSTRAINT [PK_UserDashboardPreferences]
    PRIMARY KEY CLUSTERED ([PreferenceId] ASC);
GO

-- Creating primary key on [RegionId] in table 'RegionMaster'
ALTER TABLE [dbo].[RegionMaster]
ADD CONSTRAINT [PK_RegionMaster]
    PRIMARY KEY CLUSTERED ([RegionId] ASC);
GO

-- Creating primary key on [Id] in table 'EditMeasurement'
ALTER TABLE [dbo].[EditMeasurement]
ADD CONSTRAINT [PK_EditMeasurement]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [UserId], [CountryId] in table 'UserCountryMapping'
ALTER TABLE [dbo].[UserCountryMapping]
ADD CONSTRAINT [PK_UserCountryMapping]
    PRIMARY KEY NONCLUSTERED ([UserId], [CountryId] ASC);
GO

-- Creating primary key on [CategoryId] in table 'CustomCategory'
ALTER TABLE [dbo].[CustomCategory]
ADD CONSTRAINT [PK_CustomCategory]
    PRIMARY KEY CLUSTERED ([CategoryId] ASC);
GO

-- Creating primary key on [CommentId], [OrganizationId] in table 'CapaComments'
ALTER TABLE [dbo].[CapaComments]
ADD CONSTRAINT [PK_CapaComments]
    PRIMARY KEY CLUSTERED ([CommentId], [OrganizationId] ASC);
GO

-- Creating primary key on [TestMethodId], [OrganizationId] in table 'OrganizationTestMethodMaster'
ALTER TABLE [dbo].[OrganizationTestMethodMaster]
ADD CONSTRAINT [PK_OrganizationTestMethodMaster]
    PRIMARY KEY CLUSTERED ([TestMethodId], [OrganizationId] ASC);
GO

-- Creating primary key on [TestPointId], [TestPointVersion], [CategoryId], [OrganizationId], [ParameterId] in table 'TestPointCustomParameterMapping'
ALTER TABLE [dbo].[TestPointCustomParameterMapping]
ADD CONSTRAINT [PK_TestPointCustomParameterMapping]
    PRIMARY KEY NONCLUSTERED ([TestPointId], [TestPointVersion], [CategoryId], [OrganizationId], [ParameterId] ASC);
GO

-- Creating primary key on [OrganizationCategoryId], [OrganizationId] in table 'OrganizationCategoryMaster'
ALTER TABLE [dbo].[OrganizationCategoryMaster]
ADD CONSTRAINT [PK_OrganizationCategoryMaster]
    PRIMARY KEY CLUSTERED ([OrganizationCategoryId], [OrganizationId] ASC);
GO

-- Creating primary key on [OrganizationCategoryId], [OrganizationId], [ParameterId] in table 'OrganizationCustomParameterMaster'
ALTER TABLE [dbo].[OrganizationCustomParameterMaster]
ADD CONSTRAINT [PK_OrganizationCustomParameterMaster]
    PRIMARY KEY CLUSTERED ([OrganizationCategoryId], [OrganizationId], [ParameterId] ASC);
GO

-- Creating primary key on [VersionId] in table 'SupportedVersionMaster'
ALTER TABLE [dbo].[SupportedVersionMaster]
ADD CONSTRAINT [PK_SupportedVersionMaster]
    PRIMARY KEY CLUSTERED ([VersionId] ASC);
GO

-- Creating primary key on [LuminometerId] in table 'LuminometerMaster'
ALTER TABLE [dbo].[LuminometerMaster]
ADD CONSTRAINT [PK_LuminometerMaster]
    PRIMARY KEY CLUSTERED ([LuminometerId] ASC);
GO

-- Creating primary key on [WorkFlowId] in table 'WorkFlowMaster'
ALTER TABLE [dbo].[WorkFlowMaster]
ADD CONSTRAINT [PK_WorkFlowMaster]
    PRIMARY KEY CLUSTERED ([WorkFlowId] ASC);
GO

-- Creating primary key on [TestPointId], [TestPointVersion], [OrganizationId], [TestMethodId] in table 'TestPointTestMethodMapping'
ALTER TABLE [dbo].[TestPointTestMethodMapping]
ADD CONSTRAINT [PK_TestPointTestMethodMapping]
    PRIMARY KEY CLUSTERED ([TestPointId], [TestPointVersion], [OrganizationId], [TestMethodId] ASC);
GO

-- Creating primary key on [UserId], [OrganizationId], [TestPlanId], [TestPlanVersion] in table 'TestPlanUserMapping'
ALTER TABLE [dbo].[TestPlanUserMapping]
ADD CONSTRAINT [PK_TestPlanUserMapping]
    PRIMARY KEY CLUSTERED ([UserId], [OrganizationId], [TestPlanId], [TestPlanVersion] ASC);
GO

-- Creating primary key on [ResultId], [MeasurementId], [OrganizationCategoryId], [ParameterId], [ParameterVersion] in table 'TestResultCustomParameterMapping'
ALTER TABLE [dbo].[TestResultCustomParameterMapping]
ADD CONSTRAINT [PK_TestResultCustomParameterMapping]
    PRIMARY KEY CLUSTERED ([ResultId], [MeasurementId], [OrganizationCategoryId], [ParameterId], [ParameterVersion] ASC);
GO

-- Creating primary key on [OrganizationId], [LevelId] in table 'LocationLevelMaster'
ALTER TABLE [dbo].[LocationLevelMaster]
ADD CONSTRAINT [PK_LocationLevelMaster]
    PRIMARY KEY CLUSTERED ([OrganizationId], [LevelId] ASC);
GO

-- Creating primary key on [EditId] in table 'EditTestResultCustomParameterMapping'
ALTER TABLE [dbo].[EditTestResultCustomParameterMapping]
ADD CONSTRAINT [PK_EditTestResultCustomParameterMapping]
    PRIMARY KEY CLUSTERED ([EditId] ASC);
GO

-- Creating primary key on [AdhocMeasurementId], [AdhocResultId] in table 'AdhocTestPointResult'
ALTER TABLE [dbo].[AdhocTestPointResult]
ADD CONSTRAINT [PK_AdhocTestPointResult]
    PRIMARY KEY CLUSTERED ([AdhocMeasurementId], [AdhocResultId] ASC);
GO

-- Creating primary key on [AdhocResultId] in table 'AdhocTestPlanResult'
ALTER TABLE [dbo].[AdhocTestPlanResult]
ADD CONSTRAINT [PK_AdhocTestPlanResult]
    PRIMARY KEY CLUSTERED ([AdhocResultId] ASC);
GO

-- Creating primary key on [MenuId] in table 'Menu'
ALTER TABLE [dbo].[Menu]
ADD CONSTRAINT [PK_Menu]
    PRIMARY KEY CLUSTERED ([MenuId] ASC);
GO

-- Creating primary key on [Id] in table 'FeatureGroup'
ALTER TABLE [dbo].[FeatureGroup]
ADD CONSTRAINT [PK_FeatureGroup]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [CommonTaskId] in table 'CommonTasks'
ALTER TABLE [dbo].[CommonTasks]
ADD CONSTRAINT [PK_CommonTasks]
    PRIMARY KEY CLUSTERED ([CommonTaskId] ASC);
GO

-- Creating primary key on [OrganizationId], [TestMethodId], [TestMethodVersion] in table 'OrganizationTestMethodVersions'
ALTER TABLE [dbo].[OrganizationTestMethodVersions]
ADD CONSTRAINT [PK_OrganizationTestMethodVersions]
    PRIMARY KEY CLUSTERED ([OrganizationId], [TestMethodId], [TestMethodVersion] ASC);
GO

-- Creating primary key on [UnitId] in table 'UnitMaster'
ALTER TABLE [dbo].[UnitMaster]
ADD CONSTRAINT [PK_UnitMaster]
    PRIMARY KEY CLUSTERED ([UnitId] ASC);
GO

-- Creating primary key on [ParameterVersion], [ParameterId], [OrganizationId], [OrganizationCategoryId] in table 'OrganizationCustomParameterVersions'
ALTER TABLE [dbo].[OrganizationCustomParameterVersions]
ADD CONSTRAINT [PK_OrganizationCustomParameterVersions]
    PRIMARY KEY CLUSTERED ([ParameterVersion], [ParameterId], [OrganizationId], [OrganizationCategoryId] ASC);
GO

-- Creating primary key on [ReportId] in table 'UserReportPreferences'
ALTER TABLE [dbo].[UserReportPreferences]
ADD CONSTRAINT [PK_UserReportPreferences]
    PRIMARY KEY CLUSTERED ([ReportId] ASC);
GO

-- Creating primary key on [ReportId], [LocationId] in table 'ReportLocationMapping'
ALTER TABLE [dbo].[ReportLocationMapping]
ADD CONSTRAINT [PK_ReportLocationMapping]
    PRIMARY KEY CLUSTERED ([ReportId], [LocationId] ASC);
GO

-- Creating primary key on [MappingId] in table 'DashboardSPMapping'
ALTER TABLE [dbo].[DashboardSPMapping]
ADD CONSTRAINT [PK_DashboardSPMapping]
    PRIMARY KEY CLUSTERED ([MappingId] ASC);
GO

-- Creating primary key on [Id] in table 'ServiceRunLog'
ALTER TABLE [dbo].[ServiceRunLog]
ADD CONSTRAINT [PK_ServiceRunLog]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [ReportScheduleId], [OrganizationId] in table 'SamplePlanSchedule'
ALTER TABLE [dbo].[SamplePlanSchedule]
ADD CONSTRAINT [PK_SamplePlanSchedule]
    PRIMARY KEY CLUSTERED ([ReportScheduleId], [OrganizationId] ASC);
GO

-- Creating primary key on [ReportScheduleId], [OrganizationId], [ResultId] in table 'ResultScheduleMapping'
ALTER TABLE [dbo].[ResultScheduleMapping]
ADD CONSTRAINT [PK_ResultScheduleMapping]
    PRIMARY KEY CLUSTERED ([ReportScheduleId], [OrganizationId], [ResultId] ASC);
GO

-- Creating primary key on [Id], [OrganizationId] in table 'RolePermissions'
ALTER TABLE [dbo].[RolePermissions]
ADD CONSTRAINT [PK_RolePermissions]
    PRIMARY KEY CLUSTERED ([Id], [OrganizationId] ASC);
GO

-- Creating primary key on [Id] in table 'AdhocEditMeasurement'
ALTER TABLE [dbo].[AdhocEditMeasurement]
ADD CONSTRAINT [PK_AdhocEditMeasurement]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [AuditLogId] in table 'AuditLogMaster'
ALTER TABLE [dbo].[AuditLogMaster]
ADD CONSTRAINT [PK_AuditLogMaster]
    PRIMARY KEY CLUSTERED ([AuditLogId] ASC);
GO

-- Creating primary key on [AuditLogDetailId] in table 'AuditLogDetails'
ALTER TABLE [dbo].[AuditLogDetails]
ADD CONSTRAINT [PK_AuditLogDetails]
    PRIMARY KEY CLUSTERED ([AuditLogDetailId] ASC);
GO

-- Creating primary key on [ArchivalId] in table 'ArchivalMaster'
ALTER TABLE [dbo].[ArchivalMaster]
ADD CONSTRAINT [PK_ArchivalMaster]
    PRIMARY KEY CLUSTERED ([ArchivalId] ASC);
GO

-- Creating primary key on [Id] in table 'ApplicationInformation'
ALTER TABLE [dbo].[ApplicationInformation]
ADD CONSTRAINT [PK_ApplicationInformation]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [ReportFilterId], [OrganizationId] in table 'ReportFilterMaster'
ALTER TABLE [dbo].[ReportFilterMaster]
ADD CONSTRAINT [PK_ReportFilterMaster]
    PRIMARY KEY CLUSTERED ([ReportFilterId], [OrganizationId] ASC);
GO

-- Creating primary key on [SrNo] in table 'RolePermissionsForAudit'
ALTER TABLE [dbo].[RolePermissionsForAudit]
ADD CONSTRAINT [PK_RolePermissionsForAudit]
    PRIMARY KEY CLUSTERED ([SrNo] ASC);
GO

-- Creating primary key on [OrganizationId], [ScheduleId] in table 'ScheduleMaster'
ALTER TABLE [dbo].[ScheduleMaster]
ADD CONSTRAINT [PK_ScheduleMaster]
    PRIMARY KEY CLUSTERED ([OrganizationId], [ScheduleId] ASC);
GO

-- Creating primary key on [OrganizationId], [MeasurementId], [TestPlanId], [TestPlanName], [TestPointName], [TestMethodId], [TestMethodVersion], [LocationName], [Adhoc], [Retest], [Mapped], [Is3MSwab], [Archived], [RowNo] in table 'DashBoardView'
ALTER TABLE [dbo].[DashBoardView]
ADD CONSTRAINT [PK_DashBoardView]
    PRIMARY KEY CLUSTERED ([OrganizationId], [MeasurementId], [TestPlanId], [TestPlanName], [TestPointName], [TestMethodId], [TestMethodVersion], [LocationName], [Adhoc], [Retest], [Mapped], [Is3MSwab], [Archived], [RowNo] ASC);
GO

-- Creating primary key on [ResultId] in table 'TestPlanResult'
ALTER TABLE [dbo].[TestPlanResult]
ADD CONSTRAINT [PK_TestPlanResult]
    PRIMARY KEY CLUSTERED ([ResultId] ASC);
GO

-- Creating primary key on [OrganizationRoleMaster_OrganizationId], [OrganizationRoleMaster_RoleId], [OrganizationRoleUserMapping_OrganizationRoleMaster_UserId] in table 'OrganizationRoleUserMapping'
ALTER TABLE [dbo].[OrganizationRoleUserMapping]
ADD CONSTRAINT [PK_OrganizationRoleUserMapping]
    PRIMARY KEY NONCLUSTERED ([OrganizationRoleMaster_OrganizationId], [OrganizationRoleMaster_RoleId], [OrganizationRoleUserMapping_OrganizationRoleMaster_UserId] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [OrganizationId] in table 'OrganizationRoleMaster'
ALTER TABLE [dbo].[OrganizationRoleMaster]
ADD CONSTRAINT [FK_OrganizationMasterOrganizationRoleMaster]
    FOREIGN KEY ([OrganizationId])
    REFERENCES [dbo].[OrganizationMaster]
        ([OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [TestPlanTypeId] in table 'TestPlanMaster'
ALTER TABLE [dbo].[TestPlanMaster]
ADD CONSTRAINT [FK_TestPlanTestPlanType]
    FOREIGN KEY ([TestPlanTypeId])
    REFERENCES [dbo].[TestPlanTypeMaster]
        ([TestPlanTypeId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_TestPlanTestPlanType'
CREATE INDEX [IX_FK_TestPlanTestPlanType]
ON [dbo].[TestPlanMaster]
    ([TestPlanTypeId]);
GO

-- Creating foreign key on [OrganizationId] in table 'TestPointMaster'
ALTER TABLE [dbo].[TestPointMaster]
ADD CONSTRAINT [FK_OrganizationID]
    FOREIGN KEY ([OrganizationId])
    REFERENCES [dbo].[OrganizationMaster]
        ([OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_OrganizationID'
CREATE INDEX [IX_FK_OrganizationID]
ON [dbo].[TestPointMaster]
    ([OrganizationId]);
GO

-- Creating foreign key on [OrganizationId] in table 'TestPlanMaster'
ALTER TABLE [dbo].[TestPlanMaster]
ADD CONSTRAINT [FK_OrganizationMasterTestPlanMaster]
    FOREIGN KEY ([OrganizationId])
    REFERENCES [dbo].[OrganizationMaster]
        ([OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_OrganizationMasterTestPlanMaster'
CREATE INDEX [IX_FK_OrganizationMasterTestPlanMaster]
ON [dbo].[TestPlanMaster]
    ([OrganizationId]);
GO

-- Creating foreign key on [OrganizationId] in table 'LocationMaster'
ALTER TABLE [dbo].[LocationMaster]
ADD CONSTRAINT [FK_OrganizationMasterAreaMaster]
    FOREIGN KEY ([OrganizationId])
    REFERENCES [dbo].[OrganizationMaster]
        ([OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_OrganizationMasterAreaMaster'
CREATE INDEX [IX_FK_OrganizationMasterAreaMaster]
ON [dbo].[LocationMaster]
    ([OrganizationId]);
GO

-- Creating foreign key on [OrganizationRoleMaster_OrganizationId], [OrganizationRoleMaster_RoleId] in table 'OrganizationRoleUserMapping'
ALTER TABLE [dbo].[OrganizationRoleUserMapping]
ADD CONSTRAINT [FK_OrganizationRoleUserMapping_OrganizationRoleMaster]
    FOREIGN KEY ([OrganizationRoleMaster_OrganizationId], [OrganizationRoleMaster_RoleId])
    REFERENCES [dbo].[OrganizationRoleMaster]
        ([OrganizationId], [RoleId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [OrganizationRoleUserMapping_OrganizationRoleMaster_UserId] in table 'OrganizationRoleUserMapping'
ALTER TABLE [dbo].[OrganizationRoleUserMapping]
ADD CONSTRAINT [FK_OrganizationRoleUserMapping_UserMaster]
    FOREIGN KEY ([OrganizationRoleUserMapping_OrganizationRoleMaster_UserId])
    REFERENCES [dbo].[UserMaster]
        ([UserId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_OrganizationRoleUserMapping_UserMaster'
CREATE INDEX [IX_FK_OrganizationRoleUserMapping_UserMaster]
ON [dbo].[OrganizationRoleUserMapping]
    ([OrganizationRoleUserMapping_OrganizationRoleMaster_UserId]);
GO

-- Creating foreign key on [OrganizationId] in table 'OrganizationConfiguration'
ALTER TABLE [dbo].[OrganizationConfiguration]
ADD CONSTRAINT [FK_OrganizationConfigurationId]
    FOREIGN KEY ([OrganizationId])
    REFERENCES [dbo].[OrganizationMaster]
        ([OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [OrganizationId] in table 'OrganizationImageMaster'
ALTER TABLE [dbo].[OrganizationImageMaster]
ADD CONSTRAINT [FK_OrganizationImage]
    FOREIGN KEY ([OrganizationId])
    REFERENCES [dbo].[OrganizationMaster]
        ([OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [OrganizationId] in table 'OrganizationComments'
ALTER TABLE [dbo].[OrganizationComments]
ADD CONSTRAINT [FK_OrganizationMasterOrganizationComments]
    FOREIGN KEY ([OrganizationId])
    REFERENCES [dbo].[OrganizationMaster]
        ([OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_OrganizationMasterOrganizationComments'
CREATE INDEX [IX_FK_OrganizationMasterOrganizationComments]
ON [dbo].[OrganizationComments]
    ([OrganizationId]);
GO

-- Creating foreign key on [UserId] in table 'UserPreferences'
ALTER TABLE [dbo].[UserPreferences]
ADD CONSTRAINT [FK_UserMasterUserPreferences]
    FOREIGN KEY ([UserId])
    REFERENCES [dbo].[UserMaster]
        ([UserId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [OrganizationId] in table 'DeviceSyncDetails'
ALTER TABLE [dbo].[DeviceSyncDetails]
ADD CONSTRAINT [FK_OrganizationMasterDeviceSyncDetails]
    FOREIGN KEY ([OrganizationId])
    REFERENCES [dbo].[OrganizationMaster]
        ([OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_OrganizationMasterDeviceSyncDetails'
CREATE INDEX [IX_FK_OrganizationMasterDeviceSyncDetails]
ON [dbo].[DeviceSyncDetails]
    ([OrganizationId]);
GO

-- Creating foreign key on [ApplicationId] in table 'FeatureMaster'
ALTER TABLE [dbo].[FeatureMaster]
ADD CONSTRAINT [FK_ApplicationMasterFeatureMaster]
    FOREIGN KEY ([ApplicationId])
    REFERENCES [dbo].[ApplicationMaster]
        ([ApplicationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_ApplicationMasterFeatureMaster'
CREATE INDEX [IX_FK_ApplicationMasterFeatureMaster]
ON [dbo].[FeatureMaster]
    ([ApplicationId]);
GO

-- Creating foreign key on [ApplicationId] in table 'TestMethodMaster'
ALTER TABLE [dbo].[TestMethodMaster]
ADD CONSTRAINT [FK_ApplicationMasterTestMethodMaster]
    FOREIGN KEY ([ApplicationId])
    REFERENCES [dbo].[ApplicationMaster]
        ([ApplicationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_ApplicationMasterTestMethodMaster'
CREATE INDEX [IX_FK_ApplicationMasterTestMethodMaster]
ON [dbo].[TestMethodMaster]
    ([ApplicationId]);
GO

-- Creating foreign key on [ApplicationId] in table 'SwabTypeMaster'
ALTER TABLE [dbo].[SwabTypeMaster]
ADD CONSTRAINT [FK_ApplicationMasterSwabTypeMaster]
    FOREIGN KEY ([ApplicationId])
    REFERENCES [dbo].[ApplicationMaster]
        ([ApplicationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_ApplicationMasterSwabTypeMaster'
CREATE INDEX [IX_FK_ApplicationMasterSwabTypeMaster]
ON [dbo].[SwabTypeMaster]
    ([ApplicationId]);
GO

-- Creating foreign key on [ApplicationId] in table 'OrganizationTypeMaster'
ALTER TABLE [dbo].[OrganizationTypeMaster]
ADD CONSTRAINT [FK_ApplicationMasterOrganizationTypeMaster]
    FOREIGN KEY ([ApplicationId])
    REFERENCES [dbo].[ApplicationMaster]
        ([ApplicationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_ApplicationMasterOrganizationTypeMaster'
CREATE INDEX [IX_FK_ApplicationMasterOrganizationTypeMaster]
ON [dbo].[OrganizationTypeMaster]
    ([ApplicationId]);
GO

-- Creating foreign key on [ApplicationId] in table 'TestPlanTypeMaster'
ALTER TABLE [dbo].[TestPlanTypeMaster]
ADD CONSTRAINT [FK_ApplicationMasterTestPlanTypeMaster]
    FOREIGN KEY ([ApplicationId])
    REFERENCES [dbo].[ApplicationMaster]
        ([ApplicationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_ApplicationMasterTestPlanTypeMaster'
CREATE INDEX [IX_FK_ApplicationMasterTestPlanTypeMaster]
ON [dbo].[TestPlanTypeMaster]
    ([ApplicationId]);
GO

-- Creating foreign key on [TestPlanId], [TestPlanVersion], [OrganizationId] in table 'TestPlanTestPointMapping'
ALTER TABLE [dbo].[TestPlanTestPointMapping]
ADD CONSTRAINT [FK_TestPlanMasterTestPlanTestPointMapping]
    FOREIGN KEY ([TestPlanId], [TestPlanVersion], [OrganizationId])
    REFERENCES [dbo].[TestPlanMaster]
        ([TestPlanId], [TestPlanVersion], [OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [OrganizationId] in table 'ScheduleDefinitionMaster'
ALTER TABLE [dbo].[ScheduleDefinitionMaster]
ADD CONSTRAINT [FK_OrganizationMasterScheduleDefinitionMaster]
    FOREIGN KEY ([OrganizationId])
    REFERENCES [dbo].[OrganizationMaster]
        ([OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_OrganizationMasterScheduleDefinitionMaster'
CREATE INDEX [IX_FK_OrganizationMasterScheduleDefinitionMaster]
ON [dbo].[ScheduleDefinitionMaster]
    ([OrganizationId]);
GO

-- Creating foreign key on [ScheduleId], [OrganizationId] in table 'ScheduleDaysOfWeek'
ALTER TABLE [dbo].[ScheduleDaysOfWeek]
ADD CONSTRAINT [FK_ScheduleDaysOfWeekScheduleDefinitionMaster]
    FOREIGN KEY ([ScheduleId], [OrganizationId])
    REFERENCES [dbo].[ScheduleDefinitionMaster]
        ([ScheduleId], [OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [ScheduleId], [OrganizationId] in table 'ScheduleWeeksOfMonth'
ALTER TABLE [dbo].[ScheduleWeeksOfMonth]
ADD CONSTRAINT [FK_ScheduleWeeksOfMonthScheduleDefinitionMaster]
    FOREIGN KEY ([ScheduleId], [OrganizationId])
    REFERENCES [dbo].[ScheduleDefinitionMaster]
        ([ScheduleId], [OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [ScheduleId], [OrganizationId] in table 'ScheduleMonthsOfYear'
ALTER TABLE [dbo].[ScheduleMonthsOfYear]
ADD CONSTRAINT [FK_ScheduleMonthsOfYearScheduleDefinitionMaster]
    FOREIGN KEY ([ScheduleId], [OrganizationId])
    REFERENCES [dbo].[ScheduleDefinitionMaster]
        ([ScheduleId], [OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [ScheduleId], [OrganizationId] in table 'ScheduleDaysOfMonth'
ALTER TABLE [dbo].[ScheduleDaysOfMonth]
ADD CONSTRAINT [FK_ScheduleDefinitionMasterScheduleDaysOfMonth]
    FOREIGN KEY ([ScheduleId], [OrganizationId])
    REFERENCES [dbo].[ScheduleDefinitionMaster]
        ([ScheduleId], [OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [RegionId] in table 'CountryMaster'
ALTER TABLE [dbo].[CountryMaster]
ADD CONSTRAINT [FK_RegionMasterCountryMaster]
    FOREIGN KEY ([RegionId])
    REFERENCES [dbo].[RegionMaster]
        ([RegionId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_RegionMasterCountryMaster'
CREATE INDEX [IX_FK_RegionMasterCountryMaster]
ON [dbo].[CountryMaster]
    ([RegionId]);
GO

-- Creating foreign key on [UserId] in table 'UserCountryMapping'
ALTER TABLE [dbo].[UserCountryMapping]
ADD CONSTRAINT [FK_UserMasterUserCountryMapping]
    FOREIGN KEY ([UserId])
    REFERENCES [dbo].[UserMaster]
        ([UserId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [CountryId] in table 'UserCountryMapping'
ALTER TABLE [dbo].[UserCountryMapping]
ADD CONSTRAINT [FK_CountryMasterUserCountryMapping]
    FOREIGN KEY ([CountryId])
    REFERENCES [dbo].[CountryMaster]
        ([CountryId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_CountryMasterUserCountryMapping'
CREATE INDEX [IX_FK_CountryMasterUserCountryMapping]
ON [dbo].[UserCountryMapping]
    ([CountryId]);
GO

-- Creating foreign key on [ApplicationId] in table 'OrganizationTestMethodMaster'
ALTER TABLE [dbo].[OrganizationTestMethodMaster]
ADD CONSTRAINT [FK_ApplicationMasterOrganizationTestMethodMaster]
    FOREIGN KEY ([ApplicationId])
    REFERENCES [dbo].[ApplicationMaster]
        ([ApplicationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_ApplicationMasterOrganizationTestMethodMaster'
CREATE INDEX [IX_FK_ApplicationMasterOrganizationTestMethodMaster]
ON [dbo].[OrganizationTestMethodMaster]
    ([ApplicationId]);
GO

-- Creating foreign key on [OrganizationId] in table 'OrganizationTestMethodMaster'
ALTER TABLE [dbo].[OrganizationTestMethodMaster]
ADD CONSTRAINT [FK_OrganizationMasterOrganizationTestMethodMaster]
    FOREIGN KEY ([OrganizationId])
    REFERENCES [dbo].[OrganizationMaster]
        ([OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_OrganizationMasterOrganizationTestMethodMaster'
CREATE INDEX [IX_FK_OrganizationMasterOrganizationTestMethodMaster]
ON [dbo].[OrganizationTestMethodMaster]
    ([OrganizationId]);
GO

-- Creating foreign key on [OrganizationId] in table 'CapaComments'
ALTER TABLE [dbo].[CapaComments]
ADD CONSTRAINT [FK_OrganizationMasterCapaComments]
    FOREIGN KEY ([OrganizationId])
    REFERENCES [dbo].[OrganizationMaster]
        ([OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_OrganizationMasterCapaComments'
CREATE INDEX [IX_FK_OrganizationMasterCapaComments]
ON [dbo].[CapaComments]
    ([OrganizationId]);
GO

-- Creating foreign key on [TestPointId], [TestPointVersion] in table 'TestPointCustomParameterMapping'
ALTER TABLE [dbo].[TestPointCustomParameterMapping]
ADD CONSTRAINT [FK_TestPointMasterTestPointCustomParameterMapping]
    FOREIGN KEY ([TestPointId], [TestPointVersion])
    REFERENCES [dbo].[TestPointMaster]
        ([TestPointId], [TestPointVersion])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [OrganizationId] in table 'OrganizationCategoryMaster'
ALTER TABLE [dbo].[OrganizationCategoryMaster]
ADD CONSTRAINT [FK_OrganizationMasterOrganizationCategoryMaster]
    FOREIGN KEY ([OrganizationId])
    REFERENCES [dbo].[OrganizationMaster]
        ([OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_OrganizationMasterOrganizationCategoryMaster'
CREATE INDEX [IX_FK_OrganizationMasterOrganizationCategoryMaster]
ON [dbo].[OrganizationCategoryMaster]
    ([OrganizationId]);
GO

-- Creating foreign key on [OrganizationCategoryId], [OrganizationId] in table 'OrganizationCustomParameterMaster'
ALTER TABLE [dbo].[OrganizationCustomParameterMaster]
ADD CONSTRAINT [FK_OrganizationCategoryMasterOrganizationCustomParameterMaster]
    FOREIGN KEY ([OrganizationCategoryId], [OrganizationId])
    REFERENCES [dbo].[OrganizationCategoryMaster]
        ([OrganizationCategoryId], [OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [OrganizationId] in table 'LuminometerMaster'
ALTER TABLE [dbo].[LuminometerMaster]
ADD CONSTRAINT [FK_OrganizationMasterLuminometerMaster]
    FOREIGN KEY ([OrganizationId])
    REFERENCES [dbo].[OrganizationMaster]
        ([OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_OrganizationMasterLuminometerMaster'
CREATE INDEX [IX_FK_OrganizationMasterLuminometerMaster]
ON [dbo].[LuminometerMaster]
    ([OrganizationId]);
GO

-- Creating foreign key on [LocationId], [OrganizationId] in table 'TestPointMaster'
ALTER TABLE [dbo].[TestPointMaster]
ADD CONSTRAINT [FK_LocationMasterTestPointMaster]
    FOREIGN KEY ([LocationId], [OrganizationId])
    REFERENCES [dbo].[LocationMaster]
        ([LocationId], [OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_LocationMasterTestPointMaster'
CREATE INDEX [IX_FK_LocationMasterTestPointMaster]
ON [dbo].[TestPointMaster]
    ([LocationId], [OrganizationId]);
GO

-- Creating foreign key on [TestPointId], [TestPointVersion] in table 'TestPointTestMethodMapping'
ALTER TABLE [dbo].[TestPointTestMethodMapping]
ADD CONSTRAINT [FK_TestPointMasterTestPointTestMethodMapping]
    FOREIGN KEY ([TestPointId], [TestPointVersion])
    REFERENCES [dbo].[TestPointMaster]
        ([TestPointId], [TestPointVersion])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [UserId] in table 'TestPlanUserMapping'
ALTER TABLE [dbo].[TestPlanUserMapping]
ADD CONSTRAINT [FK_UserMasterTestPlanUserMapping]
    FOREIGN KEY ([UserId])
    REFERENCES [dbo].[UserMaster]
        ([UserId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [TestPlanId], [TestPlanVersion], [OrganizationId] in table 'TestPlanUserMapping'
ALTER TABLE [dbo].[TestPlanUserMapping]
ADD CONSTRAINT [FK_TestPlanMasterTestPlanUserMapping]
    FOREIGN KEY ([TestPlanId], [TestPlanVersion], [OrganizationId])
    REFERENCES [dbo].[TestPlanMaster]
        ([TestPlanId], [TestPlanVersion], [OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_TestPlanMasterTestPlanUserMapping'
CREATE INDEX [IX_FK_TestPlanMasterTestPlanUserMapping]
ON [dbo].[TestPlanUserMapping]
    ([TestPlanId], [TestPlanVersion], [OrganizationId]);
GO

-- Creating foreign key on [TestPointId], [TestPointVersion] in table 'TestPlanTestPointMapping'
ALTER TABLE [dbo].[TestPlanTestPointMapping]
ADD CONSTRAINT [FK_TestPointMasterTestPlanTestPointMapping]
    FOREIGN KEY ([TestPointId], [TestPointVersion])
    REFERENCES [dbo].[TestPointMaster]
        ([TestPointId], [TestPointVersion])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_TestPointMasterTestPlanTestPointMapping'
CREATE INDEX [IX_FK_TestPointMasterTestPlanTestPointMapping]
ON [dbo].[TestPlanTestPointMapping]
    ([TestPointId], [TestPointVersion]);
GO

-- Creating foreign key on [OrganizationId] in table 'LocationLevelMaster'
ALTER TABLE [dbo].[LocationLevelMaster]
ADD CONSTRAINT [FK_OrganizationMasterLocationLevelMaster]
    FOREIGN KEY ([OrganizationId])
    REFERENCES [dbo].[OrganizationMaster]
        ([OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [Id] in table 'EditTestResultCustomParameterMapping'
ALTER TABLE [dbo].[EditTestResultCustomParameterMapping]
ADD CONSTRAINT [FK_EditMeasurementEditTestResultCustomParameterMapping]
    FOREIGN KEY ([Id])
    REFERENCES [dbo].[EditMeasurement]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_EditMeasurementEditTestResultCustomParameterMapping'
CREATE INDEX [IX_FK_EditMeasurementEditTestResultCustomParameterMapping]
ON [dbo].[EditTestResultCustomParameterMapping]
    ([Id]);
GO

-- Creating foreign key on [AdhocResultId] in table 'AdhocTestPointResult'
ALTER TABLE [dbo].[AdhocTestPointResult]
ADD CONSTRAINT [FK_AdhocTestPlanResultAdhocTestPointResult]
    FOREIGN KEY ([AdhocResultId])
    REFERENCES [dbo].[AdhocTestPlanResult]
        ([AdhocResultId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_AdhocTestPlanResultAdhocTestPointResult'
CREATE INDEX [IX_FK_AdhocTestPlanResultAdhocTestPointResult]
ON [dbo].[AdhocTestPointResult]
    ([AdhocResultId]);
GO

-- Creating foreign key on [OrganizationId] in table 'UserDashboardPreferences'
ALTER TABLE [dbo].[UserDashboardPreferences]
ADD CONSTRAINT [FK_OrganizationMasterUserDashboardPreferences1]
    FOREIGN KEY ([OrganizationId])
    REFERENCES [dbo].[OrganizationMaster]
        ([OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_OrganizationMasterUserDashboardPreferences1'
CREATE INDEX [IX_FK_OrganizationMasterUserDashboardPreferences1]
ON [dbo].[UserDashboardPreferences]
    ([OrganizationId]);
GO

-- Creating foreign key on [TestMethodId], [OrganizationId] in table 'OrganizationTestMethodVersions'
ALTER TABLE [dbo].[OrganizationTestMethodVersions]
ADD CONSTRAINT [FK_OrganizationTestMethodMasterOrganizationTestMethodVersions]
    FOREIGN KEY ([TestMethodId], [OrganizationId])
    REFERENCES [dbo].[OrganizationTestMethodMaster]
        ([TestMethodId], [OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [TestMethodId], [OrganizationId] in table 'TestPointTestMethodMapping'
ALTER TABLE [dbo].[TestPointTestMethodMapping]
ADD CONSTRAINT [FK_OrganizationTestMethodMasterTestPointTestMethodMapping]
    FOREIGN KEY ([TestMethodId], [OrganizationId])
    REFERENCES [dbo].[OrganizationTestMethodMaster]
        ([TestMethodId], [OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_OrganizationTestMethodMasterTestPointTestMethodMapping'
CREATE INDEX [IX_FK_OrganizationTestMethodMasterTestPointTestMethodMapping]
ON [dbo].[TestPointTestMethodMapping]
    ([TestMethodId], [OrganizationId]);
GO

-- Creating foreign key on [UnitId] in table 'OrganizationTestMethodVersions'
ALTER TABLE [dbo].[OrganizationTestMethodVersions]
ADD CONSTRAINT [FK_UnitMasterOrganizationTestMethodVersionMaster]
    FOREIGN KEY ([UnitId])
    REFERENCES [dbo].[UnitMaster]
        ([UnitId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_UnitMasterOrganizationTestMethodVersionMaster'
CREATE INDEX [IX_FK_UnitMasterOrganizationTestMethodVersionMaster]
ON [dbo].[OrganizationTestMethodVersions]
    ([UnitId]);
GO

-- Creating foreign key on [CategoryId], [OrganizationId], [ParameterId] in table 'TestPointCustomParameterMapping'
ALTER TABLE [dbo].[TestPointCustomParameterMapping]
ADD CONSTRAINT [FK_OrganizationCustomParameterMasterTestPointCustomParameterMapping]
    FOREIGN KEY ([CategoryId], [OrganizationId], [ParameterId])
    REFERENCES [dbo].[OrganizationCustomParameterMaster]
        ([OrganizationCategoryId], [OrganizationId], [ParameterId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_OrganizationCustomParameterMasterTestPointCustomParameterMapping'
CREATE INDEX [IX_FK_OrganizationCustomParameterMasterTestPointCustomParameterMapping]
ON [dbo].[TestPointCustomParameterMapping]
    ([CategoryId], [OrganizationId], [ParameterId]);
GO

-- Creating foreign key on [OrganizationId] in table 'UserReportPreferences'
ALTER TABLE [dbo].[UserReportPreferences]
ADD CONSTRAINT [FK_OrganizationMasterUserReportPreferences]
    FOREIGN KEY ([OrganizationId])
    REFERENCES [dbo].[OrganizationMaster]
        ([OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_OrganizationMasterUserReportPreferences'
CREATE INDEX [IX_FK_OrganizationMasterUserReportPreferences]
ON [dbo].[UserReportPreferences]
    ([OrganizationId]);
GO

-- Creating foreign key on [UserId] in table 'UserReportPreferences'
ALTER TABLE [dbo].[UserReportPreferences]
ADD CONSTRAINT [FK_UserMasterUserReportPreferences]
    FOREIGN KEY ([UserId])
    REFERENCES [dbo].[UserMaster]
        ([UserId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_UserMasterUserReportPreferences'
CREATE INDEX [IX_FK_UserMasterUserReportPreferences]
ON [dbo].[UserReportPreferences]
    ([UserId]);
GO

-- Creating foreign key on [ReportId] in table 'ReportLocationMapping'
ALTER TABLE [dbo].[ReportLocationMapping]
ADD CONSTRAINT [FK_UserReportPreferencesReportLocationMapping]
    FOREIGN KEY ([ReportId])
    REFERENCES [dbo].[UserReportPreferences]
        ([ReportId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [PreferenceId] in table 'DashboardSPMapping'
ALTER TABLE [dbo].[DashboardSPMapping]
ADD CONSTRAINT [FK_UserDashboardPreferencesDashboardSPMapping]
    FOREIGN KEY ([PreferenceId])
    REFERENCES [dbo].[UserDashboardPreferences]
        ([PreferenceId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_UserDashboardPreferencesDashboardSPMapping'
CREATE INDEX [IX_FK_UserDashboardPreferencesDashboardSPMapping]
ON [dbo].[DashboardSPMapping]
    ([PreferenceId]);
GO

-- Creating foreign key on [OrganizationCategoryId], [OrganizationId], [ParameterId] in table 'OrganizationCustomParameterVersions'
ALTER TABLE [dbo].[OrganizationCustomParameterVersions]
ADD CONSTRAINT [FK_OrganizationCustomParameterMasterOrganizationCustomParameterVersions]
    FOREIGN KEY ([OrganizationCategoryId], [OrganizationId], [ParameterId])
    REFERENCES [dbo].[OrganizationCustomParameterMaster]
        ([OrganizationCategoryId], [OrganizationId], [ParameterId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_OrganizationCustomParameterMasterOrganizationCustomParameterVersions'
CREATE INDEX [IX_FK_OrganizationCustomParameterMasterOrganizationCustomParameterVersions]
ON [dbo].[OrganizationCustomParameterVersions]
    ([OrganizationCategoryId], [OrganizationId], [ParameterId]);
GO

-- Creating foreign key on [ScheduleDefinitionMasterId], [OrganizationId] in table 'SamplePlanSchedule'
ALTER TABLE [dbo].[SamplePlanSchedule]
ADD CONSTRAINT [FK_ScheduleDefinitionMasterSamplePlanSchedule]
    FOREIGN KEY ([ScheduleDefinitionMasterId], [OrganizationId])
    REFERENCES [dbo].[ScheduleDefinitionMaster]
        ([ScheduleId], [OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_ScheduleDefinitionMasterSamplePlanSchedule'
CREATE INDEX [IX_FK_ScheduleDefinitionMasterSamplePlanSchedule]
ON [dbo].[SamplePlanSchedule]
    ([ScheduleDefinitionMasterId], [OrganizationId]);
GO

-- Creating foreign key on [CommonTaskId] in table 'RolePermissions'
ALTER TABLE [dbo].[RolePermissions]
ADD CONSTRAINT [FK_CommonTasksRolePermissions]
    FOREIGN KEY ([CommonTaskId])
    REFERENCES [dbo].[CommonTasks]
        ([CommonTaskId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_CommonTasksRolePermissions'
CREATE INDEX [IX_FK_CommonTasksRolePermissions]
ON [dbo].[RolePermissions]
    ([CommonTaskId]);
GO

-- Creating foreign key on [MenuId] in table 'RolePermissions'
ALTER TABLE [dbo].[RolePermissions]
ADD CONSTRAINT [FK_MenuRolePermissions]
    FOREIGN KEY ([MenuId])
    REFERENCES [dbo].[Menu]
        ([MenuId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_MenuRolePermissions'
CREATE INDEX [IX_FK_MenuRolePermissions]
ON [dbo].[RolePermissions]
    ([MenuId]);
GO

-- Creating foreign key on [AuditLogId] in table 'AuditLogDetails'
ALTER TABLE [dbo].[AuditLogDetails]
ADD CONSTRAINT [FK_AuditLogMasterAuditLogDetails]
    FOREIGN KEY ([AuditLogId])
    REFERENCES [dbo].[AuditLogMaster]
        ([AuditLogId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_AuditLogMasterAuditLogDetails'
CREATE INDEX [IX_FK_AuditLogMasterAuditLogDetails]
ON [dbo].[AuditLogDetails]
    ([AuditLogId]);
GO

-- Creating foreign key on [OrganizationId] in table 'ScheduleMaster'
ALTER TABLE [dbo].[ScheduleMaster]
ADD CONSTRAINT [FK_ScheduleMaster_OrganizationMaster]
    FOREIGN KEY ([OrganizationId])
    REFERENCES [dbo].[OrganizationMaster]
        ([OrganizationId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [ResultId] in table 'TestPointResult'
ALTER TABLE [dbo].[TestPointResult]
ADD CONSTRAINT [FK_TestPlanResultTestPointResult]
    FOREIGN KEY ([ResultId])
    REFERENCES [dbo].[TestPlanResult]
        ([ResultId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_TestPlanResultTestPointResult'
CREATE INDEX [IX_FK_TestPlanResultTestPointResult]
ON [dbo].[TestPointResult]
    ([ResultId]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------