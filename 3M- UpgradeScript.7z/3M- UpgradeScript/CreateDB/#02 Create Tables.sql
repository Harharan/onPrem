USE [Spark]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserMasterUserReportPreferences]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserReportPreferences]'))
ALTER TABLE [dbo].[UserReportPreferences] DROP CONSTRAINT [FK_UserMasterUserReportPreferences]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterUserReportPreferences]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserReportPreferences]'))
ALTER TABLE [dbo].[UserReportPreferences] DROP CONSTRAINT [FK_OrganizationMasterUserReportPreferences]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserMasterUserPreferences]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserPreferences]'))
ALTER TABLE [dbo].[UserPreferences] DROP CONSTRAINT [FK_UserMasterUserPreferences]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterUserDashboardPreferences1]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserDashboardPreferences]'))
ALTER TABLE [dbo].[UserDashboardPreferences] DROP CONSTRAINT [FK_OrganizationMasterUserDashboardPreferences1]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserMasterUserCountryMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserCountryMapping]'))
ALTER TABLE [dbo].[UserCountryMapping] DROP CONSTRAINT [FK_UserMasterUserCountryMapping]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CountryMasterUserCountryMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserCountryMapping]'))
ALTER TABLE [dbo].[UserCountryMapping] DROP CONSTRAINT [FK_CountryMasterUserCountryMapping]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPointMasterTestPointTestMethodMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointTestMethodMapping]'))
ALTER TABLE [dbo].[TestPointTestMethodMapping] DROP CONSTRAINT [FK_TestPointMasterTestPointTestMethodMapping]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationTestMethodMasterTestPointTestMethodMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointTestMethodMapping]'))
ALTER TABLE [dbo].[TestPointTestMethodMapping] DROP CONSTRAINT [FK_OrganizationTestMethodMasterTestPointTestMethodMapping]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPlanResultTestPointResult]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointResult]'))
ALTER TABLE [dbo].[TestPointResult] DROP CONSTRAINT [FK_TestPlanResultTestPointResult]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationID]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointMaster]'))
ALTER TABLE [dbo].[TestPointMaster] DROP CONSTRAINT [FK_OrganizationID]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_LocationMasterTestPointMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointMaster]'))
ALTER TABLE [dbo].[TestPointMaster] DROP CONSTRAINT [FK_LocationMasterTestPointMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPointMasterTestPointCustomParameterMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointCustomParameterMapping]'))
ALTER TABLE [dbo].[TestPointCustomParameterMapping] DROP CONSTRAINT [FK_TestPointMasterTestPointCustomParameterMapping]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationCustomParameterMasterTestPointCustomParameterMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointCustomParameterMapping]'))
ALTER TABLE [dbo].[TestPointCustomParameterMapping] DROP CONSTRAINT [FK_OrganizationCustomParameterMasterTestPointCustomParameterMapping]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserMasterTestPlanUserMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPlanUserMapping]'))
ALTER TABLE [dbo].[TestPlanUserMapping] DROP CONSTRAINT [FK_UserMasterTestPlanUserMapping]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPlanMasterTestPlanUserMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPlanUserMapping]'))
ALTER TABLE [dbo].[TestPlanUserMapping] DROP CONSTRAINT [FK_TestPlanMasterTestPlanUserMapping]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ApplicationMasterTestPlanTypeMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPlanTypeMaster]'))
ALTER TABLE [dbo].[TestPlanTypeMaster] DROP CONSTRAINT [FK_ApplicationMasterTestPlanTypeMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPointMasterTestPlanTestPointMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPlanTestPointMapping]'))
ALTER TABLE [dbo].[TestPlanTestPointMapping] DROP CONSTRAINT [FK_TestPointMasterTestPlanTestPointMapping]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPlanMasterTestPlanTestPointMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPlanTestPointMapping]'))
ALTER TABLE [dbo].[TestPlanTestPointMapping] DROP CONSTRAINT [FK_TestPlanMasterTestPlanTestPointMapping]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPlanTestPlanType]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPlanMaster]'))
ALTER TABLE [dbo].[TestPlanMaster] DROP CONSTRAINT [FK_TestPlanTestPlanType]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterTestPlanMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPlanMaster]'))
ALTER TABLE [dbo].[TestPlanMaster] DROP CONSTRAINT [FK_OrganizationMasterTestPlanMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ApplicationMasterTestMethodMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestMethodMaster]'))
ALTER TABLE [dbo].[TestMethodMaster] DROP CONSTRAINT [FK_ApplicationMasterTestMethodMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ApplicationMasterSwabTypeMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[SwabTypeMaster]'))
ALTER TABLE [dbo].[SwabTypeMaster] DROP CONSTRAINT [FK_ApplicationMasterSwabTypeMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ScheduleWeeksOfMonthScheduleDefinitionMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[ScheduleWeeksOfMonth]'))
ALTER TABLE [dbo].[ScheduleWeeksOfMonth] DROP CONSTRAINT [FK_ScheduleWeeksOfMonthScheduleDefinitionMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ScheduleMonthsOfYearScheduleDefinitionMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[ScheduleMonthsOfYear]'))
ALTER TABLE [dbo].[ScheduleMonthsOfYear] DROP CONSTRAINT [FK_ScheduleMonthsOfYearScheduleDefinitionMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ScheduleMaster_OrganizationMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[ScheduleMaster]'))
ALTER TABLE [dbo].[ScheduleMaster] DROP CONSTRAINT [FK_ScheduleMaster_OrganizationMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterScheduleDefinitionMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[ScheduleDefinitionMaster]'))
ALTER TABLE [dbo].[ScheduleDefinitionMaster] DROP CONSTRAINT [FK_OrganizationMasterScheduleDefinitionMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ScheduleDaysOfWeekScheduleDefinitionMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[ScheduleDaysOfWeek]'))
ALTER TABLE [dbo].[ScheduleDaysOfWeek] DROP CONSTRAINT [FK_ScheduleDaysOfWeekScheduleDefinitionMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ScheduleDefinitionMasterScheduleDaysOfMonth]') AND parent_object_id = OBJECT_ID(N'[dbo].[ScheduleDaysOfMonth]'))
ALTER TABLE [dbo].[ScheduleDaysOfMonth] DROP CONSTRAINT [FK_ScheduleDefinitionMasterScheduleDaysOfMonth]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ScheduleDefinitionMasterSamplePlanSchedule]') AND parent_object_id = OBJECT_ID(N'[dbo].[SamplePlanSchedule]'))
ALTER TABLE [dbo].[SamplePlanSchedule] DROP CONSTRAINT [FK_ScheduleDefinitionMasterSamplePlanSchedule]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_MenuRolePermissions]') AND parent_object_id = OBJECT_ID(N'[dbo].[RolePermissions]'))
ALTER TABLE [dbo].[RolePermissions] DROP CONSTRAINT [FK_MenuRolePermissions]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CommonTasksRolePermissions]') AND parent_object_id = OBJECT_ID(N'[dbo].[RolePermissions]'))
ALTER TABLE [dbo].[RolePermissions] DROP CONSTRAINT [FK_CommonTasksRolePermissions]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserReportPreferencesReportLocationMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[ReportLocationMapping]'))
ALTER TABLE [dbo].[ReportLocationMapping] DROP CONSTRAINT [FK_UserReportPreferencesReportLocationMapping]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ApplicationMasterOrganizationTypeMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationTypeMaster]'))
ALTER TABLE [dbo].[OrganizationTypeMaster] DROP CONSTRAINT [FK_ApplicationMasterOrganizationTypeMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UnitMasterOrganizationTestMethodVersionMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodVersions]'))
ALTER TABLE [dbo].[OrganizationTestMethodVersions] DROP CONSTRAINT [FK_UnitMasterOrganizationTestMethodVersionMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationTestMethodMasterOrganizationTestMethodVersions]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodVersions]'))
ALTER TABLE [dbo].[OrganizationTestMethodVersions] DROP CONSTRAINT [FK_OrganizationTestMethodMasterOrganizationTestMethodVersions]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterOrganizationTestMethodMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodMaster]'))
ALTER TABLE [dbo].[OrganizationTestMethodMaster] DROP CONSTRAINT [FK_OrganizationMasterOrganizationTestMethodMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ApplicationMasterOrganizationTestMethodMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodMaster]'))
ALTER TABLE [dbo].[OrganizationTestMethodMaster] DROP CONSTRAINT [FK_ApplicationMasterOrganizationTestMethodMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationRoleUserMapping_UserMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationRoleUserMapping]'))
ALTER TABLE [dbo].[OrganizationRoleUserMapping] DROP CONSTRAINT [FK_OrganizationRoleUserMapping_UserMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationRoleUserMapping_OrganizationRoleMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationRoleUserMapping]'))
ALTER TABLE [dbo].[OrganizationRoleUserMapping] DROP CONSTRAINT [FK_OrganizationRoleUserMapping_OrganizationRoleMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterOrganizationRoleMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationRoleMaster]'))
ALTER TABLE [dbo].[OrganizationRoleMaster] DROP CONSTRAINT [FK_OrganizationMasterOrganizationRoleMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationImage]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationImageMaster]'))
ALTER TABLE [dbo].[OrganizationImageMaster] DROP CONSTRAINT [FK_OrganizationImage]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationCustomParameterMasterOrganizationCustomParameterVersions]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationCustomParameterVersions]'))
ALTER TABLE [dbo].[OrganizationCustomParameterVersions] DROP CONSTRAINT [FK_OrganizationCustomParameterMasterOrganizationCustomParameterVersions]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationCategoryMasterOrganizationCustomParameterMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationCustomParameterMaster]'))
ALTER TABLE [dbo].[OrganizationCustomParameterMaster] DROP CONSTRAINT [FK_OrganizationCategoryMasterOrganizationCustomParameterMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationConfigurationId]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationConfiguration]'))
ALTER TABLE [dbo].[OrganizationConfiguration] DROP CONSTRAINT [FK_OrganizationConfigurationId]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterOrganizationComments]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationComments]'))
ALTER TABLE [dbo].[OrganizationComments] DROP CONSTRAINT [FK_OrganizationMasterOrganizationComments]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterOrganizationCategoryMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationCategoryMaster]'))
ALTER TABLE [dbo].[OrganizationCategoryMaster] DROP CONSTRAINT [FK_OrganizationMasterOrganizationCategoryMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterLuminometerMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[LuminometerMaster]'))
ALTER TABLE [dbo].[LuminometerMaster] DROP CONSTRAINT [FK_OrganizationMasterLuminometerMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterAreaMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[LocationMaster]'))
ALTER TABLE [dbo].[LocationMaster] DROP CONSTRAINT [FK_OrganizationMasterAreaMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterLocationLevelMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[LocationLevelMaster]'))
ALTER TABLE [dbo].[LocationLevelMaster] DROP CONSTRAINT [FK_OrganizationMasterLocationLevelMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ApplicationMasterFeatureMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[FeatureMaster]'))
ALTER TABLE [dbo].[FeatureMaster] DROP CONSTRAINT [FK_ApplicationMasterFeatureMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_EditMeasurementEditTestResultCustomParameterMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[EditTestResultCustomParameterMapping]'))
ALTER TABLE [dbo].[EditTestResultCustomParameterMapping] DROP CONSTRAINT [FK_EditMeasurementEditTestResultCustomParameterMapping]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterDeviceSyncDetails]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceSyncDetails]'))
ALTER TABLE [dbo].[DeviceSyncDetails] DROP CONSTRAINT [FK_OrganizationMasterDeviceSyncDetails]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserDashboardPreferencesDashboardSPMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[DashboardSPMapping]'))
ALTER TABLE [dbo].[DashboardSPMapping] DROP CONSTRAINT [FK_UserDashboardPreferencesDashboardSPMapping]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_RegionMasterCountryMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[CountryMaster]'))
ALTER TABLE [dbo].[CountryMaster] DROP CONSTRAINT [FK_RegionMasterCountryMaster]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterCapaComments]') AND parent_object_id = OBJECT_ID(N'[dbo].[CapaComments]'))
ALTER TABLE [dbo].[CapaComments] DROP CONSTRAINT [FK_OrganizationMasterCapaComments]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_AuditLogMasterAuditLogDetails]') AND parent_object_id = OBJECT_ID(N'[dbo].[AuditLogDetails]'))
ALTER TABLE [dbo].[AuditLogDetails] DROP CONSTRAINT [FK_AuditLogMasterAuditLogDetails]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_AdhocTestPlanResultAdhocTestPointResult]') AND parent_object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]'))
ALTER TABLE [dbo].[AdhocTestPointResult] DROP CONSTRAINT [FK_AdhocTestPlanResultAdhocTestPointResult]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_LMPlantOrganizationId]') AND parent_object_id = OBJECT_ID(N'[dbo].[LuminometerPlantMapping]'))
ALTER TABLE [dbo].[LuminometerPlantMapping] DROP CONSTRAINT [FK_LMPlantOrganizationId]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_LMPlantLuminometerId]') AND parent_object_id = OBJECT_ID(N'[dbo].[LuminometerPlantMapping]'))
ALTER TABLE [dbo].[LuminometerPlantMapping] DROP CONSTRAINT [FK_LMPlantLuminometerId]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_LMPlantLocationId]') AND parent_object_id = OBJECT_ID(N'[dbo].[LuminometerPlantMapping]'))
ALTER TABLE [dbo].[LuminometerPlantMapping] DROP CONSTRAINT [FK_LMPlantLocationId]
GO

/****** Object:  Index [IX_FK_UserMasterUserReportPreferences]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[UserReportPreferences]') AND name = N'IX_FK_UserMasterUserReportPreferences')
DROP INDEX [IX_FK_UserMasterUserReportPreferences] ON [dbo].[UserReportPreferences]
GO
/****** Object:  Index [IX_FK_OrganizationMasterUserReportPreferences]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[UserReportPreferences]') AND name = N'IX_FK_OrganizationMasterUserReportPreferences')
DROP INDEX [IX_FK_OrganizationMasterUserReportPreferences] ON [dbo].[UserReportPreferences]
GO
/****** Object:  Index [IX_FK_OrganizationMasterUserDashboardPreferences1]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[UserDashboardPreferences]') AND name = N'IX_FK_OrganizationMasterUserDashboardPreferences1')
DROP INDEX [IX_FK_OrganizationMasterUserDashboardPreferences1] ON [dbo].[UserDashboardPreferences]
GO
/****** Object:  Index [IX_FK_CountryMasterUserCountryMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[UserCountryMapping]') AND name = N'IX_FK_CountryMasterUserCountryMapping')
DROP INDEX [IX_FK_CountryMasterUserCountryMapping] ON [dbo].[UserCountryMapping]
GO
/****** Object:  Index [IX_FK_OrganizationTestMethodMasterTestPointTestMethodMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPointTestMethodMapping]') AND name = N'IX_FK_OrganizationTestMethodMasterTestPointTestMethodMapping')
DROP INDEX [IX_FK_OrganizationTestMethodMasterTestPointTestMethodMapping] ON [dbo].[TestPointTestMethodMapping]
GO
/****** Object:  Index [NCI-TestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPointResult]') AND name = N'NCI-TestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To')
DROP INDEX [NCI-TestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To] ON [dbo].[TestPointResult]
GO
/****** Object:  Index [IX_FK_TestPlanResultTestPointResult]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPointResult]') AND name = N'IX_FK_TestPlanResultTestPointResult')
DROP INDEX [IX_FK_TestPlanResultTestPointResult] ON [dbo].[TestPointResult]
GO
/****** Object:  Index [IX_FK_OrganizationID]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPointMaster]') AND name = N'IX_FK_OrganizationID')
DROP INDEX [IX_FK_OrganizationID] ON [dbo].[TestPointMaster]
GO
/****** Object:  Index [IX_FK_LocationMasterTestPointMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPointMaster]') AND name = N'IX_FK_LocationMasterTestPointMaster')
DROP INDEX [IX_FK_LocationMasterTestPointMaster] ON [dbo].[TestPointMaster]
GO
/****** Object:  Index [IX_FK_OrganizationCustomParameterMasterTestPointCustomParameterMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPointCustomParameterMapping]') AND name = N'IX_FK_OrganizationCustomParameterMasterTestPointCustomParameterMapping')
DROP INDEX [IX_FK_OrganizationCustomParameterMasterTestPointCustomParameterMapping] ON [dbo].[TestPointCustomParameterMapping]
GO
/****** Object:  Index [IX_FK_TestPlanMasterTestPlanUserMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanUserMapping]') AND name = N'IX_FK_TestPlanMasterTestPlanUserMapping')
DROP INDEX [IX_FK_TestPlanMasterTestPlanUserMapping] ON [dbo].[TestPlanUserMapping]
GO
/****** Object:  Index [IX_FK_ApplicationMasterTestPlanTypeMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanTypeMaster]') AND name = N'IX_FK_ApplicationMasterTestPlanTypeMaster')
DROP INDEX [IX_FK_ApplicationMasterTestPlanTypeMaster] ON [dbo].[TestPlanTypeMaster]
GO
/****** Object:  Index [IX_FK_TestPointMasterTestPlanTestPointMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanTestPointMapping]') AND name = N'IX_FK_TestPointMasterTestPlanTestPointMapping')
DROP INDEX [IX_FK_TestPointMasterTestPlanTestPointMapping] ON [dbo].[TestPlanTestPointMapping]
GO
/****** Object:  Index [NCI-TestPlanResult-Oid-RidTplid]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanResult]') AND name = N'NCI-TestPlanResult-Oid-RidTplid')
DROP INDEX [NCI-TestPlanResult-Oid-RidTplid] ON [dbo].[TestPlanResult]
GO
/****** Object:  Index [IX_FK_TestPlanTestPlanType]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanMaster]') AND name = N'IX_FK_TestPlanTestPlanType')
DROP INDEX [IX_FK_TestPlanTestPlanType] ON [dbo].[TestPlanMaster]
GO
/****** Object:  Index [IX_FK_OrganizationMasterTestPlanMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanMaster]') AND name = N'IX_FK_OrganizationMasterTestPlanMaster')
DROP INDEX [IX_FK_OrganizationMasterTestPlanMaster] ON [dbo].[TestPlanMaster]
GO
/****** Object:  Index [IX_FK_ApplicationMasterTestMethodMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestMethodMaster]') AND name = N'IX_FK_ApplicationMasterTestMethodMaster')
DROP INDEX [IX_FK_ApplicationMasterTestMethodMaster] ON [dbo].[TestMethodMaster]
GO
/****** Object:  Index [IX_FK_ApplicationMasterSwabTypeMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[SwabTypeMaster]') AND name = N'IX_FK_ApplicationMasterSwabTypeMaster')
DROP INDEX [IX_FK_ApplicationMasterSwabTypeMaster] ON [dbo].[SwabTypeMaster]
GO
/****** Object:  Index [IX_FK_OrganizationMasterScheduleDefinitionMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[ScheduleDefinitionMaster]') AND name = N'IX_FK_OrganizationMasterScheduleDefinitionMaster')
DROP INDEX [IX_FK_OrganizationMasterScheduleDefinitionMaster] ON [dbo].[ScheduleDefinitionMaster]
GO
/****** Object:  Index [IX_FK_ScheduleDefinitionMasterSamplePlanSchedule]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[SamplePlanSchedule]') AND name = N'IX_FK_ScheduleDefinitionMasterSamplePlanSchedule')
DROP INDEX [IX_FK_ScheduleDefinitionMasterSamplePlanSchedule] ON [dbo].[SamplePlanSchedule]
GO
/****** Object:  Index [IX_FK_MenuRolePermissions]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[RolePermissions]') AND name = N'IX_FK_MenuRolePermissions')
DROP INDEX [IX_FK_MenuRolePermissions] ON [dbo].[RolePermissions]
GO
/****** Object:  Index [IX_FK_CommonTasksRolePermissions]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[RolePermissions]') AND name = N'IX_FK_CommonTasksRolePermissions')
DROP INDEX [IX_FK_CommonTasksRolePermissions] ON [dbo].[RolePermissions]
GO
/****** Object:  Index [IX_FK_ApplicationMasterOrganizationTypeMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationTypeMaster]') AND name = N'IX_FK_ApplicationMasterOrganizationTypeMaster')
DROP INDEX [IX_FK_ApplicationMasterOrganizationTypeMaster] ON [dbo].[OrganizationTypeMaster]
GO
/****** Object:  Index [IX_FK_UnitMasterOrganizationTestMethodVersionMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodVersions]') AND name = N'IX_FK_UnitMasterOrganizationTestMethodVersionMaster')
DROP INDEX [IX_FK_UnitMasterOrganizationTestMethodVersionMaster] ON [dbo].[OrganizationTestMethodVersions]
GO
/****** Object:  Index [IX_FK_OrganizationMasterOrganizationTestMethodMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodMaster]') AND name = N'IX_FK_OrganizationMasterOrganizationTestMethodMaster')
DROP INDEX [IX_FK_OrganizationMasterOrganizationTestMethodMaster] ON [dbo].[OrganizationTestMethodMaster]
GO
/****** Object:  Index [IX_FK_ApplicationMasterOrganizationTestMethodMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodMaster]') AND name = N'IX_FK_ApplicationMasterOrganizationTestMethodMaster')
DROP INDEX [IX_FK_ApplicationMasterOrganizationTestMethodMaster] ON [dbo].[OrganizationTestMethodMaster]
GO
/****** Object:  Index [IX_FK_OrganizationRoleUserMapping_UserMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationRoleUserMapping]') AND name = N'IX_FK_OrganizationRoleUserMapping_UserMaster')
DROP INDEX [IX_FK_OrganizationRoleUserMapping_UserMaster] ON [dbo].[OrganizationRoleUserMapping]
GO
/****** Object:  Index [IX_FK_OrganizationCustomParameterMasterOrganizationCustomParameterVersions]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationCustomParameterVersions]') AND name = N'IX_FK_OrganizationCustomParameterMasterOrganizationCustomParameterVersions')
DROP INDEX [IX_FK_OrganizationCustomParameterMasterOrganizationCustomParameterVersions] ON [dbo].[OrganizationCustomParameterVersions]
GO
/****** Object:  Index [IX_FK_OrganizationMasterOrganizationComments]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationComments]') AND name = N'IX_FK_OrganizationMasterOrganizationComments')
DROP INDEX [IX_FK_OrganizationMasterOrganizationComments] ON [dbo].[OrganizationComments]
GO
/****** Object:  Index [IX_FK_OrganizationMasterOrganizationCategoryMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationCategoryMaster]') AND name = N'IX_FK_OrganizationMasterOrganizationCategoryMaster')
DROP INDEX [IX_FK_OrganizationMasterOrganizationCategoryMaster] ON [dbo].[OrganizationCategoryMaster]
GO
/****** Object:  Index [IX_FK_OrganizationMasterLuminometerMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[LuminometerMaster]') AND name = N'IX_FK_OrganizationMasterLuminometerMaster')
DROP INDEX [IX_FK_OrganizationMasterLuminometerMaster] ON [dbo].[LuminometerMaster]
GO
/****** Object:  Index [IX_FK_OrganizationMasterAreaMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[LocationMaster]') AND name = N'IX_FK_OrganizationMasterAreaMaster')
DROP INDEX [IX_FK_OrganizationMasterAreaMaster] ON [dbo].[LocationMaster]
GO
/****** Object:  Index [IX_FK_ApplicationMasterFeatureMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[FeatureMaster]') AND name = N'IX_FK_ApplicationMasterFeatureMaster')
DROP INDEX [IX_FK_ApplicationMasterFeatureMaster] ON [dbo].[FeatureMaster]
GO
/****** Object:  Index [IX_FK_EditMeasurementEditTestResultCustomParameterMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EditTestResultCustomParameterMapping]') AND name = N'IX_FK_EditMeasurementEditTestResultCustomParameterMapping')
DROP INDEX [IX_FK_EditMeasurementEditTestResultCustomParameterMapping] ON [dbo].[EditTestResultCustomParameterMapping]
GO
/****** Object:  Index [IX_FK_OrganizationMasterDeviceSyncDetails]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DeviceSyncDetails]') AND name = N'IX_FK_OrganizationMasterDeviceSyncDetails')
DROP INDEX [IX_FK_OrganizationMasterDeviceSyncDetails] ON [dbo].[DeviceSyncDetails]
GO
/****** Object:  Index [IX_FK_UserDashboardPreferencesDashboardSPMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DashboardSPMapping]') AND name = N'IX_FK_UserDashboardPreferencesDashboardSPMapping')
DROP INDEX [IX_FK_UserDashboardPreferencesDashboardSPMapping] ON [dbo].[DashboardSPMapping]
GO
/****** Object:  Index [IX_FK_RegionMasterCountryMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CountryMaster]') AND name = N'IX_FK_RegionMasterCountryMaster')
DROP INDEX [IX_FK_RegionMasterCountryMaster] ON [dbo].[CountryMaster]
GO
/****** Object:  Index [IX_FK_OrganizationMasterCapaComments]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CapaComments]') AND name = N'IX_FK_OrganizationMasterCapaComments')
DROP INDEX [IX_FK_OrganizationMasterCapaComments] ON [dbo].[CapaComments]
GO
/****** Object:  Index [IX_FK_AuditLogMasterAuditLogDetails]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AuditLogDetails]') AND name = N'IX_FK_AuditLogMasterAuditLogDetails')
DROP INDEX [IX_FK_AuditLogMasterAuditLogDetails] ON [dbo].[AuditLogDetails]
GO
/****** Object:  Index [NCI-AdhocTestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]') AND name = N'NCI-AdhocTestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To')
DROP INDEX [NCI-AdhocTestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To] ON [dbo].[AdhocTestPointResult]
GO
/****** Object:  Index [IX_FK_AdhocTestPlanResultAdhocTestPointResult]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]') AND name = N'IX_FK_AdhocTestPlanResultAdhocTestPointResult')
DROP INDEX [IX_FK_AdhocTestPlanResultAdhocTestPointResult] ON [dbo].[AdhocTestPointResult]
GO
/****** Object:  Index [NCI-AdhocTestPlanResult-Oid-RidTplid]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPlanResult]') AND name = N'NCI-AdhocTestPlanResult-Oid-RidTplid')
DROP INDEX [NCI-AdhocTestPlanResult-Oid-RidTplid] ON [dbo].[AdhocTestPlanResult]
GO
/****** Object:  Table [dbo].[WorkFlowMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[WorkFlowMaster]') AND type in (N'U'))
DROP TABLE [dbo].[WorkFlowMaster]
GO
/****** Object:  Table [dbo].[UserReportPreferences]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserReportPreferences]') AND type in (N'U'))
DROP TABLE [dbo].[UserReportPreferences]
GO
/****** Object:  Table [dbo].[UserPreferences]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserPreferences]') AND type in (N'U'))
DROP TABLE [dbo].[UserPreferences]
GO
/****** Object:  Table [dbo].[UserMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserMaster]') AND type in (N'U'))
DROP TABLE [dbo].[UserMaster]
GO
/****** Object:  Table [dbo].[UserDashboardPreferences]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserDashboardPreferences]') AND type in (N'U'))
DROP TABLE [dbo].[UserDashboardPreferences]
GO
/****** Object:  Table [dbo].[UserDashboardFilters]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserDashboardFilters]') AND type in (N'U'))
DROP TABLE [dbo].[UserDashboardFilters]
GO
/****** Object:  Table [dbo].[UserCountryMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserCountryMapping]') AND type in (N'U'))
DROP TABLE [dbo].[UserCountryMapping]
GO
/****** Object:  Table [dbo].[UnitMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UnitMaster]') AND type in (N'U'))
DROP TABLE [dbo].[UnitMaster]
GO
/****** Object:  Table [dbo].[TimezoneMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TimezoneMaster]') AND type in (N'U'))
DROP TABLE [dbo].[TimezoneMaster]
GO
/****** Object:  Table [dbo].[TestResultCustomParameterMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestResultCustomParameterMapping]') AND type in (N'U'))
DROP TABLE [dbo].[TestResultCustomParameterMapping]
GO
/****** Object:  Table [dbo].[TestPointTestMethodMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPointTestMethodMapping]') AND type in (N'U'))
DROP TABLE [dbo].[TestPointTestMethodMapping]
GO
/****** Object:  Table [dbo].[TestPointResult]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPointResult]') AND type in (N'U'))
DROP TABLE [dbo].[TestPointResult]
GO
/****** Object:  Table [dbo].[TestPointMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPointMaster]') AND type in (N'U'))
DROP TABLE [dbo].[TestPointMaster]
GO
/****** Object:  Table [dbo].[TestPointCustomParameterMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPointCustomParameterMapping]') AND type in (N'U'))
DROP TABLE [dbo].[TestPointCustomParameterMapping]
GO
/****** Object:  Table [dbo].[TestPlanUserMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanUserMapping]') AND type in (N'U'))
DROP TABLE [dbo].[TestPlanUserMapping]
GO
/****** Object:  Table [dbo].[TestPlanTypeMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanTypeMaster]') AND type in (N'U'))
DROP TABLE [dbo].[TestPlanTypeMaster]
GO
/****** Object:  Table [dbo].[TestPlanTestPointMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanTestPointMapping]') AND type in (N'U'))
DROP TABLE [dbo].[TestPlanTestPointMapping]
GO
/****** Object:  Table [dbo].[TestPlanResult]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanResult]') AND type in (N'U'))
DROP TABLE [dbo].[TestPlanResult]
GO
/****** Object:  Table [dbo].[TestPlanMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanMaster]') AND type in (N'U'))
DROP TABLE [dbo].[TestPlanMaster]
GO
/****** Object:  Table [dbo].[TestMethodMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestMethodMaster]') AND type in (N'U'))
DROP TABLE [dbo].[TestMethodMaster]
GO
/****** Object:  Table [dbo].[SwabTypeMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SwabTypeMaster]') AND type in (N'U'))
DROP TABLE [dbo].[SwabTypeMaster]
GO
/****** Object:  Table [dbo].[SupportedVersionMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SupportedVersionMaster]') AND type in (N'U'))
DROP TABLE [dbo].[SupportedVersionMaster]
GO
/****** Object:  Table [dbo].[ServiceRunLog]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ServiceRunLog]') AND type in (N'U'))
DROP TABLE [dbo].[ServiceRunLog]
GO
/****** Object:  Table [dbo].[ScheduleWeeksOfMonth]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ScheduleWeeksOfMonth]') AND type in (N'U'))
DROP TABLE [dbo].[ScheduleWeeksOfMonth]
GO
/****** Object:  Table [dbo].[ScheduleMonthsOfYear]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ScheduleMonthsOfYear]') AND type in (N'U'))
DROP TABLE [dbo].[ScheduleMonthsOfYear]
GO
/****** Object:  Table [dbo].[ScheduleMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ScheduleMaster]') AND type in (N'U'))
DROP TABLE [dbo].[ScheduleMaster]
GO
/****** Object:  Table [dbo].[ScheduleDefinitionMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ScheduleDefinitionMaster]') AND type in (N'U'))
DROP TABLE [dbo].[ScheduleDefinitionMaster]
GO
/****** Object:  Table [dbo].[ScheduleDaysOfWeek]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ScheduleDaysOfWeek]') AND type in (N'U'))
DROP TABLE [dbo].[ScheduleDaysOfWeek]
GO
/****** Object:  Table [dbo].[ScheduleDaysOfMonth]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ScheduleDaysOfMonth]') AND type in (N'U'))
DROP TABLE [dbo].[ScheduleDaysOfMonth]
GO
/****** Object:  Table [dbo].[SamplePlanSchedule]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SamplePlanSchedule]') AND type in (N'U'))
DROP TABLE [dbo].[SamplePlanSchedule]
GO
/****** Object:  Table [dbo].[RolePermissionsForAudit]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RolePermissionsForAudit]') AND type in (N'U'))
DROP TABLE [dbo].[RolePermissionsForAudit]
GO
/****** Object:  Table [dbo].[RolePermissions]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RolePermissions]') AND type in (N'U'))
DROP TABLE [dbo].[RolePermissions]
GO
/****** Object:  Table [dbo].[RoleMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RoleMaster]') AND type in (N'U'))
DROP TABLE [dbo].[RoleMaster]
GO
/****** Object:  Table [dbo].[ResultScheduleMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ResultScheduleMapping]') AND type in (N'U'))
DROP TABLE [dbo].[ResultScheduleMapping]
GO
/****** Object:  Table [dbo].[ReportMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportMaster]') AND type in (N'U'))
DROP TABLE [dbo].[ReportMaster]
GO
/****** Object:  Table [dbo].[ReportLocationMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportLocationMapping]') AND type in (N'U'))
DROP TABLE [dbo].[ReportLocationMapping]
GO
/****** Object:  Table [dbo].[ReportFilterMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportFilterMaster]') AND type in (N'U'))
DROP TABLE [dbo].[ReportFilterMaster]
GO
/****** Object:  Table [dbo].[RegionMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RegionMaster]') AND type in (N'U'))
DROP TABLE [dbo].[RegionMaster]
GO
/****** Object:  Table [dbo].[OrganizationTypeMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationTypeMaster]') AND type in (N'U'))
DROP TABLE [dbo].[OrganizationTypeMaster]
GO
/****** Object:  Table [dbo].[OrganizationTestMethodVersions]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodVersions]') AND type in (N'U'))
DROP TABLE [dbo].[OrganizationTestMethodVersions]
GO
/****** Object:  Table [dbo].[OrganizationTestMethodMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodMaster]') AND type in (N'U'))
DROP TABLE [dbo].[OrganizationTestMethodMaster]
GO
/****** Object:  Table [dbo].[OrganizationRoleUserMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationRoleUserMapping]') AND type in (N'U'))
DROP TABLE [dbo].[OrganizationRoleUserMapping]
GO
/****** Object:  Table [dbo].[OrganizationRoleMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationRoleMaster]') AND type in (N'U'))
DROP TABLE [dbo].[OrganizationRoleMaster]
GO
/****** Object:  Table [dbo].[OrganizationMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationMaster]') AND type in (N'U'))
DROP TABLE [dbo].[OrganizationMaster]
GO
/****** Object:  Table [dbo].[OrganizationImageMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationImageMaster]') AND type in (N'U'))
DROP TABLE [dbo].[OrganizationImageMaster]
GO
/****** Object:  Table [dbo].[OrganizationCustomParameterVersions]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationCustomParameterVersions]') AND type in (N'U'))
DROP TABLE [dbo].[OrganizationCustomParameterVersions]
GO
/****** Object:  Table [dbo].[OrganizationCustomParameterMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationCustomParameterMaster]') AND type in (N'U'))
DROP TABLE [dbo].[OrganizationCustomParameterMaster]
GO
/****** Object:  Table [dbo].[OrganizationConfiguration]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationConfiguration]') AND type in (N'U'))
DROP TABLE [dbo].[OrganizationConfiguration]
GO
/****** Object:  Table [dbo].[OrganizationComments]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationComments]') AND type in (N'U'))
DROP TABLE [dbo].[OrganizationComments]
GO
/****** Object:  Table [dbo].[OrganizationCategoryMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationCategoryMaster]') AND type in (N'U'))
DROP TABLE [dbo].[OrganizationCategoryMaster]
GO
/****** Object:  Table [dbo].[Menu]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Menu]') AND type in (N'U'))
DROP TABLE [dbo].[Menu]
GO
/****** Object:  Table [dbo].[LuminometerMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LuminometerMaster]') AND type in (N'U'))
DROP TABLE [dbo].[LuminometerMaster]
GO
/****** Object:  Table [dbo].[LocationMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LocationMaster]') AND type in (N'U'))
DROP TABLE [dbo].[LocationMaster]
GO
/****** Object:  Table [dbo].[LocationLevelMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LocationLevelMaster]') AND type in (N'U'))
DROP TABLE [dbo].[LocationLevelMaster]
GO
/****** Object:  Table [dbo].[LicenseTypeMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LicenseTypeMaster]') AND type in (N'U'))
DROP TABLE [dbo].[LicenseTypeMaster]
GO
/****** Object:  Table [dbo].[FeatureMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FeatureMaster]') AND type in (N'U'))
DROP TABLE [dbo].[FeatureMaster]
GO
/****** Object:  Table [dbo].[FeatureGroup]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FeatureGroup]') AND type in (N'U'))
DROP TABLE [dbo].[FeatureGroup]
GO
/****** Object:  Table [dbo].[FailedLoginAttempts]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FailedLoginAttempts]') AND type in (N'U'))
DROP TABLE [dbo].[FailedLoginAttempts]
GO
/****** Object:  Table [dbo].[EditTestResultCustomParameterMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EditTestResultCustomParameterMapping]') AND type in (N'U'))
DROP TABLE [dbo].[EditTestResultCustomParameterMapping]
GO
/****** Object:  Table [dbo].[EditMeasurement]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EditMeasurement]') AND type in (N'U'))
DROP TABLE [dbo].[EditMeasurement]
GO
/****** Object:  Table [dbo].[DeviceSyncDetails]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceSyncDetails]') AND type in (N'U'))
DROP TABLE [dbo].[DeviceSyncDetails]
GO
/****** Object:  Table [dbo].[DashboardSPMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DashboardSPMapping]') AND type in (N'U'))
DROP TABLE [dbo].[DashboardSPMapping]
GO
/****** Object:  Table [dbo].[CustomCategory]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CustomCategory]') AND type in (N'U'))
DROP TABLE [dbo].[CustomCategory]
GO
/****** Object:  Table [dbo].[CountryMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CountryMaster]') AND type in (N'U'))
DROP TABLE [dbo].[CountryMaster]
GO
/****** Object:  Table [dbo].[CommonTasks]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CommonTasks]') AND type in (N'U'))
DROP TABLE [dbo].[CommonTasks]
GO
/****** Object:  Table [dbo].[CapaComments]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CapaComments]') AND type in (N'U'))
DROP TABLE [dbo].[CapaComments]
GO
/****** Object:  Table [dbo].[AuditLogMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AuditLogMaster]') AND type in (N'U'))
DROP TABLE [dbo].[AuditLogMaster]
GO
/****** Object:  Table [dbo].[AuditLogDetails]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AuditLogDetails]') AND type in (N'U'))
DROP TABLE [dbo].[AuditLogDetails]
GO
/****** Object:  Table [dbo].[ArchivalMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ArchivalMaster]') AND type in (N'U'))
DROP TABLE [dbo].[ArchivalMaster]
GO
/****** Object:  Table [dbo].[ApplicationMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ApplicationMaster]') AND type in (N'U'))
DROP TABLE [dbo].[ApplicationMaster]
GO
/****** Object:  Table [dbo].[ApplicationInformation]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ApplicationInformation]') AND type in (N'U'))
DROP TABLE [dbo].[ApplicationInformation]
GO
/****** Object:  Table [dbo].[AdhocTestPointResult]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]') AND type in (N'U'))
DROP TABLE [dbo].[AdhocTestPointResult]
GO
/****** Object:  Table [dbo].[AdhocTestPlanResult]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPlanResult]') AND type in (N'U'))
DROP TABLE [dbo].[AdhocTestPlanResult]
GO
/****** Object:  Table [dbo].[AdhocEditMeasurement]    Script Date: 5/20/2018 3:55:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AdhocEditMeasurement]') AND type in (N'U'))
DROP TABLE [dbo].[AdhocEditMeasurement]
GO
/****** Object:  Table [dbo].[LuminometerPlantMapping]    Script Date: 11/30/2018 4:51:07 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LuminometerPlantMapping]') AND type in (N'U'))
DROP TABLE [dbo].[LuminometerPlantMapping]
GO

/****** Object:  Table [dbo].[AdhocEditMeasurement]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AdhocEditMeasurement]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[AdhocEditMeasurement](
	[OrganizationId] [int] NOT NULL,
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[AdhocResultId] [bigint] NOT NULL,
	[AdhocMeasurementId] [smallint] NOT NULL,
	[ReasonForChange] [nvarchar](1000) NOT NULL,
	[OldResult] [smallint] NULL,
	[OldResultValue] [float] NULL,
	[NewResult] [smallint] NULL,
	[NewResultValue] [float] NULL,
	[OldCapaComments] [nvarchar](1000) NULL,
	[NewCapaComments] [nvarchar](1000) NULL,
	[OldTester] [int] NULL,
	[NewTester] [int] NULL,
	[EditDate] [datetime] NOT NULL,
	[EditedBy] [int] NOT NULL,
 CONSTRAINT [PK_AdhocEditMeasurement] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[AdhocTestPlanResult]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPlanResult]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[AdhocTestPlanResult](
	[AdhocResultId] [bigint] IDENTITY(1,1) NOT NULL,
	[OrganizationId] [int] NOT NULL,
	[TestPlanId] [int] NOT NULL,
	[TestPlanVersion] [smallint] NOT NULL,
	[TestPlanName] [nvarchar](max) NULL,
	[LocationId] [int] NULL,
	[LocationVersion] [smallint] NULL,
	[Status] [smallint] NOT NULL,
	[OpenedDate] [datetime] NULL,
	[OpenedBy] [int] NULL,
	[DeviceId] [nvarchar](50) NOT NULL,
	[LastEditedBy] [int] NULL,
	[LastEditedDate] [datetime] NULL,
 CONSTRAINT [PK_AdhocTestPlanResult] PRIMARY KEY CLUSTERED 
(
	[AdhocResultId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[AdhocTestPointResult]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[AdhocTestPointResult](
	[AdhocResultId] [bigint] NOT NULL,
	[AdhocMeasurementId] [smallint] NOT NULL,
	[TestPointId] [int] NULL,
	[TestPointVersion] [smallint] NULL,
	[TestPointName] [nvarchar](max) NULL,
	[TestPointLocationId] [int] NULL,
	[LocationName] [nvarchar](max) NULL,
	[TestMethodId] [smallint] NOT NULL,
	[TestMethodVersion] [smallint] NOT NULL,
	[TestMethodName] [nvarchar](50) NULL,
	[TestType] [smallint] NOT NULL,
	[IsAdhoc] [bit] NOT NULL,
	[IsRetest] [bit] NOT NULL,
	[Status] [smallint] NOT NULL,
	[Result] [smallint] NULL,
	[ResultValue] [float] NOT NULL,
	[ResultDate] [datetime] NULL,
	[IsEdited] [bit] NOT NULL,
	[ResultTakenBy] [int] NULL,
	[ResultTakenByName] [nvarchar](100) NULL,
	[OriginalAdhocMeasurementId] [bigint] NULL,
	[CapaComments] [nvarchar](1000) NULL,
	[CreatedBy] [int] NULL,
	[CreatedDate] [datetime] NULL,
	[LastEditDate] [datetime] NULL,
	[LastEditedBy] [int] NULL,
	[ATPPassThreshold] [decimal](10, 2) NULL,
	[ATPFailThreshold] [decimal](10, 2) NULL,
	[ThresholdType] [smallint] NULL,
	[UnitId] [int] NULL,
	[UnitName] [nvarchar](10) NULL,
	[IsMapped] [bit] NOT NULL,
	[Is3MSwab] [bit] NOT NULL,
	[IsFinal] [bit] NULL,
	[TestOrder] [int] NULL,
 CONSTRAINT [PK_AdhocTestPointResult] PRIMARY KEY CLUSTERED 
(
	[AdhocMeasurementId] ASC,
	[AdhocResultId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[ApplicationInformation]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ApplicationInformation]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ApplicationInformation](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ApplicationUrl] [nvarchar](200) NOT NULL,
	[HostName] [nvarchar](100) NOT NULL,
	[IpAddress] [nvarchar](200) NOT NULL,
	[CommonServicePort] [smallint] NOT NULL,
	[WebServicePort] [smallint] NOT NULL,
	[DeviceServicePort] [smallint] NOT NULL,
	[InstallationDate] [datetime] NOT NULL,
	[DBServerName] [nvarchar](100) NOT NULL,
	[PackageVersion] [nvarchar](50) NOT NULL,
	[Comments] [nvarchar](500) NULL,
	[IsUninstall] [bit] NULL,
 CONSTRAINT [PK_ApplicationInformation] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[ApplicationMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ApplicationMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ApplicationMaster](
	[ApplicationId] [smallint] IDENTITY(1,1) NOT NULL,
	[ApplicationName] [nvarchar](30) NOT NULL,
 CONSTRAINT [PK_ApplicationMaster] PRIMARY KEY CLUSTERED 
(
	[ApplicationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[ArchivalMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ArchivalMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ArchivalMaster](
	[ArchivalId] [int] IDENTITY(1,1) NOT NULL,
	[OrganizationId] [int] NOT NULL,
	[StartDate] [datetime] NOT NULL,
	[EndDate] [datetime] NOT NULL,
	[SamplePlan] [nvarchar](max) NOT NULL,
	[ScheduleOn] [datetime] NOT NULL,
	[ArchivalStatus] [bit] NULL,
	[IsAlive] [bit] NOT NULL,
	[ArchivedOn] [datetime] NULL,
	[CreatedBy] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
 CONSTRAINT [PK_ArchivalMaster] PRIMARY KEY CLUSTERED 
(
	[ArchivalId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[AuditLogDetails]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AuditLogDetails]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[AuditLogDetails](
	[AuditLogDetailId] [bigint] IDENTITY(1,1) NOT NULL,
	[AuditLogId] [bigint] NOT NULL,
	[TableName] [nvarchar](200) NOT NULL,
	[FieldName] [nvarchar](200) NOT NULL,
	[OperationType] [nvarchar](50) NOT NULL,
	[OldValue] [nvarchar](max) NULL,
	[NewValue] [nvarchar](max) NULL,
	[Display] [bit] NOT NULL,
	[PrimaryField] [nvarchar](max) NULL,
 CONSTRAINT [PK_AuditLogDetails] PRIMARY KEY CLUSTERED 
(
	[AuditLogDetailId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[AuditLogMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AuditLogMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[AuditLogMaster](
	[AuditLogId] [bigint] IDENTITY(1,1) NOT NULL,
	[ActionDate] [datetime] NOT NULL,
	[ActionBy] [int] NULL,
	[Description] [nvarchar](max) NULL,
	[KeyId] [int] NULL,
	[RootField] [nvarchar](max) NOT NULL,
 CONSTRAINT [PK_AuditLogMaster] PRIMARY KEY CLUSTERED 
(
	[AuditLogId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[CapaComments]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CapaComments]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CapaComments](
	[OrganizationId] [int] NOT NULL,
	[CommentId] [smallint] IDENTITY(1,1) NOT NULL,
	[CommentText] [nvarchar](1000) NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[EditedBy] [int] NULL,
	[EditedDate] [datetime] NULL,
 CONSTRAINT [PK_CapaComments] PRIMARY KEY CLUSTERED 
(
	[CommentId] ASC,
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[CommonTasks]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CommonTasks]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CommonTasks](
	[CommonTaskId] [int] IDENTITY(1,1) NOT NULL,
	[CommonTaskKey] [nvarchar](30) NOT NULL,
	[FeatureGroupKey] [smallint] NOT NULL,
	[AddUrl] [nvarchar](100) NOT NULL,
	[ViewUrl] [nvarchar](100) NULL,
	[ImageName] [nvarchar](15) NOT NULL,
 CONSTRAINT [PK_CommonTasks] PRIMARY KEY CLUSTERED 
(
	[CommonTaskId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[CountryMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CountryMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CountryMaster](
	[CountryId] [smallint] IDENTITY(1,1) NOT NULL,
	[CountryName] [nvarchar](30) NOT NULL,
	[RegionId] [smallint] NOT NULL,
 CONSTRAINT [PK_CountryMaster] PRIMARY KEY CLUSTERED 
(
	[CountryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[CustomCategory]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CustomCategory]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CustomCategory](
	[CategoryId] [smallint] IDENTITY(1,1) NOT NULL,
	[Category] [nvarchar](50) NOT NULL,
	[IsUserDefine] [bit] NOT NULL,
	[IsNumericType] [bit] NOT NULL,
 CONSTRAINT [PK_CustomCategory] PRIMARY KEY CLUSTERED 
(
	[CategoryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[DashboardSPMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DashboardSPMapping]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DashboardSPMapping](
	[MappingId] [int] IDENTITY(1,1) NOT NULL,
	[PreferenceId] [int] NOT NULL,
	[SamplePlanId] [int] NOT NULL,
	[SamplePlanVersion] [smallint] NOT NULL,
 CONSTRAINT [PK_DashboardSPMapping] PRIMARY KEY CLUSTERED 
(
	[MappingId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[DeviceSyncDetails]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DeviceSyncDetails]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DeviceSyncDetails](
	[SyncId] [int] IDENTITY(1,1) NOT NULL,
	[DeviceSerialNumber] [nvarchar](50) NOT NULL,
	[OrganizationId] [int] NOT NULL,
	[LastSyncTime] [datetime] NOT NULL,
	[DeviceName] [nvarchar](30) NULL,
	[SyncMode] [smallint] NOT NULL,
	[SyncManagerIdentifier] [nvarchar](50) NULL,
	[SyncBy] [int] NULL,
	[IsAdminNotified] [bit] NOT NULL,
 CONSTRAINT [PK_DeviceSyncDetails] PRIMARY KEY CLUSTERED 
(
	[SyncId] ASC,
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[EditMeasurement]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EditMeasurement]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EditMeasurement](
	[OrganizationId] [int] NOT NULL,
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[ResultId] [bigint] NOT NULL,
	[MeasurementId] [smallint] NOT NULL,
	[ReasonForChange] [nvarchar](1000) NOT NULL,
	[OldResult] [smallint] NULL,
	[OldResultValue] [float] NULL,
	[NewResult] [smallint] NULL,
	[NewResultValue] [float] NULL,
	[OldCapaComments] [nvarchar](1000) NULL,
	[NewCapaComments] [nvarchar](1000) NULL,
	[OldTester] [int] NULL,
	[NewTester] [int] NULL,
	[EditDate] [datetime] NOT NULL,
	[EditedBy] [int] NOT NULL,
 CONSTRAINT [PK_EditMeasurement] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[EditTestResultCustomParameterMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EditTestResultCustomParameterMapping]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EditTestResultCustomParameterMapping](
	[EditId] [bigint] IDENTITY(1,1) NOT NULL,
	[Id] [bigint] NOT NULL,
	[OldOrganizationCategoryId] [int] NOT NULL,
	[NewOrganizationCategoryId] [int] NOT NULL,
	[OldParameterId] [smallint] NOT NULL,
	[NewParameterId] [smallint] NOT NULL,
	[EditedBy] [int] NULL,
	[EditedDate] [datetime] NULL,
 CONSTRAINT [PK_EditTestResultCustomParameterMapping] PRIMARY KEY CLUSTERED 
(
	[EditId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[FailedLoginAttempts]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FailedLoginAttempts]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[FailedLoginAttempts](
	[AttemptId] [int] IDENTITY(1,1) NOT NULL,
	[OrganizationId] [int] NOT NULL,
	[LoginName] [nvarchar](50) NOT NULL,
	[LoginDateTime] [datetime] NOT NULL,
	[AttemptType] [smallint] NOT NULL DEFAULT ((1)),
 CONSTRAINT [PK_FailedLoginAttempts] PRIMARY KEY CLUSTERED 
(
	[AttemptId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[FeatureGroup]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FeatureGroup]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[FeatureGroup](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[FeatureKey] [nvarchar](30) NOT NULL,
	[PermissionType] [smallint] NOT NULL,
	[FeatureGroupKey] [smallint] NOT NULL,
 CONSTRAINT [PK_FeatureGroup] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[FeatureMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FeatureMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[FeatureMaster](
	[FeatureId] [smallint] IDENTITY(1,1) NOT NULL,
	[ApplicationId] [smallint] NOT NULL,
	[FeatureName] [nvarchar](50) NOT NULL,
	[FeatureCategory] [smallint] NOT NULL,
	[AccessType] [smallint] NOT NULL,
	[Url] [nvarchar](250) NULL,
	[ParentFeatureId] [smallint] NOT NULL,
	[IsMenuItem] [bit] NOT NULL,
 CONSTRAINT [PK_FeatureMaster] PRIMARY KEY CLUSTERED 
(
	[FeatureId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[LicenseTypeMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LicenseTypeMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LicenseTypeMaster](
	[LicenseId] [smallint] IDENTITY(1,1) NOT NULL,
	[LicenseType] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_LicenseTypeMaster] PRIMARY KEY CLUSTERED 
(
	[LicenseId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[LocationLevelMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LocationLevelMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LocationLevelMaster](
	[OrganizationId] [int] NOT NULL,
	[LevelId] [smallint] NOT NULL,
	[LevelName] [nvarchar](50) NOT NULL,
	[Order] [smallint] NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[EditedBy] [int] NOT NULL,
	[EditedDate] [datetime] NOT NULL,
 CONSTRAINT [PK_LocationLevelMaster] PRIMARY KEY CLUSTERED 
(
	[OrganizationId] ASC,
	[LevelId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[LocationMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LocationMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LocationMaster](
	[OrganizationId] [int] NOT NULL,
	[LocationId] [int] NOT NULL,
	[LocationVersion] [smallint] NOT NULL,
	[LocationName] [nvarchar](max) NULL,
	[Level] [smallint] NOT NULL,
	[ParentLocationId] [int] NULL,
	[Status] [smallint] NOT NULL,
	[IsCurrent] [bit] NOT NULL,
	[Description] [nvarchar](1000) NULL,
	[Notes] [nvarchar](max) NULL,
	[LastEditDate] [datetime] NULL,
	[LastEditedBy] [int] NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[CountryId] [smallint] NULL,
	[Timezone] [nvarchar](100) NULL,
	[StateId] [int] NULL,
	[CityId] [int] NULL
 CONSTRAINT [PK_LocationMaster] PRIMARY KEY CLUSTERED 
(
	[LocationId] ASC,
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[LocationPrefrence]    Script Date: 7/23/2021 9:55:20 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[LocationPreference](
	[OrganizationId] [int] NOT NULL,
	[LocationId] [int] NOT NULL,
	[DateFormat] [nvarchar](30) NULL,
	[NumberFormat] [smallint] NULL,
	[TemperatureUnit] [smallint] NOT NULL,
	[IsMilitaryTime] [bit] NULL,
	[SessionTimeout] [int] NULL,
	[RequirePasswordForDevice] [bit] NOT NULL,
	[MobileDataStoragePeriod] [smallint] NOT NULL,
 CONSTRAINT [PK_LocationPreference] PRIMARY KEY CLUSTERED 
(
	[LocationId] ASC,
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[LocationPreference]  WITH CHECK ADD  CONSTRAINT [FK_LocationPreference_LocationMaster] FOREIGN KEY([LocationId], [OrganizationId])
REFERENCES [dbo].[LocationMaster] ([LocationId], [OrganizationId])
GO

ALTER TABLE [dbo].[LocationPreference] CHECK CONSTRAINT [FK_LocationPreference_LocationMaster]
GO

/****** Object:  Table [dbo].[LuminometerMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LuminometerMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LuminometerMaster](
	[LuminometerId] [int] IDENTITY(1,1) NOT NULL,
	[OrganizationId] [int] NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[DeviceSerialNumber] [nvarchar](50) NOT NULL,
	[BuildVersion] [nvarchar](10) NOT NULL,
	[FirmwareVersion] [nvarchar](50) NOT NULL,
	[MacId] [nvarchar](50) NULL,
	[HardwareVersion] [nvarchar](10) NULL,
	[OSVersion] [nvarchar](50) NULL,
	[CalibrationDate] [datetime] NULL,
	[FirmwareVersionNew] [nvarchar](50) NULL
 CONSTRAINT [PK_LuminometerMaster] PRIMARY KEY CLUSTERED 
(
	[LuminometerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[Menu]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Menu]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Menu](
	[MenuId] [smallint] IDENTITY(1,1) NOT NULL,
	[MenuKey] [nvarchar](30) NOT NULL,
	[Url] [nvarchar](50) NOT NULL,
	[ImageName] [nvarchar](15) NOT NULL,
 CONSTRAINT [PK_Menu] PRIMARY KEY CLUSTERED 
(
	[MenuId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[OrganizationCategoryMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationCategoryMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[OrganizationCategoryMaster](
	[OrganizationCategoryId] [int] NOT NULL,
	[OrganizationId] [int] NOT NULL,
	[CategoryName] [nvarchar](50) NOT NULL,
	[IsUserDefine] [bit] NOT NULL,
	[IsNumericType] [bit] NOT NULL,
 CONSTRAINT [PK_OrganizationCategoryMaster] PRIMARY KEY CLUSTERED 
(
	[OrganizationCategoryId] ASC,
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[OrganizationComments]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationComments]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[OrganizationComments](
	[OrganizationId] [int] NOT NULL,
	[CommentId] [smallint] NOT NULL,
	[Comment] [nvarchar](250) NOT NULL,
	[CommentDate] [datetime] NOT NULL,
	[CreatedBy] [int] NOT NULL,
 CONSTRAINT [PK_OrganizationComments] PRIMARY KEY CLUSTERED 
(
	[CommentId] ASC,
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[OrganizationConfiguration]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationConfiguration]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[OrganizationConfiguration](
	[OrganizationId] [int] NOT NULL,
	[ChangeTestPointThreshold] [bit] NOT NULL,
	[MobileDataStoragePeriod] [smallint] NOT NULL,
	[ATPPassThreshold] [int] NULL,
	[ATPFailThreshold] [int] NULL,
	[TimezoneName] [nvarchar](100) NOT NULL,
	[RequireStrongPassword] [bit] NOT NULL,
	[DateFormat] [nvarchar](30) NULL,
	[RequirePasswordForDevice] [bit] NOT NULL,
	[SyncType] [smallint] NOT NULL,
	[NumberFormat] [smallint] NULL,
	[TemperatureUnit] [smallint] NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[LastEditedBy] [int] NULL,
	[LastEditDate] [datetime] NULL,
	[DeleteObjects] [bit] NOT NULL DEFAULT (1),
 CONSTRAINT [PK_OrganizationConfiguration] PRIMARY KEY CLUSTERED 
(
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[OrganizationCustomParameterMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationCustomParameterMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[OrganizationCustomParameterMaster](
	[OrganizationId] [int] NOT NULL,
	[OrganizationCategoryId] [int] NOT NULL,
	[ParameterId] [int] NOT NULL,
	[IsApplicable] [bit] NOT NULL,
	[LastEditDate] [datetime] NULL,
	[LastEditedBy] [int] NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [int] NOT NULL,
 CONSTRAINT [PK_OrganizationCustomParameterMaster] PRIMARY KEY CLUSTERED 
(
	[OrganizationCategoryId] ASC,
	[OrganizationId] ASC,
	[ParameterId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[OrganizationCustomParameterVersions]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationCustomParameterVersions]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[OrganizationCustomParameterVersions](
	[OrganizationId] [int] NOT NULL,
	[OrganizationCategoryId] [int] NOT NULL,
	[ParameterId] [int] NOT NULL,
	[ParameterVersion] [smallint] NOT NULL,
	[IsCurrent] [bit] NOT NULL,
	[ParameterName] [nvarchar](50) NULL,
	[ParameterNumericValue] [int] NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [int] NOT NULL,
 CONSTRAINT [PK_OrganizationCustomParameterVersions] PRIMARY KEY CLUSTERED 
(
	[ParameterVersion] ASC,
	[ParameterId] ASC,
	[OrganizationId] ASC,
	[OrganizationCategoryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[OrganizationImageMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationImageMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[OrganizationImageMaster](
	[OrganizationId] [int] NOT NULL,
	[Logo] [varbinary](max) NOT NULL,
 CONSTRAINT [PK_OrganizationImageMaster] PRIMARY KEY CLUSTERED 
(
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[OrganizationMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[OrganizationMaster](
	[OrganizationId] [int] IDENTITY(1,1) NOT NULL,
	[OrganizationTypeId] [int] NULL,
	[ApplicationId] [smallint] NULL,
	[OrganizationName] [nvarchar](50) NOT NULL,
	[IsLicensed] [bit] NULL,
	[Status] [smallint] NULL,
	[Address] [nvarchar](50) NULL,
	[ZipCode] [nvarchar](30) NULL,
	[CountryId] [smallint] NULL,
	[LicenseID] [smallint] NULL,
	[ValidTill] [datetime] NULL,
	[HierarchyLevel] [smallint] NULL,
	[PrimaryContact] [int] NULL,
	[SecondaryContact] [int] NULL,
	[ConfigurationComplete] [bit] NULL,
	[CurrentStep] [smallint] NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[LastEditDate] [datetime] NULL,
	[LastEditedBy] [int] NULL,
	[DomainName] [nvarchar](30) NULL,
	[OrganizationKey] [nvarchar](100) NULL,
	[Fax] [nvarchar](25) NULL,
	[OrganizationLocale] [nvarchar](10) NULL,
	[IsHavingMultiLocationSamplePlan] [bit] not null Default 0
 CONSTRAINT [PK_OrganizationMaster] PRIMARY KEY CLUSTERED 
(
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[OrganizationRoleMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationRoleMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[OrganizationRoleMaster](
	[OrganizationId] [int] NOT NULL,
	[RoleId] [smallint] NOT NULL,
	[RoleName] [nvarchar](30) NOT NULL,
	[RoleLevel] [smallint] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[PermissionXML] [nvarchar](max) NULL,
	[LastEditDate] [datetime] NULL,
	[LastEditedBy] [int] NULL,
	[InheritedFromParent] [bit] NULL,
	[ParentOrganizationId] [int] NULL,
	[ParentRoleId] [smallint] NULL,
 CONSTRAINT [PK_OrganizationRoleMaster] PRIMARY KEY CLUSTERED 
(
	[OrganizationId] ASC,
	[RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[OrganizationRoleUserMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationRoleUserMapping]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[OrganizationRoleUserMapping](
	[OrganizationRoleMaster_OrganizationId] [int] NOT NULL,
	[OrganizationRoleMaster_RoleId] [smallint] NOT NULL,
	[OrganizationRoleUserMapping_OrganizationRoleMaster_UserId] [int] NOT NULL,
 CONSTRAINT [PK_OrganizationRoleUserMapping] PRIMARY KEY NONCLUSTERED 
(
	[OrganizationRoleMaster_OrganizationId] ASC,
	[OrganizationRoleMaster_RoleId] ASC,
	[OrganizationRoleUserMapping_OrganizationRoleMaster_UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[OrganizationTestMethodMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[OrganizationTestMethodMaster](
	[OrganizationId] [int] NOT NULL,
	[TestMethodId] [smallint] NOT NULL,
	[ApplicationId] [smallint] NOT NULL,
	[TestType] [smallint] NOT NULL,
	[IsApplicable] [bit] NOT NULL,
	[EditedBy] [int] NULL,
	[EditedDate] [datetime] NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[Order] [int] NULL,
 CONSTRAINT [PK_OrganizationTestMethodMaster] PRIMARY KEY CLUSTERED 
(
	[TestMethodId] ASC,
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[OrganizationTestMethodVersions]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodVersions]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[OrganizationTestMethodVersions](
	[OrganizationId] [int] NOT NULL,
	[TestMethodId] [smallint] NOT NULL,
	[TestMethodVersion] [smallint] NOT NULL,
	[TestMethodName] [nvarchar](50) NOT NULL,
	[IsCurrent] [bit] NOT NULL,
	[ShortName] [nvarchar](8) NULL,
	[PassThreshold] [decimal](10, 2) NULL,
	[FailThreshold] [decimal](10, 2) NULL,
	[ThresholdType] [smallint] NOT NULL,
	[UnitId] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [int] NOT NULL,
 CONSTRAINT [PK_OrganizationTestMethodVersions] PRIMARY KEY CLUSTERED 
(
	[OrganizationId] ASC,
	[TestMethodId] ASC,
	[TestMethodVersion] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[OrganizationTypeMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationTypeMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[OrganizationTypeMaster](
	[OrganizationTypeId] [smallint] IDENTITY(1,1) NOT NULL,
	[ApplicationId] [smallint] NOT NULL,
	[OrganizationTypeName] [nvarchar](30) NOT NULL,
 CONSTRAINT [PK_OrganizationTypeMaster] PRIMARY KEY CLUSTERED 
(
	[OrganizationTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[RegionMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RegionMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[RegionMaster](
	[RegionId] [smallint] IDENTITY(1,1) NOT NULL,
	[RegionName] [nvarchar](30) NOT NULL,
 CONSTRAINT [PK_RegionMaster] PRIMARY KEY CLUSTERED 
(
	[RegionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[ReportFilterMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportFilterMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ReportFilterMaster](
	[ReportFilterId] [int] NOT NULL,
	[OrganizationId] [int] NOT NULL,
	[FilterName] [nvarchar](50) NOT NULL,
	[ReportId] [smallint] NOT NULL,
	[IsFavorite] [bit] NOT NULL,
	[TimePeriod] [smallint] NOT NULL,
	[StartDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
	[SamplePlans] [varchar](max) NULL,
	[ResultFilter] [smallint] NOT NULL,
	[TestTypes] [varchar](max) NULL,
	[IncludeRetest] [bit] NOT NULL,
	[Locations] [varchar](max) NULL,
	[Parameters] [nvarchar](max) NULL,
	[AdditionalResultFilter] [nvarchar](max) NULL,
	[ResultValueMax] [float] NULL,
	[ResultValueMin] [float] NULL,
	[Testers] [nvarchar](max) NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [int] NOT NULL,
 CONSTRAINT [PK_ResultFilterMaster] PRIMARY KEY CLUSTERED 
(
	[ReportFilterId] ASC,
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ReportLocationMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportLocationMapping]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ReportLocationMapping](
	[ReportId] [int] NOT NULL,
	[LocationId] [int] NOT NULL,
	[LocationVersion] [smallint] NOT NULL,
 CONSTRAINT [PK_ReportLocationMapping] PRIMARY KEY CLUSTERED 
(
	[ReportId] ASC,
	[LocationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[ReportMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReportMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ReportMaster](
	[ReportId] [smallint] IDENTITY(1,1) NOT NULL,
	[ApplicationId] [smallint] NOT NULL,
	[ReportName] [nvarchar](30) NOT NULL,
 CONSTRAINT [PK_ReportMaster] PRIMARY KEY CLUSTERED 
(
	[ReportId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[ResultScheduleMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ResultScheduleMapping]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ResultScheduleMapping](
	[ReportScheduleId] [int] NOT NULL,
	[OrganizationId] [int] NOT NULL,
	[ResultId] [bigint] NOT NULL,
 CONSTRAINT [PK_ResultScheduleMapping] PRIMARY KEY CLUSTERED 
(
	[ReportScheduleId] ASC,
	[OrganizationId] ASC,
	[ResultId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[RoleMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RoleMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[RoleMaster](
	[RoleId] [smallint] IDENTITY(1,1) NOT NULL,
	[ApplicationId] [smallint] NOT NULL,
	[RoleName] [nvarchar](30) NOT NULL,
	[RoleLevel] [smallint] NOT NULL,
	[Only3M] [bit] NOT NULL,
	[DisplayLevelText] [nvarchar](30) NOT NULL,
 CONSTRAINT [PK_RoleMaster] PRIMARY KEY CLUSTERED 
(
	[RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[RolePermissions]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RolePermissions]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[RolePermissions](
	[Id] [int] NOT NULL,
	[OrganizationId] [int] NOT NULL,
	[RoleId] [smallint] NOT NULL,
	[MenuId] [smallint] NOT NULL,
	[CommonTaskId] [int] NOT NULL,
	[FeatureGroupKey] [smallint] NOT NULL,
	[Permission] [smallint] NOT NULL,
	[Order] [smallint] NOT NULL,
	[Display] [bit] NOT NULL,
	[OpeningMode] [smallint] NOT NULL,
 CONSTRAINT [PK_RolePermissions] PRIMARY KEY CLUSTERED 
(
	[Id] ASC,
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[RolePermissionsForAudit]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RolePermissionsForAudit]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[RolePermissionsForAudit](
	[Id] [int] NOT NULL,
	[OrganizationId] [int] NOT NULL,
	[RoleId] [smallint] NOT NULL,
	[FeatureGroupKey] [smallint] NOT NULL,
	[Permission] [smallint] NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[LastEditedBy] [int] NULL,
	[SrNo] [int] IDENTITY(1,1) NOT NULL,
 CONSTRAINT [PK_RolePermissionsForAudit] PRIMARY KEY CLUSTERED 
(
	[SrNo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[SamplePlanSchedule]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SamplePlanSchedule]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[SamplePlanSchedule](
	[ReportScheduleId] [int] NOT NULL,
	[OrganizationId] [int] NOT NULL,
	[ScheduleDefinitionMasterId] [int] NOT NULL,
	[ScheduleDate] [datetime] NOT NULL,
	[IsMissingNotificationSend] [bit] NOT NULL,
	[IsScheduledNotificationSend] [bit] NOT NULL,
 CONSTRAINT [PK_SamplePlanSchedule] PRIMARY KEY CLUSTERED 
(
	[ReportScheduleId] ASC,
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[ScheduleDaysOfMonth]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ScheduleDaysOfMonth]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ScheduleDaysOfMonth](
	[OrganizationId] [int] NOT NULL,
	[ScheduleId] [int] NOT NULL,
	[Day1] [bit] NULL,
	[Day2] [bit] NULL,
	[Day3] [bit] NULL,
	[Day4] [bit] NULL,
	[Day5] [bit] NULL,
	[Day6] [bit] NULL,
	[Day7] [bit] NULL,
	[Day8] [bit] NULL,
	[Day9] [bit] NULL,
	[Day10] [bit] NULL,
	[Day11] [bit] NULL,
	[Day12] [bit] NULL,
	[Day13] [bit] NULL,
	[Day14] [bit] NULL,
	[Day15] [bit] NULL,
	[Day16] [bit] NULL,
	[Day17] [bit] NULL,
	[Day18] [bit] NULL,
	[Day19] [bit] NULL,
	[Day20] [bit] NULL,
	[Day21] [bit] NULL,
	[Day22] [bit] NULL,
	[Day23] [bit] NULL,
	[Day24] [bit] NULL,
	[Day25] [bit] NULL,
	[Day26] [bit] NULL,
	[Day27] [bit] NULL,
	[Day28] [bit] NULL,
	[Day29] [bit] NULL,
	[Day30] [bit] NULL,
	[Day31] [bit] NULL,
	[Last] [bit] NULL,
 CONSTRAINT [PK_ScheduleDaysOfMonth] PRIMARY KEY CLUSTERED 
(
	[OrganizationId] ASC,
	[ScheduleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[ScheduleDaysOfWeek]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ScheduleDaysOfWeek]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ScheduleDaysOfWeek](
	[OrganizationId] [int] NOT NULL,
	[ScheduleId] [int] NOT NULL,
	[Monday] [bit] NULL,
	[Tuesday] [bit] NULL,
	[Wednesday] [bit] NULL,
	[Thursday] [bit] NULL,
	[Friday] [bit] NULL,
	[Saturday] [bit] NULL,
	[Sunday] [bit] NULL,
 CONSTRAINT [PK_ScheduleDaysOfWeek] PRIMARY KEY CLUSTERED 
(
	[OrganizationId] ASC,
	[ScheduleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[ScheduleDefinitionMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ScheduleDefinitionMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ScheduleDefinitionMaster](
	[OrganizationId] [int] NOT NULL,
	[ScheduleId] [int] NOT NULL,
	[ScheduleName] [nvarchar](max) NOT NULL,
	[ScheduleType] [smallint] NOT NULL,
	[ScheduleFrequencyId] [smallint] NOT NULL,
	[StartDate] [datetime] NOT NULL,
	[ExecutionTime] [time](7) NOT NULL,
	[IsEnabled] [bit] NOT NULL,
	[NextScheduleDateTime] [datetime] NOT NULL,
	[ScheduleSourceId] [bigint] NOT NULL,
	[ScheduleSourceSubId] [int] NULL,
	[IsOneTimeOnly] [bit] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[AreaId] [int] NULL,
	[RoomId] [int] NULL,
	[EndDate] [datetime] NULL,
	[NoOfOccurrances] [smallint] NULL,
	[NoOfExecutions] [smallint] NOT NULL,
	[DailyInterval] [smallint] NULL,
	[LastEditDate] [datetime] NULL,
	[LastEditedBy] [int] NULL,
	[OccuranceCount] [smallint] NULL,
	[ScheduleMonthlyOrder] [smallint] NULL,
	[ScheduleMonthlyPattern] [smallint] NULL
 CONSTRAINT [PK_ScheduleDefinitionMaster] PRIMARY KEY CLUSTERED 
(
	[ScheduleId] ASC,
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[ScheduleMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ScheduleMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ScheduleMaster](
	[OrganizationId] [int] NOT NULL,
	[ScheduleId] [int] NOT NULL,
	[ReportFilterId] [int] NOT NULL,
	[PeriodType] [smallint] NOT NULL,
	[DaysOfWeek] [varbinary](7) NULL,
	[DayOfMonth] [smallint] NULL,
	[TimeOfDay] [time](7) NULL,
	[LastRunDate] [datetime] NULL,
	[CreatedBy] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
 CONSTRAINT [PK_ScheduleMaster] PRIMARY KEY CLUSTERED 
(
	[OrganizationId] ASC,
	[ScheduleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ScheduleMonthsOfYear]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ScheduleMonthsOfYear]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ScheduleMonthsOfYear](
	[OrganizationId] [int] NOT NULL,
	[ScheduleId] [int] NOT NULL,
	[January] [bit] NULL,
	[February] [bit] NULL,
	[March] [bit] NULL,
	[April] [bit] NULL,
	[May] [bit] NULL,
	[June] [bit] NULL,
	[July] [bit] NULL,
	[August] [bit] NULL,
	[September] [bit] NULL,
	[October] [bit] NULL,
	[November] [bit] NULL,
	[December] [bit] NULL,
 CONSTRAINT [PK_ScheduleMonthsOfYear] PRIMARY KEY CLUSTERED 
(
	[ScheduleId] ASC,
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[ScheduleWeeksOfMonth]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ScheduleWeeksOfMonth]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ScheduleWeeksOfMonth](
	[OrganizationId] [int] NOT NULL,
	[ScheduleId] [int] NOT NULL,
	[First] [bit] NULL,
	[Second] [bit] NULL,
	[Third] [bit] NULL,
	[Forth] [bit] NULL,
	[Last] [bit] NULL,
 CONSTRAINT [PK_ScheduleWeeksOfMonth] PRIMARY KEY CLUSTERED 
(
	[ScheduleId] ASC,
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[ServiceRunLog]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ServiceRunLog]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ServiceRunLog](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ServiceIdentifier] [nvarchar](100) NOT NULL,
	[FirstRundate] [datetime] NULL,
	[LastRunDate] [datetime] NULL,
 CONSTRAINT [PK_ServiceRunLog] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[SupportedVersionMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SupportedVersionMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[SupportedVersionMaster](
	[VersionId] [int] IDENTITY(1,1) NOT NULL,
	[ApplicationId] [smallint] NOT NULL,
	[Type] [smallint] NOT NULL,
	[BuildVersion] [nvarchar](10) NOT NULL,
	[IsSupported] [bit] NOT NULL,
	[IsCurrent] [bit] NOT NULL,
	[ReleaseDate] [datetime] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[LastEditedDate] [datetime] NOT NULL,
	[LastEditedBy] [int] NOT NULL,
 CONSTRAINT [PK_SupportedVersionMaster] PRIMARY KEY CLUSTERED 
(
	[VersionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[SwabTypeMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SwabTypeMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[SwabTypeMaster](
	[SwabTypeId] [smallint] IDENTITY(1,1) NOT NULL,
	[ApplicationId] [smallint] NOT NULL,
	[SwabTypeName] [nvarchar](max) NOT NULL,
 CONSTRAINT [PK_SwabTypeMaster] PRIMARY KEY CLUSTERED 
(
	[SwabTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[TestMethodMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestMethodMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[TestMethodMaster](
	[TestMethodId] [smallint] IDENTITY(1,1) NOT NULL,
	[ApplicationId] [smallint] NOT NULL,
	[TestMethodName] [nvarchar](30) NOT NULL,
	[ShortName] [nvarchar](8) NOT NULL,
	[SwabTypeRequired] [bit] NOT NULL,
	[PassThreshold] [int] NULL,
	[FailThreshold] [int] NULL,
	[ThresholdType] [smallint] NOT NULL,
	[TestType] [smallint] NOT NULL,
 CONSTRAINT [PK_TestMethodMaster] PRIMARY KEY CLUSTERED 
(
	[TestMethodId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[TestPlanMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[TestPlanMaster](
	[OrganizationId] [int] NOT NULL,
	[TestPlanId] [int] NOT NULL,
	[TestPlanVersion] [smallint] NOT NULL,
	[TestPlanTypeId] [smallint] NOT NULL,
	[TestPlanName] [nvarchar](max) NULL,
	[LocationId] [int] NULL,
	[Status] [smallint] NOT NULL,
	[IsCurrent] [bit] NOT NULL,
	[LockedBy] [int] NULL,
	[IsImported] [bit] NULL,
	[ImportId] [int] NULL,
	[RandomPointCount] [smallint] NOT NULL,
	[IsNoRepeat] [bit] NOT NULL,
	[DBId] [uniqueidentifier] NULL,
	[Description] [nvarchar](250) NULL,
	[IsRandomizationApplicable] [bit] NOT NULL,
	[IsScheduleApplicable] [bit] NOT NULL,
	[LastResultSyncDate] [datetime] NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[LastEditDate] [datetime] NULL,
	[LastEditedBy] [int] NULL,
 CONSTRAINT [PK_TestPlanMaster] PRIMARY KEY CLUSTERED 
(
	[TestPlanId] ASC,
	[TestPlanVersion] ASC,
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[TestPlanResult]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanResult]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[TestPlanResult](
	[ResultId] [bigint] IDENTITY(1,1) NOT NULL,
	[OrganizationId] [int] NOT NULL,
	[TestPlanId] [int] NOT NULL,
	[TestPlanVersion] [smallint] NOT NULL,
	[TestPlanName] [nvarchar](max) NULL,
	[LocationId] [int] NULL,
	[LocationVersion] [smallint] NOT NULL,
	[Status] [smallint] NOT NULL,
	[OpenedDate] [datetime] NOT NULL,
	[OpenedBy] [int] NOT NULL,
	[DeviceId] [nvarchar](50) NOT NULL,
	[LastEditDate] [datetime] NULL,
	[LastEditedBy] [int] NULL,
	[ImportId] [nvarchar](50) NULL,
 CONSTRAINT [PK_TestPlanResult] PRIMARY KEY CLUSTERED 
(
	[ResultId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[TestPlanTestPointMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanTestPointMapping]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[TestPlanTestPointMapping](
	[OrganizationId] [int] NOT NULL,
	[TestPlanId] [int] NOT NULL,
	[TestPlanVersion] [smallint] NOT NULL,
	[TestPointId] [int] NOT NULL,
	[TestPointVersion] [smallint] NOT NULL,
	[Order] [smallint] NULL,
	[IsRandom] [bit] NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[LastEditedBy] [int] NULL,
 CONSTRAINT [PK_TestPlanTestPointMapping] PRIMARY KEY CLUSTERED 
(
	[TestPlanId] ASC,
	[TestPlanVersion] ASC,
	[OrganizationId] ASC,
	[TestPointId] ASC,
	[TestPointVersion] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[TestPlanTypeMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanTypeMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[TestPlanTypeMaster](
	[TestPlanTypeId] [smallint] IDENTITY(1,1) NOT NULL,
	[ApplicationId] [smallint] NOT NULL,
	[TestPlanTypeName] [nvarchar](30) NOT NULL,
	[ForReports] [bit] NOT NULL,
 CONSTRAINT [PK_TestPlanTypeMaster] PRIMARY KEY CLUSTERED 
(
	[TestPlanTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[TestPlanUserMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanUserMapping]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[TestPlanUserMapping](
	[OrganizationId] [int] NOT NULL,
	[UserId] [int] NOT NULL,
	[TestPlanId] [int] NOT NULL,
	[TestPlanVersion] [smallint] NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[LastEditedBy] [int] NULL,
 CONSTRAINT [PK_TestPlanUserMapping] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC,
	[OrganizationId] ASC,
	[TestPlanId] ASC,
	[TestPlanVersion] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[TestPointCustomParameterMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPointCustomParameterMapping]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[TestPointCustomParameterMapping](
	[OrganizationId] [int] NOT NULL,
	[TestPointId] [int] NOT NULL,
	[TestPointVersion] [smallint] NOT NULL,
	[CategoryId] [int] NOT NULL,
	[ParameterId] [int] NOT NULL,
 CONSTRAINT [PK_TestPointCustomParameterMapping] PRIMARY KEY NONCLUSTERED 
(
	[TestPointId] ASC,
	[TestPointVersion] ASC,
	[CategoryId] ASC,
	[OrganizationId] ASC,
	[ParameterId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[TestPointMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPointMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[TestPointMaster](
	[OrganizationId] [int] NOT NULL,
	[TestPointId] [int] NOT NULL,
	[TestPointVersion] [smallint] NOT NULL,
	[LocationId] [int] NOT NULL,
	[TestPointName] [nvarchar](max) NULL,
	[Status] [smallint] NOT NULL,
	[IsCurrent] [bit] NOT NULL,
	[PassThreshold] [int] NULL,
	[FailThreshold] [int] NULL,
	[Description] [nvarchar](250) NULL,
	[TestPointImage] [varbinary](max) NULL,
	[IsImported] [bit] NULL,
	[ImportId] [int] NULL,
	[TestPointGroupId] [int] NOT NULL,
	[ImageLastEditedDate] [datetime] NULL,
	[CreatedBy] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[LastEditedBy] [int] NULL,
	[LastEditDate] [datetime] NULL,
 CONSTRAINT [PK_TestPointMaster] PRIMARY KEY CLUSTERED 
(
	[TestPointId] ASC,
	[TestPointVersion] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[TestPointResult]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPointResult]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[TestPointResult](
	[ResultId] [bigint] NOT NULL,
	[MeasurementId] [int] NOT NULL,
	[TestPointId] [int] NOT NULL,
	[TestPointVersion] [smallint] NOT NULL,
	[TestPointName] [nvarchar](max) NULL,
	[TestPointLocationId] [int] NOT NULL,
	[LocationName] [nvarchar](max) NULL,
	[TestMethodId] [smallint] NOT NULL,
	[TestMethodVersion] [smallint] NOT NULL,
	[TestMethodName] [nvarchar](50) NOT NULL,
	[TestType] [smallint] NOT NULL,
	[IsRetest] [bit] NOT NULL,
	[IsAdhoc] [bit] NOT NULL,
	[Status] [smallint] NOT NULL,
	[Result] [smallint] NULL,
	[ResultValue] [float] NULL,
	[ResultDate] [datetime] NULL,
	[IsEdited] [bit] NULL,
	[ResultTakenBy] [int] NULL,
	[ResultTakenByName] [nvarchar](100) NULL,
	[OriginalMeasurementId] [int] NULL,
	[CapaComments] [nvarchar](1000) NULL,
	[CreatedDate] [datetime] NULL,
	[CreatedBy] [int] NULL,
	[LastEditDate] [datetime] NULL,
	[LastEditedBy] [int] NULL,
	[ATPPassThreshold] [decimal](10, 2) NULL,
	[ATPFailThreshold] [decimal](10, 2) NULL,
	[ThresholdType] [smallint] NULL,
	[UnitId] [int] NULL,
	[UnitName] [nvarchar](10) NULL,
	[ReasonToAdd] [nvarchar](1000) NULL,
	[Is3MSwab] [bit] NOT NULL,
	[IsFinal] [bit] NULL,
	[TestOrder] [int] NULL,
 CONSTRAINT [PK_TestPointResult] PRIMARY KEY CLUSTERED 
(
	[MeasurementId] ASC,
	[ResultId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[TestPointTestMethodMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPointTestMethodMapping]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[TestPointTestMethodMapping](
	[OrganizationId] [int] NOT NULL,
	[TestPointId] [int] NOT NULL,
	[TestPointVersion] [smallint] NOT NULL,
	[TestMethodId] [smallint] NOT NULL,
	[IsThresholdOverridden] [bit] NOT NULL,
	[ATPPassThreshold] [decimal](10, 2) NULL,
	[ATPFailThreshold] [decimal](10, 2) NULL,
	[ThresholdType] [smallint] NOT NULL,
 CONSTRAINT [PK_TestPointTestMethodMapping] PRIMARY KEY CLUSTERED 
(
	[TestPointId] ASC,
	[TestPointVersion] ASC,
	[OrganizationId] ASC,
	[TestMethodId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[TestResultCustomParameterMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestResultCustomParameterMapping]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[TestResultCustomParameterMapping](
	[ResultId] [bigint] NOT NULL,
	[MeasurementId] [int] NOT NULL,
	[OrganizationCategoryId] [int] NOT NULL,
	[ParameterId] [smallint] NOT NULL,
	[ParameterVersion] [smallint] NOT NULL,
	[EditedBy] [int] NULL,
	[EditedDate] [datetime] NULL,
 CONSTRAINT [PK_TestResultCustomParameterMapping] PRIMARY KEY CLUSTERED 
(
	[ResultId] ASC,
	[MeasurementId] ASC,
	[OrganizationCategoryId] ASC,
	[ParameterId] ASC,
	[ParameterVersion] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[TimezoneMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TimezoneMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[TimezoneMaster](
	[TimezoneId] [smallint] IDENTITY(1,1) NOT NULL,
	[Timezone] [nvarchar](50) NOT NULL,
	[DisplayTimezone] [nvarchar](100) NOT NULL,
	[TimeZoneShortName] nvarchar(30),
	[CountryName] nvarchar(2000),
	[UtcOffset] int
 CONSTRAINT [PK_TimezoneMaster] PRIMARY KEY CLUSTERED 
(
	[TimezoneId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[UnitMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UnitMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UnitMaster](
	[ApplicationId] [smallint] NOT NULL,
	[UnitId] [int] IDENTITY(1,1) NOT NULL,
	[UnitName] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_UnitMaster] PRIMARY KEY CLUSTERED 
(
	[UnitId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[UserCountryMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserCountryMapping]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UserCountryMapping](
	[UserId] [int] NOT NULL,
	[CountryId] [smallint] NOT NULL,
 CONSTRAINT [PK_UserCountryMapping] PRIMARY KEY NONCLUSTERED 
(
	[UserId] ASC,
	[CountryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[UserDashboardFilters]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserDashboardFilters]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UserDashboardFilters](
	[UserId] [int] NOT NULL,
	[DashboardFilterXml] [nvarchar](max) NOT NULL,
	[locationHierarchy] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[UserDashboardPreferences]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserDashboardPreferences]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UserDashboardPreferences](
	[OrganizationId] [int] NOT NULL,
	[PreferenceId] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [nvarchar](max) NOT NULL,
	[DateSelection] [smallint] NOT NULL,
	[FromDate] [datetime] NULL,
	[ToDate] [datetime] NULL,
	[TestTypeSelection] [smallint] NOT NULL,
 CONSTRAINT [PK_UserDashboardPreferences] PRIMARY KEY CLUSTERED 
(
	[PreferenceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[UserMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UserMaster](
	[UserId] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](30) NULL,
	[FirstName] [nvarchar](30) NOT NULL,
	[LastName] [nvarchar](30) NOT NULL,
	[Email] [nvarchar](50) NULL,
	[Status] [smallint] NOT NULL,
	[DefaultOrganization] [int] NOT NULL,
	[PreferencesSet] [bit] NOT NULL,
	[ResetPassword] [bit] NOT NULL,
	[LoginName] [nvarchar](50) NULL,
	[Password] [nvarchar](100) NULL,
	[LastLoginDateTime] [datetime] NULL,
	[PhoneNo] [nvarchar](30) NULL,
	[ContractOrganization] [int] NULL,
	[Notes] [nvarchar](max) NULL,
	[Pin] [int] NULL,
	[LastChangePasswordDate] [datetime] NULL,
	[DomainName] [nvarchar](30) NULL,
	[CreatedBy] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[LastEditedBy] [int] NULL,
	[LastEditDate] [datetime] NULL,
	[IsUserNotifiedForPasswordExpiry] [bit] NOT NULL,
	[CurrentRole] [smallint] NOT NULL,
	[IsLoginRequired] [bit] NOT NULL,
	[IsDashboardLoaded] [bit] NULL,
 CONSTRAINT [PK_UserMaster] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[UserPreferences]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserPreferences]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UserPreferences](
	[UserId] [int] NOT NULL,
	[PreferredLocale] [nvarchar](10) NULL,
	[SecretQuestion] [smallint] NULL,
	[SecretAnswer] [nvarchar](150) NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[LastEditDate] [datetime] NULL,
	[LastEditedBy] [int] NULL,
 CONSTRAINT [PK_UserPreferences] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[UserReportPreferences]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserReportPreferences]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UserReportPreferences](
	[ReportId] [int] IDENTITY(1,1) NOT NULL,
	[OrganizationId] [int] NOT NULL,
	[UserId] [int] NOT NULL,
	[ReportName] [nvarchar](50) NOT NULL,
	[Title] [nvarchar](50) NULL,
	[Type] [smallint] NOT NULL,
	[ChartType] [smallint] NOT NULL,
	[ChartDimension] [smallint] NOT NULL,
	[DateSelection] [smallint] NOT NULL,
	[FromDate] [datetime] NULL,
	[ToDate] [datetime] NULL,
	[TestPointSelection] [smallint] NOT NULL,
	[DateGrouping] [smallint] NOT NULL,
	[TestPointGrouping] [smallint] NOT NULL,
	[GroupPeriod] [smallint] NULL,
	[ResultCategory] [smallint] NOT NULL,
	[SchedulingType] [smallint] NOT NULL,
	[ScheduleFrequency] [smallint] NULL,
	[CreatedDate] [datetime] NOT NULL,
	[EditedDate] [datetime] NULL,
 CONSTRAINT [PK_UserReportPreferences] PRIMARY KEY CLUSTERED 
(
	[ReportId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[WorkFlowMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[WorkFlowMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[WorkFlowMaster](
	[WorkFlowId] [uniqueidentifier] NOT NULL,
	[IsAuthenticated] [bit] NOT NULL,
	[RequestorIdentifier] [nvarchar](50) NULL,
	[OrganizationName] [nvarchar](50) NULL,
	[OrganizationId] [int] NULL,
	[UserId] [int] NULL,
	[DeviceModelNumber] [nvarchar](20) NULL,
	[CreatedDate] [datetime] NOT NULL,
	[LastUsedDate] [datetime] NOT NULL,
	[ConsumerSource] [nvarchar](20) NOT NULL,
 CONSTRAINT [PK_WorkFlowMaster] PRIMARY KEY CLUSTERED 
(
	[WorkFlowId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[LuminometerPlantMapping]    Script Date: 11/30/2018 4:51:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LuminometerPlantMapping]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LuminometerPlantMapping](
       [OrganizationId] [int] NOT NULL,
       [LuminometerId] [int] NOT NULL,
       [DeviceSerialNumber] [nvarchar](50) NOT NULL,
       [LocationId] [int] NOT NULL,
       [CreatedDate] [datetime] NOT NULL,
       [CreatedBy] [int] NOT NULL,
       [LastEditDate] [datetime] NULL,
       [LastEditedBy] [int] NULL,
CONSTRAINT [PK_LMPlantMapping] PRIMARY KEY CLUSTERED 
(
       [OrganizationId] ASC,
       [LuminometerId] ASC,
       [LocationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Index [NCI-AdhocTestPlanResult-Oid-RidTplid]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPlanResult]') AND name = N'NCI-AdhocTestPlanResult-Oid-RidTplid')
CREATE NONCLUSTERED INDEX [NCI-AdhocTestPlanResult-Oid-RidTplid] ON [dbo].[AdhocTestPlanResult]
(
	[OrganizationId] ASC
)
INCLUDE ( 	[AdhocResultId],
	[TestPlanId]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_AdhocTestPlanResultAdhocTestPointResult]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]') AND name = N'IX_FK_AdhocTestPlanResultAdhocTestPointResult')
CREATE NONCLUSTERED INDEX [IX_FK_AdhocTestPlanResultAdhocTestPointResult] ON [dbo].[AdhocTestPointResult]
(
	[AdhocResultId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [NCI-AdhocTestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]') AND name = N'NCI-AdhocTestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To')
CREATE NONCLUSTERED INDEX [NCI-AdhocTestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To] ON [dbo].[AdhocTestPointResult]
(
	[ResultDate] ASC
)
INCLUDE ( 	[AdhocResultId],
	[AdhocMeasurementId],
	[TestPointId],
	[TestPointLocationId],
	[TestMethodId],
	[IsRetest],
	[Result],
	[ResultTakenBy],
	[Is3MSwab],
	[TestOrder]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_AuditLogMasterAuditLogDetails]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AuditLogDetails]') AND name = N'IX_FK_AuditLogMasterAuditLogDetails')
CREATE NONCLUSTERED INDEX [IX_FK_AuditLogMasterAuditLogDetails] ON [dbo].[AuditLogDetails]
(
	[AuditLogId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_OrganizationMasterCapaComments]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CapaComments]') AND name = N'IX_FK_OrganizationMasterCapaComments')
CREATE NONCLUSTERED INDEX [IX_FK_OrganizationMasterCapaComments] ON [dbo].[CapaComments]
(
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_RegionMasterCountryMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CountryMaster]') AND name = N'IX_FK_RegionMasterCountryMaster')
CREATE NONCLUSTERED INDEX [IX_FK_RegionMasterCountryMaster] ON [dbo].[CountryMaster]
(
	[RegionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_UserDashboardPreferencesDashboardSPMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DashboardSPMapping]') AND name = N'IX_FK_UserDashboardPreferencesDashboardSPMapping')
CREATE NONCLUSTERED INDEX [IX_FK_UserDashboardPreferencesDashboardSPMapping] ON [dbo].[DashboardSPMapping]
(
	[PreferenceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_OrganizationMasterDeviceSyncDetails]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DeviceSyncDetails]') AND name = N'IX_FK_OrganizationMasterDeviceSyncDetails')
CREATE NONCLUSTERED INDEX [IX_FK_OrganizationMasterDeviceSyncDetails] ON [dbo].[DeviceSyncDetails]
(
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_EditMeasurementEditTestResultCustomParameterMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EditTestResultCustomParameterMapping]') AND name = N'IX_FK_EditMeasurementEditTestResultCustomParameterMapping')
CREATE NONCLUSTERED INDEX [IX_FK_EditMeasurementEditTestResultCustomParameterMapping] ON [dbo].[EditTestResultCustomParameterMapping]
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_ApplicationMasterFeatureMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[FeatureMaster]') AND name = N'IX_FK_ApplicationMasterFeatureMaster')
CREATE NONCLUSTERED INDEX [IX_FK_ApplicationMasterFeatureMaster] ON [dbo].[FeatureMaster]
(
	[ApplicationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_OrganizationMasterAreaMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[LocationMaster]') AND name = N'IX_FK_OrganizationMasterAreaMaster')
CREATE NONCLUSTERED INDEX [IX_FK_OrganizationMasterAreaMaster] ON [dbo].[LocationMaster]
(
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_OrganizationMasterLuminometerMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[LuminometerMaster]') AND name = N'IX_FK_OrganizationMasterLuminometerMaster')
CREATE NONCLUSTERED INDEX [IX_FK_OrganizationMasterLuminometerMaster] ON [dbo].[LuminometerMaster]
(
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_OrganizationMasterOrganizationCategoryMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationCategoryMaster]') AND name = N'IX_FK_OrganizationMasterOrganizationCategoryMaster')
CREATE NONCLUSTERED INDEX [IX_FK_OrganizationMasterOrganizationCategoryMaster] ON [dbo].[OrganizationCategoryMaster]
(
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_OrganizationMasterOrganizationComments]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationComments]') AND name = N'IX_FK_OrganizationMasterOrganizationComments')
CREATE NONCLUSTERED INDEX [IX_FK_OrganizationMasterOrganizationComments] ON [dbo].[OrganizationComments]
(
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_OrganizationCustomParameterMasterOrganizationCustomParameterVersions]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationCustomParameterVersions]') AND name = N'IX_FK_OrganizationCustomParameterMasterOrganizationCustomParameterVersions')
CREATE NONCLUSTERED INDEX [IX_FK_OrganizationCustomParameterMasterOrganizationCustomParameterVersions] ON [dbo].[OrganizationCustomParameterVersions]
(
	[OrganizationCategoryId] ASC,
	[OrganizationId] ASC,
	[ParameterId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_OrganizationRoleUserMapping_UserMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationRoleUserMapping]') AND name = N'IX_FK_OrganizationRoleUserMapping_UserMaster')
CREATE NONCLUSTERED INDEX [IX_FK_OrganizationRoleUserMapping_UserMaster] ON [dbo].[OrganizationRoleUserMapping]
(
	[OrganizationRoleUserMapping_OrganizationRoleMaster_UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_ApplicationMasterOrganizationTestMethodMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodMaster]') AND name = N'IX_FK_ApplicationMasterOrganizationTestMethodMaster')
CREATE NONCLUSTERED INDEX [IX_FK_ApplicationMasterOrganizationTestMethodMaster] ON [dbo].[OrganizationTestMethodMaster]
(
	[ApplicationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_OrganizationMasterOrganizationTestMethodMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodMaster]') AND name = N'IX_FK_OrganizationMasterOrganizationTestMethodMaster')
CREATE NONCLUSTERED INDEX [IX_FK_OrganizationMasterOrganizationTestMethodMaster] ON [dbo].[OrganizationTestMethodMaster]
(
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_UnitMasterOrganizationTestMethodVersionMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodVersions]') AND name = N'IX_FK_UnitMasterOrganizationTestMethodVersionMaster')
CREATE NONCLUSTERED INDEX [IX_FK_UnitMasterOrganizationTestMethodVersionMaster] ON [dbo].[OrganizationTestMethodVersions]
(
	[UnitId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_ApplicationMasterOrganizationTypeMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationTypeMaster]') AND name = N'IX_FK_ApplicationMasterOrganizationTypeMaster')
CREATE NONCLUSTERED INDEX [IX_FK_ApplicationMasterOrganizationTypeMaster] ON [dbo].[OrganizationTypeMaster]
(
	[ApplicationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_CommonTasksRolePermissions]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[RolePermissions]') AND name = N'IX_FK_CommonTasksRolePermissions')
CREATE NONCLUSTERED INDEX [IX_FK_CommonTasksRolePermissions] ON [dbo].[RolePermissions]
(
	[CommonTaskId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_MenuRolePermissions]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[RolePermissions]') AND name = N'IX_FK_MenuRolePermissions')
CREATE NONCLUSTERED INDEX [IX_FK_MenuRolePermissions] ON [dbo].[RolePermissions]
(
	[MenuId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_ScheduleDefinitionMasterSamplePlanSchedule]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[SamplePlanSchedule]') AND name = N'IX_FK_ScheduleDefinitionMasterSamplePlanSchedule')
CREATE NONCLUSTERED INDEX [IX_FK_ScheduleDefinitionMasterSamplePlanSchedule] ON [dbo].[SamplePlanSchedule]
(
	[ScheduleDefinitionMasterId] ASC,
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_OrganizationMasterScheduleDefinitionMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[ScheduleDefinitionMaster]') AND name = N'IX_FK_OrganizationMasterScheduleDefinitionMaster')
CREATE NONCLUSTERED INDEX [IX_FK_OrganizationMasterScheduleDefinitionMaster] ON [dbo].[ScheduleDefinitionMaster]
(
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_ApplicationMasterSwabTypeMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[SwabTypeMaster]') AND name = N'IX_FK_ApplicationMasterSwabTypeMaster')
CREATE NONCLUSTERED INDEX [IX_FK_ApplicationMasterSwabTypeMaster] ON [dbo].[SwabTypeMaster]
(
	[ApplicationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_ApplicationMasterTestMethodMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestMethodMaster]') AND name = N'IX_FK_ApplicationMasterTestMethodMaster')
CREATE NONCLUSTERED INDEX [IX_FK_ApplicationMasterTestMethodMaster] ON [dbo].[TestMethodMaster]
(
	[ApplicationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_OrganizationMasterTestPlanMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanMaster]') AND name = N'IX_FK_OrganizationMasterTestPlanMaster')
CREATE NONCLUSTERED INDEX [IX_FK_OrganizationMasterTestPlanMaster] ON [dbo].[TestPlanMaster]
(
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_TestPlanTestPlanType]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanMaster]') AND name = N'IX_FK_TestPlanTestPlanType')
CREATE NONCLUSTERED INDEX [IX_FK_TestPlanTestPlanType] ON [dbo].[TestPlanMaster]
(
	[TestPlanTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [NCI-TestPlanResult-Oid-RidTplid]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanResult]') AND name = N'NCI-TestPlanResult-Oid-RidTplid')
CREATE NONCLUSTERED INDEX [NCI-TestPlanResult-Oid-RidTplid] ON [dbo].[TestPlanResult]
(
	[OrganizationId] ASC
)
INCLUDE ( 	[ResultId],
	[TestPlanId]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_TestPointMasterTestPlanTestPointMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanTestPointMapping]') AND name = N'IX_FK_TestPointMasterTestPlanTestPointMapping')
CREATE NONCLUSTERED INDEX [IX_FK_TestPointMasterTestPlanTestPointMapping] ON [dbo].[TestPlanTestPointMapping]
(
	[TestPointId] ASC,
	[TestPointVersion] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_ApplicationMasterTestPlanTypeMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanTypeMaster]') AND name = N'IX_FK_ApplicationMasterTestPlanTypeMaster')
CREATE NONCLUSTERED INDEX [IX_FK_ApplicationMasterTestPlanTypeMaster] ON [dbo].[TestPlanTypeMaster]
(
	[ApplicationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_TestPlanMasterTestPlanUserMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanUserMapping]') AND name = N'IX_FK_TestPlanMasterTestPlanUserMapping')
CREATE NONCLUSTERED INDEX [IX_FK_TestPlanMasterTestPlanUserMapping] ON [dbo].[TestPlanUserMapping]
(
	[TestPlanId] ASC,
	[TestPlanVersion] ASC,
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_OrganizationCustomParameterMasterTestPointCustomParameterMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPointCustomParameterMapping]') AND name = N'IX_FK_OrganizationCustomParameterMasterTestPointCustomParameterMapping')
CREATE NONCLUSTERED INDEX [IX_FK_OrganizationCustomParameterMasterTestPointCustomParameterMapping] ON [dbo].[TestPointCustomParameterMapping]
(
	[CategoryId] ASC,
	[OrganizationId] ASC,
	[ParameterId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_LocationMasterTestPointMaster]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPointMaster]') AND name = N'IX_FK_LocationMasterTestPointMaster')
CREATE NONCLUSTERED INDEX [IX_FK_LocationMasterTestPointMaster] ON [dbo].[TestPointMaster]
(
	[LocationId] ASC,
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_OrganizationID]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPointMaster]') AND name = N'IX_FK_OrganizationID')
CREATE NONCLUSTERED INDEX [IX_FK_OrganizationID] ON [dbo].[TestPointMaster]
(
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_TestPlanResultTestPointResult]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPointResult]') AND name = N'IX_FK_TestPlanResultTestPointResult')
CREATE NONCLUSTERED INDEX [IX_FK_TestPlanResultTestPointResult] ON [dbo].[TestPointResult]
(
	[ResultId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [NCI-TestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPointResult]') AND name = N'NCI-TestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To')
CREATE NONCLUSTERED INDEX [NCI-TestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To] ON [dbo].[TestPointResult]
(
	[ResultDate] ASC
)
INCLUDE ( 	[ResultId],
	[MeasurementId],
	[TestPointId],
	[TestPointLocationId],
	[TestMethodId],
	[IsRetest],
	[Result],
	[ResultTakenBy],
	[Is3MSwab],
	[TestOrder]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_OrganizationTestMethodMasterTestPointTestMethodMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPointTestMethodMapping]') AND name = N'IX_FK_OrganizationTestMethodMasterTestPointTestMethodMapping')
CREATE NONCLUSTERED INDEX [IX_FK_OrganizationTestMethodMasterTestPointTestMethodMapping] ON [dbo].[TestPointTestMethodMapping]
(
	[TestMethodId] ASC,
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_CountryMasterUserCountryMapping]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[UserCountryMapping]') AND name = N'IX_FK_CountryMasterUserCountryMapping')
CREATE NONCLUSTERED INDEX [IX_FK_CountryMasterUserCountryMapping] ON [dbo].[UserCountryMapping]
(
	[CountryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_OrganizationMasterUserDashboardPreferences1]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[UserDashboardPreferences]') AND name = N'IX_FK_OrganizationMasterUserDashboardPreferences1')
CREATE NONCLUSTERED INDEX [IX_FK_OrganizationMasterUserDashboardPreferences1] ON [dbo].[UserDashboardPreferences]
(
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_OrganizationMasterUserReportPreferences]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[UserReportPreferences]') AND name = N'IX_FK_OrganizationMasterUserReportPreferences')
CREATE NONCLUSTERED INDEX [IX_FK_OrganizationMasterUserReportPreferences] ON [dbo].[UserReportPreferences]
(
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_UserMasterUserReportPreferences]    Script Date: 5/20/2018 3:55:20 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[UserReportPreferences]') AND name = N'IX_FK_UserMasterUserReportPreferences')
CREATE NONCLUSTERED INDEX [IX_FK_UserMasterUserReportPreferences] ON [dbo].[UserReportPreferences]
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_AdhocTestPlanResultAdhocTestPointResult]') AND parent_object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]'))
ALTER TABLE [dbo].[AdhocTestPointResult]  WITH CHECK ADD  CONSTRAINT [FK_AdhocTestPlanResultAdhocTestPointResult] FOREIGN KEY([AdhocResultId])
REFERENCES [dbo].[AdhocTestPlanResult] ([AdhocResultId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_AdhocTestPlanResultAdhocTestPointResult]') AND parent_object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]'))
ALTER TABLE [dbo].[AdhocTestPointResult] CHECK CONSTRAINT [FK_AdhocTestPlanResultAdhocTestPointResult]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_AuditLogMasterAuditLogDetails]') AND parent_object_id = OBJECT_ID(N'[dbo].[AuditLogDetails]'))
ALTER TABLE [dbo].[AuditLogDetails]  WITH CHECK ADD  CONSTRAINT [FK_AuditLogMasterAuditLogDetails] FOREIGN KEY([AuditLogId])
REFERENCES [dbo].[AuditLogMaster] ([AuditLogId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_AuditLogMasterAuditLogDetails]') AND parent_object_id = OBJECT_ID(N'[dbo].[AuditLogDetails]'))
ALTER TABLE [dbo].[AuditLogDetails] CHECK CONSTRAINT [FK_AuditLogMasterAuditLogDetails]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterCapaComments]') AND parent_object_id = OBJECT_ID(N'[dbo].[CapaComments]'))
ALTER TABLE [dbo].[CapaComments]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationMasterCapaComments] FOREIGN KEY([OrganizationId])
REFERENCES [dbo].[OrganizationMaster] ([OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterCapaComments]') AND parent_object_id = OBJECT_ID(N'[dbo].[CapaComments]'))
ALTER TABLE [dbo].[CapaComments] CHECK CONSTRAINT [FK_OrganizationMasterCapaComments]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_RegionMasterCountryMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[CountryMaster]'))
ALTER TABLE [dbo].[CountryMaster]  WITH CHECK ADD  CONSTRAINT [FK_RegionMasterCountryMaster] FOREIGN KEY([RegionId])
REFERENCES [dbo].[RegionMaster] ([RegionId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_RegionMasterCountryMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[CountryMaster]'))
ALTER TABLE [dbo].[CountryMaster] CHECK CONSTRAINT [FK_RegionMasterCountryMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserDashboardPreferencesDashboardSPMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[DashboardSPMapping]'))
ALTER TABLE [dbo].[DashboardSPMapping]  WITH CHECK ADD  CONSTRAINT [FK_UserDashboardPreferencesDashboardSPMapping] FOREIGN KEY([PreferenceId])
REFERENCES [dbo].[UserDashboardPreferences] ([PreferenceId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserDashboardPreferencesDashboardSPMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[DashboardSPMapping]'))
ALTER TABLE [dbo].[DashboardSPMapping] CHECK CONSTRAINT [FK_UserDashboardPreferencesDashboardSPMapping]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterDeviceSyncDetails]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceSyncDetails]'))
ALTER TABLE [dbo].[DeviceSyncDetails]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationMasterDeviceSyncDetails] FOREIGN KEY([OrganizationId])
REFERENCES [dbo].[OrganizationMaster] ([OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterDeviceSyncDetails]') AND parent_object_id = OBJECT_ID(N'[dbo].[DeviceSyncDetails]'))
ALTER TABLE [dbo].[DeviceSyncDetails] CHECK CONSTRAINT [FK_OrganizationMasterDeviceSyncDetails]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_EditMeasurementEditTestResultCustomParameterMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[EditTestResultCustomParameterMapping]'))
ALTER TABLE [dbo].[EditTestResultCustomParameterMapping]  WITH CHECK ADD  CONSTRAINT [FK_EditMeasurementEditTestResultCustomParameterMapping] FOREIGN KEY([Id])
REFERENCES [dbo].[EditMeasurement] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_EditMeasurementEditTestResultCustomParameterMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[EditTestResultCustomParameterMapping]'))
ALTER TABLE [dbo].[EditTestResultCustomParameterMapping] CHECK CONSTRAINT [FK_EditMeasurementEditTestResultCustomParameterMapping]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ApplicationMasterFeatureMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[FeatureMaster]'))
ALTER TABLE [dbo].[FeatureMaster]  WITH CHECK ADD  CONSTRAINT [FK_ApplicationMasterFeatureMaster] FOREIGN KEY([ApplicationId])
REFERENCES [dbo].[ApplicationMaster] ([ApplicationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ApplicationMasterFeatureMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[FeatureMaster]'))
ALTER TABLE [dbo].[FeatureMaster] CHECK CONSTRAINT [FK_ApplicationMasterFeatureMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterLocationLevelMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[LocationLevelMaster]'))
ALTER TABLE [dbo].[LocationLevelMaster]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationMasterLocationLevelMaster] FOREIGN KEY([OrganizationId])
REFERENCES [dbo].[OrganizationMaster] ([OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterLocationLevelMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[LocationLevelMaster]'))
ALTER TABLE [dbo].[LocationLevelMaster] CHECK CONSTRAINT [FK_OrganizationMasterLocationLevelMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterAreaMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[LocationMaster]'))
ALTER TABLE [dbo].[LocationMaster]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationMasterAreaMaster] FOREIGN KEY([OrganizationId])
REFERENCES [dbo].[OrganizationMaster] ([OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterAreaMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[LocationMaster]'))
ALTER TABLE [dbo].[LocationMaster] CHECK CONSTRAINT [FK_OrganizationMasterAreaMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterLuminometerMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[LuminometerMaster]'))
ALTER TABLE [dbo].[LuminometerMaster]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationMasterLuminometerMaster] FOREIGN KEY([OrganizationId])
REFERENCES [dbo].[OrganizationMaster] ([OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterLuminometerMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[LuminometerMaster]'))
ALTER TABLE [dbo].[LuminometerMaster] CHECK CONSTRAINT [FK_OrganizationMasterLuminometerMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterOrganizationCategoryMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationCategoryMaster]'))
ALTER TABLE [dbo].[OrganizationCategoryMaster]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationMasterOrganizationCategoryMaster] FOREIGN KEY([OrganizationId])
REFERENCES [dbo].[OrganizationMaster] ([OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterOrganizationCategoryMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationCategoryMaster]'))
ALTER TABLE [dbo].[OrganizationCategoryMaster] CHECK CONSTRAINT [FK_OrganizationMasterOrganizationCategoryMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterOrganizationComments]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationComments]'))
ALTER TABLE [dbo].[OrganizationComments]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationMasterOrganizationComments] FOREIGN KEY([OrganizationId])
REFERENCES [dbo].[OrganizationMaster] ([OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterOrganizationComments]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationComments]'))
ALTER TABLE [dbo].[OrganizationComments] CHECK CONSTRAINT [FK_OrganizationMasterOrganizationComments]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationConfigurationId]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationConfiguration]'))
ALTER TABLE [dbo].[OrganizationConfiguration]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationConfigurationId] FOREIGN KEY([OrganizationId])
REFERENCES [dbo].[OrganizationMaster] ([OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationConfigurationId]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationConfiguration]'))
ALTER TABLE [dbo].[OrganizationConfiguration] CHECK CONSTRAINT [FK_OrganizationConfigurationId]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationCategoryMasterOrganizationCustomParameterMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationCustomParameterMaster]'))
ALTER TABLE [dbo].[OrganizationCustomParameterMaster]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationCategoryMasterOrganizationCustomParameterMaster] FOREIGN KEY([OrganizationCategoryId], [OrganizationId])
REFERENCES [dbo].[OrganizationCategoryMaster] ([OrganizationCategoryId], [OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationCategoryMasterOrganizationCustomParameterMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationCustomParameterMaster]'))
ALTER TABLE [dbo].[OrganizationCustomParameterMaster] CHECK CONSTRAINT [FK_OrganizationCategoryMasterOrganizationCustomParameterMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationCustomParameterMasterOrganizationCustomParameterVersions]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationCustomParameterVersions]'))
ALTER TABLE [dbo].[OrganizationCustomParameterVersions]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationCustomParameterMasterOrganizationCustomParameterVersions] FOREIGN KEY([OrganizationCategoryId], [OrganizationId], [ParameterId])
REFERENCES [dbo].[OrganizationCustomParameterMaster] ([OrganizationCategoryId], [OrganizationId], [ParameterId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationCustomParameterMasterOrganizationCustomParameterVersions]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationCustomParameterVersions]'))
ALTER TABLE [dbo].[OrganizationCustomParameterVersions] CHECK CONSTRAINT [FK_OrganizationCustomParameterMasterOrganizationCustomParameterVersions]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationImage]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationImageMaster]'))
ALTER TABLE [dbo].[OrganizationImageMaster]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationImage] FOREIGN KEY([OrganizationId])
REFERENCES [dbo].[OrganizationMaster] ([OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationImage]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationImageMaster]'))
ALTER TABLE [dbo].[OrganizationImageMaster] CHECK CONSTRAINT [FK_OrganizationImage]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterOrganizationRoleMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationRoleMaster]'))
ALTER TABLE [dbo].[OrganizationRoleMaster]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationMasterOrganizationRoleMaster] FOREIGN KEY([OrganizationId])
REFERENCES [dbo].[OrganizationMaster] ([OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterOrganizationRoleMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationRoleMaster]'))
ALTER TABLE [dbo].[OrganizationRoleMaster] CHECK CONSTRAINT [FK_OrganizationMasterOrganizationRoleMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationRoleUserMapping_OrganizationRoleMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationRoleUserMapping]'))
ALTER TABLE [dbo].[OrganizationRoleUserMapping]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationRoleUserMapping_OrganizationRoleMaster] FOREIGN KEY([OrganizationRoleMaster_OrganizationId], [OrganizationRoleMaster_RoleId])
REFERENCES [dbo].[OrganizationRoleMaster] ([OrganizationId], [RoleId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationRoleUserMapping_OrganizationRoleMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationRoleUserMapping]'))
ALTER TABLE [dbo].[OrganizationRoleUserMapping] CHECK CONSTRAINT [FK_OrganizationRoleUserMapping_OrganizationRoleMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationRoleUserMapping_UserMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationRoleUserMapping]'))
ALTER TABLE [dbo].[OrganizationRoleUserMapping]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationRoleUserMapping_UserMaster] FOREIGN KEY([OrganizationRoleUserMapping_OrganizationRoleMaster_UserId])
REFERENCES [dbo].[UserMaster] ([UserId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationRoleUserMapping_UserMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationRoleUserMapping]'))
ALTER TABLE [dbo].[OrganizationRoleUserMapping] CHECK CONSTRAINT [FK_OrganizationRoleUserMapping_UserMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ApplicationMasterOrganizationTestMethodMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodMaster]'))
ALTER TABLE [dbo].[OrganizationTestMethodMaster]  WITH CHECK ADD  CONSTRAINT [FK_ApplicationMasterOrganizationTestMethodMaster] FOREIGN KEY([ApplicationId])
REFERENCES [dbo].[ApplicationMaster] ([ApplicationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ApplicationMasterOrganizationTestMethodMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodMaster]'))
ALTER TABLE [dbo].[OrganizationTestMethodMaster] CHECK CONSTRAINT [FK_ApplicationMasterOrganizationTestMethodMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterOrganizationTestMethodMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodMaster]'))
ALTER TABLE [dbo].[OrganizationTestMethodMaster]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationMasterOrganizationTestMethodMaster] FOREIGN KEY([OrganizationId])
REFERENCES [dbo].[OrganizationMaster] ([OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterOrganizationTestMethodMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodMaster]'))
ALTER TABLE [dbo].[OrganizationTestMethodMaster] CHECK CONSTRAINT [FK_OrganizationMasterOrganizationTestMethodMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationTestMethodMasterOrganizationTestMethodVersions]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodVersions]'))
ALTER TABLE [dbo].[OrganizationTestMethodVersions]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationTestMethodMasterOrganizationTestMethodVersions] FOREIGN KEY([TestMethodId], [OrganizationId])
REFERENCES [dbo].[OrganizationTestMethodMaster] ([TestMethodId], [OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationTestMethodMasterOrganizationTestMethodVersions]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodVersions]'))
ALTER TABLE [dbo].[OrganizationTestMethodVersions] CHECK CONSTRAINT [FK_OrganizationTestMethodMasterOrganizationTestMethodVersions]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UnitMasterOrganizationTestMethodVersionMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodVersions]'))
ALTER TABLE [dbo].[OrganizationTestMethodVersions]  WITH CHECK ADD  CONSTRAINT [FK_UnitMasterOrganizationTestMethodVersionMaster] FOREIGN KEY([UnitId])
REFERENCES [dbo].[UnitMaster] ([UnitId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UnitMasterOrganizationTestMethodVersionMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodVersions]'))
ALTER TABLE [dbo].[OrganizationTestMethodVersions] CHECK CONSTRAINT [FK_UnitMasterOrganizationTestMethodVersionMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ApplicationMasterOrganizationTypeMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationTypeMaster]'))
ALTER TABLE [dbo].[OrganizationTypeMaster]  WITH CHECK ADD  CONSTRAINT [FK_ApplicationMasterOrganizationTypeMaster] FOREIGN KEY([ApplicationId])
REFERENCES [dbo].[ApplicationMaster] ([ApplicationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ApplicationMasterOrganizationTypeMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[OrganizationTypeMaster]'))
ALTER TABLE [dbo].[OrganizationTypeMaster] CHECK CONSTRAINT [FK_ApplicationMasterOrganizationTypeMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserReportPreferencesReportLocationMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[ReportLocationMapping]'))
ALTER TABLE [dbo].[ReportLocationMapping]  WITH CHECK ADD  CONSTRAINT [FK_UserReportPreferencesReportLocationMapping] FOREIGN KEY([ReportId])
REFERENCES [dbo].[UserReportPreferences] ([ReportId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserReportPreferencesReportLocationMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[ReportLocationMapping]'))
ALTER TABLE [dbo].[ReportLocationMapping] CHECK CONSTRAINT [FK_UserReportPreferencesReportLocationMapping]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CommonTasksRolePermissions]') AND parent_object_id = OBJECT_ID(N'[dbo].[RolePermissions]'))
ALTER TABLE [dbo].[RolePermissions]  WITH CHECK ADD  CONSTRAINT [FK_CommonTasksRolePermissions] FOREIGN KEY([CommonTaskId])
REFERENCES [dbo].[CommonTasks] ([CommonTaskId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CommonTasksRolePermissions]') AND parent_object_id = OBJECT_ID(N'[dbo].[RolePermissions]'))
ALTER TABLE [dbo].[RolePermissions] CHECK CONSTRAINT [FK_CommonTasksRolePermissions]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_MenuRolePermissions]') AND parent_object_id = OBJECT_ID(N'[dbo].[RolePermissions]'))
ALTER TABLE [dbo].[RolePermissions]  WITH CHECK ADD  CONSTRAINT [FK_MenuRolePermissions] FOREIGN KEY([MenuId])
REFERENCES [dbo].[Menu] ([MenuId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_MenuRolePermissions]') AND parent_object_id = OBJECT_ID(N'[dbo].[RolePermissions]'))
ALTER TABLE [dbo].[RolePermissions] CHECK CONSTRAINT [FK_MenuRolePermissions]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ScheduleDefinitionMasterSamplePlanSchedule]') AND parent_object_id = OBJECT_ID(N'[dbo].[SamplePlanSchedule]'))
ALTER TABLE [dbo].[SamplePlanSchedule]  WITH CHECK ADD  CONSTRAINT [FK_ScheduleDefinitionMasterSamplePlanSchedule] FOREIGN KEY([ScheduleDefinitionMasterId], [OrganizationId])
REFERENCES [dbo].[ScheduleDefinitionMaster] ([ScheduleId], [OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ScheduleDefinitionMasterSamplePlanSchedule]') AND parent_object_id = OBJECT_ID(N'[dbo].[SamplePlanSchedule]'))
ALTER TABLE [dbo].[SamplePlanSchedule] CHECK CONSTRAINT [FK_ScheduleDefinitionMasterSamplePlanSchedule]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ScheduleDefinitionMasterScheduleDaysOfMonth]') AND parent_object_id = OBJECT_ID(N'[dbo].[ScheduleDaysOfMonth]'))
ALTER TABLE [dbo].[ScheduleDaysOfMonth]  WITH CHECK ADD  CONSTRAINT [FK_ScheduleDefinitionMasterScheduleDaysOfMonth] FOREIGN KEY([ScheduleId], [OrganizationId])
REFERENCES [dbo].[ScheduleDefinitionMaster] ([ScheduleId], [OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ScheduleDefinitionMasterScheduleDaysOfMonth]') AND parent_object_id = OBJECT_ID(N'[dbo].[ScheduleDaysOfMonth]'))
ALTER TABLE [dbo].[ScheduleDaysOfMonth] CHECK CONSTRAINT [FK_ScheduleDefinitionMasterScheduleDaysOfMonth]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ScheduleDaysOfWeekScheduleDefinitionMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[ScheduleDaysOfWeek]'))
ALTER TABLE [dbo].[ScheduleDaysOfWeek]  WITH CHECK ADD  CONSTRAINT [FK_ScheduleDaysOfWeekScheduleDefinitionMaster] FOREIGN KEY([ScheduleId], [OrganizationId])
REFERENCES [dbo].[ScheduleDefinitionMaster] ([ScheduleId], [OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ScheduleDaysOfWeekScheduleDefinitionMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[ScheduleDaysOfWeek]'))
ALTER TABLE [dbo].[ScheduleDaysOfWeek] CHECK CONSTRAINT [FK_ScheduleDaysOfWeekScheduleDefinitionMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterScheduleDefinitionMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[ScheduleDefinitionMaster]'))
ALTER TABLE [dbo].[ScheduleDefinitionMaster]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationMasterScheduleDefinitionMaster] FOREIGN KEY([OrganizationId])
REFERENCES [dbo].[OrganizationMaster] ([OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterScheduleDefinitionMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[ScheduleDefinitionMaster]'))
ALTER TABLE [dbo].[ScheduleDefinitionMaster] CHECK CONSTRAINT [FK_OrganizationMasterScheduleDefinitionMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ScheduleMaster_OrganizationMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[ScheduleMaster]'))
ALTER TABLE [dbo].[ScheduleMaster]  WITH CHECK ADD  CONSTRAINT [FK_ScheduleMaster_OrganizationMaster] FOREIGN KEY([OrganizationId])
REFERENCES [dbo].[OrganizationMaster] ([OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ScheduleMaster_OrganizationMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[ScheduleMaster]'))
ALTER TABLE [dbo].[ScheduleMaster] CHECK CONSTRAINT [FK_ScheduleMaster_OrganizationMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ScheduleMonthsOfYearScheduleDefinitionMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[ScheduleMonthsOfYear]'))
ALTER TABLE [dbo].[ScheduleMonthsOfYear]  WITH CHECK ADD  CONSTRAINT [FK_ScheduleMonthsOfYearScheduleDefinitionMaster] FOREIGN KEY([ScheduleId], [OrganizationId])
REFERENCES [dbo].[ScheduleDefinitionMaster] ([ScheduleId], [OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ScheduleMonthsOfYearScheduleDefinitionMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[ScheduleMonthsOfYear]'))
ALTER TABLE [dbo].[ScheduleMonthsOfYear] CHECK CONSTRAINT [FK_ScheduleMonthsOfYearScheduleDefinitionMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ScheduleWeeksOfMonthScheduleDefinitionMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[ScheduleWeeksOfMonth]'))
ALTER TABLE [dbo].[ScheduleWeeksOfMonth]  WITH CHECK ADD  CONSTRAINT [FK_ScheduleWeeksOfMonthScheduleDefinitionMaster] FOREIGN KEY([ScheduleId], [OrganizationId])
REFERENCES [dbo].[ScheduleDefinitionMaster] ([ScheduleId], [OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ScheduleWeeksOfMonthScheduleDefinitionMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[ScheduleWeeksOfMonth]'))
ALTER TABLE [dbo].[ScheduleWeeksOfMonth] CHECK CONSTRAINT [FK_ScheduleWeeksOfMonthScheduleDefinitionMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ApplicationMasterSwabTypeMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[SwabTypeMaster]'))
ALTER TABLE [dbo].[SwabTypeMaster]  WITH CHECK ADD  CONSTRAINT [FK_ApplicationMasterSwabTypeMaster] FOREIGN KEY([ApplicationId])
REFERENCES [dbo].[ApplicationMaster] ([ApplicationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ApplicationMasterSwabTypeMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[SwabTypeMaster]'))
ALTER TABLE [dbo].[SwabTypeMaster] CHECK CONSTRAINT [FK_ApplicationMasterSwabTypeMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ApplicationMasterTestMethodMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestMethodMaster]'))
ALTER TABLE [dbo].[TestMethodMaster]  WITH CHECK ADD  CONSTRAINT [FK_ApplicationMasterTestMethodMaster] FOREIGN KEY([ApplicationId])
REFERENCES [dbo].[ApplicationMaster] ([ApplicationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ApplicationMasterTestMethodMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestMethodMaster]'))
ALTER TABLE [dbo].[TestMethodMaster] CHECK CONSTRAINT [FK_ApplicationMasterTestMethodMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterTestPlanMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPlanMaster]'))
ALTER TABLE [dbo].[TestPlanMaster]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationMasterTestPlanMaster] FOREIGN KEY([OrganizationId])
REFERENCES [dbo].[OrganizationMaster] ([OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterTestPlanMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPlanMaster]'))
ALTER TABLE [dbo].[TestPlanMaster] CHECK CONSTRAINT [FK_OrganizationMasterTestPlanMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPlanTestPlanType]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPlanMaster]'))
ALTER TABLE [dbo].[TestPlanMaster]  WITH CHECK ADD  CONSTRAINT [FK_TestPlanTestPlanType] FOREIGN KEY([TestPlanTypeId])
REFERENCES [dbo].[TestPlanTypeMaster] ([TestPlanTypeId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPlanTestPlanType]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPlanMaster]'))
ALTER TABLE [dbo].[TestPlanMaster] CHECK CONSTRAINT [FK_TestPlanTestPlanType]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPlanMasterTestPlanTestPointMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPlanTestPointMapping]'))
ALTER TABLE [dbo].[TestPlanTestPointMapping]  WITH CHECK ADD  CONSTRAINT [FK_TestPlanMasterTestPlanTestPointMapping] FOREIGN KEY([TestPlanId], [TestPlanVersion], [OrganizationId])
REFERENCES [dbo].[TestPlanMaster] ([TestPlanId], [TestPlanVersion], [OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPlanMasterTestPlanTestPointMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPlanTestPointMapping]'))
ALTER TABLE [dbo].[TestPlanTestPointMapping] CHECK CONSTRAINT [FK_TestPlanMasterTestPlanTestPointMapping]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPointMasterTestPlanTestPointMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPlanTestPointMapping]'))
ALTER TABLE [dbo].[TestPlanTestPointMapping]  WITH CHECK ADD  CONSTRAINT [FK_TestPointMasterTestPlanTestPointMapping] FOREIGN KEY([TestPointId], [TestPointVersion])
REFERENCES [dbo].[TestPointMaster] ([TestPointId], [TestPointVersion])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPointMasterTestPlanTestPointMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPlanTestPointMapping]'))
ALTER TABLE [dbo].[TestPlanTestPointMapping] CHECK CONSTRAINT [FK_TestPointMasterTestPlanTestPointMapping]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ApplicationMasterTestPlanTypeMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPlanTypeMaster]'))
ALTER TABLE [dbo].[TestPlanTypeMaster]  WITH CHECK ADD  CONSTRAINT [FK_ApplicationMasterTestPlanTypeMaster] FOREIGN KEY([ApplicationId])
REFERENCES [dbo].[ApplicationMaster] ([ApplicationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ApplicationMasterTestPlanTypeMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPlanTypeMaster]'))
ALTER TABLE [dbo].[TestPlanTypeMaster] CHECK CONSTRAINT [FK_ApplicationMasterTestPlanTypeMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPlanMasterTestPlanUserMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPlanUserMapping]'))
ALTER TABLE [dbo].[TestPlanUserMapping]  WITH CHECK ADD  CONSTRAINT [FK_TestPlanMasterTestPlanUserMapping] FOREIGN KEY([TestPlanId], [TestPlanVersion], [OrganizationId])
REFERENCES [dbo].[TestPlanMaster] ([TestPlanId], [TestPlanVersion], [OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPlanMasterTestPlanUserMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPlanUserMapping]'))
ALTER TABLE [dbo].[TestPlanUserMapping] CHECK CONSTRAINT [FK_TestPlanMasterTestPlanUserMapping]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserMasterTestPlanUserMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPlanUserMapping]'))
ALTER TABLE [dbo].[TestPlanUserMapping]  WITH CHECK ADD  CONSTRAINT [FK_UserMasterTestPlanUserMapping] FOREIGN KEY([UserId])
REFERENCES [dbo].[UserMaster] ([UserId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserMasterTestPlanUserMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPlanUserMapping]'))
ALTER TABLE [dbo].[TestPlanUserMapping] CHECK CONSTRAINT [FK_UserMasterTestPlanUserMapping]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationCustomParameterMasterTestPointCustomParameterMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointCustomParameterMapping]'))
ALTER TABLE [dbo].[TestPointCustomParameterMapping]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationCustomParameterMasterTestPointCustomParameterMapping] FOREIGN KEY([CategoryId], [OrganizationId], [ParameterId])
REFERENCES [dbo].[OrganizationCustomParameterMaster] ([OrganizationCategoryId], [OrganizationId], [ParameterId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationCustomParameterMasterTestPointCustomParameterMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointCustomParameterMapping]'))
ALTER TABLE [dbo].[TestPointCustomParameterMapping] CHECK CONSTRAINT [FK_OrganizationCustomParameterMasterTestPointCustomParameterMapping]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPointMasterTestPointCustomParameterMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointCustomParameterMapping]'))
ALTER TABLE [dbo].[TestPointCustomParameterMapping]  WITH CHECK ADD  CONSTRAINT [FK_TestPointMasterTestPointCustomParameterMapping] FOREIGN KEY([TestPointId], [TestPointVersion])
REFERENCES [dbo].[TestPointMaster] ([TestPointId], [TestPointVersion])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPointMasterTestPointCustomParameterMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointCustomParameterMapping]'))
ALTER TABLE [dbo].[TestPointCustomParameterMapping] CHECK CONSTRAINT [FK_TestPointMasterTestPointCustomParameterMapping]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_LocationMasterTestPointMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointMaster]'))
ALTER TABLE [dbo].[TestPointMaster]  WITH CHECK ADD  CONSTRAINT [FK_LocationMasterTestPointMaster] FOREIGN KEY([LocationId], [OrganizationId])
REFERENCES [dbo].[LocationMaster] ([LocationId], [OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_LocationMasterTestPointMaster]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointMaster]'))
ALTER TABLE [dbo].[TestPointMaster] CHECK CONSTRAINT [FK_LocationMasterTestPointMaster]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationID]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointMaster]'))
ALTER TABLE [dbo].[TestPointMaster]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationID] FOREIGN KEY([OrganizationId])
REFERENCES [dbo].[OrganizationMaster] ([OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationID]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointMaster]'))
ALTER TABLE [dbo].[TestPointMaster] CHECK CONSTRAINT [FK_OrganizationID]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPlanResultTestPointResult]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointResult]'))
ALTER TABLE [dbo].[TestPointResult]  WITH CHECK ADD  CONSTRAINT [FK_TestPlanResultTestPointResult] FOREIGN KEY([ResultId])
REFERENCES [dbo].[TestPlanResult] ([ResultId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPlanResultTestPointResult]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointResult]'))
ALTER TABLE [dbo].[TestPointResult] CHECK CONSTRAINT [FK_TestPlanResultTestPointResult]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationTestMethodMasterTestPointTestMethodMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointTestMethodMapping]'))
ALTER TABLE [dbo].[TestPointTestMethodMapping]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationTestMethodMasterTestPointTestMethodMapping] FOREIGN KEY([TestMethodId], [OrganizationId])
REFERENCES [dbo].[OrganizationTestMethodMaster] ([TestMethodId], [OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationTestMethodMasterTestPointTestMethodMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointTestMethodMapping]'))
ALTER TABLE [dbo].[TestPointTestMethodMapping] CHECK CONSTRAINT [FK_OrganizationTestMethodMasterTestPointTestMethodMapping]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPointMasterTestPointTestMethodMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointTestMethodMapping]'))
ALTER TABLE [dbo].[TestPointTestMethodMapping]  WITH CHECK ADD  CONSTRAINT [FK_TestPointMasterTestPointTestMethodMapping] FOREIGN KEY([TestPointId], [TestPointVersion])
REFERENCES [dbo].[TestPointMaster] ([TestPointId], [TestPointVersion])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPointMasterTestPointTestMethodMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointTestMethodMapping]'))
ALTER TABLE [dbo].[TestPointTestMethodMapping] CHECK CONSTRAINT [FK_TestPointMasterTestPointTestMethodMapping]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CountryMasterUserCountryMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserCountryMapping]'))
ALTER TABLE [dbo].[UserCountryMapping]  WITH CHECK ADD  CONSTRAINT [FK_CountryMasterUserCountryMapping] FOREIGN KEY([CountryId])
REFERENCES [dbo].[CountryMaster] ([CountryId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CountryMasterUserCountryMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserCountryMapping]'))
ALTER TABLE [dbo].[UserCountryMapping] CHECK CONSTRAINT [FK_CountryMasterUserCountryMapping]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserMasterUserCountryMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserCountryMapping]'))
ALTER TABLE [dbo].[UserCountryMapping]  WITH CHECK ADD  CONSTRAINT [FK_UserMasterUserCountryMapping] FOREIGN KEY([UserId])
REFERENCES [dbo].[UserMaster] ([UserId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserMasterUserCountryMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserCountryMapping]'))
ALTER TABLE [dbo].[UserCountryMapping] CHECK CONSTRAINT [FK_UserMasterUserCountryMapping]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterUserDashboardPreferences1]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserDashboardPreferences]'))
ALTER TABLE [dbo].[UserDashboardPreferences]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationMasterUserDashboardPreferences1] FOREIGN KEY([OrganizationId])
REFERENCES [dbo].[OrganizationMaster] ([OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterUserDashboardPreferences1]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserDashboardPreferences]'))
ALTER TABLE [dbo].[UserDashboardPreferences] CHECK CONSTRAINT [FK_OrganizationMasterUserDashboardPreferences1]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserMasterUserPreferences]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserPreferences]'))
ALTER TABLE [dbo].[UserPreferences]  WITH CHECK ADD  CONSTRAINT [FK_UserMasterUserPreferences] FOREIGN KEY([UserId])
REFERENCES [dbo].[UserMaster] ([UserId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserMasterUserPreferences]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserPreferences]'))
ALTER TABLE [dbo].[UserPreferences] CHECK CONSTRAINT [FK_UserMasterUserPreferences]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterUserReportPreferences]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserReportPreferences]'))
ALTER TABLE [dbo].[UserReportPreferences]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationMasterUserReportPreferences] FOREIGN KEY([OrganizationId])
REFERENCES [dbo].[OrganizationMaster] ([OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_OrganizationMasterUserReportPreferences]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserReportPreferences]'))
ALTER TABLE [dbo].[UserReportPreferences] CHECK CONSTRAINT [FK_OrganizationMasterUserReportPreferences]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserMasterUserReportPreferences]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserReportPreferences]'))
ALTER TABLE [dbo].[UserReportPreferences]  WITH CHECK ADD  CONSTRAINT [FK_UserMasterUserReportPreferences] FOREIGN KEY([UserId])
REFERENCES [dbo].[UserMaster] ([UserId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserMasterUserReportPreferences]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserReportPreferences]'))
ALTER TABLE [dbo].[UserReportPreferences] CHECK CONSTRAINT [FK_UserMasterUserReportPreferences]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_LMPlantLocationId]') AND parent_object_id = OBJECT_ID(N'[dbo].[LuminometerPlantMapping]'))
ALTER TABLE [dbo].[LuminometerPlantMapping]  WITH CHECK ADD  CONSTRAINT [FK_LMPlantLocationId] FOREIGN KEY([LocationId], [OrganizationId])
REFERENCES [dbo].[LocationMaster] ([LocationId], [OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_LMPlantLocationId]') AND parent_object_id = OBJECT_ID(N'[dbo].[LuminometerPlantMapping]'))
ALTER TABLE [dbo].[LuminometerPlantMapping] CHECK CONSTRAINT [FK_LMPlantLocationId]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_LMPlantLuminometerId]') AND parent_object_id = OBJECT_ID(N'[dbo].[LuminometerPlantMapping]'))
ALTER TABLE [dbo].[LuminometerPlantMapping]  WITH CHECK ADD  CONSTRAINT [FK_LMPlantLuminometerId] FOREIGN KEY([LuminometerId])
REFERENCES [dbo].[LuminometerMaster] ([LuminometerId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_LMPlantLuminometerId]') AND parent_object_id = OBJECT_ID(N'[dbo].[LuminometerPlantMapping]'))
ALTER TABLE [dbo].[LuminometerPlantMapping] CHECK CONSTRAINT [FK_LMPlantLuminometerId]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_LMPlantOrganizationId]') AND parent_object_id = OBJECT_ID(N'[dbo].[LuminometerPlantMapping]'))
ALTER TABLE [dbo].[LuminometerPlantMapping]  WITH CHECK ADD  CONSTRAINT [FK_LMPlantOrganizationId] FOREIGN KEY([OrganizationId])
REFERENCES [dbo].[OrganizationMaster] ([OrganizationId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_LMPlantOrganizationId]') AND parent_object_id = OBJECT_ID(N'[dbo].[LuminometerPlantMapping]'))
ALTER TABLE [dbo].[LuminometerPlantMapping] CHECK CONSTRAINT [FK_LMPlantOrganizationId]
GO

IF OBJECT_ID ( '[dbo].[CustomParameterLocationMapping]', 'U' ) IS  NULL     
Begin
CREATE TABLE [dbo].[CustomParameterLocationMapping](
	[OrganizationId] [int] NOT NULL,
	[CategoryId] [int] NOT NULL,
	[ParameterId] [int] NOT NULL,
	[LocationId] [int] NOT NULL,
	[LocationLevel] [int] NULL
 CONSTRAINT [PK_CustomParameterLocationMapping] PRIMARY KEY CLUSTERED 
(
	[OrganizationId] ASC,
	[CategoryId] ASC,
	[ParameterId] ASC,
	[LocationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

End
GO

IF OBJECT_ID ( '[dbo].[CountryTimezoneMapping]', 'U' ) IS  NULL     
Begin
CREATE TABLE [dbo].[CountryTimezoneMapping](
	[MappingId] [int] IDENTITY(1,1) NOT NULL,
	[TimezoneId] [int] NULL,
	[CountryId] [int] NULL
) ON [PRIMARY]
End
GO

update UserMaster 
set IsLoginRequired=0 
where LoginName is null and IsLoginRequired=1
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserTestPointFilters]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UserTestPointFilters](
	[UserId] [int] NOT NULL,
	[DateSelectedFilter] varchar(max),
PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END


/***********************  RoleFeaturesGroup   *************************/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RoleFeaturesGroup]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[RoleFeaturesGroup](
	[FeatureGroupId] [int] NOT NULL,
	[FeatureGroupName] [nvarchar](100) NOT NULL,
	[Order] [int] NOT NULL,

 CONSTRAINT [PK_RoleFeaturesGroup] PRIMARY KEY CLUSTERED 
(
	[FeatureGroupId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO


/***********************  RoleFeatureMaster   *************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RoleFeatureMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[RoleFeatureMaster](
	[FeatureId] [int] NOT NULL,
	[FeatureName] [nvarchar](100) NOT NULL,
	[FeatureGroupId] [int] NOT NULL,
	[Order] [int] NOT NULL,

 CONSTRAINT [PK_RoleFeatureMaster] PRIMARY KEY CLUSTERED 
(
	[FeatureId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO


/***********************  PermissionMaster   *************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PermissionMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PermissionMaster](
	[Id] [int] NOT NULL,
	[OrganizationId] [int] NOT NULL,
	[RoleId] [int] NOT NULL,
	[FeatureId] [int] NOT NULL,
	[Permission] [int] NOT NULL,

 CONSTRAINT [PK_PermissionMaster] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO

/****** Object:  Table [dbo].[Cities_Master]    Script Date: 7/30/2021 6:03:45 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Cities_Master](
	[CityID] [int] NOT NULL,
	[Name] [nvarchar](255) NOT NULL,
	[StateId] [int] NOT NULL,
	[StateCode] [nvarchar](255) NOT NULL,
	[CountryId] [int] NOT NULL,
	[CountryCode] [char](2) NOT NULL
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[States_Master]    Script Date: 7/30/2021 6:03:45 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[States_Master](
	[StateId] [int] NOT NULL,
	[Name] [nvarchar](255) NOT NULL,
	[StateCode] [nvarchar](255) NULL,
	[ShortName] [nvarchar](255) NULL,
	[CountryId] [int] NOT NULL,
	[CountryCode] [char](2) NOT NULL
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO


/*************************Timezoneshortcode column added*****************************/
Use [Spark]
Go


IF NOT EXISTS (SELECT * FROM sys.columns
WHERE object_id = OBJECT_ID(N'[dbo].[TestPointResult]')
AND name = 'TimeZoneShortCode'
)
BEGIN
alter table TestPointResult
add TimeZoneShortCode varchar(8)
END

IF NOT EXISTS (SELECT * FROM sys.columns
WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]')
AND name = 'TimeZoneShortCode'
)
BEGIN
alter table AdhocTestPointResult
add TimeZoneShortCode varchar(8)
END

IF NOT EXISTS (SELECT * FROM sys.columns
WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanTestPointMapping]')
AND name = 'LocationId'
)
BEGIN
Alter table [Spark].[dbo].[TestPlanTestPointMapping]
add LocationId int Null
END

Use [Spark_Archive]
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE object_id = OBJECT_ID(N'[Spark_Archive].[dbo].[AdhocTestPointResult]')
AND name = 'TimeZoneShortCode'
)
BEGIN
alter table [Spark_Archive].[dbo].AdhocTestPointResult
add TimeZoneShortCode varchar(8)
END

IF NOT EXISTS (SELECT * FROM sys.columns
WHERE object_id = OBJECT_ID(N'[Spark_Archive].[dbo].[TestPointResult]')
AND name = 'TimeZoneShortCode'
)
BEGIN
alter table [Spark_Archive].[dbo].TestPointResult
add TimeZoneShortCode varchar(8)
END

Go

