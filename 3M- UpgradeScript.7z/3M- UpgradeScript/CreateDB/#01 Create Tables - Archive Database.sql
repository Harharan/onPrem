USE [Spark_Archive]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPlanResultTestPointResult]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointResult]'))
ALTER TABLE [dbo].[TestPointResult] DROP CONSTRAINT [FK_TestPlanResultTestPointResult]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_EditMeasurementEditTestResultCustomParameterMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[EditTestResultCustomParameterMapping]'))
ALTER TABLE [dbo].[EditTestResultCustomParameterMapping] DROP CONSTRAINT [FK_EditMeasurementEditTestResultCustomParameterMapping]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_AdhocTestPlanResultAdhocTestPointResult]') AND parent_object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]'))
ALTER TABLE [dbo].[AdhocTestPointResult] DROP CONSTRAINT [FK_AdhocTestPlanResultAdhocTestPointResult]
GO
/****** Object:  Index [NCI-TestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To]    Script Date: 5/20/2018 6:12:02 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPointResult]') AND name = N'NCI-TestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To')
DROP INDEX [NCI-TestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To] ON [dbo].[TestPointResult]
GO
/****** Object:  Index [IX_FK_TestPlanResultTestPointResult]    Script Date: 5/20/2018 6:12:02 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPointResult]') AND name = N'IX_FK_TestPlanResultTestPointResult')
DROP INDEX [IX_FK_TestPlanResultTestPointResult] ON [dbo].[TestPointResult]
GO
/****** Object:  Index [NCI-TestPlanResult-Oid-RidTplid]    Script Date: 5/20/2018 6:12:02 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanResult]') AND name = N'NCI-TestPlanResult-Oid-RidTplid')
DROP INDEX [NCI-TestPlanResult-Oid-RidTplid] ON [dbo].[TestPlanResult]
GO
/****** Object:  Index [IX_FK_EditMeasurementEditTestResultCustomParameterMapping]    Script Date: 5/20/2018 6:12:02 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EditTestResultCustomParameterMapping]') AND name = N'IX_FK_EditMeasurementEditTestResultCustomParameterMapping')
DROP INDEX [IX_FK_EditMeasurementEditTestResultCustomParameterMapping] ON [dbo].[EditTestResultCustomParameterMapping]
GO
/****** Object:  Index [NCI-AdhocTestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To]    Script Date: 5/20/2018 6:12:02 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]') AND name = N'NCI-AdhocTestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To')
DROP INDEX [NCI-AdhocTestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To] ON [dbo].[AdhocTestPointResult]
GO
/****** Object:  Index [IX_FK_AdhocTestPlanResultAdhocTestPointResult]    Script Date: 5/20/2018 6:12:02 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]') AND name = N'IX_FK_AdhocTestPlanResultAdhocTestPointResult')
DROP INDEX [IX_FK_AdhocTestPlanResultAdhocTestPointResult] ON [dbo].[AdhocTestPointResult]
GO
/****** Object:  Index [NCI-AdhocTestPlanResult-Oid-RidTplid]    Script Date: 5/20/2018 6:12:02 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPlanResult]') AND name = N'NCI-AdhocTestPlanResult-Oid-RidTplid')
DROP INDEX [NCI-AdhocTestPlanResult-Oid-RidTplid] ON [dbo].[AdhocTestPlanResult]
GO
/****** Object:  Table [dbo].[TestResultCustomParameterMapping]    Script Date: 5/20/2018 6:12:02 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestResultCustomParameterMapping]') AND type in (N'U'))
DROP TABLE [dbo].[TestResultCustomParameterMapping]
GO
/****** Object:  Table [dbo].[TestPointResult]    Script Date: 5/20/2018 6:12:02 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPointResult]') AND type in (N'U'))
DROP TABLE [dbo].[TestPointResult]
GO
/****** Object:  Table [dbo].[TestPlanResult]    Script Date: 5/20/2018 6:12:02 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanResult]') AND type in (N'U'))
DROP TABLE [dbo].[TestPlanResult]
GO
/****** Object:  Table [dbo].[EditTestResultCustomParameterMapping]    Script Date: 5/20/2018 6:12:02 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EditTestResultCustomParameterMapping]') AND type in (N'U'))
DROP TABLE [dbo].[EditTestResultCustomParameterMapping]
GO
/****** Object:  Table [dbo].[EditMeasurement]    Script Date: 5/20/2018 6:12:02 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EditMeasurement]') AND type in (N'U'))
DROP TABLE [dbo].[EditMeasurement]
GO
/****** Object:  Table [dbo].[AdhocTestPointResult]    Script Date: 5/20/2018 6:12:02 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]') AND type in (N'U'))
DROP TABLE [dbo].[AdhocTestPointResult]
GO
/****** Object:  Table [dbo].[AdhocTestPlanResult]    Script Date: 5/20/2018 6:12:02 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPlanResult]') AND type in (N'U'))
DROP TABLE [dbo].[AdhocTestPlanResult]
GO
/****** Object:  Table [dbo].[AdhocEditMeasurement]    Script Date: 5/20/2018 6:12:02 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AdhocEditMeasurement]') AND type in (N'U'))
DROP TABLE [dbo].[AdhocEditMeasurement]
GO
/****** Object:  Table [dbo].[AdhocEditMeasurement]    Script Date: 5/20/2018 6:12:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AdhocEditMeasurement]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[AdhocEditMeasurement](
	[OrganizationId] [int] NOT NULL,
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[AdhocResultId] [bigint] NOT NULL,
	[AdhocMeasurementId] [smallint] NOT NULL,
	[ReasonForChange] [nvarchar](1000) NOT NULL,
	[OldResult] [smallint] NULL,
	[OldResultValue] [float] NULL,
	[NewResult] [smallint] NULL,
	[NewResultValue] [float] NULL,
	[OldCapaComments] [nvarchar](1000) NULL,
	[NewCapaComments] [nvarchar](1000) NULL,
	[OldTester] [int] NULL,
	[NewTester] [int] NULL,
	[EditDate] [datetime] NOT NULL,
	[EditedBy] [int] NOT NULL,
 CONSTRAINT [PK_AdhocEditMeasurement] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[AdhocTestPlanResult]    Script Date: 5/20/2018 6:12:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPlanResult]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[AdhocTestPlanResult](
	[AdhocResultId] [bigint] IDENTITY(1,1) NOT NULL,
	[OrganizationId] [int] NOT NULL,
	[TestPlanId] [int] NOT NULL,
	[TestPlanVersion] [smallint] NOT NULL,
	[TestPlanName] [nvarchar](max) NULL,
	[LocationId] [int] NULL,
	[LocationVersion] [smallint] NULL,
	[Status] [smallint] NOT NULL,
	[OpenedDate] [datetime] NULL,
	[OpenedBy] [int] NULL,
	[DeviceId] [nvarchar](50) NOT NULL,
	[LastEditedBy] [int] NULL,
	[LastEditedDate] [datetime] NULL,
 CONSTRAINT [PK_AdhocTestPlanResult] PRIMARY KEY CLUSTERED 
(
	[AdhocResultId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[AdhocTestPointResult]    Script Date: 5/20/2018 6:12:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[AdhocTestPointResult](
	[AdhocResultId] [bigint] NOT NULL,
	[AdhocMeasurementId] [smallint] NOT NULL,
	[TestPointId] [int] NULL,
	[TestPointVersion] [smallint] NULL,
	[TestPointName] [nvarchar](max) NULL,
	[TestPointLocationId] [int] NULL,
	[LocationName] [nvarchar](max) NULL,
	[TestMethodId] [smallint] NOT NULL,
	[TestMethodVersion] [smallint] NOT NULL,
	[TestMethodName] [nvarchar](50) NULL,
	[TestType] [smallint] NOT NULL,
	[IsAdhoc] [bit] NOT NULL,
	[IsRetest] [bit] NOT NULL,
	[Status] [smallint] NOT NULL,
	[Result] [smallint] NULL,
	[ResultValue] [float] NOT NULL,
	[ResultDate] [datetime] NULL,
	[IsEdited] [bit] NOT NULL,
	[ResultTakenBy] [int] NULL,
	[ResultTakenByName] [nvarchar](100) NULL,
	[OriginalAdhocMeasurementId] [bigint] NULL,
	[CapaComments] [nvarchar](1000) NULL,
	[CreatedBy] [int] NULL,
	[CreatedDate] [datetime] NULL,
	[LastEditDate] [datetime] NULL,
	[LastEditedBy] [int] NULL,
	[ATPPassThreshold] [decimal](10, 2) NULL,
	[ATPFailThreshold] [decimal](10, 2) NULL,
	[ThresholdType] [smallint] NULL,
	[UnitId] [int] NULL,
	[UnitName] [nvarchar](10) NULL,
	[IsMapped] [bit] NOT NULL,
	[Is3MSwab] [bit] NOT NULL,
	[IsFinal] [bit] NULL,
	[TestOrder] [int] NULL,
 CONSTRAINT [PK_AdhocTestPointResult] PRIMARY KEY CLUSTERED 
(
	[AdhocMeasurementId] ASC,
	[AdhocResultId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[EditMeasurement]    Script Date: 5/20/2018 6:12:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EditMeasurement]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EditMeasurement](
	[OrganizationId] [int] NOT NULL,
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[ResultId] [bigint] NOT NULL,
	[MeasurementId] [smallint] NOT NULL,
	[ReasonForChange] [nvarchar](1000) NOT NULL,
	[OldResult] [smallint] NULL,
	[OldResultValue] [float] NULL,
	[NewResult] [smallint] NULL,
	[NewResultValue] [float] NULL,
	[OldCapaComments] [nvarchar](1000) NULL,
	[NewCapaComments] [nvarchar](1000) NULL,
	[OldTester] [int] NULL,
	[NewTester] [int] NULL,
	[EditDate] [datetime] NOT NULL,
	[EditedBy] [int] NOT NULL,
 CONSTRAINT [PK_EditMeasurement] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[EditTestResultCustomParameterMapping]    Script Date: 5/20/2018 6:12:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EditTestResultCustomParameterMapping]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EditTestResultCustomParameterMapping](
	[EditId] [bigint] IDENTITY(1,1) NOT NULL,
	[Id] [bigint] NOT NULL,
	[OldOrganizationCategoryId] [int] NOT NULL,
	[NewOrganizationCategoryId] [int] NOT NULL,
	[OldParameterId] [smallint] NOT NULL,
	[NewParameterId] [smallint] NOT NULL,
	[EditedBy] [int] NULL,
	[EditedDate] [datetime] NULL,
 CONSTRAINT [PK_EditTestResultCustomParameterMapping] PRIMARY KEY CLUSTERED 
(
	[EditId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[TestPlanResult]    Script Date: 5/20/2018 6:12:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanResult]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[TestPlanResult](
	[ResultId] [bigint] IDENTITY(1,1) NOT NULL,
	[OrganizationId] [int] NOT NULL,
	[TestPlanId] [int] NOT NULL,
	[TestPlanVersion] [smallint] NOT NULL,
	[TestPlanName] [nvarchar](max) NULL,
	[LocationId] [int] NULL,
	[LocationVersion] [smallint] NOT NULL,
	[Status] [smallint] NOT NULL,
	[OpenedDate] [datetime] NOT NULL,
	[OpenedBy] [int] NOT NULL,
	[DeviceId] [nvarchar](50) NOT NULL,
	[LastEditDate] [datetime] NULL,
	[LastEditedBy] [int] NULL,
	[ImportId] [nvarchar](50) NULL,
 CONSTRAINT [PK_TestPlanResult] PRIMARY KEY CLUSTERED 
(
	[ResultId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[TestPointResult]    Script Date: 5/20/2018 6:12:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPointResult]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[TestPointResult](
	[ResultId] [bigint] NOT NULL,
	[MeasurementId] [int] NOT NULL,
	[TestPointId] [int] NOT NULL,
	[TestPointVersion] [smallint] NOT NULL,
	[TestPointName] [nvarchar](max) NULL,
	[TestPointLocationId] [int] NOT NULL,
	[LocationName] [nvarchar](max) NULL,
	[TestMethodId] [smallint] NOT NULL,
	[TestMethodVersion] [smallint] NOT NULL,
	[TestMethodName] [nvarchar](50) NOT NULL,
	[TestType] [smallint] NOT NULL,
	[IsRetest] [bit] NOT NULL,
	[IsAdhoc] [bit] NOT NULL,
	[Status] [smallint] NOT NULL,
	[Result] [smallint] NULL,
	[ResultValue] [float] NULL,
	[ResultDate] [datetime] NULL,
	[IsEdited] [bit] NULL,
	[ResultTakenBy] [int] NULL,
	[ResultTakenByName] [nvarchar](100) NULL,
	[OriginalMeasurementId] [int] NULL,
	[CapaComments] [nvarchar](1000) NULL,
	[CreatedDate] [datetime] NULL,
	[CreatedBy] [int] NULL,
	[LastEditDate] [datetime] NULL,
	[LastEditedBy] [int] NULL,
	[ATPPassThreshold] [decimal](10, 2) NULL,
	[ATPFailThreshold] [decimal](10, 2) NULL,
	[ThresholdType] [smallint] NULL,
	[UnitId] [int] NULL,
	[UnitName] [nvarchar](10) NULL,
	[ReasonToAdd] [nvarchar](1000) NULL,
	[Is3MSwab] [bit] NOT NULL,
	[IsFinal] [bit] NULL,
	[TestOrder] [int] NULL,
 CONSTRAINT [PK_TestPointResult] PRIMARY KEY CLUSTERED 
(
	[MeasurementId] ASC,
	[ResultId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[TestResultCustomParameterMapping]    Script Date: 5/20/2018 6:12:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestResultCustomParameterMapping]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[TestResultCustomParameterMapping](
	[ResultId] [bigint] NOT NULL,
	[MeasurementId] [int] NOT NULL,
	[OrganizationCategoryId] [int] NOT NULL,
	[ParameterId] [smallint] NOT NULL,
	[ParameterVersion] [smallint] NOT NULL,
	[EditedBy] [int] NULL,
	[EditedDate] [datetime] NULL,
 CONSTRAINT [PK_TestResultCustomParameterMapping] PRIMARY KEY CLUSTERED 
(
	[ResultId] ASC,
	[MeasurementId] ASC,
	[OrganizationCategoryId] ASC,
	[ParameterId] ASC,
	[ParameterVersion] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Index [NCI-AdhocTestPlanResult-Oid-RidTplid]    Script Date: 5/20/2018 6:12:02 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPlanResult]') AND name = N'NCI-AdhocTestPlanResult-Oid-RidTplid')
CREATE NONCLUSTERED INDEX [NCI-AdhocTestPlanResult-Oid-RidTplid] ON [dbo].[AdhocTestPlanResult]
(
	[OrganizationId] ASC
)
INCLUDE ( 	[AdhocResultId],
	[TestPlanId]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_AdhocTestPlanResultAdhocTestPointResult]    Script Date: 5/20/2018 6:12:02 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]') AND name = N'IX_FK_AdhocTestPlanResultAdhocTestPointResult')
CREATE NONCLUSTERED INDEX [IX_FK_AdhocTestPlanResultAdhocTestPointResult] ON [dbo].[AdhocTestPointResult]
(
	[AdhocResultId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [NCI-AdhocTestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To]    Script Date: 5/20/2018 6:12:02 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]') AND name = N'NCI-AdhocTestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To')
CREATE NONCLUSTERED INDEX [NCI-AdhocTestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To] ON [dbo].[AdhocTestPointResult]
(
	[ResultDate] ASC
)
INCLUDE ( 	[AdhocResultId],
	[AdhocMeasurementId],
	[TestPointId],
	[TestPointLocationId],
	[TestMethodId],
	[IsRetest],
	[Result],
	[ResultTakenBy],
	[Is3MSwab],
	[TestOrder]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_EditMeasurementEditTestResultCustomParameterMapping]    Script Date: 5/20/2018 6:12:02 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EditTestResultCustomParameterMapping]') AND name = N'IX_FK_EditMeasurementEditTestResultCustomParameterMapping')
CREATE NONCLUSTERED INDEX [IX_FK_EditMeasurementEditTestResultCustomParameterMapping] ON [dbo].[EditTestResultCustomParameterMapping]
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [NCI-TestPlanResult-Oid-RidTplid]    Script Date: 5/20/2018 6:12:02 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanResult]') AND name = N'NCI-TestPlanResult-Oid-RidTplid')
CREATE NONCLUSTERED INDEX [NCI-TestPlanResult-Oid-RidTplid] ON [dbo].[TestPlanResult]
(
	[OrganizationId] ASC
)
INCLUDE ( 	[ResultId],
	[TestPlanId]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_FK_TestPlanResultTestPointResult]    Script Date: 5/20/2018 6:12:02 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPointResult]') AND name = N'IX_FK_TestPlanResultTestPointResult')
CREATE NONCLUSTERED INDEX [IX_FK_TestPlanResultTestPointResult] ON [dbo].[TestPointResult]
(
	[ResultId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [NCI-TestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To]    Script Date: 5/20/2018 6:12:02 PM ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPointResult]') AND name = N'NCI-TestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To')
CREATE NONCLUSTERED INDEX [NCI-TestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To] ON [dbo].[TestPointResult]
(
	[ResultDate] ASC
)
INCLUDE ( 	[ResultId],
	[MeasurementId],
	[TestPointId],
	[TestPointLocationId],
	[TestMethodId],
	[IsRetest],
	[Result],
	[ResultTakenBy],
	[Is3MSwab],
	[TestOrder]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_AdhocTestPlanResultAdhocTestPointResult]') AND parent_object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]'))
ALTER TABLE [dbo].[AdhocTestPointResult]  WITH CHECK ADD  CONSTRAINT [FK_AdhocTestPlanResultAdhocTestPointResult] FOREIGN KEY([AdhocResultId])
REFERENCES [dbo].[AdhocTestPlanResult] ([AdhocResultId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_AdhocTestPlanResultAdhocTestPointResult]') AND parent_object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]'))
ALTER TABLE [dbo].[AdhocTestPointResult] CHECK CONSTRAINT [FK_AdhocTestPlanResultAdhocTestPointResult]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_EditMeasurementEditTestResultCustomParameterMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[EditTestResultCustomParameterMapping]'))
ALTER TABLE [dbo].[EditTestResultCustomParameterMapping]  WITH CHECK ADD  CONSTRAINT [FK_EditMeasurementEditTestResultCustomParameterMapping] FOREIGN KEY([Id])
REFERENCES [dbo].[EditMeasurement] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_EditMeasurementEditTestResultCustomParameterMapping]') AND parent_object_id = OBJECT_ID(N'[dbo].[EditTestResultCustomParameterMapping]'))
ALTER TABLE [dbo].[EditTestResultCustomParameterMapping] CHECK CONSTRAINT [FK_EditMeasurementEditTestResultCustomParameterMapping]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPlanResultTestPointResult]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointResult]'))
ALTER TABLE [dbo].[TestPointResult]  WITH CHECK ADD  CONSTRAINT [FK_TestPlanResultTestPointResult] FOREIGN KEY([ResultId])
REFERENCES [dbo].[TestPlanResult] ([ResultId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TestPlanResultTestPointResult]') AND parent_object_id = OBJECT_ID(N'[dbo].[TestPointResult]'))
ALTER TABLE [dbo].[TestPointResult] CHECK CONSTRAINT [FK_TestPlanResultTestPointResult]
GO
