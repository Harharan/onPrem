USE [Spark]
GO

/****** Object:  Table [dbo].[ApplicationMaster]    Script Date: 18/02/2015 ******/
SET IDENTITY_INSERT [dbo].[ApplicationMaster] ON
INSERT [dbo].[ApplicationMaster] ([ApplicationId], [ApplicationName]) VALUES (1, N'IPD-Hygiene')
INSERT [dbo].[ApplicationMaster] ([ApplicationId], [ApplicationName]) VALUES (2, N'IPD- Endoscopy')
INSERT [dbo].[ApplicationMaster] ([ApplicationId], [ApplicationName]) VALUES (3, N'IPD-DigitalWash')
INSERT [dbo].[ApplicationMaster] ([ApplicationId], [ApplicationName]) VALUES (4, N'FSD-Hygiene')
SET IDENTITY_INSERT [dbo].[ApplicationMaster] OFF

/****** Object:  Table [dbo].[RegionMaster]    Script Date: 18/02/2015 ******/
INSERT INTO [dbo].[RegionMaster]([RegionName]) VALUES ('US')

/****** Object:  Table [dbo].[LicenseTypeMaster]   Script Date: 18/02/2015 ******/
SET IDENTITY_INSERT [dbo].[LicenseTypeMaster] ON
INSERT [dbo].[LicenseTypeMaster] ([LicenseId], [LicenseType]) VALUES (1, N'test')
SET IDENTITY_INSERT [dbo].[LicenseTypeMaster] OFF

/****** Object:  Table [dbo].[RoleMaster]    Script Date: 18/02/2015 ******/
SET IDENTITY_INSERT [dbo].[RoleMaster] ON
INSERT [dbo].[RoleMaster] ([RoleId], [ApplicationId], [RoleName], [RoleLevel], [Only3M], [DisplayLevelText]) VALUES (1,4, N'3MTS', 1, 0, N'Level 1')
INSERT [dbo].[RoleMaster] ([RoleId], [ApplicationId], [RoleName], [RoleLevel], [Only3M], [DisplayLevelText]) VALUES (2,4, N'Administrator', 3, 0, N'Level 3')
INSERT [dbo].[RoleMaster] ([RoleId], [ApplicationId], [RoleName], [RoleLevel], [Only3M], [DisplayLevelText]) VALUES (3,4, N'Technician', 6, 0, N'Level 6')
INSERT [dbo].[RoleMaster] ([RoleId], [ApplicationId], [RoleName], [RoleLevel], [Only3M], [DisplayLevelText]) VALUES (4,4, N'Supervisor', 7, 0, N'Level 7')
SET IDENTITY_INSERT [dbo].[RoleMaster] OFF

/****** Object:  Table [dbo].[OrganizationTypeMaster]    Script Date: 18/02/2015 ******/
SET IDENTITY_INSERT [dbo].[OrganizationTypeMaster] ON 
INSERT [dbo].[OrganizationTypeMaster] ([OrganizationTypeId], [ApplicationId], [OrganizationTypeName]) VALUES (1, 4, N'Licensed')  
INSERT [dbo].[OrganizationTypeMaster] ([OrganizationTypeId], [ApplicationId], [OrganizationTypeName]) VALUES (2, 4, N'Demo')
INSERT [dbo].[OrganizationTypeMaster] ([OrganizationTypeId], [ApplicationId], [OrganizationTypeName]) VALUES (3, 4, N'Trial')
SET IDENTITY_INSERT [dbo].[OrganizationTypeMaster] OFF

/****** Object:  Table [dbo].[TestPlanTypeMaster]    Script Date: 18/02/2015 ******/
SET IDENTITY_INSERT [dbo].[TestPlanTypeMaster] ON
INSERT [dbo].[TestPlanTypeMaster] ([TestPlanTypeId], [TestPlanTypeName], [ForReports], [ApplicationId]) VALUES (1, N'Sample Test Plan', 1, 1)
INSERT [dbo].[TestPlanTypeMaster] ([TestPlanTypeId], [TestPlanTypeName], [ForReports], [ApplicationId]) VALUES (2, N'Demo Test Plan', 0, 1)
INSERT [dbo].[TestPlanTypeMaster] ([TestPlanTypeId], [TestPlanTypeName], [ForReports], [ApplicationId]) VALUES (3, N'Trial Test Plan', 0, 1)
SET IDENTITY_INSERT [dbo].[TestPlanTypeMaster] OFF

/****** Object:  Table [dbo].[TestMethodMaster]    Script Date: 18/02/2015 ******/
SET IDENTITY_INSERT [dbo].[TestMethodMaster] ON
INSERT [dbo].[TestMethodMaster] ([TestMethodId], [ApplicationId], [TestMethodName], [ShortName], [SwabTypeRequired], [PassThreshold], [FailThreshold], [ThresholdType], [TestType]) 
VALUES (1, 4, N'UXL 100 (Surface ATP)', N'UXL100', 1, NULL, NULL, 2, 0)
INSERT [dbo].[TestMethodMaster] ([TestMethodId], [ApplicationId], [TestMethodName], [ShortName], [SwabTypeRequired], [PassThreshold], [FailThreshold], [ThresholdType], [TestType]) 
VALUES (2, 4, N'AQF 100 (Water free ATP)', N'AQF', 1, NULL, NULL, 2, 0)
INSERT [dbo].[TestMethodMaster] ([TestMethodId], [ApplicationId], [TestMethodName], [ShortName], [SwabTypeRequired], [PassThreshold], [FailThreshold], [ThresholdType], [TestType]) 
VALUES (3, 4, N'AQT 200 (Water total ATP)', N'AQT', 1, NULL, NULL, 2, 0)
INSERT [dbo].[TestMethodMaster] ([TestMethodId], [ApplicationId], [TestMethodName], [ShortName], [SwabTypeRequired], [PassThreshold], [FailThreshold], [ThresholdType], [TestType]) 
VALUES (4, 4, N'Visual inspection', N'VI', 0, NULL, NULL, 1, 1)
INSERT [dbo].[TestMethodMaster] ([TestMethodId], [ApplicationId], [TestMethodName], [ShortName], [SwabTypeRequired], [PassThreshold], [FailThreshold], [ThresholdType], [TestType]) 
VALUES (5, 4, N'pH', N'pH', 0, NULL, NULL, -999, 2)
INSERT [dbo].[TestMethodMaster] ([TestMethodId], [ApplicationId], [TestMethodName], [ShortName], [SwabTypeRequired], [PassThreshold], [FailThreshold], [ThresholdType], [TestType]) 
VALUES (6, 4, N'Temperature', N'Temp', 0, NULL, NULL, -999, 2)
INSERT [dbo].[TestMethodMaster] ([TestMethodId], [ApplicationId], [TestMethodName], [ShortName], [SwabTypeRequired], [PassThreshold], [FailThreshold], [ThresholdType], [TestType]) 
VALUES (7, 4, N'Allergens', N'Chemical', 0, NULL, NULL, 1, 2)

/*******20B: Based on new design changes in 20B, Following default items have been removed.**********/
--INSERT [dbo].[TestMethodMaster] ([TestMethodId], [ApplicationId], [TestMethodName], [ShortName], [SwabTypeRequired], [PassThreshold], [FailThreshold], [ThresholdType], [TestType]) 
--VALUES (8, 4, N'Other Test Type 1', N'OT1', 0, NULL, NULL, 1, 2)
--INSERT [dbo].[TestMethodMaster] ([TestMethodId], [ApplicationId], [TestMethodName], [ShortName], [SwabTypeRequired], [PassThreshold], [FailThreshold], [ThresholdType], [TestType]) 
--VALUES (9, 4, N'Other Test Type 2', N'OT2', 0, NULL, NULL, 1, 2)
--INSERT [dbo].[TestMethodMaster] ([TestMethodId], [ApplicationId], [TestMethodName], [ShortName], [SwabTypeRequired], [PassThreshold], [FailThreshold], [ThresholdType], [TestType]) 
--VALUES (10, 4, N'Other Test Type 3', N'OT3', 0, NULL, NULL, 1, 2)
--INSERT [dbo].[TestMethodMaster] ([TestMethodId], [ApplicationId], [TestMethodName], [ShortName], [SwabTypeRequired], [PassThreshold], [FailThreshold], [ThresholdType], [TestType]) 
--VALUES (11, 4, N'Other Test Type 4', N'OT4', 0, NULL, NULL, 1, 2)

SET IDENTITY_INSERT [dbo].[TestMethodMaster] OFF

/****** Object:  Table [dbo].[SwabTypeMaster]    Script Date: 18/02/2015 ******/
SET IDENTITY_INSERT [dbo].[SwabTypeMaster] ON
INSERT [dbo].[SwabTypeMaster] ([SwabTypeId], [ApplicationId], [SwabTypeName]) VALUES (1, 4, N'ATP Surface')
INSERT [dbo].[SwabTypeMaster] ([SwabTypeId], [ApplicationId], [SwabTypeName]) VALUES (2, 4, N'ATP Water')
SET IDENTITY_INSERT [dbo].[SwabTypeMaster] OFF

/****** Object:  Table [dbo].[ReportMaster]    Script Date: 18/02/2015 ******/
SET IDENTITY_INSERT [dbo].[ReportMaster] ON
INSERT INTO [dbo].[ReportMaster]  ([ReportId] ,[ApplicationId] ,[ReportName]) VALUES (1, 4 ,'Report1')
INSERT INTO [dbo].[ReportMaster]  ([ReportId] ,[ApplicationId] ,[ReportName]) VALUES (2, 4 ,'Report2')
INSERT INTO [dbo].[ReportMaster]  ([ReportId] ,[ApplicationId] ,[ReportName]) VALUES (3, 4 ,'Report3')
INSERT INTO [dbo].[ReportMaster]  ([ReportId] ,[ApplicationId] ,[ReportName]) VALUES (4, 4 ,'Report4')
INSERT INTO [dbo].[ReportMaster]  ([ReportId] ,[ApplicationId] ,[ReportName]) VALUES (5, 4 ,'Report5')
SET IDENTITY_INSERT [dbo].[ReportMaster] OFF

/****** Object:  Table [dbo].[ReportMaster]    Script Date: 25/02/2015 ******/
--SET IDENTITY_INSERT [dbo].[FeatureMaster] ON
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (1, 4, N'UserManagementFeature', 3, 1, N'#', 0, 0)
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (2, 4, N'PlanManagementFeature', 2, 1, N'#', 0, 0)
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (3, 4, N'ResourceManagementFeature', 3, 1, N'#', 0, 0)
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (4, 4, N'LuminometerManagementFeature', 3, 1, N'#', 0, 0)
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (5, 4, N'ResultManagementFeature', 2, 1, N'#', 0, 0)
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (6, 4, N'DatabaseManagementFeature', 3, 1, N'#', 0, 0)
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (7, 4, N'ReportFeature', 4, 1, N'#', 0, 0)
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (8, 4, N'SynchronizationFeature', 3, 0, N'#', 0, 0)
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (9, 4, N'LogsFeature', 3, 1, N'#', 0, 0)
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (10, 4, N'OrganizationSettingsFeature', 3, 1, N'#', 0, 0)

--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (11, 4, N'LuminometerManagement', 3, 0, N'Index|LuminometerDetails|Masters', 4, 1)
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (12, 4, N'LocationManagement', 3, 1, N'getlocationdetails|location|masters', 3, 1)
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (13, 4, N'VariableManagement', 3, 1, N'index|variable|masters', 3, 1)
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (14, 4, N'UserManagement', 3, 1, N'List|User|Masters', 1, 1)
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (15, 4, N'RoleManagement', 3, 1, N'Index|OrganizationRole|Masters', 3, 1)
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (16, 4, N'OrganizationSettings', 3, 1, N'organizationconfiguration|organizationconfiguration|configuration', 10, 1)
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (17, 4, N'DatabaseManagement', 3, 1, N'#', 6, 1)
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (18, 4, N'ImportData', 3, 0, N'Index|DataMigration|Masters', 3, 1)
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (19, 4, N'Logs', 3, 1, N'#', 9, 1)
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (20, 4, N'Synchronization', 3, 0, N'#', 8, 0)
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (21, 4, N'TestPointManagement', 2, 1, N'Index|TestPoint|Masters', 2, 1)
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (22, 4, N'TestPlanManagement', 2, 1, N'List|SamplePlan|Masters', 2, 1)
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (23, 4, N'ResultManagement', 2, 0, N'Index|EditResult|Masters', 5, 1)
--INSERT [dbo].[FeatureMaster] ([FeatureId], [ApplicationId], [FeatureName], [FeatureCategory], [AccessType], [Url], [ParentFeatureId], [IsMenuItem]) VALUES (24, 4, N'Report', 4, 1, N'#', 7, 1)
--SET IDENTITY_INSERT [dbo].[FeatureMaster] OFF

/****** Object:  Table [dbo].[CustomCategory]   Script Date: 09/03/2015 ******/
SET IDENTITY_INSERT [dbo].[CustomCategory] ON
INSERT [dbo].[CustomCategory] ([CategoryId],[Category], [IsUserDefine], [IsNumericType]) VALUES(1,N'Chemical Name', 0, 0)
INSERT [dbo].[CustomCategory] ([CategoryId],[Category], [IsUserDefine], [IsNumericType]) VALUES(2,N'Tool Name', 0, 0)
INSERT [dbo].[CustomCategory] ([CategoryId],[Category], [IsUserDefine], [IsNumericType]) VALUES(3,N'Cleaning Method', 0, 0)
--INSERT [dbo].[CustomCategory] ([CategoryId],[Category], [IsUserDefine], [IsNumericType]) VALUES(4,N'Cleaning Frequency', 0, 1)
INSERT [dbo].[CustomCategory] ([CategoryId],[Category], [IsUserDefine], [IsNumericType]) VALUES(4,N'UD1', 1, 0)
INSERT [dbo].[CustomCategory] ([CategoryId],[Category], [IsUserDefine], [IsNumericType]) VALUES(5,N'UD2', 1, 0)
INSERT [dbo].[CustomCategory] ([CategoryId],[Category], [IsUserDefine], [IsNumericType]) VALUES(6,N'UD3', 1, 0)
INSERT [dbo].[CustomCategory] ([CategoryId],[Category], [IsUserDefine], [IsNumericType]) VALUES(7,N'UD4', 1, 0)
/*******20B: Adding new Custom Category. In 20B, category has been removed hence, any new Parameter shall be associated with this category *********/
INSERT [dbo].[CustomCategory] ([CategoryId],[Category], [IsUserDefine], [IsNumericType]) VALUES(8,N'OC', 1, 0)

SET IDENTITY_INSERT [dbo].[CustomCategory] OFF

SET IDENTITY_INSERT [dbo].[UnitMaster] ON  
INSERT [dbo].[UnitMaster] ([ApplicationId],[UnitId],[UnitName]) VALUES(4,1,N'---')
INSERT [dbo].[UnitMaster] ([ApplicationId],[UnitId],[UnitName]) VALUES(4,2,N'RLU')
INSERT [dbo].[UnitMaster] ([ApplicationId],[UnitId],[UnitName]) VALUES(4,3,N'Centigrade')
INSERT [dbo].[UnitMaster] ([ApplicationId],[UnitId],[UnitName]) VALUES(4,4,N'Fahrenheit')

SET IDENTITY_INSERT [dbo].[UnitMaster] OFF 

SET IDENTITY_INSERT [dbo].[Menu] ON
INSERT [dbo].[Menu] ([MenuId], [MenuKey], [Url], [ImageName]) VALUES (1, N'ExecutiveSummary', N'Index|Dashboard', N'fa-home')
INSERT [dbo].[Menu] ([MenuId], [MenuKey], [Url], [ImageName]) VALUES (2, N'Reports', N'Index|Report|Masters', N'fa-bar-chart')
INSERT [dbo].[Menu] ([MenuId], [MenuKey], [Url], [ImageName]) VALUES (3, N'PlanManagement', N'List|SamplePlan|Masters', N'fa-th')
INSERT [dbo].[Menu] ([MenuId], [MenuKey], [Url], [ImageName]) VALUES (4, N'ResourceManagement', N'GetLocationDetails|Location|Masters', N'fa-cog')
INSERT [dbo].[Menu] ([MenuId], [MenuKey], [Url], [ImageName]) VALUES (5, N'Help', N'#', N'')
INSERT [dbo].[Menu] ([MenuId], [MenuKey], [Url], [ImageName]) VALUES (6, N'ViewPlan', N'#', N'fa-th')
INSERT [dbo].[Menu] ([MenuId], [MenuKey], [Url], [ImageName]) VALUES (7, N'TestPoint', N'#', N'fa-th')
INSERT [dbo].[Menu] ([MenuId], [MenuKey], [Url], [ImageName]) VALUES (8, N'TestVariable', N'#', N'fa-cog')
INSERT [dbo].[Menu] ([MenuId], [MenuKey], [Url], [ImageName]) VALUES (9, N'Comments', N'#', N'fa-th')
INSERT [dbo].[Menu] ([MenuId], [MenuKey], [Url], [ImageName]) VALUES (10, N'Users', N'#', N'fa-th')
INSERT [dbo].[Menu] ([MenuId], [MenuKey], [Url], [ImageName]) VALUES (11, N'Role', N'#', N'fa fa-user')
SET IDENTITY_INSERT [dbo].[Menu] OFF

SET IDENTITY_INSERT [dbo].[FeatureGroup] ON
INSERT [dbo].[FeatureGroup] ([Id], [FeatureKey], [PermissionType], [FeatureGroupKey]) VALUES (1, N'UserManagement', 1, 1)
INSERT [dbo].[FeatureGroup] ([Id], [FeatureKey], [PermissionType], [FeatureGroupKey]) VALUES (2, N'PlanManagement', 1, 2)
INSERT [dbo].[FeatureGroup] ([Id], [FeatureKey], [PermissionType], [FeatureGroupKey]) VALUES (3, N'ResourceManagement', 1, 3)
INSERT [dbo].[FeatureGroup] ([Id], [FeatureKey], [PermissionType], [FeatureGroupKey]) VALUES (4, N'LuminometerManagement', 1, 4)
INSERT [dbo].[FeatureGroup] ([Id], [FeatureKey], [PermissionType], [FeatureGroupKey]) VALUES (5, N'ResultManagement', 1, 5)
INSERT [dbo].[FeatureGroup] ([Id], [FeatureKey], [PermissionType], [FeatureGroupKey]) VALUES (6, N'DatabaseManagement', 1, 8)
INSERT [dbo].[FeatureGroup] ([Id], [FeatureKey], [PermissionType], [FeatureGroupKey]) VALUES (7, N'Reports', 1, 6)
INSERT [dbo].[FeatureGroup] ([Id], [FeatureKey], [PermissionType], [FeatureGroupKey]) VALUES (8, N'Logs', 1, 9)
INSERT [dbo].[FeatureGroup] ([Id], [FeatureKey], [PermissionType], [FeatureGroupKey]) VALUES (9, N'OrganizationSettings', 1, 10)
INSERT [dbo].[FeatureGroup] ([Id], [FeatureKey], [PermissionType], [FeatureGroupKey]) VALUES (10, N'Synchronization', 0, 7)
INSERT [dbo].[FeatureGroup] ([Id], [FeatureKey], [PermissionType], [FeatureGroupKey]) VALUES (11, N'Help', 0, 11)
SET IDENTITY_INSERT [dbo].[FeatureGroup] OFF

SET IDENTITY_INSERT [dbo].[CommonTasks] ON
INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (1, N'CTSamplePlan', 2, N'/Masters/SamplePlan/Create', N'/Masters/SamplePlan/Create', N'fa fa-th')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (2, N'CTTestPoint', 2, N'/Masters/TestPoint/Index', N'/Masters/TestPoint/Index', N'fa fa-th')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (3, N'CTUser', 1, N'/Masters/User/List', N'/Masters/User/List', N'fa fa-cog')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (4, N'CTResult', 5, N'/Masters/EditResult/Index', N'/Masters/EditResult/Index', N'fa fa-th')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (5, N'CTSystemSetup', 3, N'/Masters/Location/GetLocationDetails', N'/Masters/Location/GetLocationDetails', N'fa fa-cog')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (6, N'CTLuminometerDetail', 4, N'/Masters/LuminometerDetails/Index', N'/Masters/LuminometerDetails/Index', N'fa fa-cog')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (7, N'CTPrintReport', 6, N'GenerateReport(reportOption.PrintReport)', N'GenerateReport(reportOption.PrintReport)', N'fa fa-print')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (8, N'CTViewReport', 6, N'/Masters/Report/Index', N'/Masters/Report/Index', N'fa fa-bar-chart')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (9, N'CTExportReport', 6, N' fileDownload();saveDashboardFilter(false, false, false)', N' fileDownload();saveDashboardFilter(false, false, false)', N' fa fa-download')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (10, N'CTDBManagement', 8, N'/Masters/DataArchival/Index', N'/Masters/DataArchival/Index', N'fa fa-cog')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (11, N'CTLogs', 9, N'/Masters/AuditLog/Index', N'/Masters/AuditLog/Index', N'fa fa-cog')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (12, N'CTOrgSetting', 10, N'/Configuration/OrganizationConfiguration/OrganizationConfiguration', N'/Configuration/OrganizationConfiguration/OrganizationConfiguration', N'fa fa-cog')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (13, N'CTEditSamplePlan', 2, N'/Masters/SamplePlan/List', N'/Masters/SamplePlan/List', N'fa fa-th')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (14, N'CTEditTestPoint', 2, N'/Masters/TestPoint/Index', N'/Masters/TestPoint/Index', N'fa fa-th')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (15, N'CTSynchronization', 7, N'/Synchronization/Index', N'/Synchronization/Index', N'fa fa-cog')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (16, N'CTEditUser', 1, N'/Masters/User/List', N'/Masters/User/List', N'fa fa-cog')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (17, N'CTEditResult', 5, N'/Masters/EditResult/Index', N'/Masters/EditResult/Index', N'fa fa-th')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (18, N'CTLocation', 3, N'/Masters/Location/GetLocationDetails', N'/Masters/Location/GetLocationDetails', N'fa fa-cog')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (19, N'CTVariable', 3, N'/Masters/Variable/Index', N'/Masters/Variable/Index', N'fa fa-cog')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (20, N'CTRole', 3, N'#', N'#', N'fa fa-cog')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (21, N'CTCapaComment', 2, N'/Masters/CapaComments/Index', N'/Masters/CapaComments/Index', N'fa fa-th')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (22, N'CTSaveReport', 6, N'saveDashboardFilter(false, false, false)', N'saveDashboardFilter(false, false, false)', N'fa fa-save')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (23, N'CTScheduleReport', 6, N'autoReportSchedulingClick()', N'autoReportSchedulingClick()', N' fa fa-calendar')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (24, N'CTUserManual', 11, N'http://www.3M.com/CleanTraceLM1manual', N'http://www.3M.com/CleanTraceLM1manual', N'#')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (25, N'CTLinkTo3M', 11, N'http://www.3m.com/foodsafety/', N'http://www.3m.com/foodsafety/', N'#')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (26, N'CTAbout', 11, N'/About/Index', N'/About/Index', N'#')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (27, N'CTFavoriteReport', 6, N'onFavoriteClick()', N'onFavoriteClick()', N'fa fa-star-o')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (28, N'CTDashBoard', 2, N'/DashBoard/Index', N'/DashBoard/Index', N'fa fa-home')

INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (29, N'CTVariableDefault', 3, N'/Masters/Variable/DefaultValues', N'/Masters/Variable/DefaultValues', N'fa fa-cog')
INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (30, N'CTEditSchedule', 2, N'EditSamplePlanDetailsSchedule', N'EditSamplePlanDetailsSchedule', N'fa fa-cog')
INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (31, N'CTApplyPassFail', 2, N'ApplyPassFailCriteria', N'ApplyPassFailCriteria', N'fa fa-cog')
INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (32, N'CTAssignUserForSamplePlan', 2, N'EditSamplePlanDetailsAssignedUser', N'EditSamplePlanDetailsAssignedUser', N'fa fa-cog')
INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (33, N'CTImportData', 2, N'/Masters/DataMigration/Index', N'/Masters/DataMigration/Index', N'fa fa-cog')
INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (34, N'CTAddCapaComment', 2, N'#', N'#', N'fa fa-cog')
INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (35, N'CTAddTestPoint', 2, N'/Masters/TestPoint/CreateTestPoint', N'/Masters/TestPoint/CreateTestPoint', N'fa fa-th')
INSERT [dbo].[CommonTasks] ([CommonTaskId], [CommonTaskKey], [FeatureGroupKey], [AddUrl], [ViewUrl], [ImageName]) VALUES (36, N'CTEmailReport', 6, N'saveDashboardFilter(false, false, true)', N'saveDashboardFilter(false, false, true)', N'fa fa-envelope')
SET IDENTITY_INSERT [dbo].[CommonTasks] OFF