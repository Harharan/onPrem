USE [Spark]
GO
IF OBJECT_ID ( '[dbo].[DashBoardView]', 'V' ) IS NOT NULL   
    DROP View [dbo].[DashBoardView]
GO

/****** Object:  View [dbo].[DashBoardView]    Script Date: 17-07-2020 13:03:15 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[DashBoardView]
AS
SELECT ROW_NUMBER() OVER (
		ORDER BY ResultId
		) AS RowNo,
	OrganizationId,
	ResultId,
	MeasurementId,
	TestPlanId,
	TestPlanName,
	OpenedDate,
	TestPointId,
	TestPointName,
	TestPointUniqueId,
	TestMethodId,
	TestMethodVersion,
	TestMethodName,
	LocationId,
	LocationName,
	TesterId,
	TesterName,
	Result,
	ResultValue,
	ResultDate,
	TimeZoneName,
	CapaComments,
	PassThreshold,
	FailThreshold,
	MinRange, 
	MaxRange,
	ThresholdType,
	Adhoc,
	Retest,
	Mapped,
	Edited,
	OriginalMeasurementId,
	CreatedDate,
	LastEditedBy,
	LastEditDate,
	Is3MSwab,
	UnitName,
	ReTestOrder,
	Archived,
	IsFinal,
	TimeZoneShortName,
	TestMethodShortName,
	HierarchicalLocationName
FROM (
	SELECT dbo.TestPlanResult.OrganizationId,
		dbo.TestPlanResult.ResultId,
		dbo.TestPointResult.MeasurementId,
		dbo.TestPlanResult.TestPlanId,
		dbo.TestPlanMaster.TestPlanName,
		dbo.TestPlanResult.OpenedDate,
		dbo.TestPointResult.TestPointId,
		dbo.TestPointMaster.TestPointName,
		CAST(dbo.TestPointResult.TestPointId AS VARCHAR(20)) AS TestPointUniqueId,
		dbo.TestPointResult.TestMethodId,
		dbo.TestPointResult.TestMethodVersion,
		OTMV.TestMethodName,
		dbo.TestPointResult.TestPointLocationId AS LocationId,
		dbo.TestPointResult.LocationName,
		dbo.TestPointResult.ResultTakenBy AS TesterId,
		dbo.TestPointResult.ResultTakenByName AS TesterName,
		dbo.TestPointResult.Result,
		CASE WHEN dbo.TestPointResult.ThresholdType = 1 THEN NULL ELSE dbo.TestPointResult.ResultValue END as ResultValue,
		dbo.TestPointResult.ResultDate,
		Case When ISNULL(dbo.TestPointResult.TimeZoneName,'')<>'' Then  dbo.TestPointResult.TimeZoneName 
		Else (Select Timezone From LocationMaster Where locationId in ( Select [dbo].[GetParentLoctaionHierarchyIds](dbo.TestPointResult.TestPointLocationId,dbo.TestPlanResult.OrganizationId))) End as TimeZoneName,
		dbo.TestPointResult.CapaComments,
		CASE WHEN dbo.TestPointResult.ThresholdType = 1 THEN NULL ELSE dbo.TestPointResult.ATPPassThreshold END as PassThreshold,
        CASE WHEN dbo.TestPointResult.ThresholdType = 1 THEN NULL ELSE dbo.TestPointResult.ATPFailThreshold END as FailThreshold,
		CASE WHEN dbo.TestPointResult.ThresholdType = 1 THEN NULL ELSE dbo.TestPointResult.MinRange END AS MinRange,
		CASE WHEN dbo.TestPointResult.ThresholdType = 1 THEN NULL ELSE dbo.TestPointResult.MaxRange END AS MaxRange,
		dbo.TestPointResult.ThresholdType,
		dbo.TestPointResult.IsAdhoc AS Adhoc,
		dbo.TestPointResult.IsRetest AS Retest,
		'1' AS Mapped,
		dbo.TestPointResult.IsEdited AS Edited,
		cast(dbo.TestPointResult.OriginalMeasurementId AS INT) AS OriginalMeasurementId,
		dbo.TestPointResult.CreatedDate,
		dbo.TestPointResult.LastEditedBy,
		dbo.TestPointResult.LastEditDate,
		dbo.TestPointResult.Is3MSwab,
		dbo.TestPointResult.UnitName,
		'0' AS Archived,
		TestOrder as ReTestOrder,
		IsFinal,
		-- Case When ISNULL(dbo.TestPointResult.TimeZoneShortCode,'')<>''     
       
		--Then       
		--dbo.TestPointResult.TimeZoneShortCode -- newly added.     

		--Else ISNULL((Select Top(1) TimeZoneShortName From TimezoneMaster Where Timezone IN (Select Timezone From LocationMaster Where locationId in ( Select [dbo].[GetParentLoctaionHierarchyIds](dbo.TestPointResult.TestPointLocationId,dbo.TestPlanResult.OrganizationId)))),'') End TimeZoneShortName,
		
		Case When ISNULL(TimeZoneShortCode,'')<>'' 
		Then 
			dbo.TestPointResult.TimeZoneShortCode
		
		Else 
			Case When ISNULL(dbo.TestPointResult.TimeZoneName,'')<>'' 
			Then 
				(Select Top(1) TimeZoneShortName From TimezoneMaster Where Timezone=dbo.TestPointResult.TimeZoneName)
		
			Else 
				ISNULL((Select Top(1) TimeZoneShortName From TimezoneMaster Where Timezone IN (Select Timezone From LocationMaster Where locationId in ( Select [dbo].[GetParentLoctaionHierarchyIds](dbo.TestPointResult.TestPointLocationId,dbo.TestPlanResult.OrganizationId)))),'') 
			End 
		End TimeZoneShortName,
		
		OTMV.ShortName as TestMethodShortName,
		dbo.LocationMaster.Description As HierarchicalLocationName
		FROM dbo.TestPlanResult 
		Inner join dbo.TestPointResult
			ON dbo.TestPlanResult.ResultId = dbo.TestPointResult.ResultId
		Inner join TestPlanMaster
			on TestPlanMaster.TestPlanId = dbo.TestPlanResult.TestPlanId
		Inner join TestPointMaster
			on TestPointMaster.TestPointId = dbo.TestPointResult.TestPointId
		Left join TimezoneMaster TM on TM.Timezone = dbo.TestPointResult.TimeZoneName
		Inner join dbo.LocationMaster on dbo.LocationMaster.LocationId = dbo.TestPointMaster.LocationId and dbo.LocationMaster.OrganizationId = dbo.TestPointMaster.OrganizationId
		Inner join OrganizationTestMethodVersions OTMV on OTMV.TestMethodId =  dbo.TestPointResult.TestMethodId
		where OTMV.IsCurrent = 1
	UNION ALL
	
	SELECT dbo.AdhocTestPlanResult.OrganizationId,
		0 - dbo.AdhocTestPlanResult.AdhocResultId AS ResultId,
		dbo.AdhocTestPointResult.AdhocMeasurementId,
		dbo.AdhocTestPlanResult.TestPlanId,
		dbo.TestPlanMaster.TestPlanName,
		dbo.AdhocTestPlanResult.OpenedDate,
		dbo.AdhocTestPointResult.TestPointId,
		CASE 
			WHEN (dbo.AdhocTestPointResult.TestPointId = 0 or dbo.AdhocTestPointResult.TestPointId is NULL)
				THEN dbo.AdhocTestPointResult.TestPointName
			ELSE TestPointMaster.TestPointName
			END AS TestPointName,
		CASE 
			WHEN (dbo.AdhocTestPointResult.TestPointId = 0 or dbo.AdhocTestPointResult.TestPointId is NULL)
				THEN 'AHC_' + dbo.AdhocTestPointResult.TestPointName
			ELSE CAST(dbo.AdhocTestPointResult.TestPointId AS VARCHAR(20))
		END AS TestPointUniqueId,
		dbo.AdhocTestPointResult.TestMethodId,
		dbo.AdhocTestPointResult.TestMethodVersion,
		OTMV.TestMethodName,
		dbo.AdhocTestPointResult.TestPointLocationId AS LocationId,
		CASE 
			WHEN (dbo.AdhocTestPointResult.TestPointLocationId = 0 or dbo.AdhocTestPointResult.TestPointLocationId is NULL)
				THEN 'No Location'
			ELSE dbo.AdhocTestPointResult.LocationName
			END AS LocationName,
		dbo.AdhocTestPointResult.ResultTakenBy AS TesterId,
		dbo.AdhocTestPointResult.ResultTakenByName AS TesterName,
		dbo.AdhocTestPointResult.Result,
		CASE WHEN dbo.AdhocTestPointResult.ThresholdType = 1 THEN NULL ELSE dbo.AdhocTestPointResult.ResultValue END as ResultValue,
		dbo.AdhocTestPointResult.ResultDate,
		--dbo.AdhocTestPointResult.TimeZoneName,
		Case When ISNULL(dbo.AdhocTestPointResult.TimeZoneName,'')<>'' Then  dbo.AdhocTestPointResult.TimeZoneName 
		Else (Select Timezone From LocationMaster Where locationId in ( Select [dbo].[GetParentLoctaionHierarchyIds](dbo.AdhocTestPointResult.TestPointLocationId,dbo.AdhocTestPlanResult.OrganizationId))) End as TimeZoneName,
		dbo.AdhocTestPointResult.CapaComments,
		CASE WHEN dbo.AdhocTestPointResult.ThresholdType = 1 THEN NULL ELSE dbo.AdhocTestPointResult.ATPPassThreshold END as PassThreshold,
		CASE WHEN dbo.AdhocTestPointResult.ThresholdType = 1 THEN NULL ELSE dbo.AdhocTestPointResult.ATPFailThreshold END as FailThreshold,
		CASE WHEN dbo.AdhocTestPointResult.ThresholdType = 1 THEN NULL ELSE dbo.AdhocTestPointResult.MinRange END AS MinRange,
		CASE WHEN dbo.AdhocTestPointResult.ThresholdType = 1 THEN NULL ELSE dbo.AdhocTestPointResult.MaxRange END AS MaxRange,
		dbo.AdhocTestPointResult.ThresholdType,
		dbo.AdhocTestPointResult.IsAdhoc,
		dbo.AdhocTestPointResult.IsRetest,
		dbo.AdhocTestPointResult.IsMapped AS Mapped,
		dbo.AdhocTestPointResult.IsEdited,
		cast(dbo.AdhocTestPointResult.OriginalAdhocMeasurementId AS INT) AS OriginalMeasurementId,
		dbo.AdhocTestPointResult.CreatedDate,
		dbo.AdhocTestPointResult.LastEditedBy,
		dbo.AdhocTestPointResult.LastEditDate,
		dbo.AdhocTestPointResult.Is3MSwab,
		dbo.AdhocTestPointResult.UnitName,
		'0' AS Archived,
		TestOrder as ReTestOrder,
		IsFinal,
		--TimeZoneShortName
		Case When ISNULL(dbo.AdhocTestPointResult.TimeZoneShortCode,'')<>''     
  Then       
  dbo.AdhocTestPointResult.TimeZoneShortCode -- newly added.     
    
  
		Else ISNULL((Select Top(1) TimeZoneShortName From TimezoneMaster Where Timezone IN (Select Timezone From LocationMaster Where locationId in ( Select [dbo].[GetParentLoctaionHierarchyIds](dbo.AdhocTestPointResult.TestPointLocationId,dbo.AdhocTestPlanResult.OrganizationId)))),'') End TimeZoneShortName,
		OTMV.ShortName as TestMethodShortName,
		dbo.LocationMaster.Description As HierarchicalLocationName
	FROM dbo.AdhocTestPlanResult 
		Inner join dbo.AdhocTestPointResult
			ON dbo.AdhocTestPlanResult.AdhocResultId = dbo.AdhocTestPointResult.AdhocResultId
		Inner join TestPlanMaster
			on TestPlanMaster.TestPlanId = dbo.AdhocTestPlanResult.TestPlanId
		Left join TestPointMaster
			on TestPointMaster.TestPointId = dbo.AdhocTestPointResult.TestPointId
		Left join TimezoneMaster TM on TM.Timezone = dbo.AdhocTestPointResult.TimeZoneName
		LEFT join dbo.LocationMaster on dbo.LocationMaster.LocationId = dbo.TestPointMaster.LocationId and dbo.LocationMaster.OrganizationId = dbo.TestPointMaster.OrganizationId
		Inner join OrganizationTestMethodVersions OTMV on OTMV.TestMethodId =  dbo.AdhocTestPointResult.TestMethodId
		where OTMV.IsCurrent = 1
	UNION ALL
	
	SELECT Spark_Archive.dbo.TestPlanResult.OrganizationId,
		Spark_Archive.dbo.TestPlanResult.ResultId,
		Spark_Archive.dbo.TestPointResult.MeasurementId,
		Spark_Archive.dbo.TestPlanResult.TestPlanId,
		dbo.TestPlanMaster.TestPlanName,
		Spark_Archive.dbo.TestPlanResult.OpenedDate,
		Spark_Archive.dbo.TestPointResult.TestPointId,
		dbo.TestPointMaster.TestPointName,
		CAST(Spark_Archive.dbo.TestPointResult.TestPointId AS VARCHAR(20)) AS TestPointUniqueId,
		Spark_Archive.dbo.TestPointResult.TestMethodId,
		Spark_Archive.dbo.TestPointResult.TestMethodVersion,
		OTMV.TestMethodName,
		Spark_Archive.dbo.TestPointResult.TestPointLocationId AS LocationId,
		Spark_Archive.dbo.TestPointResult.LocationName,
		Spark_Archive.dbo.TestPointResult.ResultTakenBy AS TesterId,
		Spark_Archive.dbo.TestPointResult.ResultTakenByName AS TesterName,
		Spark_Archive.dbo.TestPointResult.Result,
		CASE WHEN Spark_Archive.dbo.TestPointResult.ThresholdType = 1 THEN NULL ELSE Spark_Archive.dbo.TestPointResult.ResultValue END as ResultValue,
		Spark_Archive.dbo.TestPointResult.ResultDate,
		--Spark_Archive.dbo.TestPointResult.TimeZoneName,
		Case When ISNULL(Spark_Archive.dbo.TestPointResult.TimeZoneName,'')<>'' Then  Spark_Archive.dbo.TestPointResult.TimeZoneName 
		Else (Select Timezone From LocationMaster Where locationId in ( Select [dbo].[GetParentLoctaionHierarchyIds](Spark_Archive.dbo.TestPointResult.TestPointLocationId,Spark_Archive.dbo.TestPlanResult.OrganizationId))) End as TimeZoneName,
		Spark_Archive.dbo.TestPointResult.CapaComments,
		CASE WHEN Spark_Archive.dbo.TestPointResult.ThresholdType = 1 THEN NULL ELSE Spark_Archive.dbo.TestPointResult.ATPPassThreshold END as PassThreshold,
		CASE WHEN Spark_Archive.dbo.TestPointResult.ThresholdType = 1 THEN NULL ELSE Spark_Archive.dbo.TestPointResult.ATPFailThreshold END as FailThreshold,
		CASE WHEN Spark_Archive.dbo.TestPointResult.ThresholdType = 1 THEN NULL ELSE Spark_Archive.dbo.TestPointResult.MinRange END AS MinRange,
		CASE WHEN Spark_Archive.dbo.TestPointResult.ThresholdType = 1 THEN NULL ELSE Spark_Archive.dbo.TestPointResult.MaxRange END AS MaxRange,
		Spark_Archive.dbo.TestPointResult.ThresholdType,
		Spark_Archive.dbo.TestPointResult.IsAdhoc AS Adhoc,
		Spark_Archive.dbo.TestPointResult.IsRetest AS Retest,
		'1' AS Mapped,
		Spark_Archive.dbo.TestPointResult.IsEdited AS Edited,
		cast(Spark_Archive.dbo.TestPointResult.OriginalMeasurementId AS INT) AS OriginalMeasurementId,
		Spark_Archive.dbo.TestPointResult.CreatedDate,
		Spark_Archive.dbo.TestPointResult.LastEditedBy,
		Spark_Archive.dbo.TestPointResult.LastEditDate,
		Spark_Archive.dbo.TestPointResult.Is3MSwab,
		Spark_Archive.dbo.TestPointResult.UnitName,
		'1' AS Archived,
		Spark_Archive.dbo.TestPointResult.TestOrder as ReTestOrder,
		IsFinal,
		--TimeZoneShortName
		 Case When ISNULL(Spark_Archive.dbo.TestPointResult.TimeZoneShortCode,'')<>''     
    Then        
 Spark_Archive.dbo.TestPointResult.TimeZoneShortCode -- newly added.  
		Else (Select Top(1) TimeZoneShortName From TimezoneMaster Where Timezone IN (Select Timezone From LocationMaster Where locationId in ( Select [dbo].[GetParentLoctaionHierarchyIds](Spark_Archive.dbo.TestPointResult.TestPointLocationId,Spark_Archive.dbo.TestPlanResult.OrganizationId)))) End TimeZoneShortName,
		OTMV.ShortName as TestMethodShortName,
		dbo.LocationMaster.Description As HierarchicalLocationName
	FROM Spark_Archive.dbo.TestPlanResult 
		Inner join Spark_Archive.dbo.TestPointResult
			ON Spark_Archive.dbo.TestPlanResult.ResultId = Spark_Archive.dbo.TestPointResult.ResultId
		Inner join TestPlanMaster
			on TestPlanMaster.TestPlanId = Spark_Archive.dbo.TestPlanResult.TestPlanId
		Inner join TestPointMaster
			on TestPointMaster.TestPointId = Spark_Archive.dbo.TestPointResult.TestPointId
		Left join TimezoneMaster TM on TM.Timezone = Spark_Archive.dbo.TestPointResult.TimeZoneName
		Inner join dbo.LocationMaster on dbo.LocationMaster.LocationId = dbo.TestPointMaster.LocationId and dbo.LocationMaster.OrganizationId = dbo.TestPointMaster.OrganizationId
		Inner join OrganizationTestMethodVersions OTMV on OTMV.TestMethodId = Spark_Archive.dbo.TestPointResult.TestMethodId
		where OTMV.IsCurrent = 1
	UNION ALL
	
	SELECT Spark_Archive.dbo.AdhocTestPlanResult.OrganizationId,
		0 - Spark_Archive.dbo.AdhocTestPlanResult.AdhocResultId AS ResultId,
		Spark_Archive.dbo.AdhocTestPointResult.AdhocMeasurementId,
		Spark_Archive.dbo.AdhocTestPlanResult.TestPlanId,
		dbo.TestPlanMaster.TestPlanName,
		Spark_Archive.dbo.AdhocTestPlanResult.OpenedDate,
		Spark_Archive.dbo.AdhocTestPointResult.TestPointId,
		CASE 
			WHEN (Spark_Archive.dbo.AdhocTestPointResult.TestPointId = 0 or Spark_Archive.dbo.AdhocTestPointResult.TestPointId is NULL)
				THEN Spark_Archive.dbo.AdhocTestPointResult.TestPointName
			ELSE dbo.TestPointMaster.TestPointName
			END AS TestPointName,
		CASE 
			WHEN (Spark_Archive.dbo.AdhocTestPointResult.TestPointId = 0 or Spark_Archive.dbo.AdhocTestPointResult.TestPointId is NULL)
				THEN 'AHC_' + Spark_Archive.dbo.AdhocTestPointResult.TestPointName
			ELSE CAST(Spark_Archive.dbo.AdhocTestPointResult.TestPointId AS VARCHAR(20))
			END AS TestPointUniqueId,
		Spark_Archive.dbo.AdhocTestPointResult.TestMethodId,
		Spark_Archive.dbo.AdhocTestPointResult.TestMethodVersion,
		OTMV.TestMethodName,
		Spark_Archive.dbo.AdhocTestPointResult.TestPointLocationId AS LocationId,
		CASE 
			WHEN (Spark_Archive.dbo.AdhocTestPointResult.TestPointLocationId = 0 or Spark_Archive.dbo.AdhocTestPointResult.TestPointLocationId is NULL)
				THEN 'No Location'
			ELSE Spark_Archive.dbo.AdhocTestPointResult.LocationName
			END AS LocationName,
		Spark_Archive.dbo.AdhocTestPointResult.ResultTakenBy AS TesterId,
		Spark_Archive.dbo.AdhocTestPointResult.ResultTakenByName AS TesterName,
		Spark_Archive.dbo.AdhocTestPointResult.Result,
		CASE WHEN Spark_Archive.dbo.AdhocTestPointResult.ThresholdType = 1 THEN NULL ELSE Spark_Archive.dbo.AdhocTestPointResult.ResultValue END as ResultValue,
		Spark_Archive.dbo.AdhocTestPointResult.ResultDate,
		--Spark_Archive.dbo.AdhocTestPointResult.TimeZoneName,
		Case When ISNULL(Spark_Archive.dbo.AdhocTestPointResult.TimeZoneName,'')<>'' Then  Spark_Archive.dbo.AdhocTestPointResult.TimeZoneName 
		Else (Select Timezone From LocationMaster Where locationId in ( Select [dbo].[GetParentLoctaionHierarchyIds](Spark_Archive.dbo.AdhocTestPointResult.TestPointLocationId,Spark_Archive.dbo.AdhocTestPlanResult.OrganizationId))) End as TimeZoneName,
		Spark_Archive.dbo.AdhocTestPointResult.CapaComments,
		CASE WHEN Spark_Archive.dbo.AdhocTestPointResult.ThresholdType = 1 THEN NULL ELSE Spark_Archive.dbo.AdhocTestPointResult.ATPPassThreshold END as PassThreshold,
		CASE WHEN Spark_Archive.dbo.AdhocTestPointResult.ThresholdType = 1 THEN NULL ELSE Spark_Archive.dbo.AdhocTestPointResult.ATPFailThreshold END as FailThreshold,
		CASE WHEN Spark_Archive.dbo.AdhocTestPointResult.ThresholdType = 1 THEN NULL ELSE Spark_Archive.dbo.AdhocTestPointResult.MinRange END AS MinRange,
		CASE WHEN Spark_Archive.dbo.AdhocTestPointResult.ThresholdType = 1 THEN NULL ELSE Spark_Archive.dbo.AdhocTestPointResult.MaxRange END AS MaxRange,
		Spark_Archive.dbo.AdhocTestPointResult.ThresholdType,
		Spark_Archive.dbo.AdhocTestPointResult.IsAdhoc,
		Spark_Archive.dbo.AdhocTestPointResult.IsRetest,
		Spark_Archive.dbo.AdhocTestPointResult.IsMapped AS Mapped,
		Spark_Archive.dbo.AdhocTestPointResult.IsEdited,
		cast(Spark_Archive.dbo.AdhocTestPointResult.OriginalAdhocMeasurementId AS INT) AS OriginalMeasurementId,
		Spark_Archive.dbo.AdhocTestPointResult.CreatedDate,
		Spark_Archive.dbo.AdhocTestPointResult.LastEditedBy,
		Spark_Archive.dbo.AdhocTestPointResult.LastEditDate,
		Spark_Archive.dbo.AdhocTestPointResult.Is3MSwab,
		Spark_Archive.dbo.AdhocTestPointResult.UnitName,
		'1' AS Archived,
		Spark_Archive.dbo.AdhocTestPointResult.TestOrder as ReTestOrder,
		IsFinal,
		--TimeZoneShortName
		Case When ISNULL(Spark_Archive.dbo.AdhocTestPointResult.TimeZoneShortCode,'')<>''     
    
    Then       
    Spark_Archive.dbo.AdhocTestPointResult.TimeZoneShortCode -- newly added.
		Else (Select Top(1) TimeZoneShortName From TimezoneMaster Where Timezone IN (Select Timezone From LocationMaster Where locationId in ( Select [dbo].[GetParentLoctaionHierarchyIds](Spark_Archive.dbo.AdhocTestPointResult.TestPointLocationId,Spark_Archive.dbo.AdhocTestPlanResult.OrganizationId)))) End TimeZoneShortName,
		OTMV.ShortName as TestMethodShortName,
		dbo.LocationMaster.Description As HierarchicalLocationName
	FROM Spark_Archive.dbo.AdhocTestPlanResult
		inner join Spark_Archive.dbo.AdhocTestPointResult
			On Spark_Archive.dbo.AdhocTestPlanResult.AdhocResultId = Spark_Archive.dbo.AdhocTestPointResult.AdhocResultId
		Inner join dbo.TestPlanMaster
			on dbo.TestPlanMaster.TestPlanId = Spark_Archive.dbo.AdhocTestPlanResult.TestPlanId
		Left join dbo.TestPointMaster
			on dbo.TestPointMaster.TestPointId = Spark_Archive.dbo.AdhocTestPointResult.TestPointId
		Left join TimezoneMaster TM on TM.Timezone = Spark_Archive.dbo.AdhocTestPointResult.TimeZoneName
		Inner join dbo.LocationMaster on dbo.LocationMaster.LocationId = dbo.TestPointMaster.LocationId and dbo.LocationMaster.OrganizationId = dbo.TestPointMaster.OrganizationId
		Inner join OrganizationTestMethodVersions OTMV on OTMV.TestMethodId = Spark_Archive.dbo.AdhocTestPointResult.TestMethodId
		where OTMV.IsCurrent = 1
	) c

GO


