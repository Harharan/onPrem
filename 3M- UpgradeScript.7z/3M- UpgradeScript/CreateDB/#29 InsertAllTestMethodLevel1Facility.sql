USE [Spark]
GO
IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodMaster]') 
AND name = 'LocationId'
)
BEGIN

Create Table #locationMaster(Id Int Identity(1,1),LocationId Int)
Select *,TestMethodId_Old=TestMethodId Into #OrganizationTestMethodMaster From OrganizationTestMethodMaster
Select *,TestMethodId_Old=TestMethodId Into #OrganizationTestMethodVersions From OrganizationTestMethodVersions
Select * Into #TestPointTestMethodMapping From TestPointTestMethodMapping
ALTER TABLE [dbo].[OrganizationTestMethodMaster] ADD [LocationId] Int
--ALTER TABLE #OrganizationTestMethodMaster ADD [TestMethodId_Old] Smallint

Update #OrganizationTestMethodMaster Set TestMethodId_Old=TestMethodId

Set nocount on

Insert Into #locationMaster
Select LocationId From LocationMaster Where ParentLocationId=0 and [Status]=1

Declare @Min int ,@Max Int
Select @Min=Min(Id),@Max=Max(Id) From #locationMaster
--Select @Min=@Max

Delete From TestPointTestMethodMapping
Delete From OrganizationTestMethodVersions
Delete From OrganizationTestMethodMaster
While(@Min<=@Max)
	Begin
		Declare @LocationId Int,@TestMethodId Smallint 
		Select @LocationId =LocationId From #locationMaster Where Id=@Min
		Select @TestMethodId=ISNULL(Max(TestMethodId),0) From OrganizationTestMethodMaster
		
		--Print ('@TestMethodId :'+Convert(Varchar(max),@TestMethodId)+' @LocationId :'+Convert(Varchar(Max),@LocationId))
		Update #OrganizationTestMethodMaster Set @TestMethodId=TestMethodId=@TestMethodId+1

		--Select @TestMethodId=ISNULL(Max(TestMethodId),0) From OrganizationTestMethodVersions

		Update #OrganizationTestMethodVersions Set TestMethodId=m.TestMethodId
		From #OrganizationTestMethodVersions v inner join #OrganizationTestMethodMaster m on v.TestMethodId_Old=m.TestMethodId_Old

		Insert Into OrganizationTestMethodMaster
		Select OrganizationId,TestMethodId,ApplicationId,TestType,IsApplicable,EditedBy,
		EditedDate,CreatedDate,CreatedBy,[Order],IsDeleted,@LocationId as LocationId From #OrganizationTestMethodMaster

		Insert Into OrganizationTestMethodVersions
		Select OrganizationId,TestMethodId,TestMethodVersion,TestMethodName,IsCurrent,ShortName,PassThreshold,FailThreshold,ThresholdType,
		UnitId,CreatedDate,CreatedBy,PassThresholdMax,FailThresholdMin,MinRange,MaxRange From #OrganizationTestMethodVersions

		--Update Test Point Data 
		--If(Exists(Select LocationId From TestPointMaster Where [dbo].[GetParentLoctaionHierarchyIds](LocationId,1)=@LocationId))
		--Begin
		Insert Into TestPointTestMethodMapping
		Select TMP.OrganizationId,TMP.TestPointId,TMP.TestPointVersion,OTM.TestMethodId,IsThresholdOverridden,ATPPassThreshold,ATPFailThreshold,
		ThresholdType,PassThresholdMax,FailThresholdMin,MinRange,MaxRange 
		From #TestPointTestMethodMapping TMP
		Inner Join #OrganizationTestMethodMaster OTM on TMP.TestMethodId=OTM.TestMethodId_Old
		Inner Join TestPointMaster TP On TMP.TestPointId=TP.TestPointId
		Where [dbo].[GetParentLoctaionHierarchyIds](TP.LocationId,1)=@LocationId
		--End

		Set @Min=@Min+1
	End

Drop Table #OrganizationTestMethodMaster
Drop Table #OrganizationTestMethodVersions
Drop Table #TestPointTestMethodMapping
Drop Table #locationMaster
END
--else
--BEGIN
--ALTER TABLE [dbo].[OrganizationTestMethodMaster] drop column [LocationId]
--END

Go