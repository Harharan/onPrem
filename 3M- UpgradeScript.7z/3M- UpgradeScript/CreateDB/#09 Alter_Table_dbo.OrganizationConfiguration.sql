USE [Spark]
GO

--

IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodVersions]') 
AND name = 'FK_OrganizationTestMethodMasterOrganizationTestMethodVersions'
)
BEGIN

ALTER TABLE [dbo].[OrganizationTestMethodVersions]  Drop  CONSTRAINT [FK_OrganizationTestMethodMasterOrganizationTestMethodVersions] 

ALTER TABLE [dbo].[OrganizationTestMethodVersions]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationTestMethodMasterOrganizationTestMethodVersions] FOREIGN KEY([OrganizationId],[TestMethodId])
REFERENCES [dbo].[OrganizationTestMethodMaster] ([OrganizationId],[TestMethodId])
END
GO
--

IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointTestMethodMapping]') 
AND name = 'FK_OrganizationTestMethodMasterTestPointTestMethodMapping'
)
BEGIN
ALTER TABLE [dbo].[TestPointTestMethodMapping] drop constraint FK_OrganizationTestMethodMasterTestPointTestMethodMapping

ALTER TABLE [dbo].[TestPointTestMethodMapping]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationTestMethodMasterTestPointTestMethodMapping] FOREIGN KEY([OrganizationId], [TestMethodId])
REFERENCES [dbo].[OrganizationTestMethodMaster] ([OrganizationId],[TestMethodId])
END
GO

--

IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodMaster]') 
AND name = 'pk_OrganizationTestMethodMaster'
)
BEGIN
ALTER TABLE [dbo].[OrganizationTestMethodMaster] drop constraint pk_OrganizationTestMethodMaster

ALTER TABLE [dbo].[OrganizationTestMethodMaster]  WITH CHECK ADD  CONSTRAINT pk_OrganizationTestMethodMaster PRIMARY KEY CLUSTERED 
(
    [OrganizationId] ASC,
    [TestMethodId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END
GO

--

IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPlanUserMapping]') 
AND name = 'FK_TestPlanMasterTestPlanUserMapping'
)
BEGIN
ALTER TABLE [dbo].[TestPlanUserMapping]  DROP  CONSTRAINT [FK_TestPlanMasterTestPlanUserMapping]

ALTER TABLE [dbo].[TestPlanUserMapping]  WITH CHECK ADD  CONSTRAINT [FK_TestPlanMasterTestPlanUserMapping] FOREIGN KEY([OrganizationId],[TestPlanId], [TestPlanVersion])
REFERENCES [dbo].[TestPlanMaster] ([OrganizationId],[TestPlanId], [TestPlanVersion])
END
GO

--

IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPlanUserMapping]') 
AND name = 'FK_TestPlanMasterTestPlanUserMapping'
)
BEGIN
ALTER TABLE [dbo].[TestPlanTestPointMapping] drop constraint [FK_TestPlanMasterTestPlanTestPointMapping]

ALTER TABLE [dbo].[TestPlanTestPointMapping]  WITH CHECK ADD  CONSTRAINT [FK_TestPlanMasterTestPlanTestPointMapping] FOREIGN KEY([OrganizationId], [TestPlanId], [TestPlanVersion])
REFERENCES [dbo].[TestPlanMaster] ([OrganizationId],[TestPlanId], [TestPlanVersion])
END
GO
  
--

IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPlanMaster]') 
AND name = 'PK_TestPlanMaster'
)
BEGIN
Alter table [dbo].[TestPlanMaster] drop CONSTRAINT [PK_TestPlanMaster]
 
Alter table [dbo].[TestPlanMaster] add CONSTRAINT [PK_TestPlanMaster] PRIMARY KEY CLUSTERED 
(
    [OrganizationId] ASC,
    [TestPlanId] ASC,
    [TestPlanVersion] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END
GO
 
--

IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPlanTestPointMapping]') 
AND name = 'PK_TestPlanTestPointMapping'
)
BEGIN
Alter table [dbo].[TestPlanTestPointMapping] drop CONSTRAINT [PK_TestPlanTestPointMapping]

Alter table [dbo].[TestPlanTestPointMapping] Add CONSTRAINT [PK_TestPlanTestPointMapping] PRIMARY KEY CLUSTERED 
(
    [OrganizationId] ASC,
    [TestPlanId] ASC,
    [TestPlanVersion] ASC,
    [TestPointId] ASC,
    [TestPointVersion] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END
GO

--

IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodMaster]') 
AND name = 'IsDeleted'
)
BEGIN
Alter table [Spark].[dbo].[OrganizationTestMethodMaster]
add IsDeleted bit default 0
END
GO

--

IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodVersions]') 
AND name = 'FK_OrganizationTestMethodMasterOrganizationTestMethodVersions'
)
BEGIN
Alter table Spark.dbo.[OrganizationTestMethodVersions] Drop constraint [FK_OrganizationTestMethodMasterOrganizationTestMethodVersions]

ALTER TABLE [dbo].[OrganizationTestMethodVersions]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationTestMethodMasterOrganizationTestMethodVersions] FOREIGN KEY([OrganizationId], [TestMethodId])
REFERENCES [dbo].[OrganizationTestMethodMaster] ([OrganizationId], [TestMethodId])
END
GO

--

IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointTestMethodMapping]') 
AND name = 'FK_OrganizationTestMethodMasterTestPointTestMethodMapping'
)
BEGIN
Alter table Spark.[dbo].[TestPointTestMethodMapping] Drop constraint [FK_OrganizationTestMethodMasterTestPointTestMethodMapping]

ALTER TABLE [dbo].[TestPointTestMethodMapping]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationTestMethodMasterTestPointTestMethodMapping] FOREIGN KEY([OrganizationId], [TestMethodId])
REFERENCES [dbo].[OrganizationTestMethodMaster] ([OrganizationId],[TestMethodId])
END
GO
--

IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodMaster]') 
AND name = 'PK_OrganizationTestMethodMaster'
)
BEGIN
Alter table Spark.[dbo].[OrganizationTestMethodMaster] Drop constraint [PK_OrganizationTestMethodMaster]

Alter table Spark.[dbo].[OrganizationTestMethodMaster] Add constraint [PK_OrganizationTestMethodMaster]
PRIMARY KEY CLUSTERED 
(
    [OrganizationId] ASC,
    [TestMethodId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END
Go

--

IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointTestMethodMapping]') 
AND name = 'PK_TestPointTestMethodMapping'
)
BEGIN
Alter table Spark.[dbo].[TestPointTestMethodMapping] Drop constraint [PK_TestPointTestMethodMapping]

Alter table Spark.[dbo].[TestPointTestMethodMapping] Add constraint [PK_TestPointTestMethodMapping]
 PRIMARY KEY CLUSTERED 
(
    [OrganizationId] ASC,
    [TestPointId] ASC,
    [TestPointVersion] ASC,
    [TestMethodId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END
Go

--
IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPlanUserMapping]') 
AND name = 'FK_TestPlanMasterTestPlanUserMapping'
)
BEGIN
Alter table spark.[dbo].[TestPlanUserMapping] drop constraint [FK_TestPlanMasterTestPlanUserMapping]

ALTER TABLE [dbo].[TestPlanUserMapping]  WITH CHECK ADD  CONSTRAINT [FK_TestPlanMasterTestPlanUserMapping] FOREIGN KEY([OrganizationId], [TestPlanId], [TestPlanVersion])
REFERENCES [dbo].[TestPlanMaster] ([OrganizationId], [TestPlanId], [TestPlanVersion])
END
GO 

-- 

IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPlanUserMapping]') 
AND name = 'PK_TestPlanUserMapping'
)
BEGIN
Alter table spark.[dbo].[TestPlanUserMapping] drop constraint [PK_TestPlanUserMapping]
Alter table spark.[dbo].[TestPlanUserMapping] add
CONSTRAINT [PK_TestPlanUserMapping] PRIMARY KEY CLUSTERED 
(
    [OrganizationId] ASC,
    [UserId] ASC,
    [TestPlanId] ASC,
    [TestPlanVersion] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END
GO 

--

IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPlanTestPointMapping]') 
AND name = 'FK_TestPlanMasterTestPlanTestPointMapping'
)
BEGIN
Alter table spark.[dbo].[TestPlanTestPointMapping] drop constraint [FK_TestPlanMasterTestPlanTestPointMapping]
 
ALTER TABLE [dbo].[TestPlanTestPointMapping]  WITH CHECK ADD  CONSTRAINT [FK_TestPlanMasterTestPlanTestPointMapping] FOREIGN KEY([OrganizationId], [TestPlanId], [TestPlanVersion])
REFERENCES [dbo].[TestPlanMaster] ([OrganizationId], [TestPlanId], [TestPlanVersion])
END
GO

--

IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPlanMaster]') 
AND name = 'PK_TestPlanMaster'
)
BEGIN
Alter table spark.[dbo].[TestPlanMaster] drop constraint [PK_TestPlanMaster]
 
Alter table spark.[dbo].[TestPlanMaster] add
CONSTRAINT [PK_TestPlanMaster] PRIMARY KEY CLUSTERED
(
    [OrganizationId] ASC,
    [TestPlanId] ASC,
    [TestPlanVersion] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
END
GO

--

IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodVersions]') 
AND name In ('PassThresholdMax','FailThresholdMin')
)
BEGIN
ALTER Table [Spark].[dbo].[OrganizationTestMethodVersions]
Add [PassThresholdMax] [decimal](10, 2) NULL, [FailThresholdMin] [decimal](10, 2) NULL
END
Go


--

IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[OrganizationCustomParameterVersions]') 
AND name = 'Status'
)
BEGIN
alter table [Spark].[dbo].[OrganizationCustomParameterVersions] add Status smallint
END
GO


--

IF EXISTS (SELECT *
           FROM   sys.objects
           WHERE  object_id = OBJECT_ID(N'[dbo].[GetTestTypeNames]')
                  AND type IN ( N'FN', N'IF', N'TF', N'FS', N'FT' ))
  DROP FUNCTION [dbo].[GetTestTypeNames]

GO 
Create function [dbo].[GetTestTypeNames](@TestPointId int, @OrganizationId int)
RETURNS nvarchar(1000)
as
begin
declare @TestTypeNames nvarchar(1000);
WITH CTE
as
(
	select TestMethodName from TestPointTestMethodMapping TPTM join OrganizationTestMethodVersions OTMV on TPTM.TestMethodId = OTMV.TestMethodId and TPTM.OrganizationId = OTMV.OrganizationId where TPTM.TestPointId=@TestPointId and OTMV.IsCurrent=1

)
select top 1 @TestTypeNames= STUFF((select ', ' + TestMethodName from CTE for XML path(''),TYPE).value('.','NVARCHAR(MAX)'), 1, 1, '') from cte
return @TestTypeNames
end
Go

--

IF EXISTS (SELECT *
           FROM   sys.objects
           WHERE  object_id = OBJECT_ID(N'[dbo].[GetParentLocationName]')
                  AND type IN ( N'FN', N'IF', N'TF', N'FS', N'FT' ))
  DROP FUNCTION [dbo].[GetParentLocationName]
GO 
Create function [dbo].[GetParentLocationName](@ChildLocationId int, @OrganizationId int)
RETURNS nvarchar(300)
as
begin
declare @ParentLocationName nvarchar(300);
;WITH CTE
as
(
	select * from LocationMaster
	where LocationId = @ChildLocationId and OrganizationId = @OrganizationId
	UNION ALL 
	SELECT lm.* FROM LocationMaster lm
	inner join cte c on lm.LocationId = c.ParentLocationId and lm.OrganizationId = c.OrganizationId and lm.OrganizationId = @OrganizationId and c.OrganizationId = @OrganizationId
)
select top 1 @ParentLocationName= STUFF((select ' > ' + LocationName from CTE order by Level for XML path(''),TYPE).value('.','NVARCHAR(MAX)'), 1, 3, '') from cte 
return @ParentLocationName
end
GO

--

IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointCustomParameterMapping]') 
AND name = 'ParameterVersion'
)
BEGIN
ALTER TABLE [dbo].[TestPointCustomParameterMapping] ADD [ParameterVersion] [smallint]
END
Go


--


--Newly Added Parameter for TestPointTestMethodMapping

IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointTestMethodMapping]') 
AND name In ('PassThresholdMax','FailThresholdMin')
)
BEGIN
ALTER Table [Spark].[dbo].[TestPointTestMethodMapping]
Add [PassThresholdMax] [decimal](10, 2) NULL, [FailThresholdMin] [decimal](10, 2) NULL
END
Go

--

IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[OrganizationConfiguration]') 
AND name = 'SessionTimeout'
)
BEGIN
Alter Table [Spark].[dbo].[OrganizationConfiguration] Add SessionTimeout int Default(1)
END
Go

--

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES
 WHERE TABLE_NAME = N'OrganizationConfiguration')
BEGIN
Update [Spark].[dbo].[OrganizationConfiguration] set SessionTimeout = 1
END
GO

--

USE Spark
Go
IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]') 
AND name In ('MinRange','MaxRange')
)
BEGIN
Alter Table [Spark].[dbo].[AdhocTestPointResult] Add MinRange int, MaxRange int 
END
Go

USE Spark
Go
IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointResult]') 
AND name In ('MinRange','MaxRange')
)
BEGIN
Alter Table [Spark].[dbo].[TestPointResult] Add MinRange int, MaxRange int 
END
Go


USE Spark_Archive
Go
IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]') 
AND name In ('MinRange','MaxRange')
)
BEGIN
Alter Table [Spark_Archive].[dbo].[AdhocTestPointResult] Add MinRange int, MaxRange int 
END
Go


USE Spark_Archive
Go
IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointResult]') 
AND name In ('MinRange','MaxRange')
)
BEGIN
Alter Table [Spark_Archive].[dbo].[TestPointResult] Add MinRange int, MaxRange int 
END
Go

--

USE Spark
GO

IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodMaster]') 
AND name = 'PK_OrganizationTestMethodMaster'
)
BEGIN
ALTER TABLE [dbo].[OrganizationTestMethodMaster] DROP CONSTRAINT [PK_OrganizationTestMethodMaster]

ALTER TABLE [dbo].[OrganizationTestMethodMaster] ADD CONSTRAINT [PK_OrganizationTestMethodMaster] PRIMARY KEY CLUSTERED 
(
	[OrganizationId] ASC,
	[TestMethodId] ASC

)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END


IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointTestMethodMapping]') 
AND name = 'FK_OrganizationTestMethodMasterTestPointTestMethodMapping'
)
BEGIN
ALTER TABLE [dbo].[TestPointTestMethodMapping] DROP CONSTRAINT [FK_OrganizationTestMethodMasterTestPointTestMethodMapping]

ALTER TABLE [dbo].[TestPointTestMethodMapping]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationTestMethodMasterTestPointTestMethodMapping] FOREIGN KEY([OrganizationId], [TestMethodId])
REFERENCES [dbo].[OrganizationTestMethodMaster] ([OrganizationId], [TestMethodId])
END


IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodVersions]') 
AND name = 'FK_OrganizationTestMethodMasterOrganizationTestMethodVersions'
)
BEGIN
ALTER TABLE [dbo].[OrganizationTestMethodVersions] DROP CONSTRAINT [FK_OrganizationTestMethodMasterOrganizationTestMethodVersions]

ALTER TABLE [dbo].[OrganizationTestMethodVersions]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationTestMethodMasterOrganizationTestMethodVersions] FOREIGN KEY([OrganizationId], [TestMethodId])
REFERENCES [dbo].[OrganizationTestMethodMaster] ([OrganizationId], [TestMethodId])
END

--

USE Spark
GO

IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPlanMaster]') 
AND name = 'PK_TestPlanMaster'
)
BEGIN

ALTER TABLE [dbo].[TestPlanMaster] DROP CONSTRAINT [PK_TestPlanMaster]

ALTER TABLE [dbo].[TestPlanMaster] ADD CONSTRAINT [PK_TestPlanMaster] PRIMARY KEY CLUSTERED 
(
	[OrganizationId] ASC,
	[TestPlanId] ASC,
	[TestPlanVersion] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END


IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPlanUserMapping]') 
AND name = 'FK_TestPlanMasterTestPlanUserMapping'
)
BEGIN

ALTER TABLE [dbo].[TestPlanUserMapping] DROP CONSTRAINT [FK_TestPlanMasterTestPlanUserMapping]

ALTER TABLE [dbo].[TestPlanUserMapping]  WITH CHECK ADD  CONSTRAINT [FK_TestPlanMasterTestPlanUserMapping] FOREIGN KEY([OrganizationId], [TestPlanId], [TestPlanVersion])
REFERENCES [dbo].[TestPlanMaster] ([OrganizationId], [TestPlanId], [TestPlanVersion])
END


IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPlanUserMapping]') 
AND name = 'PK_TestPlanUserMapping'
)
BEGIN

ALTER TABLE [dbo].[TestPlanUserMapping] DROP CONSTRAINT [PK_TestPlanUserMapping]

 ALTER TABLE [dbo].[TestPlanUserMapping] ADD CONSTRAINT [PK_TestPlanUserMapping] PRIMARY KEY CLUSTERED 
(
	[OrganizationId] ASC,
	[UserId] ASC,
	[TestPlanId] ASC,
	[TestPlanVersion] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END


IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPlanTestPointMapping]') 
AND name = 'PK_TestPlanTestPointMapping'
)
BEGIN
ALTER TABLE [dbo].[TestPlanTestPointMapping] DROP CONSTRAINT [PK_TestPlanTestPointMapping]

ALTER TABLE [dbo].[TestPlanTestPointMapping] ADD CONSTRAINT [PK_TestPlanTestPointMapping] PRIMARY KEY CLUSTERED 
(
	[OrganizationId] ASC,
	[TestPlanId] ASC,
	[TestPlanVersion] ASC,
	[TestPointId] ASC,
	[TestPointVersion] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
END


IF EXISTS (SELECT * FROM sys.check_constraints 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPlanTestPointMapping]') 
AND name = 'FK_TestPlanMasterTestPlanTestPointMapping'
)
BEGIN
ALTER TABLE [dbo].[TestPlanTestPointMapping] DROP CONSTRAINT [FK_TestPlanMasterTestPlanTestPointMapping]

ALTER TABLE [dbo].[TestPlanTestPointMapping]  WITH CHECK ADD  CONSTRAINT [FK_TestPlanMasterTestPlanTestPointMapping] FOREIGN KEY([OrganizationId], [TestPlanId], [TestPlanVersion])
REFERENCES [dbo].[TestPlanMaster] ([OrganizationId], [TestPlanId], [TestPlanVersion])
END

USE Spark
Go
IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodVersions]') 
AND name In ('MinRange','MaxRange')
)
BEGIN
Alter Table [Spark].[dbo].[OrganizationTestMethodVersions] Add MinRange int, MaxRange int 
END
Go

USE Spark
Go
IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointTestMethodMapping]') 
AND name In ('MinRange','MaxRange')
)
BEGIN
Alter Table [Spark].[dbo].[TestPointTestMethodMapping] Add MinRange int, MaxRange int 
END
Go


USE Spark
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[UserMaster]')
AND name = 'IsEnableLuminometerPin'
)
BEGIN
ALTER TABLE [Spark].[dbo].[UserMaster] Add  [IsEnableLuminometerPin] BIT default 1 NOT NULL;
END
Go
--

USE Spark
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[OrganizationConfiguration]')
AND name = 'IsMilitaryTime'
)
BEGIN
ALTER TABLE [Spark].[dbo].[OrganizationConfiguration] Add  [IsMilitaryTime] BIT default 0 NOT NULL;
END
Go

USE Spark
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointResult]')
AND name = 'TimeZoneName'
)
BEGIN
ALTER TABLE [Spark].[dbo].[TestPointResult] Add TimeZoneName nvarchar(100);
END
Go

USE Spark
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]')
AND name = 'TimeZoneName'
)
BEGIN
ALTER TABLE [Spark].[dbo].[AdhocTestPointResult] Add TimeZoneName nvarchar(100);
END
Go

USE Spark_Archive
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointResult]')
AND name = 'TimeZoneName'
)
BEGIN
ALTER TABLE [Spark_Archive].[dbo].[TestPointResult] Add TimeZoneName nvarchar(100);
END
Go

USE Spark_Archive
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]')
AND name = 'TimeZoneName'
)
BEGIN
ALTER TABLE [Spark_Archive].[dbo].[AdhocTestPointResult] Add TimeZoneName nvarchar(100);
END
Go

USE Spark
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[OrganizationConfiguration]')
AND name = 'CountryName'
)
BEGIN
ALTER TABLE [Spark].[dbo].[OrganizationConfiguration] Add CountryName nvarchar(50);
END
Go

USE Spark
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[DeviceSyncDetails]')
AND name = 'TimeZoneName'
)
BEGIN
ALTER TABLE [Spark].[dbo].[DeviceSyncDetails] Add TimeZoneName nvarchar(100);
END
Go

USE Spark
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[TimezoneMaster]')
AND name in ('TimeZoneShortName','CountryName') 
)
BEGIN
ALTER TABLE [Spark].[dbo].[TimezoneMaster] Add TimeZoneShortName nvarchar(30), CountryName nvarchar(2000);
END
Go


USE Spark
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[OrganizationConfiguration]')
AND name = 'CountryName'
)
BEGIN
ALTER TABLE [Spark].[dbo].[OrganizationConfiguration] Add CountryName nvarchar(100);
END
Go

USE Spark_Archive
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointResult]')
AND name = 'UtcResultDate'
)
BEGIN
ALTER TABLE [Spark_Archive].[dbo].[TestPointResult] Add UtcResultDate datetime;
END
Go

USE Spark_Archive
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]')
AND name = 'UtcResultDate'
)
BEGIN
ALTER TABLE [Spark_Archive].[dbo].[AdhocTestPointResult] Add UtcResultDate datetime;
END
Go

USE Spark
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointResult]')
AND name = 'UtcResultDate'
)
BEGIN
ALTER TABLE [Spark].[dbo].[TestPointResult] Add UtcResultDate datetime;
END
Go

USE Spark
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]')
AND name = 'UtcResultDate'
)
BEGIN
ALTER TABLE [Spark].[dbo].[AdhocTestPointResult] Add UtcResultDate datetime;
END
Go

USE Spark 
Go 
BEGIN 
ALTER TABLE  [Spark].[dbo].[TestPointResult] ALTER COLUMN [CapaComments] nvarchar(MAX)
END 
Go

USE Spark 
Go 
BEGIN 
ALTER TABLE  [Spark].[dbo].[AdhocTestPointResult] ALTER COLUMN [CapaComments] nvarchar(MAX)
END 
GO

USE Spark 
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE object_id = OBJECT_ID(N'[dbo].[CapaComments]')
AND name = 'IsDeleted'
)
BEGIN
Alter table [Spark].[dbo].[CapaComments]
add IsDeleted bit default 0
END
GO



