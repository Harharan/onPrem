USE [Spark]
GO
IF OBJECT_ID ( '[dbo].[GetTestPointSearchSuggestion]', 'P' ) IS NOT NULL   
    DROP PROCEDURE [dbo].[GetTestPointSearchSuggestion]
GO
/****** Object:  StoredProcedure [dbo].[GetTestPointsList]    Script Date: 04-09-2020 14:40:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

  -- GetTestPointSearchSuggestion 1,'1,2,6','', '%S%', VI, null, 2    
CREATE Procedure GetTestPointSearchSuggestion    
(      
--declare      
 @OrganizationId INT,      
 @LocationArray VARCHAR(MAX),      
 @Status varchar(50),      
 @SearchText nvarchar(max) = '%%',      
 @testMethodShortNames varchar(MAX),      
 @CustomTestTypeIds varchar(max),    
 @TpOrSP int    
)      
AS       
BEGIN      
      
declare @PageNumber int = 1      
declare @RowsOfPage int = 5      
declare @ActualSearchText nvarchar(max)      
      
set @ActualSearchText = substring(@SearchText,2,Len(@SearchText)-2)      
      
------------------split LocationPlants and store in @PlantsIdtbl table      
DECLARE @PlantsIdtbl AS TABLE (PlantId INT)      
INSERT INTO @PlantsIdtbl      
SELECT [value]      
FROM dbo.fn_Split(@LocationArray, ',')      
      
DECLARE @AllLocations bit      
Select @AllLocations = case when count(1) >0 then 0 else 1 end from @PlantsIdtbl      
      
if(@AllLocations != 1)      
BEGIN      
Declare @LocationIdtbl as table (ID int)      
Insert into @LocationIdtbl       
select FinalPlanId from dbo.[GetLoctaionHierarchyIds](@LocationArray,@OrganizationId)      
END      
      
create Table #testMethodShortName (ShortName varchar(Max))      
Insert into #testMethodShortName (ShortName)      
SELECT convert(varchar, [value])      
FROM dbo.fn_Split(@testMethodShortNames, ',')      
      
DECLARE @tblStatus AS TABLE ([status] INT)      
INSERT INTO @tblStatus      
SELECT [value]      
FROM dbo.fn_Split(@Status, ',')      
      
Declare @tblCustomTestMethodId as Table (testMethodId int)      
Insert Into @tblCustomTestMethodId      
select [value]      
From dbo.fn_Split(@CustomTestTypeIds, ',')      
      
Declare @countOfTestMethodsToFilter int = ((select count(1) from @tblCustomTestMethodId) + (select count(1) from #testMethodShortName))      
      
--If no value in tblStatus present the insert 1,2 to return active and inactive records      
if((select count(1) from @tblStatus) = 0)      
Begin      
Insert Into @tblStatus select 1      
Insert Into @tblStatus select 2      
End      
      
DECLARE @AllTestMethods bit      
Select @AllTestMethods = case when ('' = ISNULL(@CustomTestTypeIds,'') and ( '' = ISNULL(@testMethodShortNames,''))) then 1 else 0 end      
      
Declare @testMethodIdsForFilter As Table (testMethodId int)      
Insert Into @testMethodIdsForFilter      
Select OTM.TestMethodId from OrganizationTestMethodMaster OTM      
  join OrganizationTestMethodVersions OTMV on OTM.TestMethodId = OTMV.TestMethodId      
  and OTM.OrganizationId = OTMV.OrganizationId and OTMV.IsCurrent=1 and OTM.IsApplicable = 1      
  where (ShortName in (select ShortName from #testMethodShortName) or @AllTestMethods = 1)      
  and (OTM.LocationId in (select ID from @LocationIdtbl) or @AllLocations = 1)      
        
insert into @testMethodIdsForFilter      
select testMethodId from @tblCustomTestMethodId      
      
Declare @testPoints As Table (testPointId int, testMethodId int)      
    
Declare @testPlans As Table (SamplePlanId int)      
    
if @TpOrSP=1    
begin    
Insert Into @testPoints      
Select TPTMM.TestPointId, TPTMM.TestMethodId from OrganizationTestMethodMaster OTM      
  join OrganizationTestMethodVersions OTMV on OTM.TestMethodId = OTMV.TestMethodId      
  join TestPointTestMethodMapping TPTMM on OTMV.TestMethodId = TPTMM.TestMethodId      
  join TestPointMaster TPM on TPM.TestPointId = TPTMM.TestPointId      
  and OTM.OrganizationId = OTMV.OrganizationId and OTMV.IsCurrent=1 and OTM.IsApplicable = 1      
  where      
   (OTM.LocationId in (select ID from @LocationIdtbl) or @AllLocations = 1)      
  and TPM.[Status] != 3 and TPM.TestPointName like @SearchText      
end    
else if @TpOrSP=2    
Begin    
  ------------------------------------------------------------------------------------    
      
  Insert Into @testPlans      
Select SPM.TestPlanId from OrganizationTestMethodMaster OTM      
  join OrganizationTestMethodVersions OTMV on OTM.TestMethodId = OTMV.TestMethodId      
 join TestPointTestMethodMapping TPTMM on OTMV.TestMethodId = TPTMM.TestMethodId      
  join TestPointMaster TPM on TPM.TestPointId = TPTMM.TestPointId      
   inner join TestPlanTestPointMapping TPTPM on TPTPM.OrganizationId=TPM.OrganizationId and TPTPM.TestPointId=tpm.TestPointId    
   inner join TestPlanMaster SPM on SPM.TestPlanId=TPTPM.TestPlanId    
  and OTM.OrganizationId = OTMV.OrganizationId and OTMV.IsCurrent=1 and OTM.IsApplicable = 1    
  where      
   (OTM.LocationId in (select ID from @LocationIdtbl) or @AllLocations = 1)      
  and SPM.TestPlanName like @SearchText     
    
    
    
--select SPM.TestPlanId from TestPlanMaster SPM inner join OrganizationMaster OZM on OZM.OrganizationId=SPM.OrganizationId     
--  where      
--   --(SPM.LocationId in (select ID from @LocationIdtbl) or @AllLocations = 1)  and    
--   SPM.Status=1 and SPM.TestPlanName like @SearchText     
      
  ------------------------------------------------------------------------------------    
  end    
     
Declare @filteredTestPointsId  As Table (testPointId int)      
Declare @filteredTestPlanId  As Table (TestPlanId int)        
if @TpOrSP=1    
begin    
Insert Into @filteredTestPointsId      
select       
tps.testPointId       
from @testPoints tps        
join @testMethodIdsForFilter tMIFF on tMIFF.testMethodId = tps.testMethodId      
where ISNULL(tMIFF.testMethodId, 0) <> 0      
group by tps.testPointId      
having (count(tMIFF.testMethodId) >= @countOfTestMethodsToFilter)      
ENd    
else if  @TpOrSP=2    
begin    
Insert Into @filteredTestPlanId      
--select       
--Sps.SamplePlanId       
--from @testPlans Sps   
  
select Distinct SP.SamplePlanId  
from TestPointTestMethodMapping TPTM   
INNER JOIN OrganizationTestMethodVersions TMT on TMT.TestMethodId=TPTM.TestMethodId   
INNER JOIN TestPointMaster TP on TPTM.TestPointId=TP.TestPointId  
INNER JOIN TestPlanTestPointMapping TPTP on TP.TestPointId=TPTP.TestPointId  
Inner join @testPlans SP on SP.SamplePlanId=TPTP.TestPlanId  
where TMT.TestMethodId in (select testMethodId from @testMethodIdsForFilter)  
  
    
ENd    
     
    
    
CREATE TABLE #TestPoints (      
TestPointId int,      
TestPointName nvarchar(200),      
Status smallint not null,      
LocationId int,      
)      
    
--    
CREATE TABLE #TestPlans (      
TestPlanId int,      
TestPlanName nvarchar(200),      
Status smallint not null,      
LocationId int,      
)      
--    
      
------************** Section 1 **************--------------      
--Get the all unique test points(oldest active by name and location)      
 if @TpOrSP=1    
begin     
INSERT INTO #TestPoints    
Select      
TestPointId,      
TestPointName,      
Status,      
LocationId      
 from (      
  Select      
  TPM.TestPointId,      
  TPM.TestPointName,      
  TPM.Status,      
  LM.LocationId,      
  row_number() over (partition by TPM.TestPointName, TPM.LocationId order by TPM.Status, TPM.TestPointId) as rnum      
   from  TestPointMaster TPM      
    join LocationMaster LM on LM.LocationId = TPM.LocationId and LM.OrganizationId = TPM.OrganizationId      
    left  join TestPlanTestPointMapping TPPM on TPPM.OrganizationId = TPM.OrganizationId and TPPM.TestPointId = TPM.TestPointId and TPPM.TestPointVersion = TPM.TestPointVersion      
    where TPM.OrganizationId = @OrganizationId and TPM.Status != 3 and TPM.TestPointName like @SearchText      
    and (TPM.LocationId in (select ID from @LocationIdtbl) or @AllLocations = 1)      
    and TPM.TestPointId in (select testPointId from @filteredTestPointsId)      
 ) sp where sp.rnum=1      
 end    
 ------------------------------------------------------------------------------------------------------------------------    
 else  if @TpOrSP=2    
begin    
    
INSERT INTO #TestPlans    
Select      
TestPlanId,  TestPlanName,  Status,  LocationId from TestPlanMaster TPM where    
TPM.OrganizationId=@OrganizationId and    
--TPM.LocationId in (select ID from @LocationIdtbl) or @AllLocations = 1    
TPM.TestPlanId in (select TestPlanId from @filteredTestPlanId)  and TPM.TestPlanName like @SearchText    
 end    
 ------------------------------------------------------------------------------------------------------------------------------    
   
    
 if @TpOrSP=1    
begin     
Select       
 TestPointName      
 FROM (      
  Select       
  distinct TestPointName      
  from #TestPoints      
  WHERE [Status] in (select status from @tblStatus)      
 ) AS TP       
 order by CHARINDEX(@ActualSearchText, TestPointName), TestPointName      
 OFFSET (@PageNumber-1)*@RowsOfPage ROWS      
 FETCH NEXT @RowsOfPage ROWS ONLY      
End    
    
else if @TpOrSP=2    
begin     
Select       
 TestPlanName      
 FROM (      
  Select       
  distinct TestPlanName      
  from #TestPlans  inner join TestPlanTestPointMapping TPPM on TPPM.TestPlanId=#TestPlans.TestPlanId  
  inner join TestPointMaster TP on TP.TestPointId=TPPM.TestPointId   
  WHERE TP.[Status] in (select status from @tblStatus)      
 ) AS TP       
 order by CHARINDEX(@ActualSearchText, TestPlanName), TestPlanName      
 OFFSET (@PageNumber-1)*@RowsOfPage ROWS      
 FETCH NEXT @RowsOfPage ROWS ONLY      
End    
    
     
    
    
    
      
DROP TABLE #TestPoints      
DROP TABLE #TestPlans    
Drop Table #testMethodShortName      
End   