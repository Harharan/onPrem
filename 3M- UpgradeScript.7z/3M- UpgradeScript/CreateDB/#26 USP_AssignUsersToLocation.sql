USE [Spark]
GO
/****** Object:  StoredProcedure [dbo].[GetDashboardData]    Script Date: 11-09-2020 20:28:15 ******/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[USP_AssignUsersToLocation]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[USP_AssignUsersToLocation]
GO
Create Procedure USP_AssignUsersToLocation
As
Begin
CREATE TABLE #UserList
(
id int Identity(1,1),
userId int
)

INSERT INTO #UserList
SELECT UserId FROM UserMaster WHERE Status != 4 --INSERT ONLY ACTIVE USERS
--AND ((SELECT COUNT(1) FROM EntityLocationMapping) = 0)

CREATE TABLE #LocationList
(
LocationId int
)

INSERT INTO #LocationList
SELECT LocationId FROM LocationMaster WHERE ParentLocationId=0 --INSERT ONLY LEVEL ONE LOCATIONS

DECLARE @MIN INT, @MAX INT
SELECT @MIN=MIN(id), @MAX = MAX(id) FROM #UserList
WHILE(@MIN <= @MAX)
	BEGIN
		DECLARE @UserId int
		SELECT @UserId = userId from #UserList where id=@MIN
		Insert Into EntityLocationMapping (OrganizationId,EntityType,EntityID,LocationId)
		SELECT 1,1,@UserId,LocationId FROM #LocationList
		WHERE LocationId NOT IN (SELECT LocationId FROM EntityLocationMapping WHERE OrganizationId=1 AND EntityType=1 AND EntityID=@UserId)
		SET @MIN = @MIN + 1;
	END

DROP TABLE #UserList
DROP TABLE #LocationList
End

