USE [Spark]
GO

/****** Object:  StoredProcedure [dbo].[GetTestPointListForLocations]    Script Date: 28-07-2020 15:05:35 ******/
IF OBJECT_ID ( '[dbo].[GetTestPointListForLocations]', 'P' ) IS NOT NULL   
    DROP PROCEDURE [dbo].[GetTestPointListForLocations]
GO

CREATE PROCEDURE [dbo].[GetTestPointListForLocations]    
	@LocationArray VARCHAR(MAX)
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

CREATE Table #LocationList(LocationID INT)
INSERT INTO #LocationList
SELECT [value]
FROM dbo.fn_Split(@LocationArray, ',')

	Select * 
			From TestPlanMaster
			Where TestPlanId In 
			(
				Select TestPlanId From TestPointMaster Tp Inner Join TestPlanTestPointMapping Tm
				On Tp.TestPointId=Tm.TestPointId
				Where Tp.Locationid in(Select * From #LocationList where LocationId=Tp.LocationId)
			) 
			and TestPlanId <> 1

Drop Table #LocationList

END

GO