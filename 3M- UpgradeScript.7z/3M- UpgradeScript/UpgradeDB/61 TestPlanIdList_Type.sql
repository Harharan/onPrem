USE [Spark]
GO

/****** Object:  UserDefinedTableType [dbo].[TestPlanIdList_Type]    Script Date: 01.27.2022 06:41:59 PM ******/
CREATE TYPE [dbo].[TestPlanIdList_Type] AS TABLE(
	[OrganizationId] [int] NULL,
	[TestPlanId] [int] NULL
)
GO


