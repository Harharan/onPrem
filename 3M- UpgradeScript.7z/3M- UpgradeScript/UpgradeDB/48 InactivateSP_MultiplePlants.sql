/*21A: Inactivate sample plan if it is having test points of multiple plants during upgrade*/
USE [SPARK]
Declare @MultiLocationSPCount int = 0;

Select TPTPM.TestPlanId,dbo.ufn_GetParentLocationId(TTPM.LocationId,1) as ParentID 
into #TP_SPDetails From 
TestPlanTestPointMapping TPTPM 
Inner join TestPointMaster TTPM on TPTPM.TestPointId = TTPM.TestPointId
Group by TestPlanId,dbo.ufn_GetParentLocationId(TTPM.LocationId,1)

select @MultiLocationSPCount = count(1) from TestPlanMaster where TestPlanId in (Select TestPlanId--,Min(ParrentID)
From #TP_SPDetails
Group by TestPlanId
Having Count(ParentID)>1) and [Status] in (0,1)

if(@MultiLocationSPCount > 0)
begin
Update OrganizationMaster set IsHavingMultiLocationSamplePlan = 1 where OrganizationId = 1
End

Drop Table #TP_SPDetails

