USE [Spark]
GO

/****** Object:  UserDefinedTableType [dbo].[LocationIdList_Type]    Script Date: 01.27.2022 06:44:10 PM ******/
CREATE TYPE [dbo].[LocationIdList_Type] AS TABLE(
	[LocationId] [int] NULL,
	[OrganizationId] [int] NULL
)
GO


