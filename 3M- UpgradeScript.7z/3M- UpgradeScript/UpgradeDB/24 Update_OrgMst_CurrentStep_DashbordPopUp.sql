USE Spark
BEGIN
Declare @InstalledVersion INT = (select top 1 REPLACE(PackageVersion, '.', '') from ApplicationInformation where IsUninstall= 1 order by id desc)
if(@InstalledVersion < 1402)
BEGIN
UPDATE [OrganizationMaster]
SET [OrganizationMaster].Fax = Cast([OrganizationMaster].CurrentStep AS nvarchar),
[OrganizationMaster].CurrentStep = -999
where ConfigurationComplete=1
END
END
GO



USE Spark
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE object_id = OBJECT_ID(N'[dbo].[OrganizationImageMaster]')
AND name = 'LogoFileName'
)
BEGIN
ALTER TABLE [Spark].[dbo].[OrganizationImageMaster] Add [LogoFileName] nvarchar(MAX) default 'Logo.jpeg' NOT NULL;
END
Go






