USE [Spark]
GO

/****** Object:  StoredProcedure [dbo].[USP_UpdateAssocitedTestPointsWithTestPlan]    Script Date: 04-09-2020 16:02:45 ******/
IF OBJECT_ID ( '[dbo].[USP_UpdateAssocitedTestPointsWithTestPlan]', 'P' ) IS NOT NULL   
    DROP PROCEDURE [dbo].[USP_UpdateAssocitedTestPointsWithTestPlan]
GO
/****** Object:  StoredProcedure [dbo].[GetTestPointsMappedListToSamplePlan]    Script Date: 03-09-2020 18:45:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE Procedure [dbo].[USP_UpdateAssocitedTestPointsWithTestPlan]
--Declare 
@OrganizationId Int,
@TestPointId Int,
@LocationId Int,
@TestPointName Varchar(100),
@StatusOld int

--Set @TestPointId=28
--Set @OrganizationId=1
--Set @LocationId=7
--Set @TestPointName='MDTP_1'
As
Begin
Set nocount on
Declare @TestPointNameNew varchar(100),@PassThresholdNew Int,@FailThresholdNew Int,@TestPointImageNew varbinary(max),@Status smallint,@IsCurrent Bit,@Description Varchar(500),
@LastEditedBy int,@LastEditDate Datetime

Select @TestPointNameNew=TestPointName,@PassThresholdNew=PassThreshold,@FailThresholdNew=FailThreshold,@TestPointImageNew=TestPointImage,@Status=[Status],@IsCurrent=IsCurrent,
@Description=Description,@LastEditedBy=LastEditedBy,@LastEditDate=LastEditDate
From TestPointMaster Where TestPointId=@TestPointId
Create Table #TestPoitsAssociatedWithTestPlan
(
ID Int Identity(1,1),
TestPointId Int,
TestPlanId Int
)
Insert Into #TestPoitsAssociatedWithTestPlan
Select TP.TestPointId,TPPM.TestPlanId From TestPlanTestPointMapping  TPPM
Right Join TestPointMaster TP On TPPM.TestPointId=TP.TestPointId
Where TP.TestPointName=@TestPointName And TP.LocationId=@LocationId and TP.TestPointId<>@TestPointId and TP.Status<>3 --And TP.Status=@StatusOld
--Select * From TestPointMaster Where TestPointId=@TestPointId
If(@StatusOld<>@Status)
	Begin
		Update TestPointMaster Set TestPointName=@TestPointNameNew,PassThreshold=@PassThresholdNew,FailThreshold=@FailThresholdNew	,TestPointImage=@TestPointImageNew,Status=@Status,
		IsCurrent=@IsCurrent,Description=@Description,LastEditedBy=@LastEditedBy,LastEditDate=@LastEditDate
		Where TestPointId In (Select TestPointId From #TestPoitsAssociatedWithTestPlan)
	End
Else
	Begin
		Update TestPointMaster Set TestPointName=@TestPointNameNew,PassThreshold=@PassThresholdNew,FailThreshold=@FailThresholdNew	,TestPointImage=@TestPointImageNew,
		IsCurrent=@IsCurrent,Description=@Description,LastEditedBy=@LastEditedBy,LastEditDate=@LastEditDate
		Where TestPointId In (Select TestPointId From #TestPoitsAssociatedWithTestPlan)
	End
Update TestPlanMaster Set LastEditDate=@LastEditDate where TestPlanId in (Select TestPlanId From #TestPoitsAssociatedWithTestPlan)
-- Insert Test Method Mapping
Delete From TestPointTestMethodMapping Where TestPointId In (Select TestPointId From #TestPoitsAssociatedWithTestPlan)
Insert Into TestPointTestMethodMapping
Select TPM.OrganizationId,TPASP.TestPointId,TPM.TestPointVersion,TPM.TestMethodId,TPM.IsThresholdOverridden,TPM.ATPPassThreshold,TPM.ATPFailThreshold,TPM.ThresholdType,TPM.PassThresholdMax,TPM.FailThresholdMin,TPM.MinRange,TPM.MaxRange 
From TestPointTestMethodMapping TPM 
Inner Join #TestPoitsAssociatedWithTestPlan TPASP On 1=1
 Where TPM.TestPointId=@TestPointId

 -- Insert Custom parameter
 Delete From TestPointCustomParameterMapping Where TestPointId In (Select TestPointId From #TestPoitsAssociatedWithTestPlan)
 Insert Into TestPointCustomParameterMapping
 Select TCM .OrganizationId,TPASP.TestPointId,TCM .TestPointVersion,TCM .CategoryId,TCM .ParameterId,TCM .ParameterVersion
From TestPointCustomParameterMapping TCM 
Inner Join #TestPoitsAssociatedWithTestPlan TPASP On 1=1
 Where TCM.TestPointId=@TestPointId

--Select * From #TestPoitsAssociatedWithTestPlan
Drop Table #TestPoitsAssociatedWithTestPlan
End
GO


