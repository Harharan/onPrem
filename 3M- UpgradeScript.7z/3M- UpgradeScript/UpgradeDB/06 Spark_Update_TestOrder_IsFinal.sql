USE [Spark]
GO

/* 
	Description: 
		This is a script to update new columns IsFinal & TestOrder for existing data of TestPointResult/AdhocTestPointResult Table.
		This script can be used to recalculate the value of IsFinal & TestOrder columns.

	Creator : Krunal Vyas
	Date Of Creation : 10th May, 2018
	Objective : To optimize the dashboard and report performance.
*/

-- Update TestOrder

	UPDATE TestPointResult
	SET TestOrder = TEMP.TestOrder
	FROM (
		SELECT Po.ResultId,
			MeasurementId,
			Row_number() OVER (
				PARTITION BY OrganizationId,
							TestPointId,
							Po.ResultId,
							TestMethodId 
				ORDER BY MeasurementId
				) AS TestOrder
		FROM TestPointResult Po
		INNER JOIN TestPlanResult Pl ON Po.ResultId = Pl.ResultId
		--WHERE Po.ResultId = 20802
		) TEMP
	INNER JOIN TestPointResult ON TestPointResult.ResultId = TEMP.ResultId
		AND TestPointResult.MeasurementId = TEMP.MeasurementId

	UPDATE TestPointResult
	SET IsFinal = 0

	UPDATE TestPointResult
	SET IsFinal = 1 
	FROM (
		Select ResultId, MeasurementId from (
		SELECT Po.ResultId,
			MeasurementId,
			Row_number() OVER (
				PARTITION BY OrganizationId,
							TestPointId,
							Po.ResultId,
							TestMethodId 
				ORDER BY MeasurementId Desc
				) AS ReverseTestOrder
		FROM TestPointResult Po
		INNER JOIN TestPlanResult Pl ON Po.ResultId = Pl.ResultId ) Base
		Where ReverseTestOrder = 1
		--WHERE Po.ResultId = 20802
		) TEMP
	INNER JOIN TestPointResult ON TestPointResult.ResultId = TEMP.ResultId
		AND TestPointResult.MeasurementId = TEMP.MeasurementId

/*====================================================================================*/
   -- AdhocTestPointResult --
/*====================================================================================*/

	UPDATE AdhocTestPointResult
	SET TestOrder = TEMP.TestOrder
	FROM (
		SELECT Po.AdhocResultId,
			AdhocMeasurementId,
			Row_number() OVER (
				PARTITION BY OrganizationId,
				(
					CASE 
						WHEN Po.TestPointId = 0
							OR Po.TestPointId IS NULL
							THEN 'AHC_' + Po.TestPointName
						ELSE CAST(Po.TestPointId AS VARCHAR(20))
						END
					), -- TestPointId
				Po.AdhocResultId,
				TestMethodId ORDER BY AdhocMeasurementId
				) AS TestOrder
		FROM AdhocTestPointResult Po
		INNER JOIN AdhocTestPlanResult Pl ON Po.AdhocResultId = Pl.AdhocResultId
		) TEMP
	INNER JOIN AdhocTestPointResult ON AdhocTestPointResult.AdhocResultId = TEMP.AdhocResultId
		AND AdhocTestPointResult.AdhocMeasurementId = TEMP.AdhocMeasurementId

	-- Reset the Final Flag
	UPDATE AdhocTestPointResult
	SET IsFinal = 0
	
	-- Update the Final Flag
	UPDATE AdhocTestPointResult
	SET IsFinal = 1
	FROM (
		SELECT AdhocResultId,
			AdhocMeasurementId
		FROM (
			SELECT Po.AdhocResultId,
				AdhocMeasurementId,
				Row_number() OVER (
					PARTITION BY OrganizationId,
					(
						CASE 
							WHEN Po.TestPointId = 0
								OR Po.TestPointId IS NULL
								THEN 'AHC_' + Po.TestPointName
							ELSE CAST(Po.TestPointId AS VARCHAR(20))
							END
						), -- TestPointId
					Po.AdhocResultId,
					TestMethodId ORDER BY AdhocMeasurementId DESC
					) AS ReverseTestOrder
			FROM AdhocTestPointResult Po
			INNER JOIN AdhocTestPlanResult Pl ON Po.AdhocResultId = Pl.AdhocResultId
			) Base
		WHERE ReverseTestOrder = 1
		) TEMP
	INNER JOIN AdhocTestPointResult ON AdhocTestPointResult.AdhocResultId = TEMP.AdhocResultId
		AND AdhocTestPointResult.AdhocMeasurementId = TEMP.AdhocMeasurementId

Go

--Select ResultId, MeasurementId, TestPointId, TestMethodId, IsFinal, TestOrder from TestPointResult
--Where ResultId =  20801