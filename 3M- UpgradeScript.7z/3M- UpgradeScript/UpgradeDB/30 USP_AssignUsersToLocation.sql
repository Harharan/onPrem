USE [Spark]
GO

/****** Object:  StoredProcedure [dbo].[USP_UpdateAssocitedTestPointsWithTestPlan]    Script Date: 04-09-2020 16:02:45 ******/
IF OBJECT_ID ( '[dbo].[USP_AssignUsersToLocation]', 'P' ) IS NOT NULL   
    DROP PROCEDURE [dbo].[USP_AssignUsersToLocation]
GO
/****** Object:  StoredProcedure [dbo].[GetTestPointsMappedListToSamplePlan]    Script Date: 03-09-2020 18:45:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

Create Procedure USP_AssignUsersToLocation
As
Begin
CREATE TABLE #UserList
(
id int Identity(1,1),
userId int
)

INSERT INTO #UserList
SELECT UserId FROM UserMaster WHERE Status != 4 --INSERT ONLY ACTIVE USERS
--AND ((SELECT COUNT(1) FROM EntityLocationMapping) = 0)

CREATE TABLE #LocationList
(
LocationId int
)

INSERT INTO #LocationList
SELECT LocationId FROM LocationMaster WHERE ParentLocationId=0 --INSERT ONLY LEVEL ONE LOCATIONS

DECLARE @MIN INT, @MAX INT
SELECT @MIN=MIN(id), @MAX = MAX(id) FROM #UserList
WHILE(@MIN <= @MAX)
	BEGIN
		DECLARE @UserId int
		SELECT @UserId = userId from #UserList where id=@MIN
		Insert Into EntityLocationMapping (OrganizationId,EntityType,EntityID,LocationId)
		SELECT 1,1,@UserId,LocationId FROM #LocationList
		WHERE LocationId NOT IN (SELECT LocationId FROM EntityLocationMapping WHERE OrganizationId=1 AND EntityType=1 AND EntityID=@UserId)
		SET @MIN = @MIN + 1;
	END

DROP TABLE #UserList
DROP TABLE #LocationList
End