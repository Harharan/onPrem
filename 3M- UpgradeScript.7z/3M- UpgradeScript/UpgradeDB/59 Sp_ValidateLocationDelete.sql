USE [Spark]
GO

/****** Object:  StoredProcedure [dbo].[usp_CheckTestPtAssWithLevelAndAllocateParentLocIdToDeletedLevelLoc]    Script Date: 01.19.2022 03:25:43 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO







-- =============================================
-- Create date: 12/01/2022
-- Description:	Check if any location level is assign to test point and Allocate ParentLocationId To Deleted Level Locations
-- =============================================

 CREATE PROCEDURE [dbo].[usp_CheckTestPtAssWithLevelAndAllocateParentLocIdToDeletedLevelLoc]
(
@LevelId int = 0,
@UserId int = 0,
@ReturnValue int output
)

AS
BEGIN
SET NOCOUNT ON
--Code need to add for locations whose with deleted level

IF EXISTS( SELECT 1 FROM 
	LocationMaster lm 
	JOIN TestPointMaster tpm ON 
	lm.LocationId = tpm.LocationId WHERE lm.Level = @LevelId AND lm.Status = 1 AND tpm.Status = 1 )
	BEGIN
		--print 'Test Point present'
		set @ReturnValue = 1
		return @ReturnValue  --If test point attached to level facility
	END
else
BEGIN
	--print 'Test Point not present'
UPDATE LocationMaster
SET Status = 2,
LastEditedBy = @UserId,
LastEditDate = GETDATE()
where Level = @LevelId
and Status = 1

UPDATE LM_Update
set LM_Update.ParentLocationId = LM_Delete.ParentLocationId
,LM_Update.LastEditDate = GETDATE()
,LM_Update.LastEditedBy = @UserId
,LM_Update.Level = @LevelId
from LocationMaster LM_Update
JOIN LocationMaster LM_Delete
on LM_Update.ParentLocationId = LM_Delete.LocationId
where LM_Update.ParentLocationId = LM_Delete.LocationId
and LM_Delete.Level = @LevelId
and LM_Update.Status = 1

delete from LocationLevelMaster where LevelId = @LevelId

update LocationLevelMaster set LevelId = LevelId - 1 where LevelId > @LevelId

set @ReturnValue = 2
return @ReturnValue

END	
END
		
GO


