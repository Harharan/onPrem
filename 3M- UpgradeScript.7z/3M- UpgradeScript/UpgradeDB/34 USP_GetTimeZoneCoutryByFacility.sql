USE [Spark]
GO

/****** Object:  StoredProcedure [dbo].[USP_GetTimeZoneCoutryByFacility]    Script Date: 27-11-2020 14:38:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[USP_GetTimeZoneCoutryByFacility]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[USP_GetTimeZoneCoutryByFacility]
GO


CREATE procedure [dbo].[USP_GetTimeZoneCoutryByFacility]
--Declare
@OrganizationId INT,
@FacilityId Int

--Set @facilityId=3
--Set @OrganizationId=1
as
Begin
--select dbo.[GetParentLoctaionHierarchyIds](@facilityId,@OrganizationId)
Select distinct Tm.DisplayTimezone,Cm.CountryName,Sm.[Name],Citym.[Name] as cityName From LocationMaster Lm
Join CountryMaster Cm on Lm.CountryId=Cm.CountryId
Join TimezoneMaster Tm on Lm.Timezone=Tm.Timezone
Left Join States_Master Sm on Sm.StateId = Lm.StateId
Left Join Cities_Master Citym on Citym.CityID = Lm.CityId
Where LocationId in (select dbo.[GetParentLoctaionHierarchyIds](@facilityId,@OrganizationId)) and ParentLocationId=0
End
GO


