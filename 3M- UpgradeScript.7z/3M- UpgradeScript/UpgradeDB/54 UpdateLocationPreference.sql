/*21A: Update location prefrence with organization preference of older version build during upgrade*/
Use [SPARK]

Declare @dataCount int
Select @dataCount = COUNT(*) From LocationPreference
IF (@dataCount = 0)
Insert Into LocationPreference (
OrganizationId,
LocationId,
[DateFormat],
NumberFormat,
TemperatureUnit,
IsMilitaryTime,
SessionTimeout,
RequirePasswordForDevice,
MobileDataStoragePeriod
)
Select 
[LM].[OrganizationId], 
[LM].[LocationId],
[OC].[DateFormat],
[OC].[NumberFormat],
[OC].[TemperatureUnit],
[OC].[IsMilitaryTime],
[OC].[SessionTimeout],
[OC].[RequirePasswordForDevice],
[OC].[MobileDataStoragePeriod]   
From 
LocationMaster LM inner join OrganizationConfiguration OC
ON
[LM].[OrganizationId] = [OC].[OrganizationId] 
where 
[LM].[Level] = 1 and [LM].[ParentLocationId] = 0

Go