USE [Spark]
Go

/* -------- RoleFeatureGroup -------- */
INSERT [dbo].[RoleFeaturesGroup] ([FeatureGroupId], [FeatureGroupName], [Order]) VALUES (1, N'Testing_and_cleaning', 1)
INSERT [dbo].[RoleFeaturesGroup] ([FeatureGroupId], [FeatureGroupName], [Order]) VALUES (2, N'Operations', 2 )
INSERT [dbo].[RoleFeaturesGroup] ([FeatureGroupId], [FeatureGroupName], [Order]) VALUES (3, N'Managing_assets', 3)

/* -------- RoleFeatures ----------- */
INSERT [dbo].[RoleFeatureMaster] ([FeatureId], [FeatureName], [FeatureGroupId], [Order]) VALUES (1, N'Test_points', 1, 1)
INSERT [dbo].[RoleFeatureMaster] ([FeatureId], [FeatureName], [FeatureGroupId], [Order]) VALUES (2, N'Sample_plans', 1, 2)
INSERT [dbo].[RoleFeatureMaster] ([FeatureId], [FeatureName], [FeatureGroupId], [Order]) VALUES (3, N'Test_types', 1, 3)
INSERT [dbo].[RoleFeatureMaster] ([FeatureId], [FeatureName], [FeatureGroupId], [Order]) VALUES (4, N'Comments', 1, 4)
INSERT [dbo].[RoleFeatureMaster] ([FeatureId], [FeatureName], [FeatureGroupId], [Order]) VALUES (5, N'Cleaning_chemicals', 1, 5)
INSERT [dbo].[RoleFeatureMaster] ([FeatureId], [FeatureName], [FeatureGroupId], [Order]) VALUES (6, N'Reports', 2, 1)
INSERT [dbo].[RoleFeatureMaster] ([FeatureId], [FeatureName], [FeatureGroupId], [Order]) VALUES (7, N'Results', 2, 2)
INSERT [dbo].[RoleFeatureMaster] ([FeatureId], [FeatureName], [FeatureGroupId], [Order]) VALUES (8, N'Dataimport_export_and_archival', 2, 3)
INSERT [dbo].[RoleFeatureMaster] ([FeatureId], [FeatureName], [FeatureGroupId], [Order]) VALUES (9, N'Activity_log', 2, 4)
INSERT [dbo].[RoleFeatureMaster] ([FeatureId], [FeatureName], [FeatureGroupId], [Order]) VALUES (10, N'LM1_luminometer_reset', 2, 5)
INSERT [dbo].[RoleFeatureMaster] ([FeatureId], [FeatureName], [FeatureGroupId], [Order]) VALUES (11, N'Organization_preferences', 3, 1)
INSERT [dbo].[RoleFeatureMaster] ([FeatureId], [FeatureName], [FeatureGroupId], [Order]) VALUES (12, N'Locations_and_facilities', 3, 2)
INSERT [dbo].[RoleFeatureMaster] ([FeatureId], [FeatureName], [FeatureGroupId], [Order]) VALUES (13, N'Users_and_roles', 3, 3)
INSERT [dbo].[RoleFeatureMaster] ([FeatureId], [FeatureName], [FeatureGroupId], [Order]) VALUES (14, N'Luminometers', 3, 4)


/*------------ PermissionMaster  ---------------*/
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (1, 1, 1, 1, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (2, 1, 1, 2, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (3, 1, 1, 3, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (4, 1, 1, 4, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (5, 1, 1, 5, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (6, 1, 1, 6, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (7, 1, 1, 7, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (8, 1, 1, 8, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (9, 1, 1, 9, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (10, 1, 1, 10, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (11, 1, 1, 11, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (12, 1, 1, 12, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (13, 1, 1, 13, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (14, 1, 1, 14, 1)

INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (15, 1, 2, 1, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (16, 1, 2, 2, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (17, 1, 2, 3, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (18, 1, 2, 4, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (19, 1, 2, 5, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (20, 1, 2, 6, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (21, 1, 2, 7, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (22, 1, 2, 8, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (23, 1, 2, 9, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (24, 1, 2, 10, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (25, 1, 2, 11, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (26, 1, 2, 12, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (27, 1, 2, 13, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (28, 1, 2, 14, 1)

INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (29, 1, 3, 1, 3)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (30, 1, 3, 2, 3)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (31, 1, 3, 3, 3)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (32, 1, 3, 4, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (33, 1, 3, 5, 3)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (34, 1, 3, 6, 3)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (35, 1, 3, 7, 3)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (36, 1, 3, 8, 0)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (37, 1, 3, 9, 0)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (38, 1, 3, 10, 3)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (39, 1, 3, 11, 0)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (40, 1, 3, 12, 0)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (41, 1, 3, 13, 0)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (42, 1, 3, 14, 0)

INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (43, 1, 4, 1, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (44, 1, 4, 2, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (45, 1, 4, 3, 3)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (46, 1, 4, 4, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (47, 1, 4, 5, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (48, 1, 4, 6, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (49, 1, 4, 7, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (50, 1, 4, 8, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (51, 1, 4, 9, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (52, 1, 4, 10, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (53, 1, 4, 11, 3)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (54, 1, 4, 12, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (55, 1, 4, 13, 1)
INSERT [dbo].[PermissionMaster] ([Id], [OrganizationId], [RoleId], [FeatureId], [Permission]) VALUES (56, 1, 4, 14, 1)


USE [Spark]
Go


/*21A-Updating Role feature permissions as per previous features permission for applicationversion below 21A*/

IF (EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES
 WHERE TABLE_NAME = N'PermissionMaster') AND EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'PermissionMaster'))
BEGIN
Declare @PackageVersion nvarchar(20) = (select top 1 PackageVersion from ApplicationInformation where IsUninstall= 1 order by id desc)
/* Get index of second dot(.) in packageversion. */
declare @IndexOfSecondDot int =  charindex( '.', @PackageVersion, charindex( '.', @PackageVersion ) + 1 )
declare @Version nvarchar(10)= SUBSTRING(@PackageVersion, 0, @IndexOfSecondDot)
set @Version = REPLACE(@Version,'.','')

if(@Version<16)
	Begin	   
		/*supervisor*/
		 /* updating permission for Testpoint and Sampleplan*/
		Update [PermissionMaster] set permission =(select top 1 permission from RolePermissions where RoleId=4 AND FeatureGroupKey=2) where RoleId=4 and FeatureId in (1,2);
		/* updating permission for Comment, cleaning chemicals, Testypes and Location& facilities*/
		Update [PermissionMaster] set permission =(select top 1 permission from RolePermissions where RoleId=4 AND FeatureGroupKey=3) where RoleId=4 and FeatureId in (3,4,5,12);	
		Update [PermissionMaster] set permission =(select top 1 permission from RolePermissions where RoleId=4 AND FeatureGroupKey=6) where RoleId=4 and FeatureId=6;	
		Update [PermissionMaster] set permission =(select top 1 permission from RolePermissions where RoleId=4 AND FeatureGroupKey=5) where RoleId=4 and FeatureId=7;
		Update [PermissionMaster] set permission =(select top 1 permission from RolePermissions where RoleId=4 AND FeatureGroupKey=8) where RoleId=4 and FeatureId=8;
		Update [PermissionMaster] set permission =(select top 1 permission from RolePermissions where RoleId=4 AND FeatureGroupKey=9) where RoleId=4 and FeatureId=9;	
		Update [PermissionMaster] set permission =(select top 1 permission from RolePermissions where RoleId=4 AND FeatureGroupKey=10) where RoleId=4 and FeatureId=11;
		Update [PermissionMaster] set permission =(select top 1 permission from RolePermissions where RoleId=4 AND FeatureGroupKey=1) where RoleId=4 and FeatureId=13;
		Update [PermissionMaster] set permission =(select top 1 permission from RolePermissions where RoleId=4 AND FeatureGroupKey=4) where RoleId=4 and FeatureId=14;

		/*technician*/
		Update [PermissionMaster] set permission =(select top 1 permission from RolePermissions where RoleId=3 AND FeatureGroupKey=2) where RoleId=3 and FeatureId in(1,2);
		Update [PermissionMaster] set permission =(select top 1 permission from RolePermissions where RoleId=3 AND FeatureGroupKey=3) where RoleId=3 and FeatureId in (3,4,5,12);	
		Update [PermissionMaster] set permission =(select top 1 permission from RolePermissions where RoleId=3 AND FeatureGroupKey=6) where RoleId=3 and FeatureId=6;	
		Update [PermissionMaster] set permission =(select top 1 permission from RolePermissions where RoleId=3 AND FeatureGroupKey=5) where RoleId=3 and FeatureId=7;
		Update [PermissionMaster] set permission =(select top 1 permission from RolePermissions where RoleId=3 AND FeatureGroupKey=8) where RoleId=3 and FeatureId=8;
		Update [PermissionMaster] set permission =(select top 1 permission from RolePermissions where RoleId=3 AND FeatureGroupKey=9) where RoleId=3 and FeatureId=9;	
		Update [PermissionMaster] set permission =(select top 1 permission from RolePermissions where RoleId=3 AND FeatureGroupKey=10) where RoleId=3 and FeatureId=11;
		Update [PermissionMaster] set permission =(select top 1 permission from RolePermissions where RoleId=3 AND FeatureGroupKey=1) where RoleId=3 and FeatureId=13;
		Update [PermissionMaster] set permission =(select top 1 permission from RolePermissions where RoleId=3 AND FeatureGroupKey=4) where RoleId=3 and FeatureId=14;

	End
END
GO

