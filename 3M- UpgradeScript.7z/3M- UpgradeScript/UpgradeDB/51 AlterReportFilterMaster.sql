Use [Spark]
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE object_id = OBJECT_ID(N'[dbo].[ReportFilterMaster]')
AND name = 'DateOptionSelected'
)
BEGIN
ALTER TABLE [Spark].[dbo].ReportFilterMaster Add DateOptionSelected int;
END

Use [Spark]
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE object_id = OBJECT_ID(N'[dbo].[UserDashboardFilters]')
AND name = 'IsSelectNone'
)
BEGIN
ALTER TABLE UserDashboardFilters ADD IsSelectNone bit
END