USE [Spark]

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetSamplePlanLocations]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GetSamplePlanLocations]
GO
/****** Object:  StoredProcedure [dbo].[GetSamplePlanLocations]    Script Date: 04/14/2021 5:29:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[GetSamplePlanLocations]
(
	@OrganizationId INT,
	@samplePlanId INT
)
AS 
BEGIN
	SET NOCOUNT ON;

	Declare @LocationIds varchar(MAX)
	select @LocationIds = COALESCE(@LocationIds + ',', '') + CAST(LocationId AS VARCHAR(5))
	from LocationMaster where LocationId in
			(select distinct  location.LocationId 
			 from [Spark].[dbo].[TestPlanTestPointMapping] testplan 
			 inner join [Spark].[dbo].[TestPointMaster] testpoint on testplan.TestPointId=testpoint.TestPointId 
			 inner join [Spark].[dbo].[LocationMaster] location on location.LocationId=testpoint.LocationId 
			 where testplan.TestPlanId=@samplePlanId)

	select * from locationmaster where locationid in
			(select FinalPlanId 
			 from GetLevelOneLocationIds(CONVERT(varchar(max), @LocationIds),@OrganizationId) as PlantId)

END
GO
