USE [Spark]
GO

/****** Object:  StoredProcedure [dbo].[usp_CheckTestptAndSamplePlanAssociatedWithLocAndDeleteIt]    Script Date: 01.27.2022 06:25:28 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Create date: 18/01/2022
-- Description:	Check if Testpoint and sample plan associated with Location and delete it
-- =============================================



CREATE Procedure [dbo].[usp_CheckTestptAndSamplePlanAssociatedWithLocAndDeleteIt]
(
--Declare
@OrganizationId INT,
@UserId INT,
@TestPointIdList [TestPointIdList_Type] READONLY,
@TestPlanIdList [TestPlanIdList_Type] READONLY,
@LocationIdList [LocationIdList_Type] READONLY   
)
AS
BEGIN
		--check for testpoint
		IF EXISTS( select 1 from @TestPointIdList)
		BEGIN
		 print 'TestPointIdList'
			update TestPointMaster set Status = 3,LastEditDate = GETDATE(),LastEditedBy = @UserId where Status <> 3 AND
					LocationId IN ( select LocationId from @TestPointIdList)

		END

		--Check for the SamplePlan --
		IF EXISTS(select 1 from @TestPlanIdList )
		BEGIN
		print 'TestPlanIdList'
			update TestPlanMaster set Status = 3,LastEditDate = GETDATE(),LastEditedBy = @UserId where Status <> 3 AND
					TestPlanId IN ( select TestPlanId from @TestPlanIdList )
		END


		--Delete the facility location
		IF EXISTS(select 1 from @LocationIdList )
		BEGIN
		print 'LocationIdList'
			update LocationMaster set Status = 3,LastEditDate = GETDATE(),LastEditedBy = @UserId where Status <> 3 AND
			LocationId IN (select LocationId from @LocationIdList where OrganizationId = @OrganizationId)
		END

END
GO


