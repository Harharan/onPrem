Use Spark
Go
DECLARE @MtsID nvarchar(100)
SET @MtsID = (SELECT UserId  FROM UserMaster WHERE FirstName = '3MTS')
IF NOT EXISTS (SELECT * FROM UserPreferences WHERE UserId = @MtsID )
INSERT [dbo].[UserPreferences]( [UserId],[PreferredLocale],[SecretQuestion],[SecretAnswer],[CreatedDate],[CreatedBy],[LastEditDate],[LastEditedBy]) VALUES ( @MtsID, 'en-us', NULL, NULL, GETDATE(), 1, NULL, NULL);


