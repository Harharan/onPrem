USE [Spark]
GO

/****** Object:  StoredProcedure [dbo].[Usp_CheckTestPointExistForLocation]    Script Date: 28-07-2020 15:05:35 ******/
IF OBJECT_ID ( '[dbo].[Usp_CheckTestPointExistForLocation]', 'P' ) IS NOT NULL   
    DROP PROCEDURE [dbo].[Usp_CheckTestPointExistForLocation]
GO

CREATE Procedure [dbo].[Usp_CheckTestPointExistForLocation]
--Declare
@organizationId Int,
@testPointGroupId Int,
@testPointId Int,
@testPointName Varchar(100),
@locations Varchar(Max),
@isToApplyChangesToAll Int

--Set @organizationId=1
--Set @testPointGroupId=11
--Set @testPointId=12
--Set @testPointName='TP2'
--Set @locations='9'
--Set @isToApplyChangesToAll=0
As
Begin
Declare @LocationId int,@TPName Varchar(100),@SPName Varchar(100),@TestPlanId Int
Select @LocationId=LocationId,@TPName=TestPointName From TestPointMaster Where TestPointId=@testPointId
Create Table #Existslocation(LocationName Varchar(100), LocationId Int)
Create Table #NewAddedlocation(LocationID int)
Insert Into #NewAddedlocation
SELECT * FROM dbo.BreakStringIntoRows(@locations)

Delete From #NewAddedlocation Where LocationID In (Select LocationID From TestPointMaster Where TestPointGroupId=@testPointGroupId and Status<>3)

Select @SPName=pm.TestPlanName,@TestPlanId=Tpp.TestPlanId 
From TestPlanTestPointMapping Tpp Inner Join TestPlanMaster pm On pm.TestPlanId=Tpp.TestPlanId
Where TestPointId=@testPointId

--Check Location and TP in ID
If(@TPName=@testPointName)
	Begin
		Print('Test Update with ID')
		--Insert Into #Existslocation
	End
Else
	Begin
		Print('Test Update Name')
		If(@isToApplyChangesToAll=0)
		Begin
			Insert Into #Existslocation(LocationName,LocationId)
			Select LM.LocationName, LM.LocationId From TestPointMaster  Tp
			Inner Join LocationMaster LM On LM.LocationId=Tp.LocationId		
			Inner Join TestPlanTestPointMapping Tpp On Tpp.TestPointId=Tp.TestPointId
			Where TestPointName=@testPointName 
			And Tp.LocationId in (Select LocationId From TestPointMaster Where TestPointId=@testPointId)
			And Tp.TestPointId<>@testPointId and Tp.Status<>3
		End
		Else
		Begin
			-- Check Sample Plan Mapp TP
			Insert Into #Existslocation(LocationName,LocationId)
			Select LM.LocationName, LM.LocationId From TestPointMaster  Tp
			Inner Join LocationMaster LM On LM.LocationId=Tp.LocationId		
			Inner Join TestPlanTestPointMapping Tpp On Tpp.TestPointId=Tp.TestPointId
			Where TestPointName=@testPointName And Tp.LocationId in (Select LocationId From TestPointMaster Where TestPointGroupId=@testPointGroupId and Status<>3)
			And Tp.TestPointGroupId<>@testPointGroupId and Tp.Status<>3

			-- Check Sample Plan Not Mapp TP
			Insert Into #Existslocation(LocationName,LocationId)
			Select LM.LocationName, LM.LocationId From TestPointMaster  Tp
			Inner Join LocationMaster LM On LM.LocationId=Tp.LocationId		
			Left Join TestPlanTestPointMapping Tpp On Tpp.TestPointId=Tp.TestPointId
			Where TestPointName=@testPointName And Tpp.TestPlanId IS Null
			And Tp.TestPointGroupId<>@testPointGroupId  And Tp.LocationId in (Select LocationId From TestPointMaster Where TestPointGroupId=@testPointGroupId and Status<>3)
			And Tp.Status<>3
		End
	End
	--Select * From #NewAddedlocation
-- Check New added locations
If(Exists(Select * From #NewAddedlocation))
Begin
	Insert Into #Existslocation(LocationName,LocationId)
	Select LM.LocationName, LM.LocationId From TestPointMaster  Tp
	Inner Join LocationMaster LM On LM.LocationId=Tp.LocationId	
	Left Join TestPlanTestPointMapping TPM on TPM.TestPointId=TP.TestPointId
	Where TestPointName=@testPointName And TPM.TestPlanId IS Null
	And Tp.LocationId in (Select LocationId From #NewAddedlocation) and Tp.Status<>3
End
Select Distinct LocationName, LocationId From #Existslocation
Drop Table #NewAddedlocation
Drop Table #Existslocation
End

GO


