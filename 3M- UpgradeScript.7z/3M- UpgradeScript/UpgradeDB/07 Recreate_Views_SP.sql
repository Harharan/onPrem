USE [Spark]
GO
/****** Object:  View [dbo].[DashBoardView]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[DashBoardView]'))
DROP VIEW [dbo].[DashBoardView]
GO
/****** Object:  UserDefinedFunction [dbo].[GetParentLocationName]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetParentLocationName]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[GetParentLocationName]
GO
/****** Object:  UserDefinedFunction [dbo].[GetLoctaionHierarchyIds]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetLoctaionHierarchyIds]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[GetLoctaionHierarchyIds]
GO
/****** Object:  UserDefinedFunction [dbo].[fnSplitter]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fnSplitter]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[fnSplitter]
GO
/****** Object:  UserDefinedFunction [dbo].[fn_Split]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fn_Split]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[fn_Split]
GO
/****** Object:  StoredProcedure [dbo].[UpdateTestOrderIsFinalInTestPointResult]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateTestOrderIsFinalInTestPointResult]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[UpdateTestOrderIsFinalInTestPointResult]
GO
/****** Object:  StoredProcedure [dbo].[UpdateTestOrderIsFinalInAdhocTestPointResult]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateTestOrderIsFinalInAdhocTestPointResult]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[UpdateTestOrderIsFinalInAdhocTestPointResult]
GO
/****** Object:  StoredProcedure [dbo].[UpdateAllTestOrderIsFinal]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateAllTestOrderIsFinal]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[UpdateAllTestOrderIsFinal]
GO
/****** Object:  StoredProcedure [dbo].[TestpointTrend]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestpointTrend]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[TestpointTrend]
GO
/****** Object:  StoredProcedure [dbo].[TestpointSummary]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestpointSummary]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[TestpointSummary]
GO
/****** Object:  StoredProcedure [dbo].[TestPlanSummary]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanSummary]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[TestPlanSummary]
GO
/****** Object:  StoredProcedure [dbo].[ReviewResult]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReviewResult]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ReviewResult]
GO
/****** Object:  StoredProcedure [dbo].[RankingResult]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RankingResult]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[RankingResult]
GO
/****** Object:  StoredProcedure [dbo].[GetTestPointsMappedListToSamplePlan]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetTestPointsMappedListToSamplePlan]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GetTestPointsMappedListToSamplePlan]
GO
/****** Object:  StoredProcedure [dbo].[GetTestPointDetails]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetTestPointDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GetTestPointDetails]
GO
/****** Object:  StoredProcedure [dbo].[GetSamplePlan]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetSamplePlan]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GetSamplePlan]
GO
/****** Object:  StoredProcedure [dbo].[GetReportDataSet]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetReportDataSet]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GetReportDataSet]
GO
/****** Object:  StoredProcedure [dbo].[GetReportDashboardData]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetReportDashboardData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GetReportDashboardData]
GO
/****** Object:  StoredProcedure [dbo].[GetLocationName]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetLocationName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GetLocationName]
GO
/****** Object:  StoredProcedure [dbo].[GetDashboardData]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetDashboardData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GetDashboardData]
GO
/****** Object:  StoredProcedure [dbo].[GetCustomDashboardData]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetCustomDashboardData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GetCustomDashboardData]
GO
/****** Object:  StoredProcedure [dbo].[FilterReport]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FilterReport]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[FilterReport]
GO
/****** Object:  StoredProcedure [dbo].[AuditLogEntry]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AuditLogEntry]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[AuditLogEntry]
GO
/****** Object:  StoredProcedure [dbo].[ArchiveData]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ArchiveData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ArchiveData]
GO
/****** Object:  StoredProcedure [dbo].[AddOrganizationData]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddOrganizationData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[AddOrganizationData]
GO
/****** Object:  StoredProcedure [dbo].[AddApplicationInformation]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddApplicationInformation]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[AddApplicationInformation]
GO
/****** Object:  UserDefinedTableType [dbo].[AuditDetails]    Script Date: 6/19/2018 11:17:52 AM ******/
IF  EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'AuditDetails' AND ss.name = N'dbo')
DROP TYPE [dbo].[AuditDetails]
GO
/****** Object:  UserDefinedTableType [dbo].[AuditDetails]    Script Date: 6/19/2018 11:17:52 AM ******/
IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'AuditDetails' AND ss.name = N'dbo')
CREATE TYPE [dbo].[AuditDetails] AS TABLE(
	[TableName] [nvarchar](200) NULL,
	[FieldName] [nvarchar](200) NULL,
	[OperationType] [nvarchar](10) NULL,
	[OldValue] [nvarchar](max) NULL,
	[NewValue] [nvarchar](max) NULL,
	[Display] [bit] NULL,
	[PrimaryField] [nvarchar](max) NULL
)
GO
/****** Object:  StoredProcedure [dbo].[AddApplicationInformation]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddApplicationInformation]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

CREATE Procedure [dbo].[AddApplicationInformation]
@ApplicationUrl nvarchar(400),
@HostName nvarchar(200),
@IpAddress nvarchar(400),
@CommonServicePort smallint,
@WebServicePort smallint,
@DeviceServicePort smallint,
@DBServerName nvarchar(200),
@PackageVersion nvarchar(100)

AS

BEGIN

INSERT [dbo].[ApplicationInformation] ([ApplicationUrl], [HostName], [IpAddress], [CommonServicePort],
[WebServicePort], [DeviceServicePort], [InstallationDate], [DBServerName], [PackageVersion],[IsUninstall]) 
VALUES (@ApplicationUrl, @HostName, @IpAddress, @CommonServicePort, @WebServicePort, @DeviceServicePort, GETDATE(), @DBServerName, @PackageVersion, 0)

END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[AddOrganizationData]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddOrganizationData]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

CREATE Procedure [dbo].[AddOrganizationData]
@OrganizationName nvarchar(100),
@DomainName nvarchar(60),
@OrganizationLocale nvarchar(20),
@FirstName nvarchar(50),
@LastName nvarchar(50),
@LoginName nvarchar(50),
@Email nvarchar(50),
@LoginPass nvarchar(100)

AS

DECLARE @OrganizationId INT
DECLARE @UserId INT


BEGIN

INSERT [dbo].[OrganizationMaster] ([OrganizationTypeId], [ApplicationId], [OrganizationName], [DomainName],
[IsLicensed], [Status], [LicenseID], [ValidTill], [HierarchyLevel], 
[PrimaryContact], [SecondaryContact], [ConfigurationComplete], [CurrentStep], [CreatedDate], [CreatedBy], 
[LastEditDate], [LastEditedBy], [OrganizationKey], [OrganizationLocale]) 
VALUES (1, 4, @OrganizationName, @DomainName, 1, 1, 1, ''31-DEC-9999'', 1, 1, 1, 0, 0, GetUTCDate(), 1, NULL, NULL,N''v0P5rxC0NVt1onFJWYNQA7jRHM+BG5I41kQOhLhoRJc='', @OrganizationLocale)

SELECT @OrganizationId = MAX(OrganizationId) FROM OrganizationMaster;

--Create Default User For the organization
INSERT [dbo].[UserMaster] ([Title], [FirstName], [LastName], [Email], [Status], [DefaultOrganization], [CreatedDate], [CreatedBy],[PreferencesSet], [ResetPassword], [LoginName], [Password], [LastLoginDateTime], [PhoneNo], [ContractOrganization], [Notes], [LastEditDate], [LastEditedBy],[IsUserNotifiedForPasswordExpiry], [CurrentRole], [IsLoginRequired]) 
					VALUES (N''Mr'', N''Default'', N''User'', NULL, 1, @OrganizationId, GETDATE(), 1,0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,0, 2, 1)

INSERT [dbo].[UserMaster] ([Title], [FirstName], [LastName], [Email], [Status], [DefaultOrganization], [CreatedDate], [CreatedBy],[PreferencesSet], [ResetPassword], [LoginName], [Password], [LastLoginDateTime], [PhoneNo], [ContractOrganization], [Notes], [LastEditDate], [LastEditedBy],[IsUserNotifiedForPasswordExpiry], [CurrentRole], [IsLoginRequired]) 
					VALUES (N''Mr'', N''3MTS'', N''User'', ''3mts@mmm.com'', 1, @OrganizationId, GETDATE(), 1,0, 1, N''3mts@mmm.com'', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1)
					
SELECT @UserId = MAX(UserId) FROM UserMaster

--Create User For the organization
INSERT [dbo].[UserMaster] ([FirstName], [LastName], [Email], [Status], [DefaultOrganization], [CreatedDate], [CreatedBy], [PreferencesSet], [ResetPassword], [LoginName], [Password], [LastLoginDateTime], [PhoneNo], [ContractOrganization], [Notes], [LastEditDate], [LastEditedBy], [IsUserNotifiedForPasswordExpiry], [CurrentRole], [IsLoginRequired]) 
					VALUES (@FirstName, @LastName, @Email, 1, @OrganizationId, GetUTCDate(), 1, 0, 1, @LoginName, @LoginPass, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, 1)

UPDATE OrganizationMaster
SET PrimaryContact = @UserId + 1,
SecondaryContact = @UserId + 1,
CreatedBy = @UserId + 1,
LastEditedBy = @UserId + 1
WHERE OrganizationId = @OrganizationId

INSERT [dbo].[OrganizationRoleMaster] ([OrganizationId], [RoleId], [RoleName], [RoleLevel], [CreatedDate], [CreatedBy], [LastEditDate], [LastEditedBy]) 
SELECT @OrganizationId, ROW_NUMBER() over (order by RoleLevel) as RoleId, RoleName, RoleLevel, GETUTCDATE(), @UserId - 1, NULL, NULL
FROM RoleMaster where RoleLevel in (1,3,6,7) 

/****** Assign 3M 3MTS Role to 3MTS User ******/
INSERT INTO [dbo].[OrganizationRoleUserMapping]	([OrganizationRoleMaster_OrganizationId] ,[OrganizationRoleMaster_RoleId] ,[OrganizationRoleUserMapping_OrganizationRoleMaster_UserId]) 
SELECT top 1 
@OrganizationId as OrganizationRoleMaster_OrganizationId
, RoleId as OrganizationRoleMaster_RoleId
, @UserId as OrganizationRoleUserMapping_OrganizationRoleMaster_UserId
FROM OrganizationRoleMaster
WHERE OrganizationId = @OrganizationId AND RoleLevel = 1

/****** Assign 3M Admin Role to User ******/
INSERT INTO [dbo].[OrganizationRoleUserMapping]	([OrganizationRoleMaster_OrganizationId] ,[OrganizationRoleMaster_RoleId] ,[OrganizationRoleUserMapping_OrganizationRoleMaster_UserId]) 
SELECT top 1 
@OrganizationId as OrganizationRoleMaster_OrganizationId
, RoleId as OrganizationRoleMaster_RoleId
, @UserId + 1 as OrganizationRoleUserMapping_OrganizationRoleMaster_UserId
FROM OrganizationRoleMaster
WHERE OrganizationId = @OrganizationId AND RoleLevel = 3

INSERT INTO [dbo].[LocationLevelMaster]([OrganizationId],[LevelId],[LevelName],[Order],[CreatedBy],[CreatedDate],[EditedBy],[EditedDate]) VALUES(@OrganizationId,1,N''Plant'',1,@UserId - 1,getdate(),@UserId - 1,getdate())
INSERT INTO [dbo].[LocationLevelMaster]([OrganizationId],[LevelId],[LevelName],[Order],[CreatedBy],[CreatedDate],[EditedBy],[EditedDate]) VALUES(@OrganizationId,2,N''Building'',1,@UserId - 1,getdate(),@UserId - 1,getdate())
INSERT INTO [dbo].[LocationLevelMaster]([OrganizationId],[LevelId],[LevelName],[Order],[CreatedBy],[CreatedDate],[EditedBy],[EditedDate]) VALUES(@OrganizationId,3,N''Department'',1,@UserId - 1,getdate(),@UserId - 1,getdate())
INSERT INTO [dbo].[LocationLevelMaster]([OrganizationId],[LevelId],[LevelName],[Order],[CreatedBy],[CreatedDate],[EditedBy],[EditedDate]) VALUES(@OrganizationId,4,N''Line'',1,@UserId - 1,getdate(),@UserId - 1,getdate())

INSERT INTO [dbo].[TestPlanMaster]([OrganizationId],[TestPlanId],[TestPlanVersion], [TestPlanTypeId],[TestPlanName],[LocationId],[Status],[IsCurrent],[CreatedDate],[CreatedBy],[LockedBy],[LastEditDate],[LastEditedBy],[IsImported],[ImportId],[RandomPointCount],[IsNoRepeat],[DBId],[IsRandomizationApplicable],[IsScheduleApplicable])
Values(@OrganizationId,1,1,1,N''Unplanned Test'',NULL,1,1,GetDate(),@UserId - 1,NULL,NULL,NULL,NULL,NULL,0,1,NULL,0,0)


--******************************* Common Tasks Scripts ***********************************--

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (1, 1, 1, 1, 8, 6, 1, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (2, 1, 1, 1, 15, 7, 1, 2, 0, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (3, 1, 1, 1, 13, 2, 1, 3, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (4, 1, 1, 1, 1, 2, 1, 4, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (5, 1, 1, 2, 7, 6, 1, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (6, 1, 1, 2, 9, 6, 1, 5, 1, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (7, 1, 1, 2, 22, 6, 1, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (8, 1, 1, 2, 23, 6, 1, 4, 1, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (9, 1, 1, 2, 17, 5, 1, 5, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (10, 1, 1, 3, 1, 2, 1, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (11, 1, 1, 3, 2, 2, 1, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (12, 1, 1, 3, 3, 1, 1, 3, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (13, 1, 1, 3, 15, 7, 1, 4, 0, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (14, 1, 1, 5, 24, 11, 1, 1, 1, 3)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (15, 1, 1, 5, 25, 11, 1, 2, 1, 3)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (16, 1, 1, 5, 26, 11, 1, 3, 1, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (17, 1, 1, 5, 6, 4, 1, 4, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (18, 1, 1, 5, 10, 8, 1, 5, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (19, 1, 1, 5, 11, 9, 1, 6, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (20, 1, 1, 5, 12, 10, 1, 7, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (21, 1, 1, 5, 21, 2, 1, 7, 0, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (22, 1, 1, 4, 18, 3, 1, 1, 0, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (23, 1, 1, 4, 19, 3, 1, 2, 0, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (24, 1, 1, 4, 20, 3, 1, 3, 0, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (25, 1, 2, 1, 8, 6, 1, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (26, 1, 2, 1, 15, 7, 1, 2, 0, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (27, 1, 2, 1, 13, 2, 1, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (28, 1, 2, 1, 1, 2, 1, 4, 0, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (29, 1, 2, 2, 7, 6, 1, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (30, 1, 2, 2, 9, 6, 1, 5, 1, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (31, 1, 2, 2, 22, 6, 1, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (32, 1, 2, 2, 23, 6, 1, 4, 1, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (33, 1, 2, 2, 17, 5, 1, 7, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (34, 1, 2, 3, 1, 2, 1, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (35, 1, 2, 3, 2, 2, 1, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (36, 1, 2, 3, 3, 1, 1, 3, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (37, 1, 2, 3, 15, 7, 1, 4, 0, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (38, 1, 2, 5, 24, 11, 1, 1, 1, 3)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (39, 1, 2, 5, 25, 11, 1, 2, 1, 3)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (40, 1, 2, 5, 26, 11, 1, 3, 1, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (41, 1, 2, 5, 6, 4, 1, 4, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (42, 1, 2, 5, 10, 8, 1, 5, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (43, 1, 2, 5, 11, 9, 1, 6, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (44, 1, 2, 5, 12, 10, 1, 7, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (45, 1, 2, 5, 21, 2, 1, 7, 0, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (46, 1, 2, 4, 18, 3, 1, 1, 0, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (47, 1, 2, 4, 19, 3, 1, 2, 0, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (48, 1, 2, 4, 20, 3, 1, 3, 0, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (49, 1, 4, 1, 8, 6, 1, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (50, 1, 4, 1, 3, 1, 3, 4, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (51, 1, 4, 1, 13, 2, 1, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (52, 1, 4, 1, 1, 2, 1, 4, 0, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (53, 1, 4, 2, 7, 6, 1, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (54, 1, 4, 2, 9, 6, 1, 5, 1, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (55, 1, 4, 2, 22, 6, 1, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (56, 1, 4, 2, 23, 6, 1, 4, 1, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (57, 1, 4, 2, 17, 5, 3, 7, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (58, 1, 4, 3, 1, 2, 1, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (59, 1, 4, 3, 2, 2, 1, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (60, 1, 4, 3, 3, 1, 3, 3, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (61, 1, 4, 3, 15, 7, 1, 4, 0, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (62, 1, 4, 5, 24, 11, 1, 1, 1, 3)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (63, 1, 4, 5, 25, 11, 1, 2, 1, 3)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (64, 1, 4, 5, 26, 11, 1, 3, 1, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (65, 1, 4, 5, 6, 4, 1, 4, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (66, 1, 4, 5, 10, 8, 0, 5, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (67, 1, 4, 5, 11, 9, 3, 6, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (68, 1, 4, 5, 12, 10, 3, 7, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (69, 1, 4, 5, 21, 2, 1, 7, 0, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (70, 1, 4, 4, 18, 3, 3, 1, 0, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (71, 1, 4, 4, 19, 3, 3, 2, 0, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (72, 1, 4, 4, 20, 3, 3, 3, 0, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (73, 1, 3, 1, 8, 6, 1, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (74, 1, 3, 1, 15, 7, 1, 2, 0, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (75, 1, 3, 1, 13, 2, 3, 3, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (76, 1, 3, 1, 1, 2, 3, 4, 0, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (77, 1, 3, 2, 7, 6, 1, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (78, 1, 3, 2, 9, 6, 1, 5, 1, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (79, 1, 3, 2, 22, 6, 1, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (80, 1, 3, 2, 23, 6, 1, 4, 1, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (81, 1, 3, 2, 17, 5, 3, 7, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (82, 1, 3, 3, 1, 2, 3, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (83, 1, 3, 3, 2, 2, 3, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (84, 1, 3, 3, 3, 1, 0, 3, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (85, 1, 3, 3, 15, 7, 1, 4, 0, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (86, 1, 3, 5, 24, 11, 1, 1, 1, 3)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (87, 1, 3, 5, 25, 11, 1, 2, 1, 3)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (88, 1, 3, 5, 26, 11, 1, 3, 1, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (89, 1, 3, 5, 6, 4, 3, 4, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (90, 1, 3, 5, 10, 8, 0, 5, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (91, 1, 3, 5, 11, 9, 0, 6, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (92, 1, 3, 5, 12, 10, 0, 7, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (93, 1, 3, 5, 21, 2, 3, 7, 0, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (94, 1, 3, 4, 18, 3, 0, 1, 0, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (95, 1, 3, 4, 19, 3, 0, 2, 0, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (96, 1, 3, 4, 20, 3, 0, 3, 0, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (99, 1, 4, 2, 27, 6, 1, 3, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (100, 1, 3, 2, 27, 6, 1, 3, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (101, 1, 1, 3, 28, 2, 1, 4, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (102, 1, 2, 3, 28, 2, 1, 4, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (103, 1, 3, 3, 28, 2, 3, 4, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (104, 1, 4, 3, 28, 2, 1, 4, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (105, 1, 2, 1, 2, 2, 1, 3, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (106, 1, 2, 1, 3, 1, 1, 4, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (107, 1, 2, 1, 5, 3, 1, 5, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (108, 1, 2, 1, 4, 5, 1, 6, 0, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (109, 1, 2, 6, 13, 2, 1, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (110, 1, 2, 6, 30, 2, 1, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (111, 1, 2, 6, 31, 2, 1, 4, 1, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (112, 1, 2, 6, 28, 2, 1, 6, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (113, 1, 2, 6, 32, 2, 1, 3, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (114, 1, 2, 7, 33, 2, 1, 3, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (115, 1, 2, 7, 28, 2, 1, 4, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (116, 1, 2, 8, 28, 2, 1, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (117, 1, 2, 9, 34, 2, 1, 1, 1, 3)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (118, 1, 2, 9, 28, 2, 1, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (119, 1, 2, 7, 13, 2, 1, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (120, 1, 2, 7, 35, 2, 1, 1, 1, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (121, 1, 2, 10, 13, 2, 1, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (122, 1, 2, 10, 2, 2, 1, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (123, 1, 2, 10, 28, 2, 1, 3, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (124, 1, 4, 1, 2, 2, 1, 3, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (125, 1, 4, 1, 5, 3, 3, 5, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (126, 1, 4, 1, 17, 5, 3, 6, 0, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (127, 1, 4, 6, 13, 2, 1, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (128, 1, 4, 6, 30, 2, 1, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (129, 1, 4, 6, 32, 2, 1, 3, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (130, 1, 4, 6, 31, 2, 1, 4, 1, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (131, 1, 4, 6, 28, 2, 1, 5, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (132, 1, 4, 7, 35, 2, 1, 1, 1, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (133, 1, 4, 7, 13, 2, 1, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (134, 1, 4, 7, 33, 2, 1, 3, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (135, 1, 4, 7, 28, 2, 1, 4, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (136, 1, 4, 8, 28, 2, 1, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (137, 1, 4, 9, 34, 2, 1, 1, 1, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (138, 1, 4, 9, 28, 2, 1, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (139, 1, 4, 10, 13, 2, 1, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (140, 1, 4, 10, 2, 2, 1, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (141, 1, 4, 10, 28, 2, 1, 3, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (142, 1, 2, 2, 27, 6, 1, 3, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (143, 1, 2, 2, 36, 6, 1, 6, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (144, 1, 4, 2, 36, 6, 1, 6, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (145, 1, 3, 2, 36, 6, 1, 6, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (146, 1, 2, 2, 28, 2, 1, 8, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (147, 1, 4, 2, 28, 2, 1, 8, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (148, 1, 3, 2, 28, 2, 3, 8, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (149, 1, 3, 1, 2, 2, 3, 3, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (150, 1, 3, 1, 17, 5, 3, 4, 0, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (151, 1, 3, 6, 13, 2, 3, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (152, 1, 3, 6, 30, 2, 3, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (153, 1, 3, 6, 32, 2, 3, 3, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (154, 1, 3, 6, 31, 2, 3, 4, 1, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (155, 1, 3, 6, 28, 2, 3, 5, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (156, 1, 3, 7, 35, 2, 3, 1, 1, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (157, 1, 3, 7, 13, 2, 3, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (158, 1, 3, 7, 33, 2, 3, 3, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (159, 1, 3, 7, 28, 2, 3, 4, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (160, 1, 3, 8, 28, 2, 3, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (161, 1, 3, 9, 34, 2, 3, 1, 1, 2)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (162, 1, 3, 9, 28, 2, 3, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (163, 1, 3, 10, 13, 2, 3, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (164, 1, 3, 10, 2, 2, 3, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (165, 1, 3, 10, 28, 2, 3, 3, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (166, 1, 3, 1, 3, 1, 0, 4, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (167, 1, 2, 11, 3, 1, 1, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (168, 1, 2, 11, 28, 2, 1, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (169, 1, 4, 11, 3, 1, 3, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (170, 1, 4, 11, 28, 2, 1, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (171, 1, 3, 11, 3, 1, 0, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (172, 1, 3, 11, 28, 2, 3, 2, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (173, 1, 2, 8, 2, 2, 1, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (174, 1, 3, 8, 2, 2, 1, 1, 1, 1)

INSERT [dbo].[RolePermissions] ([Id], [OrganizationId], [RoleId], [MenuId], [CommonTaskId], [FeatureGroupKey], [Permission], [Order], [Display], [OpeningMode]) VALUES (175, 1, 4, 8, 2, 2, 1, 1, 1, 1)


--******************************************** Copy Roles For Audit Log **************************************************************************************
--************************************************************3MTS User****************************************************************************

--***************************************For Executive Summary*************************************************************************************
--View Reports
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (1, @OrganizationId, 1, 6, 1, 1, 1) 

--Synchronization
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (2, @OrganizationId, 1, 7, 1, 1, 1) 

--Edit Sample Plan
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (3, @OrganizationId, 1, 2, 1, 1, 1) 

--Add Sample PLan
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (4, @OrganizationId, 1, 2, 1, 1, 1)

--Favorite Report
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (97, @OrganizationId, 1, 6, 1, 1, 1)

--***************************************For Report Dashboard*******************************************************************************************
--Add New Report
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (5, @OrganizationId, 1, 6, 1, 1, 1)

--Export/Print Report
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (6, @OrganizationId, 1, 6, 1, 1, 1)

--Edit Report
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (7, @OrganizationId, 1, 6, 1, 1, 1)

--View Report History
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (8, @OrganizationId, 1, 6, 1, 1, 1)

--Add/Edit Test Results
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (9, @OrganizationId, 1, 5, 1, 1, 1)

--**************************************For Plan Management***********************************************************************************************
--Add Sample Plan
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (10, @OrganizationId, 1, 2, 1, 1, 1)

--Add/Edit Test Point
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (11, @OrganizationId, 1, 2, 1, 1, 1)

--Add/Edit User
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (12, @OrganizationId, 1, 1, 1, 1, 1)

--Synchronization
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (13, @OrganizationId, 1, 7, 1, 1, 1) 

--**************************************For Help Menu****************************************************************************************************
--User Manual
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (14, @OrganizationId, 1, 11, 1, 1, 1) 

--3M secure website
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (15, @OrganizationId, 1, 11, 1, 1, 1) 

--About
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (16, @OrganizationId, 1, 11, 1, 1, 1) 

--Luminometer Detail
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (17, @OrganizationId, 1, 4, 1, 1, 1) 

--Database Management
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (18, @OrganizationId, 1, 8, 1, 1, 1) 

--Logs
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (19, @OrganizationId, 1, 9, 1, 1, 1)

--Organization Settings
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (20, @OrganizationId, 1, 10, 1, 1, 1)

--Add/Edit Capa Comments
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (21, @OrganizationId, 1, 2, 1, 1, 1)

--*************************************************For Resource Management********************************************************************************
--Location Screen
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (22, @OrganizationId, 1,3, 1, 1, 1)

--Variable Screen
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (23, @OrganizationId, 1, 3, 1, 1, 1)

--Role Screen
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (24, @OrganizationId, 1, 3, 1, 1, 1)



--*****************************************************************Administrator User*********************************************************************

--********************************************For Executive Summary
--View Reports
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (25, @OrganizationId, 2, 6, 1, 1, 1) 

--Synchronization
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (26, @OrganizationId, 2, 7, 1, 1, 1) 

--Edit Sample Plan
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (27, @OrganizationId, 2, 2, 1, 1, 1) 

--Add Sample PLan
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (28, @OrganizationId, 2, 2, 1, 1, 1)

--Favorite Report
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (98, @OrganizationId, 2, 6, 1, 1, 1)

--*******************************************For Report Dashboard****************************************************************************************
--Add New Report
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (29, @OrganizationId, 2, 6, 1, 1, 1)

--Export/Print Report
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (30, @OrganizationId, 2, 6, 1, 1, 1)

--Edit Report
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (31, @OrganizationId, 2, 6, 1, 1, 1)

--View Report History
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (32, @OrganizationId, 2, 6, 1, 1, 1)

--Add/Edit Test Results
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (33, @OrganizationId, 2, 5, 1, 1, 1)

--*******************************************For Plan Management****************************************************************************************
--Add Sample Plan
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (34, @OrganizationId, 2, 2, 1, 1, 1)

--Add/Edit Test Point
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (35, @OrganizationId, 2, 2, 1, 1, 1)

--Add/Edit User
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (36, @OrganizationId, 2, 1, 1, 1, 1)

--Synchronization
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (37, @OrganizationId, 2, 7, 1, 1, 1) 

--**********************************************For Help Menu********************************************************************************************
--User Manual
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (38, @OrganizationId, 2, 11, 1, 1, 1) 

--3M secure website
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (39, @OrganizationId, 2, 11, 1, 1, 1) 

--About
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (40, @OrganizationId, 2, 11, 1, 1, 1) 

--Luminometer Detail
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (41, @OrganizationId, 2, 4, 1, 1, 1)

--Database Management
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (42, @OrganizationId, 2, 8, 1, 1, 1) 

--Logs
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (43, @OrganizationId, 2, 9, 1, 1, 1)

--Organization Settings
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (44, @OrganizationId, 2, 10, 1, 1, 1)

--Add/Edit Capa Comments
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (45, @OrganizationId, 2, 2, 1, 1, 1)

--*************************************************For Resource Management********************************************************************************
--Location Screen
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (46, @OrganizationId, 2, 3, 1, 1, 1)

--Variable Screen
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (47, @OrganizationId, 2, 3, 1, 1, 1)

--Role Screen
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (48, @OrganizationId, 2, 3, 1, 1, 1)


--***********************************************************************For Supervisor User*****************************************************************
--*************************************************For Executive Summary
--View Reports
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (49, @OrganizationId, 4, 6, 1, 1, 1) 

--Synchronization
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (50, @OrganizationId, 4, 7, 1, 1, 1) 

--Edit Sample Plan
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (51, @OrganizationId, 4, 2, 1, 1, 1) 

--Add Sample PLan
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (52, @OrganizationId, 4, 2, 1, 1, 1)

--Favorite Report
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (99, @OrganizationId, 4, 6, 1, 1, 1)

--*************************************************For Report Dashboard**********************************************************************************
--Add New Report
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (53, @OrganizationId, 4, 6, 1,1, 1)

--Export/Print Report
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (54, @OrganizationId, 4, 6, 1, 1, 1)

--Edit Report
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (55, @OrganizationId, 4, 6, 1, 1, 1)

--View Report History
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (56, @OrganizationId, 4, 6, 1, 1, 1)

--Add/Edit Test Results
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (57, @OrganizationId, 4, 5, 3, 1, 1)

--**************************************************For Plan Management**********************************************************************************
--Add Sample Plan
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (58, @OrganizationId, 4, 2, 1, 1, 1)

--Add/Edit Test Point
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (59, @OrganizationId, 4, 2, 1, 1, 1)

--View User
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (60, @OrganizationId, 4, 1, 3, 1, 1)

--Synchronization
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (61, @OrganizationId, 4, 7, 1, 1, 1) 

--**************************************************For Help Menu***************************************************************************************
--User Manual
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (62, @OrganizationId, 4, 11, 1, 1, 1) 

--3M secure website
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (63, @OrganizationId, 4, 11, 1, 1, 1) 

--About
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (64, @OrganizationId, 4, 11, 1, 1, 1) 

--Luminometer Detail
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (65, @OrganizationId, 4, 4, 1, 1, 1)

--Database Management
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (66, @OrganizationId, 4, 8, 0, 1, 1) 

--Logs
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (67, @OrganizationId, 4, 9, 3, 1, 1)

--Organization Settings
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (68, @OrganizationId, 4, 10, 3, 1, 1)

--Add/Edit Capa Comments
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (69, @OrganizationId, 4, 2, 1, 1, 1)

--*************************************************For Resource Management********************************************************************************
--Location Screen
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (70, @OrganizationId, 4, 3, 3, 1, 1)

--Variable Screen
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (71, @OrganizationId, 4, 3, 3, 1, 1)

--Role Screen
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (72, @OrganizationId, 4, 3, 3, 1, 1)


--******************************************************************For Technician User*****************************************************************
--********************************************For Executive Summary*************************************************************************************
--View Reports
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (73, @OrganizationId, 3, 6, 1, 1, 1) 

--Synchronization
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (74, @OrganizationId, 3, 7, 1, 1, 1)

--View Sample Plan
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (75, @OrganizationId, 3, 2, 3, 1, 1) 

--Add Sample Plan
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (76, @OrganizationId, 3, 2, 3, 1, 1) 

--Favorite Report
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (100, @OrganizationId, 3,  6, 1, 1, 1)

--*******************************************For Report Dashboard****************************************************************************************
--Add New Report
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (77, @OrganizationId, 3, 6, 1, 1, 1)

--Export/Print Report
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (78, @OrganizationId, 3, 6, 1, 1, 1)

--Edit Report
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (79, @OrganizationId, 3, 6, 1, 1, 1)

--View Report History
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (80, @OrganizationId, 3, 6, 1, 1, 1)

--Add/Edit Test Results
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (81, @OrganizationId, 3, 5, 3, 1, 1)

--********************************************For Plan Management*****************************************************************************************
--Add Sample Plan
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (82, @OrganizationId, 3, 2, 3, 1, 1)

--View Test Point
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (83, @OrganizationId, 3, 2, 3, 1, 1)

--View Users
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (84, @OrganizationId, 3, 1, 0, 1, 1)

--Synchronization
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (85, @OrganizationId, 3, 7, 1, 1, 1)


--**************************************************For Help Menu***************************************************************************************
--User Manual
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (86, @OrganizationId, 3, 11, 1, 1, 1) 

--3M secure website
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (87, @OrganizationId, 3, 11, 1, 1, 1) 

--About
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (88, @OrganizationId, 3, 11, 1, 1, 1) 

--Luminometer Detail
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (89, @OrganizationId, 3, 4, 3, 1, 1)

--Database Management
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (90, @OrganizationId, 3, 8, 0, 1, 1) 

--Logs
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (91, @OrganizationId, 3, 9, 0, 1, 1)

--Organization Settings
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (92, @OrganizationId, 3, 10, 0, 1, 1)

--Add/Edit Capa Comments
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (93, @OrganizationId, 3, 2, 3, 1, 1)

--*************************************************For Resource Management********************************************************************************
--Location Screen
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (94, @OrganizationId, 3, 3, 0, 1, 1)

--Variable Screen
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (95, @OrganizationId, 3, 3, 0, 1, 1)

--Role Screen
INSERT [dbo].[RolePermissionsForAudit] ([Id], [OrganizationId], [RoleId], [FeatureGroupKey], [Permission], [CreatedBy],[LastEditedBy]) 
VALUES (96, @OrganizationId, 3, 3, 0, 1, 1)

END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[ArchiveData]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ArchiveData]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

CREATE Procedure [dbo].[ArchiveData] 
AS
BEGIN
		SELECT ArchivalId, OrganizationId, StartDate, EndDate, CreatedBy, SamplePlan
		INTO #ArchivalEntries
		FROM ArchivalMaster
		WHERE IsAlive = 1 and ScheduleOn < GETUTCDATE()
		
		IF NOT EXISTS (SELECT ArchivalId from #ArchivalEntries)
		BEGIN
			RETURN
		END
		
BEGIN TRAN T1
BEGIN TRY
		--and ArchivalStatus = 0
		--IsAlive = 0 and ArchivalStatus = 1

		DECLARE @TestPlanResult_Temp table(ResultId bigint, OrganizationId int)

		/*TestPlanResult*/
		SET IDENTITY_INSERT Spark_Archive..TestPlanResult ON	
		INSERT INTO Spark_Archive..TestPlanResult (ResultId, OrganizationId, TestPlanId, TestPlanVersion, TestPlanName, LocationId, LocationVersion, [Status], OpenedDate, OpenedBy, DeviceId, LastEditDate, LastEditedBy, ImportId)
		OUTPUT INSERTED.ResultId, INSERTED.OrganizationId into @TestPlanResult_Temp
		SELECT TPR.ResultId, TPR.OrganizationId, TestPlanId, TestPlanVersion, TestPlanName, LocationId, LocationVersion, [Status], OpenedDate, OpenedBy, DeviceId, LastEditDate, LastEditedBy, ImportId FROM TestPlanResult TPR
		INNER JOIN #ArchivalEntries A on TPR.OrganizationId = A.OrganizationId
		WHERE TPR.OpenedDate between A.StartDate and A.EndDate	AND (A.SamplePlan = ''0'' OR TPR.TestPlanId in (select value from dbo.fn_split(A.SamplePlan, '','')))	
		SET IDENTITY_INSERT Spark_Archive..TestPlanResult OFF

		--SET IDENTITY_INSERT Spark_Archive..TestPointResult ON
		/* [Kruanl:11 May, 2018] Added two columns : IsFinal, TestOrder */
		INSERT INTO Spark_Archive..TestPointResult(ResultId, MeasurementId, TestPointId, TestPointVersion, TestPointName, TestPointLocationId, LocationName, 
		TestMethodId, TestMethodVersion, TestMethodName, TestType, IsRetest, IsAdhoc, [Status], Result, ResultValue, ResultDate,
		IsEdited, ResultTakenBy, ResultTakenByName, OriginalMeasurementId, CapaComments, CreatedDate, CreatedBy, LastEditdate,
		LastEditedBy,ATPPassThreshold, ATPFailThreshold, ThresholdType, UnitId, UnitName, ReasonToAdd, Is3MSwab, IsFinal, TestOrder)
		SELECT TPR.ResultId, MeasurementId, TestPointId, TestPointVersion, TestPointName, TestPointLocationId, LocationName, 
		TestMethodId, TestMethodVersion, TestMethodName, TestType, IsRetest, IsAdhoc, [Status], Result, ResultValue, ResultDate,
		IsEdited, ResultTakenBy, ResultTakenByName, OriginalMeasurementId, CapaComments, CreatedDate, CreatedBy, LastEditdate,
		LastEditedBy,ATPPassThreshold, ATPFailThreshold, ThresholdType, UnitId, UnitName, ReasonToAdd, TPR.Is3MSwab, IsFinal, TestOrder
		 FROM TestPointResult TPR
		INNER JOIN @TestPlanResult_Temp T
		ON TPR.ResultId = T.ResultId 
		--SET IDENTITY_INSERT Spark_Archive..TestPointResult OFF

		--SET IDENTITY_INSERT Spark_Archive..TestResultCustomParameterMapping ON
		INSERT INTO Spark_Archive..TestResultCustomParameterMapping (ResultId, MeasurementId, OrganizationCategoryId, ParameterId, ParameterVersion, editedby, EditedDate)
		SELECT TCRPM.ResultId, MeasurementId, OrganizationCategoryId, ParameterId, ParameterVersion, editedby, EditedDate
		FROM TestResultCustomParameterMapping TCRPM
		INNER JOIN @TestPlanResult_Temp T 
		ON TCRPM.ResultId = T.ResultId
		--SET IDENTITY_INSERT Spark_Archive..TestResultCustomParameterMapping OFF

		DECLARE @EditMeasurement table(Id int)

		SET IDENTITY_INSERT Spark_Archive..EditMeasurement ON
		INSERT INTO Spark_Archive..EditMeasurement(OrganizationId, Id, ResultId, MeasurementId, ReasonForChange, OldResult, OldResultValue,
		NewResult, NewResultValue, OldCapaComments, NewCapaComments, OldTester, NewTester, EditDate, EditedBy)
		OUTPUT INSERTED.Id into @EditMeasurement
		SELECT E.OrganizationId, Id, E.ResultId, MeasurementId, ReasonForChange, OldResult, OldResultValue,
		NewResult, NewResultValue, OldCapaComments, NewCapaComments, OldTester, NewTester, EditDate, EditedBy
		 FROM EditMeasurement E
		INNER JOIN @TestPlanResult_Temp T on E.ResultId = T.ResultId and E.OrganizationId = T.OrganizationId
		SET IDENTITY_INSERT Spark_Archive..EditMeasurement OFF

		SET IDENTITY_INSERT Spark_Archive..EditTestResultCustomParameterMapping ON
		INSERT INTO Spark_Archive..EditTestResultCustomParameterMapping(EditId, Id, OldOrganizationCategoryId, NewOrganizationCategoryId, OldParameterId,
		NewParameterId, EditedBy, EditedDate)
		SELECT EditId, ETCPM.Id, OldOrganizationCategoryId, NewOrganizationCategoryId, OldParameterId,
		NewParameterId, EditedBy, EditedDate
		FROM EditTestResultCustomParameterMapping ETCPM
		INNER JOIN @EditMeasurement E 
		ON ETCPM.Id = E.Id
		SET IDENTITY_INSERT Spark_Archive..EditTestResultCustomParameterMapping OFF

		/*ADHOC TestPlanResult*/

		DECLARE @ADHOCTestPlanResult_Temp table(AdhocResultId bigint, OrganizationId int)

		SET IDENTITY_INSERT Spark_Archive..AdhocTestPlanResult ON
		INSERT INTO Spark_Archive..AdhocTestPlanResult(AdhocResultId, OrganizationId, TestPlanId, TestPlanVersion, TestPlanName, LocationId,
		LocationVersion, [Status], OpenedDate, OpenedBy, DeviceId, LastEditedBy, LastEditedDate)
		OUTPUT INSERTED.AdhocResultId, INSERTED.OrganizationId into @ADHOCTestPlanResult_Temp
		SELECT AdhocResultId, ATPR.OrganizationId, TestPlanId, TestPlanVersion, TestPlanName, LocationId,
		LocationVersion, [Status], OpenedDate, OpenedBy, DeviceId, LastEditedBy, LastEditedDate
		 FROM AdhocTestPlanResult ATPR
		INNER JOIN #ArchivalEntries A on ATPR.OrganizationId = A.OrganizationId
		WHERE ATPR.OpenedDate between A.StartDate and A.EndDate AND (A.SamplePlan = ''0'' OR ATPR.TestPlanId in (select value from dbo.fn_split(A.SamplePlan, '','')))	
		SET IDENTITY_INSERT Spark_Archive..AdhocTestPlanResult OFF

		--SET IDENTITY_INSERT Spark_Archive..AdhocTestPointResult ON
		/* [Kruanl:11 May, 2018] Added two columns : IsFinal, TestOrder */
		INSERT INTO Spark_Archive..AdhocTestPointResult(TPR.AdhocResultId, AdhocMeasurementId, TestPointId, TestPointVersion, TestPointName, TestPointLocationId, 
		LocationName, TestMethodId, TestMethodVersion, TestMethodName, TestType, IsAdhoc, IsRetest, [Status], Result, ResultValue,
		ResultDate, IsEdited, ResultTakenBy, ResultTakenByName, OriginalAdhocMeasurementId, CapaComments, CreatedBy, CreatedDate, 
		LastEditDate, LastEditedBy, ATPPassThreshold, ATPFailThreshold, ThresholdType, UnitId, UnitName, IsMapped, Is3MSwab, IsFinal, TestOrder)
		SELECT TPR.AdhocResultId, AdhocMeasurementId, TestPointId, TestPointVersion, TestPointName, TestPointLocationId, 
		LocationName, TestMethodId, TestMethodVersion, TestMethodName, TestType, IsAdhoc, IsRetest, [Status], Result, ResultValue,
		ResultDate, IsEdited, ResultTakenBy, ResultTakenByName, OriginalAdhocMeasurementId, CapaComments, CreatedBy, CreatedDate, 
		LastEditDate, LastEditedBy, ATPPassThreshold, ATPFailThreshold, ThresholdType, UnitId, UnitName, IsMapped, TPR.Is3MSwab, IsFinal, TestOrder		
		 FROM AdhocTestPointResult TPR
		INNER JOIN @ADHOCTestPlanResult_Temp T
		ON TPR.AdhocResultId = T.AdhocResultId 
		--SET IDENTITY_INSERT Spark_Archive..AdhocTestPointResult OFF

		SET IDENTITY_INSERT Spark_Archive..AdhocEditMeasurement ON
		INSERT INTO Spark_Archive..AdhocEditMeasurement(OrganizationId, Id, AdhocResultId, AdhocMeasurementId, ReasonForChange, 
		OldResult, OldResultValue, NewResult, NewResultValue, OldCapaComments, NewCapaComments, OldTester, NewTester, EditDate, 
		EditedBy) 
		SELECT E.OrganizationId, Id, E.AdhocResultId, AdhocMeasurementId, ReasonForChange, OldResult, OldResultValue, 
		NewResult, NewResultValue, OldCapaComments, NewCapaComments, OldTester, NewTester, EditDate, EditedBy
		 FROM AdhocEditMeasurement E
		INNER JOIN @ADHOCTestPlanResult_Temp T on E.AdhocResultId = T.AdhocResultId	and E.OrganizationId = T.OrganizationId
		SET IDENTITY_INSERT Spark_Archive..AdhocEditMeasurement OFF

		/*Purge data*/
		DELETE ETCPM
		FROM EditTestResultCustomParameterMapping ETCPM
		INNER JOIN @EditMeasurement E ON ETCPM.Id = E.Id

		DELETE EM
		FROM EditMeasurement EM
		INNER JOIN @TestPlanResult_Temp Ttemp on EM.ResultId = Ttemp.ResultId and Em.OrganizationId = Ttemp.OrganizationId	

		DELETE TRCPM
		FROM TestResultCustomParameterMapping TRCPM
		INNER JOIN @TestPlanResult_Temp Ttemp on TRCPM.ResultId = Ttemp.ResultId

		DELETE Tres
		FROM TestPointResult Tres
		INNER JOIN @TestPlanResult_Temp Ttemp on Tres.ResultId = Ttemp.ResultId	

		DELETE T 
		FROM TestPlanResult T
		INNER JOIN @TestPlanResult_Temp Ttemp on T.ResultId = Ttemp.ResultId and T.OrganizationId = Ttemp.OrganizationId

		DELETE AEM
		FROM AdhocEditMeasurement AEM
		INNER JOIN @ADHOCTestPlanResult_Temp Atemp on AEm.AdhocResultId = Atemp.AdhocResultId
		
		DELETE ATPR
		FROM AdhocTestPointResult ATPR
		INNER JOIN @ADHOCTestPlanResult_Temp Atemp on ATPr.AdhocResultId = atemp.AdhocResultId

		DELETE ATPR 
		FROM ADHOCTestPlanResult ATPR
		INNER JOIN @ADHOCTestPlanResult_Temp Atemp on ATPR.OrganizationId = Atemp.OrganizationId and ATPR.AdhocResultId = Atemp.AdhocResultId



		/*Update Archival Master*/
		Update ArchivalMaster 
		SET IsAlive = 0
		, ArchivalStatus = 1
		, ArchivedOn = GETUTCDATE()
		WHERE ArchivalId in (SELECT ArchivalID from #ArchivalEntries)

	COMMIT TRAN T1
END TRY
BEGIN CATCH
	 IF @@TRANCOUNT > 0
      ROLLBACK TRANSACTION T1

	Update ArchivalMaster 
	SET 
	IsAlive = 0
	, ArchivalStatus = 0
	WHERE ArchivalId in (SELECT ArchivalID from #ArchivalEntries)

	/*Audit log Entry*/
	INSERT INTO AuditLogMaster (ActionBy, ActionDate, Description, KeyId, RootField)
	SELECT NULL, GETUTCDATE(), ''Archival Process Failed For Archival Master ID: '' + CAST(A.ArchivalId AS NVARCHAR(100)) + CHAR(13) + CHAR(10) + ERROR_MESSAGE(), A.OrganizationId, '''' 
	FROM #ArchivalEntries A

	;THROW;
END CATCH
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[AuditLogEntry]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AuditLogEntry]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

CREATE Procedure [dbo].[AuditLogEntry] 
 @KeyID INT,
 @Description NVARCHAR(MAX),
 @ActionBy INT,
 @RootField NVARCHAR(MAX),
 @AuditModel AS AuditDetails READONLY
AS
BEGIN
	IF EXISTS (SELECT 1 FROM @AuditModel)
	BEGIN
		DECLARE @newAuditId INT

		INSERT INTO AuditLogMaster (ActionDate, ActionBy, [Description], KeyId,RootField)
		SELECT GETUTCDATE(), @ActionBy, @Description, @KeyId,@RootField

		SELECT @newAuditId = MAX(AuditLogId) FROM AuditLogMaster

		INSERT INTO AuditLogDetails(AuditLogId, TableName, FieldName, OperationType, OldValue, NewValue,Display,PrimaryField)
		SELECT @newAuditId as AuditLogId, a.TableName, a.FieldName, a.OperationType, a.OldValue, a.NewValue,a.Display,a.PrimaryField
		FROM @AuditModel a
		
		RETURN @newAuditId
	END
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[FilterReport]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FilterReport]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
CREATE Procedure [dbo].[FilterReport] 
(
	@OrganizationId INT,
	@MethodId VARCHAR(MAX) = ''1,2,3'', -- TestMethodMaster
	@StartDate Date = null,
	@EndDate Date = null,
	@SamplePlanId VARCHAR(MAX), -- plan Id
	@TesterId Int = null, -- Resulttakenby
	@Variable XML = null, -- 
	@Result float = null,
	@ResultStatus smallint = null, -- 0 fail, 1 pass, 2 -?
	@ResultValueStart float = null,
	@ResultValueEnd float = null
)
AS 
BEGIN

Declare @data as table (Name Varchar(50), Value varchar(max))

Declare @MethodIdtbl as table (ID int)
Insert into @MethodIdtbl 
select [value] from dbo.fn_Split(@MethodId,'','')

Declare @TestPlanIdtbl as table (ID int)
Insert into @TestPlanIdtbl 
select [value] from dbo.fn_Split(@SamplePlanId,'','')

--StartDate
INSERT INTO @data values (''StartDate'',@StartDate)
--EndDate
INSERT INTO @data values (''EndDate'',@EndDate)

-- Method Id
INSERT INTO @data 
select ''Method'', Stuff((
select '', '' + TestMethodName from TestMethodMaster
where TestMethodId in (select Id from @MethodIdtbl)
for xml path('''')),1,1,'''')

-- Sample Plan
INSERT INTO @data 
select ''SamplePlan'', Stuff((
select '', '' + TestPlanName from TestPlanMaster
where OrganizationId = @OrganizationId and TestPlanId in (select Id from @TestPlanIdtbl)
for xml path('''')),1,1,'''')

--Tester
INSERT INTO @data 
select ''Tester'', FirstName + '' '' + LastName from UserMaster
where UserId = @TesterId

--Variable
--INSERT INTO @data
--select ''Variable'' , ParameterName from OrganizationCustomParameterMaster ocpm
--INNER JOIN  @Variable.nodes(''/ArrayOfReportFilterForVariable/ReportFilterForVariable'') Node(Data) ON ocpm.OrganizationId=Node.Data.value(''(OrganizationId)[1]'', ''int'') 
--               AND ocpm.OrganizationCategoryId=Node.Data.value(''(CategoryId)[1]'', ''int'')  
--               AND ocpm.ParameterId=Node.Data.value(''(ParameterId)[1]'', ''int'')  
----where OrganizationId = @OrganizationId and ParameterId = @Variable

--Result Value
IF(@Result is not null)
Begin
	INSERT INTO @data Values (''Result'', Cast(@Result as varchar(10)))
End

--Result Status Value
IF(@ResultStatus is not null)
Begin
	INSERT INTO @data Values (''ResultStatus'', Case @ResultStatus when 0 then ''Fail'' when 1 then ''Pass'' else ''Caution'' end)
End

IF(@ResultValueStart is not null and @ResultValueEnd is not null)
Begin
	INSERT INTO @data Values (''ResultBetween'', cast (@ResultValueStart as varchar(10))+ '' - '' + Cast(@ResultValueEnd  as varchar(10)))
End

select * from @data

END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[GetCustomDashboardData]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetCustomDashboardData]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

-- Exec GetDashboardData 1, ''12/31/1999 6:30:00 PM'', ''5/31/2018 6:29:59 PM'', ''1,2,3,4,5'', ''1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52'', '''' 
-- Exec GetCustomDashboardData 1, ''12/31/1999 6:30:00 PM'', ''5/31/2018 6:29:59 PM'', ''1,2,3,4,5'', ''1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52'', '''' 
/****** Object:  StoredProcedure [dbo].[GetDashboardData]    Script Date: 4/9/2018 4:27:40 PM ******/

CREATE Procedure [dbo].[GetCustomDashboardData]
(
	@OrganizationId INT,
	@StartDate Datetime,
	@EndDate Datetime,
	@TestTypes VARCHAR(Max),
	@samplePlans Varchar(Max),
	@LocationPlantArray Varchar(Max)
)
AS 
BEGIN

SET NOCOUNT ON
SET ARITHABORT ON;

	DECLARE @AllTestPlans bit
	DECLARE @AllTestTypes bit
	DECLARE @AllLocations bit

	------------------split test types and store in #TestTypesIdtbl table
    CREATE TABLE #TestTypesIdtbl (TestTypeId INT)
	INSERT INTO #TestTypesIdtbl
	SELECT [value]
	FROM dbo.fn_Split(@TestTypes, '','')

	------------------split Sample Plans and store in #SamplePlansIdtbl table
	CREATE TABLE #SamplePlansIdtbl (SamplePlanId INT)
	INSERT INTO #SamplePlansIdtbl
	SELECT [value]
	FROM dbo.fn_Split(@samplePlans, '','')

	------------------split LocationPlants and store in #PlantsIdtbl table
	CREATE TABLE #PlantsIdtbl (PlantId INT)
	INSERT INTO #PlantsIdtbl
	SELECT [value]
	FROM dbo.fn_Split(@LocationPlantArray, '','')

	select @AllTestPlans = case when count(1) >0 then 0 else 1 end from #SamplePlansIdtbl
	select @AllTestTypes = case when count(1) >0 then 0 else 1 end from #TestTypesIdtbl
	Select @AllLocations = case when count(1) >0 then 0 else 1 end from #PlantsIdtbl

	-----------------take parent plan Id from #PlantsIdtbl and retrive its all childs and store them into #FinalPlantsIdtbl and then add LocationPlants(first level plants in #FinalPlantsIdtbl table)
	CREATE TABLE #FinalPlantsIdtbl (FinalPlanId INT);

	if(@AllLocations != 1)
	BEGIN
	
	WITH Locationtbl AS
	(
		SELECT LocationId
			FROM LocationMaster WHERE ParentLocationId in (select PlantId from #PlantsIdtbl) and Status = 1 and LocationMaster.OrganizationId = @OrganizationId
		UNION ALL
		SELECT LocationMaster.LocationId FROM LocationMaster  JOIN Locationtbl  ON LocationMaster.ParentLocationId = Locationtbl.LocationId where LocationMaster.Status = 1 and LocationMaster.OrganizationId = @OrganizationId
	)

	INSERT INTO #FinalPlantsIdtbl
	SELECT LocationId 
	FROM Locationtbl

	Insert INTO #FinalPlantsIdtbl
	SELECT PlantId 
	from #PlantsIdtbl

	OPTION(MAXRECURSION 32767)
	END

	--------------if all the test methods present then set the @AllTestTypes = 1 to retrive all testmethods data.
	if((select COUNT([TestTypeId]) from #TestTypesIdtbl) = 5)
	BEGIN
	set @AllTestTypes=1;
	END

	----------if @AllTestTypes not equals to 1 means all testmethods are not selected then check for testmethod id 5 is present or not and retrive Testmethods.
	if(@AllTestTypes != 1)
	BEGIN
	if exists (select TestTypeId from #TestTypesIdtbl where TestTypeId = 5)
	BEGIN
		INSERT INTO #TestTypesIdtbl(TestTypeId)
		select TestMethodId
		FROM OrganizationTestMethodMaster 
		where OrganizationId = @OrganizationId and TestMethodId > 5
	END
	END
	---------------Filter data from DashboardView
	SELECT dbo.TestPlanResult.OrganizationId,
		dbo.TestPlanResult.ResultId,
		dbo.TestPointResult.MeasurementId,
		dbo.TestPlanResult.TestPlanId,
		dbo.TestPlanMaster.TestPlanName,
		dbo.TestPointMaster.TestPointName,
		CAST(dbo.TestPointResult.TestPointId AS VARCHAR(20)) AS TestPointUniqueId,
		--dbo.TestPointResult.TestMethodId,
		--dbo.TestPointResult.TestMethodName,
		--dbo.TestPointResult.TestPointLocationId AS LocationId,
		--dbo.TestPointResult.LocationName,
		dbo.TestPointResult.ResultTakenBy AS TesterId,
		dbo.TestPointResult.Result,
		--dbo.TestPointResult.ResultValue,
		dbo.TestPointResult.ResultDate,
		--dbo.TestPointResult.CapaComments,
		--dbo.TestPointResult.ATPPassThreshold AS PassThreshold,
		--dbo.TestPointResult.ATPFailThreshold AS FailThreshold,
		dbo.TestPointResult.IsRetest AS Retest,
		--cast(dbo.TestPointResult.OriginalMeasurementId AS INT) AS OriginalMeasurementId,
		dbo.TestPointResult.Is3MSwab,
		--dbo.TestPointResult.UnitName,
		TestOrder AS ReTestOrder--,
		--IsFinal
	FROM dbo.TestPlanResult
		INNER JOIN dbo.TestPointResult ON dbo.TestPlanResult.ResultId = dbo.TestPointResult.ResultId
		Inner join dbo.TestPlanMaster on dbo.TestPlanMaster.TestPlanId = dbo.TestPlanResult.TestPlanId
		Inner join dbo.TestPointMaster on dbo.TestPointMaster.TestPointId = dbo.TestPointResult.TestPointId
	WHERE dbo.TestPlanResult.OrganizationId = @OrganizationId 
	and dbo.TestPointResult.ResultDate between @StartDate and @EndDate
	and (dbo.TestPointResult.TestMethodId in (select TestTypeId from #TestTypesIdtbl) or  @AllTestTypes = 1)
	and (dbo.TestPlanResult.TestPlanId in (select SamplePlanId from #SamplePlansIdtbl) or @AllTestPlans = 1) 
	and (dbo.TestPointResult.TestPointLocationId in (select FinalPlanId from #FinalPlantsIdtbl) or @AllLocations = 1) 

	UNION ALL

	SELECT dbo.AdhocTestPlanResult.OrganizationId,
		0 - dbo.AdhocTestPlanResult.AdhocResultId AS ResultId,
		dbo.AdhocTestPointResult.AdhocMeasurementId,
		dbo.AdhocTestPlanResult.TestPlanId,
		dbo.TestPlanMaster.TestPlanName,
		CASE 
			WHEN (dbo.AdhocTestPointResult.TestPointId = 0 or dbo.AdhocTestPointResult.TestPointId is NULL)
				THEN dbo.AdhocTestPointResult.TestPointName
			ELSE dbo.TestPointMaster.TestPointName
			END AS TestPointName,
		CASE 
			WHEN (dbo.AdhocTestPointResult.TestPointId = 0 or dbo.AdhocTestPointResult.TestPointId is NULL)
				THEN ''AHC_'' + dbo.AdhocTestPointResult.TestPointName
			ELSE CAST(dbo.AdhocTestPointResult.TestPointId AS VARCHAR(20))
			END AS TestPointUniqueId,
		--dbo.AdhocTestPointResult.TestMethodId,
		--dbo.AdhocTestPointResult.TestMethodName,
		--dbo.AdhocTestPointResult.TestPointLocationId AS LocationId,
		--''No Location'' AS LocationName,
		dbo.AdhocTestPointResult.ResultTakenBy AS TesterId,
		dbo.AdhocTestPointResult.Result,
		--dbo.AdhocTestPointResult.ResultValue AS ResultValue,
		dbo.AdhocTestPointResult.ResultDate,
		--dbo.AdhocTestPointResult.CapaComments,
		--dbo.AdhocTestPointResult.ATPPassThreshold AS PassThreshold,
		--dbo.AdhocTestPointResult.ATPFailThreshold AS FailThreshold,
		dbo.AdhocTestPointResult.IsRetest,
		--cast(dbo.AdhocTestPointResult.OriginalAdhocMeasurementId AS INT) AS OriginalMeasurementId,
		dbo.AdhocTestPointResult.Is3MSwab,
		--dbo.AdhocTestPointResult.UnitName,
		TestOrder AS ReTestOrder--,
		--IsFinal
	FROM dbo.AdhocTestPlanResult
		INNER JOIN dbo.AdhocTestPointResult ON dbo.AdhocTestPlanResult.AdhocResultId = dbo.AdhocTestPointResult.AdhocResultId
		Inner join dbo.TestPlanMaster on dbo.TestPlanMaster.TestPlanId = dbo.AdhocTestPlanResult.TestPlanId
		LEFT join dbo.TestPointMaster on dbo.TestPointMaster.TestPointId = dbo.AdhocTestPointResult.TestPointId
	WHERE dbo.AdhocTestPlanResult.OrganizationId = @OrganizationId
		AND dbo.AdhocTestPointResult.ResultDate BETWEEN @StartDate AND @EndDate
		AND (dbo.AdhocTestPointResult.TestMethodId IN (SELECT TestTypeId FROM #TestTypesIdtbl) OR @AllTestTypes = 1)
		AND ( dbo.AdhocTestPlanResult.TestPlanId IN (SELECT SamplePlanId FROM #SamplePlansIdtbl) OR @AllTestPlans = 1)
		and (dbo.AdhocTestPointResult.TestPointLocationId in (select FinalPlanId from #FinalPlantsIdtbl) or @AllLocations = 1) 

	UNION ALL

	SELECT Spark_Archive.dbo.TestPlanResult.OrganizationId,
		Spark_Archive.dbo.TestPlanResult.ResultId,
		Spark_Archive.dbo.TestPointResult.MeasurementId,
		Spark_Archive.dbo.TestPlanResult.TestPlanId,
		dbo.TestPlanMaster.TestPlanName,
		dbo.TestPointMaster.TestPointName,
		CAST(Spark_Archive.dbo.TestPointResult.TestPointId AS VARCHAR(20)) AS TestPointUniqueId,
		--Spark_Archive.dbo.TestPointResult.TestMethodId,
		--Spark_Archive.dbo.TestPointResult.TestMethodName,
		--Spark_Archive.dbo.TestPointResult.TestPointLocationId AS LocationId,
		--Spark_Archive.dbo.TestPointResult.LocationName,
		Spark_Archive.dbo.TestPointResult.ResultTakenBy AS TesterId,
		Spark_Archive.dbo.TestPointResult.Result,
		--Spark_Archive.dbo.TestPointResult.ResultValue AS ResultValue,
		Spark_Archive.dbo.TestPointResult.ResultDate,
		--Spark_Archive.dbo.TestPointResult.CapaComments,
		--Spark_Archive.dbo.TestPointResult.ATPPassThreshold AS PassThreshold,
		--Spark_Archive.dbo.TestPointResult.ATPFailThreshold AS FailThreshold,
		Spark_Archive.dbo.TestPointResult.IsRetest AS Retest,
		--cast(Spark_Archive.dbo.TestPointResult.OriginalMeasurementId AS INT) AS OriginalMeasurementId,
		Spark_Archive.dbo.TestPointResult.Is3MSwab,
		--Spark_Archive.dbo.TestPointResult.UnitName,
		Spark_Archive.dbo.TestPointResult.TestOrder AS ReTestOrder--,
		--IsFinal
	FROM Spark_Archive.dbo.TestPlanResult
		INNER JOIN Spark_Archive.dbo.TestPointResult ON Spark_Archive.dbo.TestPlanResult.ResultId = Spark_Archive.dbo.TestPointResult.ResultId
		Inner join dbo.TestPlanMaster on dbo.TestPlanMaster.TestPlanId = Spark_Archive.dbo.TestPlanResult.TestPlanId
		Inner join dbo.TestPointMaster on dbo.TestPointMaster.TestPointId = Spark_Archive.dbo.TestPointResult.TestPointId
	WHERE Spark_Archive.dbo.TestPlanResult.OrganizationId = @OrganizationId
		AND Spark_Archive.dbo.TestPointResult.ResultDate BETWEEN @StartDate AND @EndDate
		AND ( Spark_Archive.dbo.TestPointResult.TestMethodId IN ( SELECT TestTypeId FROM #TestTypesIdtbl) OR @AllTestTypes = 1)
		AND ( Spark_Archive.dbo.TestPlanResult.TestPlanId IN ( SELECT SamplePlanId FROM #SamplePlansIdtbl) OR @AllTestPlans = 1)
		and (Spark_Archive.dbo.TestPointResult.TestPointLocationId in (select FinalPlanId from #FinalPlantsIdtbl) or @AllLocations = 1) 
	
	UNION ALL

	SELECT Spark_Archive.dbo.AdhocTestPlanResult.OrganizationId,
		0 - Spark_Archive.dbo.AdhocTestPlanResult.AdhocResultId AS ResultId,
		Spark_Archive.dbo.AdhocTestPointResult.AdhocMeasurementId,
		Spark_Archive.dbo.AdhocTestPlanResult.TestPlanId,
		dbo.TestPlanMaster.TestPlanName,
		CASE 
			WHEN (Spark_Archive.dbo.AdhocTestPointResult.TestPointId = 0 or Spark_Archive.dbo.AdhocTestPointResult.TestPointId is NULL)
				THEN Spark_Archive.dbo.AdhocTestPointResult.TestPointName
			ELSE dbo.TestPointMaster.TestPointName
			END AS TestPointName,
		CASE 
			WHEN (Spark_Archive.dbo.AdhocTestPointResult.TestPointId = 0 or Spark_Archive.dbo.AdhocTestPointResult.TestPointId is NULL)
				THEN ''AHC_'' + Spark_Archive.dbo.AdhocTestPointResult.TestPointName
			ELSE CAST(Spark_Archive.dbo.AdhocTestPointResult.TestPointId AS VARCHAR(20))
			END AS TestPointUniqueId,
		--Spark_Archive.dbo.AdhocTestPointResult.TestMethodId,
		----Spark_Archive.dbo.AdhocTestPointResult.TestMethodVersion,
		--Spark_Archive.dbo.AdhocTestPointResult.TestMethodName,
		--Spark_Archive.dbo.AdhocTestPointResult.TestPointLocationId AS LocationId,
		--''No Location'' AS LocationName,
		Spark_Archive.dbo.AdhocTestPointResult.ResultTakenBy AS TesterId,
		Spark_Archive.dbo.AdhocTestPointResult.Result,
		--Spark_Archive.dbo.AdhocTestPointResult.ResultValue AS ResultValue,
		Spark_Archive.dbo.AdhocTestPointResult.ResultDate,
		--Spark_Archive.dbo.AdhocTestPointResult.CapaComments,
		--Spark_Archive.dbo.AdhocTestPointResult.ATPPassThreshold AS PassThreshold,
		--Spark_Archive.dbo.AdhocTestPointResult.ATPFailThreshold AS FailThreshold,
		Spark_Archive.dbo.AdhocTestPointResult.IsRetest,
		--cast(Spark_Archive.dbo.AdhocTestPointResult.OriginalAdhocMeasurementId AS INT) AS OriginalMeasurementId,
		Spark_Archive.dbo.AdhocTestPointResult.Is3MSwab,
		--Spark_Archive.dbo.AdhocTestPointResult.UnitName,
		Spark_Archive.dbo.AdhocTestPointResult.TestOrder AS ReTestOrder--,
		--IsFinal
	FROM Spark_Archive.dbo.AdhocTestPlanResult
		INNER JOIN Spark_Archive.dbo.AdhocTestPointResult ON Spark_Archive.dbo.AdhocTestPlanResult.AdhocResultId = Spark_Archive.dbo.AdhocTestPointResult.AdhocResultId
		Inner join dbo.TestPlanMaster on dbo.TestPlanMaster.TestPlanId = Spark_Archive.dbo.AdhocTestPlanResult.TestPlanId
		Inner join dbo.TestPointMaster on dbo.TestPointMaster.TestPointId = Spark_Archive.dbo.AdhocTestPointResult.TestPointId
	WHERE Spark_Archive.dbo.AdhocTestPlanResult.OrganizationId = @OrganizationId
		AND Spark_Archive.dbo.AdhocTestPointResult.ResultDate BETWEEN @StartDate AND @EndDate
		AND ( Spark_Archive.dbo.AdhocTestPointResult.TestMethodId IN ( SELECT TestTypeId FROM #TestTypesIdtbl) OR @AllTestTypes = 1)
		AND ( Spark_Archive.dbo.AdhocTestPlanResult.TestPlanId IN ( SELECT SamplePlanId FROM #SamplePlansIdtbl) OR @AllTestPlans = 1)
		and (Spark_Archive.dbo.AdhocTestPointResult.TestPointLocationId in (select FinalPlanId from #FinalPlantsIdtbl) or @AllLocations = 1)

	DROP TABLE #TestTypesIdtbl
	DROP TABLE #SamplePlansIdtbl
	DROP TABLE #FinalPlantsIdtbl

END

--EXEC [GetDashboardData] 
--	@OrganizationId = 1,
--	@StartDate = ''2018-03-05 00:00:00.000'',
--	@EndDate = ''2018-03-28 00:00:00.000'',
--	@TestTypes = ''1,4'', 
--	@samplePlans = ''5,2'',
--	@LocationPlantArray =''1,2''

--Go
--	select*from Dashboardview
--Go

--Drop procedure GetDashboardData

' 
END
GO
/****** Object:  StoredProcedure [dbo].[GetDashboardData]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetDashboardData]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'



CREATE Procedure [dbo].[GetDashboardData]
(
	@OrganizationId INT,
	@StartDate Datetime,
	@EndDate Datetime,
	@TestTypes VARCHAR(Max),
	@samplePlans Varchar(Max),
	@LocationPlantArray Varchar(Max)
)
AS 
BEGIN

SET NOCOUNT ON
SET ARITHABORT ON;

	DECLARE @AllTestPlans bit
	DECLARE @AllTestTypes bit
	DECLARE @AllLocations bit

	------------------split test types and store in @TestTypesIdtbl table
    DECLARE @TestTypesIdtbl AS TABLE (TestTypeId INT)
	INSERT INTO @TestTypesIdtbl
	SELECT [value]
	FROM dbo.fn_Split(@TestTypes, '','')

	------------------split Sample Plans and store in @SamplePlansIdtbl table
	DECLARE @SamplePlansIdtbl AS TABLE (SamplePlanId INT)
	INSERT INTO @SamplePlansIdtbl
	SELECT [value]
	FROM dbo.fn_Split(@samplePlans, '','')

	------------------split LocationPlants and store in @PlantsIdtbl table
	DECLARE @PlantsIdtbl AS TABLE (PlantId INT)
	INSERT INTO @PlantsIdtbl
	SELECT [value]
	FROM dbo.fn_Split(@LocationPlantArray, '','')

	select @AllTestPlans = case when count(1) >0 then 0 else 1 end from @SamplePlansIdtbl
	select @AllTestTypes = case when count(1) >0 then 0 else 1 end from @TestTypesIdtbl
	Select @AllLocations = case when count(1) >0 then 0 else 1 end from @PlantsIdtbl

	-----------------take parent plan Id from @PlantsIdtbl and retrive its all childs and store them into @FinalPlantsIdtbl and then add LocationPlants(first level plants in @FinalPlantsIdtbl table)

	if(@AllLocations != 1)
	BEGIN
	DECLARE @FinalPlantsIdtbl AS TABLE (FinalPlanId INT);
	WITH Locationtbl AS
	(
		SELECT *
			FROM LocationMaster WHERE ParentLocationId in (select PlantId from @PlantsIdtbl) and Status = 1 and LocationMaster.OrganizationId = @OrganizationId
		UNION ALL
		SELECT LocationMaster.* FROM LocationMaster  JOIN Locationtbl  ON LocationMaster.ParentLocationId = Locationtbl.LocationId where LocationMaster.Status = 1 and LocationMaster.OrganizationId = @OrganizationId
	)

	INSERT INTO @FinalPlantsIdtbl
	SELECT LocationId 
	FROM Locationtbl

	Insert INTO @FinalPlantsIdtbl
	SELECT PlantId 
	from @PlantsIdtbl

	OPTION(MAXRECURSION 32767)
	END

	--------------if all the test methods present then set the @AllTestTypes = 1 to retrive all testmethods data.
	if((select COUNT([TestTypeId]) from @TestTypesIdtbl) = 5)
	BEGIN
	set @AllTestTypes=1;
	END

	----------if @AllTestTypes not equals to 1 means all testmethods are not selected then check for testmethod id 5 is present or not and retrive Testmethods.
	if(@AllTestTypes != 1)
	BEGIN
	if exists (select TestTypeId from @TestTypesIdtbl where TestTypeId = 5)
	BEGIN
		INSERT INTO @TestTypesIdtbl(TestTypeId)
		select TestMethodId
		FROM OrganizationTestMethodMaster 
		where OrganizationId = @OrganizationId and TestMethodId > 5
	END
	END
	---------------Filter data from DashboardView

	SELECT * FROM DashboardView 

	WHERE  DashboardView.OrganizationId = organizationId
	and DashboardView.ResultDate between 
	@StartDate and
	@EndDate
	--and (@StartDate = null or  DashboardView.ResultDate > @StartDate)
	--and (@EndDate = null or DashboardView.ResultDate <= @EndDate)
	and (DashboardView.TestMethodId in (select TestTypeId from @TestTypesIdtbl) or  @AllTestTypes = 1)
	and (DashboardView.TestPlanId in (select SamplePlanId from @SamplePlansIdtbl) or @AllTestPlans = 1) 
	and (DashboardView.LocationId in (select FinalPlanId from @FinalPlantsIdtbl) or @AllLocations = 1) 

	SELECT*from @FinalPlantsIdtbl

END

--EXEC [GetDashboardData] 
--	@OrganizationId = 1,
--	@StartDate = ''2018-03-05 00:00:00.000'',
--	@EndDate = ''2018-03-28 00:00:00.000'',
--	@TestTypes = ''1,4'', 
--	@samplePlans = ''5,2'',
--	@LocationPlantArray =''1,2''

--Go
--	select*from Dashboardview
--Go

--Drop procedure GetDashboardData

' 
END
GO
/****** Object:  StoredProcedure [dbo].[GetLocationName]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetLocationName]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

CREATE Procedure [dbo].[GetLocationName] 
 @OrganizationId INT,
 @MatchKey INT,
 @Output varchar(1000) out 
 
AS
BEGIN
	DECLARE @path AS VARCHAR(1000) 
    DECLARE @ParentLocationId AS INT    

    SET @path           =   (SELECT LocationName FROM LocationMaster WHERE LocationId = @MatchKey and organizationId=@OrganizationId)
    SET @ParentLocationId   =   (SELECT ParentLocationId FROM LocationMaster WHERE LocationId = @MatchKey and organizationId=@OrganizationId)


    WHILE @ParentLocationId != 0
    BEGIN
        SET @path = (SELECT LocationName FROM LocationMaster WHERE LocationId = @ParentLocationId and organizationId=@OrganizationId) + '':'' + @path 
        SET @ParentLocationId = (SELECT ParentLocationId FROM LocationMaster WHERE LocationId = @ParentLocationId and organizationId=@OrganizationId)
    END

set @Output =  @Path
select @Output

END
	
' 
END
GO
/****** Object:  StoredProcedure [dbo].[GetReportDashboardData]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetReportDashboardData]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

/****** Object:  StoredProcedure [dbo].[GetDashboardData]    Script Date: 4/9/2018 4:27:40 PM ******/
/* 
	Exec GetReportDashboardData 1, ''12/31/1999 6:30:00 PM'', ''5/31/2018 6:29:59 PM'', ''1,2,3,4,5'', ''1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52''
	Exec GetDashboardData 1, ''12/31/1999 6:30:00 PM'', ''5/31/2018 6:29:59 PM'', ''1,2,3,4,5'', ''1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52'', '''' 
*/
CREATE Procedure [dbo].[GetReportDashboardData]
(
	@OrganizationId INT,
	@StartDate Datetime,
	@EndDate Datetime,
	@TestTypes VARCHAR(Max),
	@samplePlans Varchar(Max)
	
)
AS 
BEGIN

	SET NOCOUNT ON
	SET ARITHABORT ON;

	DECLARE @AllTestPlans bit
	DECLARE @AllTestTypes bit
	--DECLARE @AllLocations bit

	------------------split test types and store in @TestTypesIdtbl table
    --DECLARE @TestTypesIdtbl AS TABLE (TestTypeId INT)
	CREATE TABLE #TestTypesIdtbl (TestTypeId INT)
	INSERT INTO #TestTypesIdtbl
	SELECT [value]
	FROM dbo.fn_Split(@TestTypes, '','')

	------------------split Sample Plans and store in #SamplePlansIdtbl table
	--DECLARE #SamplePlansIdtbl AS TABLE (SamplePlanId INT)
	CREATE TABLE #SamplePlansIdtbl (SamplePlanId INT)
	INSERT INTO #SamplePlansIdtbl
	SELECT [value]
	FROM dbo.fn_Split(@samplePlans, '','')

	select @AllTestPlans = case when count(1) >0 then 0 else 1 end from #SamplePlansIdtbl
	select @AllTestTypes = case when count(1) >0 then 0 else 1 end from #TestTypesIdtbl
	
	--------------if all the test methods present then set the @AllTestTypes = 1 to retrive all testmethods data.
	if((select COUNT([TestTypeId]) from #TestTypesIdtbl) = 5)
	BEGIN
	set @AllTestTypes=1;
	END

	----------if @AllTestTypes not equals to 1 means all testmethods are not selected then check for testmethod id 5 is present or not and retrive Testmethods.
	if(@AllTestTypes != 1)
	BEGIN
	if exists (select TestTypeId from #TestTypesIdtbl where TestTypeId = 5)
	BEGIN
		INSERT INTO #TestTypesIdtbl(TestTypeId)
		select TestMethodId
		FROM OrganizationTestMethodMaster 
		where OrganizationId = @OrganizationId and TestMethodId > 5
	END
	END
	---------------Filter data from DashboardView

	SELECT dbo.TestPlanResult.OrganizationId,
		dbo.TestPlanResult.ResultId,
		dbo.TestPointResult.MeasurementId,
		dbo.TestPlanResult.TestPlanId,
		dbo.TestPlanMaster.TestPlanName,
		dbo.TestPointMaster.TestPointName,
		CAST(dbo.TestPointResult.TestPointId AS VARCHAR(20)) AS TestPointUniqueId,
		dbo.TestPointResult.TestMethodId,
		dbo.TestPointResult.TestMethodName,
		dbo.TestPointResult.TestPointLocationId AS LocationId,
		dbo.TestPointResult.LocationName,
		dbo.TestPointResult.ResultTakenBy AS TesterId,
		dbo.TestPointResult.Result,		
		CASE WHEN dbo.TestPointResult.ThresholdType = 1 THEN NULL ELSE dbo.TestPointResult.ResultValue END as ResultValue,
		dbo.TestPointResult.ResultDate,
		dbo.TestPointResult.CapaComments,		
		CASE WHEN dbo.TestPointResult.ThresholdType = 1 THEN NULL ELSE dbo.TestPointResult.ATPPassThreshold END as PassThreshold,
        CASE WHEN dbo.TestPointResult.ThresholdType = 1 THEN NULL ELSE dbo.TestPointResult.ATPFailThreshold END as FailThreshold,
		dbo.TestPointResult.IsRetest AS Retest,
		cast(dbo.TestPointResult.OriginalMeasurementId AS INT) AS OriginalMeasurementId,
		dbo.TestPointResult.Is3MSwab,
		dbo.TestPointResult.UnitName,
		TestOrder AS ReTestOrder,
		IsFinal
	FROM dbo.TestPlanResult
		INNER JOIN dbo.TestPointResult ON dbo.TestPlanResult.ResultId = dbo.TestPointResult.ResultId
		Inner join dbo.TestPlanMaster on dbo.TestPlanMaster.TestPlanId = dbo.TestPlanResult.TestPlanId
		Inner join dbo.TestPointMaster on dbo.TestPointMaster.TestPointId = dbo.TestPointResult.TestPointId
	WHERE dbo.TestPlanResult.OrganizationId = @OrganizationId
		AND dbo.TestPointResult.ResultDate BETWEEN @StartDate
			AND @EndDate
		AND (
			dbo.TestPointResult.TestMethodId IN (
				SELECT TestTypeId
				FROM #TestTypesIdtbl
				)
			OR @AllTestTypes = 1
			)
		AND (
			dbo.TestPlanResult.TestPlanId IN (
				SELECT SamplePlanId
				FROM #SamplePlansIdtbl
				)
			OR @AllTestPlans = 1
			)

	UNION ALL

	SELECT dbo.AdhocTestPlanResult.OrganizationId,
		0 - dbo.AdhocTestPlanResult.AdhocResultId AS ResultId,
		dbo.AdhocTestPointResult.AdhocMeasurementId,
		dbo.AdhocTestPlanResult.TestPlanId,
		dbo.TestPlanMaster.TestPlanName,
		CASE 
			WHEN (dbo.AdhocTestPointResult.TestPointId = 0 or dbo.AdhocTestPointResult.TestPointId is NULL)
				THEN dbo.AdhocTestPointResult.TestPointName
			ELSE dbo.TestPointMaster.TestPointName
			END AS TestPointName,
		CASE 
			WHEN (dbo.AdhocTestPointResult.TestPointId = 0 or dbo.AdhocTestPointResult.TestPointId is NULL)
				THEN ''AHC_'' + dbo.AdhocTestPointResult.TestPointName
			ELSE CAST(dbo.AdhocTestPointResult.TestPointId AS VARCHAR(20))
			END AS TestPointUniqueId,
		dbo.AdhocTestPointResult.TestMethodId,
		dbo.AdhocTestPointResult.TestMethodName,
		dbo.AdhocTestPointResult.TestPointLocationId AS LocationId,
		CASE 
			WHEN (dbo.AdhocTestPointResult.TestPointLocationId = 0 or dbo.AdhocTestPointResult.TestPointLocationId is NULL)
				THEN ''No Location''
			ELSE dbo.AdhocTestPointResult.LocationName
			END AS LocationName,
		--''No Location'' AS LocationName,
		dbo.AdhocTestPointResult.ResultTakenBy AS TesterId,
		dbo.AdhocTestPointResult.Result,		
		CASE WHEN dbo.AdhocTestPointResult.ThresholdType = 1 THEN NULL ELSE dbo.AdhocTestPointResult.ResultValue END as ResultValue,
		dbo.AdhocTestPointResult.ResultDate,
		dbo.AdhocTestPointResult.CapaComments,		
		CASE WHEN dbo.AdhocTestPointResult.ThresholdType = 1 THEN NULL ELSE dbo.AdhocTestPointResult.ATPPassThreshold END as PassThreshold,
		CASE WHEN dbo.AdhocTestPointResult.ThresholdType = 1 THEN NULL ELSE dbo.AdhocTestPointResult.ATPFailThreshold END as FailThreshold,
		dbo.AdhocTestPointResult.IsRetest,
		cast(dbo.AdhocTestPointResult.OriginalAdhocMeasurementId AS INT) AS OriginalMeasurementId,
		dbo.AdhocTestPointResult.Is3MSwab,
		dbo.AdhocTestPointResult.UnitName,
		TestOrder AS ReTestOrder,
		IsFinal
	FROM dbo.AdhocTestPlanResult
		INNER JOIN dbo.AdhocTestPointResult ON dbo.AdhocTestPlanResult.AdhocResultId = dbo.AdhocTestPointResult.AdhocResultId
		Inner join dbo.TestPlanMaster on dbo.TestPlanMaster.TestPlanId = dbo.AdhocTestPlanResult.TestPlanId
		LEFT join dbo.TestPointMaster on dbo.TestPointMaster.TestPointId = dbo.AdhocTestPointResult.TestPointId
	WHERE dbo.AdhocTestPlanResult.OrganizationId = @OrganizationId
		AND dbo.AdhocTestPointResult.ResultDate BETWEEN @StartDate
			AND @EndDate
		AND (
			dbo.AdhocTestPointResult.TestMethodId IN (
				SELECT TestTypeId
				FROM #TestTypesIdtbl
				)
			OR @AllTestTypes = 1
			)
		AND (
			dbo.AdhocTestPlanResult.TestPlanId IN (
				SELECT SamplePlanId
				FROM #SamplePlansIdtbl
				)
			OR @AllTestPlans = 1
			)

	UNION ALL

	SELECT Spark_Archive.dbo.TestPlanResult.OrganizationId,
		Spark_Archive.dbo.TestPlanResult.ResultId,
		Spark_Archive.dbo.TestPointResult.MeasurementId,
		Spark_Archive.dbo.TestPlanResult.TestPlanId,
		dbo.TestPlanMaster.TestPlanName,
		dbo.TestPointMaster.TestPointName,
		CAST(Spark_Archive.dbo.TestPointResult.TestPointId AS VARCHAR(20)) AS TestPointUniqueId,
		Spark_Archive.dbo.TestPointResult.TestMethodId,
		Spark_Archive.dbo.TestPointResult.TestMethodName,
		Spark_Archive.dbo.TestPointResult.TestPointLocationId AS LocationId,
		Spark_Archive.dbo.TestPointResult.LocationName,
		Spark_Archive.dbo.TestPointResult.ResultTakenBy AS TesterId,
		Spark_Archive.dbo.TestPointResult.Result,		
		CASE WHEN Spark_Archive.dbo.TestPointResult.ThresholdType = 1 THEN NULL ELSE Spark_Archive.dbo.TestPointResult.ResultValue END as ResultValue,
		Spark_Archive.dbo.TestPointResult.ResultDate,
		Spark_Archive.dbo.TestPointResult.CapaComments,
		CASE WHEN Spark_Archive.dbo.TestPointResult.ThresholdType = 1 THEN NULL ELSE Spark_Archive.dbo.TestPointResult.ATPPassThreshold END as PassThreshold,
		CASE WHEN Spark_Archive.dbo.TestPointResult.ThresholdType = 1 THEN NULL ELSE Spark_Archive.dbo.TestPointResult.ATPFailThreshold END as FailThreshold,
		Spark_Archive.dbo.TestPointResult.IsRetest AS Retest,
		cast(Spark_Archive.dbo.TestPointResult.OriginalMeasurementId AS INT) AS OriginalMeasurementId,
		Spark_Archive.dbo.TestPointResult.Is3MSwab,
		Spark_Archive.dbo.TestPointResult.UnitName,
		Spark_Archive.dbo.TestPointResult.TestOrder AS ReTestOrder,
		IsFinal
	FROM Spark_Archive.dbo.TestPlanResult
		INNER JOIN Spark_Archive.dbo.TestPointResult ON Spark_Archive.dbo.TestPlanResult.ResultId = Spark_Archive.dbo.TestPointResult.ResultId
		Inner join dbo.TestPlanMaster on dbo.TestPlanMaster.TestPlanId = Spark_Archive.dbo.TestPlanResult.TestPlanId
		Inner join dbo.TestPointMaster on dbo.TestPointMaster.TestPointId = Spark_Archive.dbo.TestPointResult.TestPointId
	WHERE Spark_Archive.dbo.TestPlanResult.OrganizationId = @OrganizationId
		AND Spark_Archive.dbo.TestPointResult.ResultDate BETWEEN @StartDate
			AND @EndDate
		AND (
			Spark_Archive.dbo.TestPointResult.TestMethodId IN (
				SELECT TestTypeId
				FROM #TestTypesIdtbl
				)
			OR @AllTestTypes = 1
			)
		AND (
			Spark_Archive.dbo.TestPlanResult.TestPlanId IN (
				SELECT SamplePlanId
				FROM #SamplePlansIdtbl
				)
			OR @AllTestPlans = 1
			)

	UNION ALL

	SELECT Spark_Archive.dbo.AdhocTestPlanResult.OrganizationId,
		0 - Spark_Archive.dbo.AdhocTestPlanResult.AdhocResultId AS ResultId,
		Spark_Archive.dbo.AdhocTestPointResult.AdhocMeasurementId,
		Spark_Archive.dbo.AdhocTestPlanResult.TestPlanId,
		dbo.TestPlanMaster.TestPlanName,
		CASE 
			WHEN (Spark_Archive.dbo.AdhocTestPointResult.TestPointId = 0 or Spark_Archive.dbo.AdhocTestPointResult.TestPointId is NULL)
				THEN Spark_Archive.dbo.AdhocTestPointResult.TestPointName
			ELSE dbo.TestPointMaster.TestPointName
			END AS TestPointName,
		CASE 
			WHEN (Spark_Archive.dbo.AdhocTestPointResult.TestPointId = 0 or Spark_Archive.dbo.AdhocTestPointResult.TestPointId is NULL)
				THEN ''AHC_'' + Spark_Archive.dbo.AdhocTestPointResult.TestPointName
			ELSE CAST(Spark_Archive.dbo.AdhocTestPointResult.TestPointId AS VARCHAR(20))
			END AS TestPointUniqueId,
		Spark_Archive.dbo.AdhocTestPointResult.TestMethodId,
		--Spark_Archive.dbo.AdhocTestPointResult.TestMethodVersion,
		Spark_Archive.dbo.AdhocTestPointResult.TestMethodName,
		Spark_Archive.dbo.AdhocTestPointResult.TestPointLocationId AS LocationId,
		CASE 
			WHEN (Spark_Archive.dbo.AdhocTestPointResult.TestPointLocationId = 0 or Spark_Archive.dbo.AdhocTestPointResult.TestPointLocationId is NULL)
				THEN ''No Location''
			ELSE Spark_Archive.dbo.AdhocTestPointResult.LocationName
			END AS LocationName,
		--''No Location'' AS LocationName,
		Spark_Archive.dbo.AdhocTestPointResult.ResultTakenBy AS TesterId,
		Spark_Archive.dbo.AdhocTestPointResult.Result,
		CASE WHEN Spark_Archive.dbo.AdhocTestPointResult.ThresholdType = 1 THEN NULL ELSE Spark_Archive.dbo.AdhocTestPointResult.ResultValue END as ResultValue,
		Spark_Archive.dbo.AdhocTestPointResult.ResultDate,
		Spark_Archive.dbo.AdhocTestPointResult.CapaComments,
		CASE WHEN Spark_Archive.dbo.AdhocTestPointResult.ThresholdType = 1 THEN NULL ELSE Spark_Archive.dbo.AdhocTestPointResult.ATPPassThreshold END as PassThreshold,
		CASE WHEN Spark_Archive.dbo.AdhocTestPointResult.ThresholdType = 1 THEN NULL ELSE Spark_Archive.dbo.AdhocTestPointResult.ATPFailThreshold END as FailThreshold,
		Spark_Archive.dbo.AdhocTestPointResult.IsRetest,
		cast(Spark_Archive.dbo.AdhocTestPointResult.OriginalAdhocMeasurementId AS INT) AS OriginalMeasurementId,
		Spark_Archive.dbo.AdhocTestPointResult.Is3MSwab,
		Spark_Archive.dbo.AdhocTestPointResult.UnitName,
		Spark_Archive.dbo.AdhocTestPointResult.TestOrder AS ReTestOrder,
		IsFinal
	FROM Spark_Archive.dbo.AdhocTestPlanResult
		INNER JOIN Spark_Archive.dbo.AdhocTestPointResult ON Spark_Archive.dbo.AdhocTestPlanResult.AdhocResultId = Spark_Archive.dbo.AdhocTestPointResult.AdhocResultId
		Inner join dbo.TestPlanMaster on dbo.TestPlanMaster.TestPlanId = Spark_Archive.dbo.AdhocTestPlanResult.TestPlanId
		LEFT join dbo.TestPointMaster on dbo.TestPointMaster.TestPointId = Spark_Archive.dbo.AdhocTestPointResult.TestPointId
	WHERE Spark_Archive.dbo.AdhocTestPlanResult.OrganizationId = @OrganizationId
		AND Spark_Archive.dbo.AdhocTestPointResult.ResultDate BETWEEN @StartDate
			AND @EndDate
		AND (
			Spark_Archive.dbo.AdhocTestPointResult.TestMethodId IN (
				SELECT TestTypeId
				FROM #TestTypesIdtbl
				)
			OR @AllTestTypes = 1
			)
		AND (
			Spark_Archive.dbo.AdhocTestPlanResult.TestPlanId IN (
				SELECT SamplePlanId
				FROM #SamplePlansIdtbl
				)
			OR @AllTestPlans = 1
			)
	
	DROP TABLE #TestTypesIdtbl
	DROP TABLE #SamplePlansIdtbl
	
END

--EXEC [GetDashboardData] 
--	@OrganizationId = 1,
--	@StartDate = ''2018-03-05 00:00:00.000'',
--	@EndDate = ''2018-03-28 00:00:00.000'',
--	@TestTypes = ''1,4'', 
--	@samplePlans = ''5,2'',
--	@LocationPlantArray =''1,2''

--Go
--	select*from Dashboardview
--Go

--Drop procedure GetDashboardData

' 
END
GO
/****** Object:  StoredProcedure [dbo].[GetReportDataSet]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetReportDataSet]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'


-- EXEC [GetReportDataSet] 1,''5/12/2018 6:00:00 AM'',''5/19/2018 5:59:59 AM'',''1,2,3,4,5'',''1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55'',''7,27,36,37,30,35''
-- EXEC [GetReportDataSet] 1,''2000-01-01'',''2018-05-31'','''','''',''''

CREATE Procedure [dbo].[GetReportDataSet]
@OrganizationId int,
@StartDate datetime,
@EndDate datetime,
@TestPlanId nvarchar(max) = '''',
@TestTypeId nvarchar(10) = '''',
@LocationId nvarchar(max)  = '''',
@TesterId varchar(max)  = '''',
@Result varchar(max) = '''',
@IncludeRetest bit = 1,
@ResultMin float = null,
@ResultMax float = null,
@Variable varchar(max) = ''''
as
begin

declare @TestPlanIds as table(TestPlanId int)
declare @AllTestPlans bit

declare @TestTypeIds as table(TestTypeId int)
declare @AllTestTypes bit

declare @LocationIds as table(LocationId int)
declare @AllLocation bit

declare @TesterIds as table(TesterId int)
declare @AllTesterId bit

declare @Results as table(Result int)
declare @AllResult bit

declare @Variables as table(CategoryId int, ParameterId int)
declare @AllVariable bit

declare @TestResults as table(ResultId int, MeasurementId int)
declare @AllTestResults bit

insert into @TestPlanIds(TestPlanId)
select value
FROM dbo.fn_split(@TestPlanId,'','')

insert into @TestTypeIds(TestTypeId)
SELECT value from dbo.fn_split(@TestTypeId, '','')

insert into @LocationIds(LocationId)
SELECT value from dbo.fn_split(@LocationId, '','')

insert into @TesterIds(TesterId)
SELECT value from dbo.fn_split(@TesterId, '','')

insert into @Results(Result)
SELECT value from dbo.fn_split(@Result, '','')

insert into @Variables(CategoryId,ParameterId)
SELECT SUBSTRING(value,1,(CHARINDEX('','',value)- 1)), SUBSTRING(value,(CHARINDEX('','',value)+1), LEN(value)) from dbo.fn_split(@Variable, ''|'')
--UNION ALL
--SELECT 0

if exists (select TestTypeId from @TestTypeIds where TestTypeId = 5)
BEGIN
	INSERT INTO @TestTypeIds(TestTypeId)
	select TestMethodId
	FROM OrganizationTestMethodMaster 
	where OrganizationId = @OrganizationId and TestMethodId > 5
END

select @AllTestPlans = case when count(1) >0 then 1 else 0 end from @TestPlanIds
select @AllTestTypes = case when count(1) >0 then 1 else 0 end from @TestTypeIds
select @AllLocation = case when count(1) >0 then 1 else 0 end from @LocationIds
select @AllTesterId = case when count(1) >0 then 1 else 0 end from @TesterIds
select @AllResult = case when count(1) >0 then 1 else 0 end from @Results
select @AllVariable = case when count(1) >0 then 1 else 0 end from @Variables
--set @StartDate = LEFT(CONVERT(nvarchar,@StartDate,120),11) + N''00:00:00''
--set @EndDate = LEFT(CONVERT(nvarchar,@EndDate,120),11) + N''23:59:59''

IF(@AllVariable = 1)
BEGIN
	insert into @TestResults (ResultId, MeasurementId)
	Select Distinct ResultId, MeasurementId from
	(Select ResultId, MeasurementId 
		from TestResultCustomParameterMapping tr
			inner join @Variables v
				on v.CategoryId = tr.OrganizationCategoryId and v.ParameterId = tr.ParameterId
	--Union
	--Select ResultId, MeasurementId 
	--	from Spark_Archive.dbo.TestResultCustomParameterMapping tr
	--		inner join @Variables v
	--			on v.CategoryId = tr.OrganizationCategoryId and v.ParameterId = tr.ParameterId 
	) x
END

--Select * from @TestResults

select @AllTestResults = case when count(1) >0 then 1 else 0 end from @TestResults

SELECT 
	dbv.OrganizationId,
	dbv.ResultId,
	dbv.MeasurementId,
	dbv.TestPlanId,
	TestPlanName,
	OpenedDate,
	TestPointId,
	TestPointUniqueId,
	TestPointName,
	OTMM.TestType as TestMethodId, 
	OTMV.TestMethodVersion,
	Case When OTMM.TestType = 2 then OTMV.TestMethodName else OTMV.ShortName ENd as TestMethodName, 
	dbv.LocationId,
	dbv.LocationName,
	dbv.TesterId,
	UM.FirstName + '' '' + UM.LastName as TesterName,
	dbv.Result,
	ResultValue,
	ResultDate,
	CapaComments,
	dbv.PassThreshold,
	dbv.FailThreshold,
	Adhoc,
	Retest,
	Mapped,
	Edited,
	OriginalMeasurementId,
	dbv.CreatedDate,
	dbv.LastEditedBy,
	dbv.LastEditDate,
	ReTestOrder,
	RowNo,
	Is3MSwab,
	UnitName,
	Archived,
	IsFinal		 
Into #ResultSet
from DashBoardView dbv
		left join OrganizationTestMethodMaster OTMM on dbv.OrganizationId = OTMM.OrganizationID and dbv.TestMethodId = OTMM.TestMethodId
		left join OrganizationTestMethodVersions OTMV on OTMV.OrganizationId = OTMM.OrganizationID and OTMV.TestMethodId = OTMM.TestMethodId and OTMV.IsCurrent=1
		left join UserMaster UM on UM.UserId = dbv.TesterId -- To Be Removed
		--left join TestMethodMaster TMM on OTMM.TestMethodId = TMM.TestMethodId
		left join @TestPlanIds t on t.TestPlanId = dbv.TestPlanId
		left join @TestTypeIds tt on dbv.TestMethodId = tt.TestTypeId --OTMM.TestType = tt.TestTypeId
		left join @LocationIds l on dbv.LocationId = l.LocationId
		left join @TesterIds Tester on dbv.TesterId = Tester.TesterId
		left join @Results r on dbv.Result = r.Result
		left join @TestResults tr on dbv.ResultId = tr.ResultId and  dbv.MeasurementId = tr.MeasurementId
where dbv.OrganizationId = @OrganizationId 
and ResultDate between @StartDate and @EndDate
and (@AllTestPlans = 0 or t.TestPlanId is not null) 
and (@AllTestTypes = 0 or tt.TestTypeId is not null)
and (@AllLocation = 0 or l.LocationId is not null)
and (@AllTesterId = 0 or Tester.TesterId is not null)
and (@AllResult = 0 or r.Result is not null)
and (@AllTestResults = 0 or tr.ResultId is not null)
and dbv.Retest = case When @IncludeRetest = 1 then dbv.Retest else 0 End
and ((dbv.ResultValue is null and  @ResultMax is null and @ResultMin is null) 
					Or  dbv.ResultValue Between (case When @ResultMin is null then dbv.ResultValue else @ResultMin End)
										And (case When @ResultMax is null then dbv.ResultValue else @ResultMax End))

Select * from #ResultSet

Select case when (select dbo.GetParentLocationName(LocationId, OrganizationId)) is null then LocationName else (select dbo.GetParentLocationName(LocationId, OrganizationId)) end as LocationName
from (Select Distinct LocationId,OrganizationId,LocationName from #ResultSet) as Locations 

Select UM.FirstName + '' '' + UM.LastName as TesterName
from (Select Distinct TesterId from #ResultSet) as Testers 
inner join UserMaster UM on UM.UserId = Testers.TesterId

Declare @TotalTest int, @RetestFailCount int

Select 
	@TotalTest = Count(1) from #ResultSet

Select 
	@RetestFailCount = Count(1) from #ResultSet
Where Retest = 1 and Result = 3		

Select ReTestOrder as TestOrder, 
		Count(1) as TestCount,
		Count(case when Result = 0 then 1 else null END) UntestedCount,
		Count(case when Result = 1 then 1 else null END) PassCount,
		Count(case when Result = 2 then 1 else null END) CautionCount,
		Count(case when Result = 3 then 1 else null END) FailCount
into #TestOrderWise
from #ResultSet
Group By ReTestOrder

Select 
	TestCount as InitialTestsCount, 
	PassCount as InitialPassTestsCount,
	CautionCount as InitialCautionTestsCount,
	FailCount as InitialFailTestsCount,
	@RetestFailCount as RetestFailCount,
	@TotalTest as TotalTest
from #TestOrderWise
Where TestOrder = 1

Select
	TestOrder, 
	TestCount, 
	PassCount,
	CautionCount,
	FailCount,
	UntestedCount,
	CumulativePercentage = (Cast(TestCount as float) / ISNULL((
		select 
			--(Sum(a.TestCount) / isnull(Sum(b.TestCount),1))  
			Sum(b.TestCount)
		from #TestOrderWise b
		where (b.TestOrder + 1) = a.TestOrder
	),TestCount) ) * 100.00
from #TestOrderWise a

DROP TABLE #ResultSet
DROP TABLE #TestOrderWise

END

--Select Top 1 * from DashBoardView

' 
END
GO
/****** Object:  StoredProcedure [dbo].[GetSamplePlan]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetSamplePlan]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

CREATE Procedure [dbo].[GetSamplePlan] 
@OrganizationId INT,
@MatchKey varchar(max),
@Output varchar(max) out 
 
AS
BEGIN
	DECLARE @planName AS VARCHAR(max) 
	select  @planName = COALESCE(@planName + '', '','''') + TestPlanName from TestPlanMaster where OrganizationId = @OrganizationId and TestPlanId in (Select ID From fnSplitter(@MatchKey))
	select @planName

set @Output =  @planName
select @Output

END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[GetTestPointDetails]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetTestPointDetails]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

CREATE Procedure [dbo].[GetTestPointDetails]
(
@OrganizationId INT,
@LocationArray VARCHAR(MAX) 
)

AS 
BEGIN

------------------split LocationPlants and store in @PlantsIdtbl table
DECLARE @PlantsIdtbl AS TABLE (PlantId INT)
INSERT INTO @PlantsIdtbl
SELECT [value]
FROM dbo.fn_Split(@LocationArray, '','')

DECLARE @AllLocations bit
Select @AllLocations = case when count(1) >0 then 0 else 1 end from @PlantsIdtbl

Declare @dependent bit

if(@AllLocations != 1)
BEGIN
Declare @LocationIdtbl as table (ID int)
Insert into @LocationIdtbl 
select FinalPlanId from dbo.[GetLoctaionHierarchyIds](@LocationArray,@OrganizationId)
END


Select
TPM.OrganizationId,
TPM.TestPointId,
TPM.TestPointName,
TPM.Status,
TPM.Description,
LM.LocationId,
TPM.TestPointVersion,
LM.LocationName,
TPM.CreatedDate,
LM.Status as LocationStatus,
OCF.ChangeTestPointThreshold,
ISNULL(TM.TestPlanName,null) SamplePlanName,

case when TM.TestPlanName is not null 
then CAST(1 AS BIT)
else 
case when exists (select Top 1 1 from TestPointResult  where TestPointResult.TestPointId = TPM.TestPointId ) then CAST(1 AS BIT) 
else CAST(0 AS BIT) end
end as IsDependent ,

case when exists (select Top 1 1 from TestPlanTestPointMapping where TestPlanTestPointMapping.TestPointId = TPM.TestPointId ) then CAST(1 AS BIT) else CAST(0 AS BIT) end as IsAssociatedToTestPlan ,

case when (select dbo.GetParentLocationName(LM.LocationId,TPM.OrganizationId)) is null then LM.LocationName else (select dbo.GetParentLocationName(LM.LocationId,TPM.OrganizationId)) end as HierarchicalLocationName

from  TestPointMaster TPM
join LocationMaster LM on LM.LocationId = TPM.LocationId and LM.OrganizationId = TPM.OrganizationId
join OrganizationConfiguration OCF on OCF.OrganizationId = TPM.OrganizationId
left  join TestPlanTestPointMapping TPPM on TPPM.OrganizationId = TPM.OrganizationId and TPPM.TestPointId = TPM.TestPointId and TPPM.TestPointVersion = TPM.TestPointVersion
left  join TestPlanMaster TM on TM.OrganizationId = TPM.OrganizationId and TM.TestPlanId = TPPM.TestPlanId and TM.TestPlanVersion = TPPM.TestPlanVersion

where TPM.OrganizationId = @OrganizationId and TPM.Status !=3
and (TPM.LocationId in (select ID from @LocationIdtbl) or @AllLocations = 1)

END

--Exec [GetTestPointDetails]
--@OrganizationId = 1,
--@LocationArray =''3''









' 
END
GO
/****** Object:  StoredProcedure [dbo].[GetTestPointsMappedListToSamplePlan]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetTestPointsMappedListToSamplePlan]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'



CREATE Procedure [dbo].[GetTestPointsMappedListToSamplePlan]
(
@OrganizationId INT,
@SamplePlanId INT 
)

AS 
BEGIN

SELECT
TPM.TestPointId,
TPM.TestPointVersion,
TM.TestPointName,
TM.Description,
TM.Status,
TPM.[Order],
TM.TestPointGroupId,
TM.LocationId AS TestPointLocationId,
TPM.IsRandom,
lm.Status  AS TestPointLocationStatus,
tplm.TestPlanName AS SamplePlanName,

case when (select dbo.GetParentLocationName(TM.LocationId,TPM.OrganizationId)) is null THEN lm.LocationName ELSE (select dbo.GetParentLocationName(TM.LocationId,TPM.OrganizationId)) END AS TestPointLocationName

FROM TestPlanTestPointMapping TPM 
inner join TestPointMaster TM ON TM.TestPointId = TPM.TestPointId and TM.OrganizationId = TPM.OrganizationId and TM.IsCurrent = 1
inner join Locationmaster lm ON lm.LocationId = TM.LocationId and lm.OrganizationId = TPM.OrganizationId
inner join TestPlanMaster tplm ON tplm.TestPlanId = TPM.TestPlanId and tplm.OrganizationId = TPM.OrganizationId
WHERE TPM.TestPlanId= @SamplePlanId and TPM.OrganizationId = @OrganizationId

END

--Exec [dbo].[GetTestPointsMappedListToSamplePlan] 1,4

--drop procedure [dbo].[GetTestPointsMappedListToSamplePlan]

' 
END
GO
/****** Object:  StoredProcedure [dbo].[RankingResult]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RankingResult]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
CREATE Procedure [dbo].[RankingResult]     
(    
 @OrganizationId INT,    
 @MethodId VARCHAR(MAX) = ''1,2,3'', -- TestMethodMaster    
 @StartDate Date = null,    
 @EndDate Date = null,    
 @SamplePlanId VARCHAR(MAX), -- plan Id    
 @TesterId Int = null, -- Resulttakenby    
 @Variable XML = null, --     
 @Result float = null,    
 @ResultValueStart float = null,    
 @ResultValueEnd float = null    
)    
AS     
BEGIN    
    
Declare @MethodIdtbl as table (ID int)    
Insert into @MethodIdtbl     
select [value] from dbo.fn_Split(@MethodId,'','')    
    
Declare @TestPlanIdtbl as table (ID int)    
Insert into @TestPlanIdtbl     
select [value] from dbo.fn_Split(@SamplePlanId,'','')    
    
--Create table @tempData     
Declare @tempData as table    
(    
 ResultId bigint,    
 MeasurementId int,      
 LocationName nvarchar(200),     
 TestPlanName nvarchar(200),     
 TestPointName nvarchar(200),    
 Result smallint,    
 OrganizationId int,    
 CapaComment Varchar(max),    
 LocationId int,     
 TestPlanId int,     
 TestPointId int    
)    
    
--Declare @final as table    
--(    
-- [Index] int,     
-- [Site] NVARCHAR(200),     
-- SamplePlan NVARCHAR(200),    
-- Testpoint NVARCHAR(200),     
-- Fail FLOAT    
--)    
    
    
INSERT INTO @tempData (ResultId,MeasurementId,LocationName, TestPlanName, TestPointName, Result,OrganizationId,CapaComment,LocationId,TestPlanId,TestPointId)    
SELECT tr.ResultId, tr.MeasurementId, l.LocationName,pl.TestPlanName,pm.TestPointName,tr.Result,pm.OrganizationId,    
--(select Stuff((select '','' + isnull(CommentText,'''') from TestResultCapaComments    
--where MeasurementId = tr.MeasurementId and ResultId = tr.ResultId and OrganizationId = @OrganizationId    
--for xml path('''')),1,1,''''))   
tr.CapaComments as CapaComment,    
l.LocationId,pl.TestPlanId,pm.TestPointId    
FROM TestPointResult tr  
INNER JOIN TestPlanResult tp ON tr.ResultId = tp.ResultId  
INNER JOIN TestPlanMaster pl ON pl.OrganizationId = tp.OrganizationId  and pl.TestPlanId = tp.TestPlanId  
INNER JOIN TestPointMaster pm ON pm.OrganizationId = tp.OrganizationId and pm.TestPointId = tr.TestPointId    --and pm.LocationId = tp.LocationId and pm.TestPointId = tr.TestPointId   
INNER JOIN LocationMaster l on pm.OrganizationId = l.OrganizationId  and pm.LocationId = l.LocationId  
INNER JOIN OrganizationTestMethodVersions  otmv ON  otmv.OrganizationId = tp.OrganizationId  and otmv.TestMethodId = tr.TestMethodId and otmv.TestMethodVersion = tr.TestMethodVersion
INNER JOIN @TestPlanIdtbl tblP ON tblP.ID = pl.TestPlanId  
WHERE pm.OrganizationId = @OrganizationId  
AND tr.TestMethodId in (select ID from @MethodIdtbl)  
AND CONVERT(DATE,tr.ResultDate) BETWEEN CONVERT(DATE,@StartDate) AND CONVERT(DATE,@EndDate)   
AND (@TesterId is null OR tr.ResultTakenBy = @TesterId)    
AND (@Result is null OR tr.ResultValue = @Result)    
AND (@ResultValueStart is null OR @ResultValueEnd is null OR (tr.ResultValue between @ResultValueStart and @ResultValueEnd))    
ORDER BY tp.OpenedDate, tr.TestPointId    
 

IF(@Variable is not null)    
BEGIN    
 --Insert into @final    
 SELECT ROW_NUMBER() over (order by fail desc) as [Index], B.Site,B.SamplePlan, B.TestPoint, Fail,NumberOfTests,    
 (select Stuff((select '','' + CapaComment from @tempData    
  where LocationId = B.LocationId and TestPlanId = B.TestPlanId  and TestPointId = B.TestPointId    
  for xml path('''')),1,1,'''')) as CapaComment    
     
 from (    
  select A.LocationName as [Site], A.TestPlanName as SamplePlan, A.TestPointName as TestPoint,A.LocationId,A.TestPlanId, A.TestPointId,    
  Cast(SUM(Case A.result when 1 then 1 else 0 end) as Float) / Cast(Count(Result) as float) as Fail,COUNT(A.ResultId)as NumberOfTests     
  from (    
   select tr.*     
   from @tempData tr    
   inner JOIN TestResultCustomParameterMapping cpm ON cpm.ResultId = tr.ResultId and cpm.MeasurementId = tr.MeasurementId   
   INNER JOIN  @Variable.nodes(''/ArrayOfReportFilterForVariable/ReportFilterForVariable'') Node(Data)ON tr.OrganizationId=Node.Data.value(''(OrganizationId)[1]'', ''int'')    
               AND cpm.OrganizationCategoryId=Node.Data.value(''(CategoryId)[1]'', ''int'')  
               AND cpm.ParameterId=Node.Data.value(''(ParameterId)[1]'', ''int'')  
  ) A    
 Group by LocationName,TestPlanName,TestPointName,LocationId,TestPlanId, TestPointId ) B    
 WHERE Fail > 0    
END    
ELSE    
BEGIN    
 --Insert into @final    
 
 SELECT ROW_NUMBER() over (order by fail desc) as [Index], B.Site,B.SamplePlan, B.TestPoint, Fail,NumberOfTests,
	(select Stuff((select '','' + CapaComment from @tempData
		where LocationId = B.LocationId and TestPlanId = B.TestPlanId  and TestPointId = B.TestPointId
		for xml path('''')),1,1,'''')) as CapaComment
	 from (
		select A.LocationName as [Site], A.TestPlanName as SamplePlan, A.TestPointName as TestPoint, A.LocationId,A.TestPlanId, A.TestPointId,
			Cast(SUM(Case A.result when 1 then 1 else 0 end) as Float) / Cast(Count(Result) as float) as Fail,COUNT(A.ResultId)as NumberOfTests   from (
			select * from @tempData
			) A
	Group by LocationName,TestPlanName,TestPointName, LocationId,TestPlanId, TestPointId ) B
	WHERE Fail > 0  
END    
    
--select * from @tempData    
    
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[ReviewResult]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReviewResult]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
CREATE Procedure [dbo].[ReviewResult]       
(      
 @OrganizationId INT,      
 @MethodId VARCHAR(MAX) = ''1,2,3'', -- TestMethodMaster      
 @StartDate Date = null,       
 @EndDate Date = null,      
 @SamplePlanId VARCHAR(MAX), -- plan Id      
 @TesterId Int = null, -- Resulttakenby      
 @Variable XML = null, --       
 @Result float = null,      
 @ResultStatus smallint = null, -- 0 fail, 1 pass, 2 -?      
 @ResultValueStart float = null,      
 @ResultValueEnd float = null      
)      
AS       
BEGIN      
      
Declare @MethodIdtbl as table (ID int)      
Insert into @MethodIdtbl       
select [value] from dbo.fn_Split(@MethodId,'','')      
      
Declare @TestPlanIdtbl as table (ID int)      
Insert into @TestPlanIdtbl       
select [value] from dbo.fn_Split(@SamplePlanId,'','')      
      
--Create table @tempData       
Declare @tempData as table      
(      
 ResultId bigint,      
 MeasurementId int,        
 LocationId int,       
 LocationName nvarchar(200),       
 TestPlanId int,       
 TestPlanName nvarchar(200),       
 OpenedDate datetime,       
 TestPointId int,       
 TestPointName nvarchar(200),       
 ATPPassThreshold int,       
 ATPFailThreshold int,       
 Result smallint,       
 ResultValue float,       
 RetestResultValue float,       
 ResultDate datetime,       
 CommentText nvarchar(400),      
 ResultTakenBy int,
 TestMethodName nvarchar(200)
)      
      
      
INSERT INTO @tempData (ResultId,MeasurementId, LocationId, LocationName, TestPlanId, TestPlanName, OpenedDate, TestPointId, TestPointName, ATPPassThreshold, ATPFailThreshold, Result, TestMethodName , ResultValue, RetestResultValue, ResultDate, CommentText,ResultTakenBy)  
  
    
SELECT tr.ResultId, tr.MeasurementId, l.LocationId,l.LocationName,pl.TestPlanId, pl.TestPlanName, tp.OpenedDate, pm.TestPointId, pm.TestPointName, tr.ATPPassThreshold,tr.ATPFailThreshold ,      
tr.Result,
otmv.TestMethodName,      
CASE when Tr.IsRetest = 0 then Tr.ResultValue else null end as ResultValue,       
CASE when Tr.IsRetest = 1 then Tr.ResultValue else null end as RetestResultValue,       
tr.ResultDate, tr.CapaComments, tr.ResultTakenBy   
FROM TestPointResult tr   
INNER JOIN TestPlanResult tp ON tr.ResultId = tp.ResultId  
INNER JOIN TestPlanMaster pl ON pl.OrganizationId = tp.OrganizationId  and pl.TestPlanId = tp.TestPlanId  
INNER JOIN TestPointMaster pm ON pm.OrganizationId = tp.OrganizationId and pm.TestPointId = tr.TestPointId    --and pm.LocationId = tp.LocationId and pm.TestPointId = tr.TestPointId   
INNER JOIN LocationMaster l on pm.OrganizationId = l.OrganizationId  and pm.LocationId = l.LocationId  
INNER JOIN OrganizationTestMethodVersions  otmv ON  otmv.OrganizationId = tp.OrganizationId  and otmv.TestMethodId = tr.TestMethodId and otmv.TestMethodVersion = tr.TestMethodVersion
INNER JOIN @TestPlanIdtbl tblP ON tblP.ID = pl.TestPlanId  
WHERE pm.OrganizationId = @OrganizationId  
AND tr.TestMethodId in (select ID from @MethodIdtbl)  
AND CONVERT(DATE,tr.ResultDate) BETWEEN CONVERT(DATE,@StartDate) AND CONVERT(DATE,@EndDate)   
AND (@TesterId is null OR tr.ResultTakenBy = @TesterId)      
AND (@Result is null OR tr.ResultValue = @Result)      
AND (@ResultStatus is null OR tr.Result = @ResultStatus)      
AND (@ResultValueStart is null OR @ResultValueEnd is null OR (tr.ResultValue between @ResultValueStart and @ResultValueEnd))      
ORDER BY tp.OpenedDate, tr.TestPointId      
      
IF(@Variable is not null)      
BEGIN      
 select tr.* from @tempData tr      
 --inner JOIN TestResultCustomParameterMapping cpm ON cpm.ResultId = tr.ResultId and cpm.MeasurementId = tr.MeasurementId AND cpm.ParameterId = @Variable      
 inner JOIN TestResultCustomParameterMapping cpm ON cpm.ResultId = tr.ResultId and cpm.MeasurementId = tr.MeasurementId   
   INNER JOIN  @Variable.nodes(''/ArrayOfReportFilterForVariable/ReportFilterForVariable'') Node(Data)ON --tr.OrganizationId=Node.Data.value(''(OrganizationId)[1]'', ''int'')    
               cpm.OrganizationCategoryId=Node.Data.value(''(CategoryId)[1]'', ''int'')  
               AND cpm.ParameterId=Node.Data.value(''(ParameterId)[1]'', ''int'')  
END      
ELSE      
 select * from @tempData      
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[TestPlanSummary]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanSummary]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
CREATE Procedure [dbo].[TestPlanSummary] 
(
	@OrganizationId INT,
	@MethodId VARCHAR(MAX) = ''1,2,3'', -- TestMethodMaster
	@StartDate Date = null,
	@EndDate Date = null,
	@SamplePlanId VARCHAR(MAX), -- plan Id
	@TesterId Int = null, -- Resulttakenby
	@Variable XML = null, --     
	@Result float = null,
	@ResultStatus smallint = null, -- 0 fail, 1 pass, 2 -?
	@ResultValueStart float = null,
	@ResultValueEnd float = null
)
AS 
BEGIN

Declare @MethodIdtbl as table (ID int)
Insert into @MethodIdtbl 
select [value] from dbo.fn_Split(@MethodId,'','')

Declare @TestPlanIdtbl as table (ID int)
Insert into @TestPlanIdtbl 
select [value] from dbo.fn_Split(@SamplePlanId,'','')

--Create table @tempData 
Declare @tempData as table
(
	ResultId bigint,
	MeasurementId int, 
	LocationName nvarchar(200),
	TestPlanName nvarchar(200),	
	OpenedDate datetime,	
	TestPointName nvarchar(200),	
	PassCount int,
	FailCount int,
	CautionCount Int,		
	ResultDate datetime,	
	ResultTakenBy int
)


INSERT INTO @tempData (ResultId,MeasurementId, LocationName,TestPlanName, OpenedDate, TestPointName, 
					   PassCount, FailCount, CautionCount, ResultDate, ResultTakenBy)
SELECT tr.ResultId, tr.MeasurementId, l.LocationName, pl.TestPlanName, tp.OpenedDate, pm.TestPointName, 
CASE When tr.ResultValue < ATPPassThreshold then 1 else 0 end as passCount,
CASE When tr.ResultValue > ATPFailThreshold then 1 else 0 end as FailCount,
CASE When (tr.ResultValue < ATPFailThreshold AND tr.ResultValue > ATPPassThreshold) then 1 else 0 end as cautionCount,
tr.ResultDate, tr.ResultTakenBy
FROM TestPointResult tr
INNER JOIN TestPlanResult tp ON tr.ResultId = tp.ResultId  
INNER JOIN TestPlanMaster pl ON pl.OrganizationId = tp.OrganizationId  and pl.TestPlanId = tp.TestPlanId  
INNER JOIN TestPointMaster pm ON pm.OrganizationId = tp.OrganizationId and pm.TestPointId = tr.TestPointId    --and pm.LocationId = tp.LocationId and pm.TestPointId = tr.TestPointId   
INNER JOIN LocationMaster l on pm.OrganizationId = l.OrganizationId  and pm.LocationId = l.LocationId  
INNER JOIN OrganizationTestMethodVersions  otmv ON  otmv.OrganizationId = tp.OrganizationId  and otmv.TestMethodId = tr.TestMethodId and otmv.TestMethodVersion = tr.TestMethodVersion
INNER JOIN @TestPlanIdtbl tblP ON tblP.ID = pl.TestPlanId  
WHERE pm.OrganizationId = @OrganizationId  
AND tr.TestMethodId in (select ID from @MethodIdtbl)  
AND CONVERT(DATE,tr.ResultDate) BETWEEN CONVERT(DATE,@StartDate) AND CONVERT(DATE,@EndDate) 
AND (@TesterId is null OR tr.ResultTakenBy = @TesterId)
AND (@Result is null OR tr.ResultValue = @Result)
AND (@ResultStatus is null OR tr.Result = @ResultStatus)
AND (@ResultValueStart is null OR @ResultValueEnd is null OR (tr.ResultValue between @ResultValueStart and @ResultValueEnd))
ORDER BY tp.OpenedDate, tr.TestPointId

IF(@Variable is not null)
BEGIN
	SELECT Row_number() over (order by tr.testPlanName) as RowId , tr.TestPlanName, tr.LocationName, SUM(tr.PassCount) Pass,SUM(tr.FailCount) Fail, SUM(tr.CautionCount) Caution, COUNT(tr.ResultId) Total 
	FROM @tempData tr
	INNER JOIN TestResultCustomParameterMapping cpm ON cpm.ResultId = tr.ResultId and cpm.MeasurementId = tr.MeasurementId
	INNER JOIN  @Variable.nodes(''/ArrayOfReportFilterForVariable/ReportFilterForVariable'') Node(Data)ON --tr.OrganizationId=Node.Data.value(''(OrganizationId)[1]'', ''int'')    
               cpm.OrganizationCategoryId=Node.Data.value(''(CategoryId)[1]'', ''int'')  
               AND cpm.ParameterId=Node.Data.value(''(ParameterId)[1]'', ''int'')  
	GROUP BY tr.TestPlanName, tr.LocationName
END
ELSE
	SELECT Row_number() over (order by tr.testPlanName) as RowId, tr.TestPlanName, tr.LocationName, SUM(tr.PassCount) Pass,SUM(tr.FailCount) Fail, SUM(tr.CautionCount) Caution, COUNT(tr.ResultId) Total 
	FROM @tempData tr 
	GROUP BY tr.TestPlanName, tr.LocationName

END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[TestpointSummary]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestpointSummary]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

CREATE Procedure [dbo].[TestpointSummary]     
(    
 @OrganizationId INT,    
 @MethodId VARCHAR(MAX) = ''1,2,3'', -- TestMethodMaster    
 @StartDate Date = null,    
 @EndDate Date = null,    
 @SamplePlanId VARCHAR(MAX), -- plan Id    
 @TesterId Int = null, -- Resulttakenby    
 @Variable XML = null, --     
 @Result float = null,    
 @ResultStatus smallint = null, -- 0 fail, 1 pass, 2 -?    
 @ResultValueStart float = null,    
 @ResultValueEnd float = null    
)    
AS     
BEGIN    
    
Declare @MethodIdtbl as table (ID int)    
Insert into @MethodIdtbl     
select [value] from dbo.fn_Split(@MethodId,'','')    
    
Declare @TestPlanIdtbl as table (ID int)    
Insert into @TestPlanIdtbl     
select [value] from dbo.fn_Split(@SamplePlanId,'','')    
    
--Create table @tempData     
Declare @tempData as table    
(    
 ResultId bigint,    
 MeasurementId int,     
 LocationName nvarchar(200),    
 TestPlanName nvarchar(200),     
 OpenedDate datetime,     
 TestPointName nvarchar(200),     
 PassCount int,    
 FailCount int,    
 CautionCount Int,      
 ResultDate datetime,     
 ResultTakenBy int    
)    
    
    
INSERT INTO @tempData (ResultId,MeasurementId, LocationName,TestPlanName, OpenedDate, TestPointName,     
        PassCount, FailCount, CautionCount, ResultDate, ResultTakenBy)    
SELECT tr.ResultId, tr.MeasurementId, l.LocationName, pl.TestPlanName, tp.OpenedDate, pm.TestPointName,     
CASE When tr.ResultValue < ATPPassThreshold then 1 else 0 end as passCount,    
CASE When tr.ResultValue > ATPFailThreshold then 1 else 0 end as FailCount,    
CASE When (tr.ResultValue < ATPFailThreshold AND tr.ResultValue > ATPPassThreshold) then 1 else 0 end as cautionCount,    
tr.ResultDate, tr.ResultTakenBy    
FROM TestPointResult tr    
INNER JOIN TestPlanResult tp ON tr.ResultId = tp.ResultId  
INNER JOIN TestPlanMaster pl ON pl.OrganizationId = tp.OrganizationId  and pl.TestPlanId = tp.TestPlanId  
INNER JOIN TestPointMaster pm ON pm.OrganizationId = tp.OrganizationId and pm.TestPointId = tr.TestPointId    --and pm.LocationId = tp.LocationId and pm.TestPointId = tr.TestPointId   
INNER JOIN LocationMaster l on pm.OrganizationId = l.OrganizationId  and pm.LocationId = l.LocationId  
INNER JOIN OrganizationTestMethodVersions  otmv ON  otmv.OrganizationId = tp.OrganizationId  and otmv.TestMethodId = tr.TestMethodId and otmv.TestMethodVersion = tr.TestMethodVersion
INNER JOIN @TestPlanIdtbl tblP ON tblP.ID = pl.TestPlanId  
WHERE pm.OrganizationId = @OrganizationId  
AND tr.TestMethodId in (select ID from @MethodIdtbl)  
--AND CONVERT(DATE,tr.ResultDate) BETWEEN CONVERT(DATE,@StartDate) AND CONVERT(DATE,@EndDate) 
--INNER JOIN TestPlanResult tp ON tr.ResultId = tp.ResultId    
--INNER JOIN TestPointMaster pm ON pm.TestPointId = tr.TestPointId --and  pm.OrganizationId = tp.OrganizationId and pm.LocationId = tp.LocationId and pm.TestPointId = tr.TestPointId     
--INNER JOIN LocationMaster l on pm.LocationId = l.LocationId and pm.OrganizationId = l.OrganizationId    
--INNER JOIN TestPlanMaster pl ON pl.TestPlanId = tp.TestPlanId and pl.OrganizationId = tp.OrganizationId --and pl.LocationId = tp.LocationId     
--INNER JOIN @TestPlanIdtbl tblP ON tblP.ID = pl.TestPlanId    
--WHERE pm.OrganizationId = @OrganizationId    
--AND tr.TestMethodId in (select ID from @MethodIdtbl)    
--AND tp.OpenedDate BETWEEN @StartDate AND @EndDate    
AND (@TesterId is null OR tr.ResultTakenBy = @TesterId)    
AND (@Result is null OR tr.ResultValue = @Result)    
AND (@ResultStatus is null OR tr.Result = @ResultStatus)    
AND (@ResultValueStart is null OR @ResultValueEnd is null OR (tr.ResultValue between @ResultValueStart and @ResultValueEnd))    
ORDER BY tp.OpenedDate, tr.TestPointId    
    
IF(@Variable is not null)    
BEGIN    
 SELECT Row_number() over (order by tr.testpointName) as RowId ,tr.TestPointName, tr.TestPlanName, tr.LocationName, SUM(tr.PassCount) Pass,SUM(tr.FailCount) Fail, SUM(tr.CautionCount) Caution, COUNT(tr.ResultId) Total     
 FROM @tempData tr    
 --INNER JOIN TestResultCustomParameterMapping cpm ON cpm.ResultId = tr.ResultId and cpm.MeasurementId = tr.MeasurementId AND cpm.ParameterId = @Variable    
 inner JOIN TestResultCustomParameterMapping cpm ON cpm.ResultId = tr.ResultId and cpm.MeasurementId = tr.MeasurementId   
   INNER JOIN  @Variable.nodes(''/ArrayOfReportFilterForVariable/ReportFilterForVariable'') Node(Data)ON --tr.OrganizationId=Node.Data.value(''(OrganizationId)[1]'', ''int'')    
               cpm.OrganizationCategoryId=Node.Data.value(''(CategoryId)[1]'', ''int'')  
               AND cpm.ParameterId=Node.Data.value(''(ParameterId)[1]'', ''int'')  
 GROUP BY tr.TestPointName, tr.TestPlanName, tr.LocationName    
END    
ELSE    
 SELECT Row_number() over (order by tr.testpointName) as RowId, tr.TestPointName, tr.TestPlanName, tr.LocationName, SUM(tr.PassCount) Pass,SUM(tr.FailCount) Fail, SUM(tr.CautionCount) Caution, COUNT(tr.ResultId) Total     
 FROM @tempData tr     
 GROUP BY tr.TestPointName, tr.TestPlanName, tr.LocationName    
    
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[TestpointTrend]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TestpointTrend]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

CREATE Procedure [dbo].[TestpointTrend]   
(  
 @OrganizationId INT,  
 @MethodId VARCHAR(MAX) = ''1,2,3'', -- TestMethodMaster  
 @StartDate Date = null,  
 @EndDate Date = null,  
 @SamplePlanId VARCHAR(MAX), -- plan Id  
 @TesterId Int = null, -- Resulttakenby  
 @Variable Int = null, --   
 @Result float = null,  
 @ResultStatus smallint = null, -- 0 fail, 1 pass, 2 -?  
 @ResultValueStart float = null,  
 @ResultValueEnd float = null  
)  
AS   
BEGIN  
  
Declare @MethodIdtbl as table (ID int)  
Insert into @MethodIdtbl   
select [value] from dbo.fn_Split(@MethodId,'','')  
  
Declare @TestPlanIdtbl as table (ID int)  
Insert into @TestPlanIdtbl   
select [value] from dbo.fn_Split(@SamplePlanId,'','')  
  
--Create table @tempData   
Declare @tempData as table  
(  
 ResultId bigint,  
 MeasurementId int,   
 LocationName nvarchar(200),  
 TestPlanName nvarchar(200),   
 OpenedDate datetime,   
 TestPointName nvarchar(200),   
 ResultValue float,    
 ResultDate datetime,   
 ResultTakenBy int,  
 IsRetest bit,  
 ATPPassThreshold int,   
 ATPFailThreshold int  
)  
  
  
INSERT INTO @tempData (ResultId,MeasurementId, LocationName,TestPlanName, OpenedDate, TestPointName,   
        ResultValue, ResultDate, ResultTakenBy,IsRetest,ATPPassThreshold,ATPFailThreshold)  
SELECT tr.ResultId, tr.MeasurementId, l.LocationName, pl.TestPlanName, tp.OpenedDate, pm.TestPointName,   
tr.ResultValue, tr.ResultDate, tr.ResultTakenBy, tr.IsRetest,ATPPassThreshold,ATPFailThreshold  
FROM TestPointResult tr  
INNER JOIN TestPlanResult tp ON tr.ResultId = tp.ResultId  
INNER JOIN TestPlanMaster pl ON pl.OrganizationId = tp.OrganizationId  and pl.TestPlanId = tp.TestPlanId  
INNER JOIN TestPointMaster pm ON pm.OrganizationId = tp.OrganizationId and pm.TestPointId = tr.TestPointId    --and pm.LocationId = tp.LocationId and pm.TestPointId = tr.TestPointId   
INNER JOIN LocationMaster l on pm.OrganizationId = l.OrganizationId  and pm.LocationId = l.LocationId  
INNER JOIN OrganizationTestMethodVersions  otmv ON  otmv.OrganizationId = tp.OrganizationId  and otmv.TestMethodId = tr.TestMethodId and otmv.TestMethodVersion = tr.TestMethodVersion
INNER JOIN @TestPlanIdtbl tblP ON tblP.ID = pl.TestPlanId  
WHERE pm.OrganizationId = @OrganizationId  
AND tr.TestMethodId in (select ID from @MethodIdtbl)  
AND CONVERT(DATE,tr.ResultDate) BETWEEN CONVERT(DATE,@StartDate) AND CONVERT(DATE,@EndDate) 
--INNER JOIN TestPlanResult tp ON tr.ResultId = tp.ResultId  
--INNER JOIN TestPointMaster pm ON pm.TestPointId = tr.TestPointId --and  pm.OrganizationId = tp.OrganizationId and pm.LocationId = tp.LocationId and pm.TestPointId = tr.TestPointId   
--INNER JOIN LocationMaster l on pm.LocationId = l.LocationId and pm.OrganizationId = l.OrganizationId  
--INNER JOIN TestPlanMaster pl ON pl.TestPlanId = tp.TestPlanId and pl.OrganizationId = tp.OrganizationId --and pl.LocationId = tp.LocationId   
--INNER JOIN @TestPlanIdtbl tblP ON tblP.ID = pl.TestPlanId  
--WHERE pm.OrganizationId = @OrganizationId  
--AND tr.TestMethodId in (select ID from @MethodIdtbl)  
--AND tp.OpenedDate BETWEEN @StartDate AND @EndDate  
AND (@TesterId is null OR tr.ResultTakenBy = @TesterId)  
AND (@Result is null OR tr.ResultValue = @Result)  
AND (@ResultStatus is null OR tr.Result = @ResultStatus)  
AND (@ResultValueStart is null OR @ResultValueEnd is null OR (tr.ResultValue between @ResultValueStart and @ResultValueEnd))  
ORDER BY tp.OpenedDate, tr.TestPointId  
  
 IF(@Variable is not null)  
 BEGIN  
  SELECT * FROM @tempData tr  
  INNER JOIN TestResultCustomParameterMapping cpm ON cpm.ResultId = tr.ResultId and cpm.MeasurementId = tr.MeasurementId AND cpm.ParameterId = @Variable  
 END  
 ELSE  
  SELECT * FROM @tempData tr   
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[UpdateAllTestOrderIsFinal]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateAllTestOrderIsFinal]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'


-- =======================================================================================================================================
-- Author		:	Krunal Vyas
-- Create date	:	11 May, 2018
-- Description	:	Recalculate the value of IsFinal & TestOrder columns for existing data of TestPointResult/AdhocTestPointResult Table.
-- =======================================================================================================================================
CREATE Procedure [dbo].[UpdateAllTestOrderIsFinal]
	
AS
BEGIN
	
	UPDATE TestPointResult
	SET TestOrder = TEMP.TestOrder
	FROM (
		SELECT Po.ResultId,
			MeasurementId,
			Row_number() OVER (
				PARTITION BY OrganizationId,
							TestPointId,
							Po.ResultId,
							TestMethodId 
				ORDER BY MeasurementId
				) AS TestOrder
		FROM TestPointResult Po
		INNER JOIN TestPlanResult Pl ON Po.ResultId = Pl.ResultId
		--WHERE Po.ResultId = 20802
		) TEMP
	INNER JOIN TestPointResult ON TestPointResult.ResultId = TEMP.ResultId
		AND TestPointResult.MeasurementId = TEMP.MeasurementId

	UPDATE TestPointResult
	SET IsFinal = 0

	UPDATE TestPointResult
	SET IsFinal = 1 
	FROM (
		Select ResultId, MeasurementId from (
		SELECT Po.ResultId,
			MeasurementId,
			Row_number() OVER (
				PARTITION BY OrganizationId,
							TestPointId,
							Po.ResultId,
							TestMethodId 
				ORDER BY MeasurementId Desc
				) AS ReverseTestOrder
		FROM TestPointResult Po
		INNER JOIN TestPlanResult Pl ON Po.ResultId = Pl.ResultId ) Base
		Where ReverseTestOrder = 1
		--WHERE Po.ResultId = 20802
		) TEMP
	INNER JOIN TestPointResult ON TestPointResult.ResultId = TEMP.ResultId
		AND TestPointResult.MeasurementId = TEMP.MeasurementId

/*====================================================================================*/
   -- AdhocTestPointResult --
/*====================================================================================*/

	UPDATE AdhocTestPointResult
	SET TestOrder = TEMP.TestOrder
	FROM (
		SELECT Po.AdhocResultId,
			AdhocMeasurementId,
			Row_number() OVER (
				PARTITION BY OrganizationId,
				(
					CASE 
						WHEN Po.TestPointId = 0
							OR Po.TestPointId IS NULL
							THEN ''AHC_'' + Po.TestPointName
						ELSE CAST(Po.TestPointId AS VARCHAR(20))
						END
					), -- TestPointId
				Po.AdhocResultId,
				TestMethodId ORDER BY AdhocMeasurementId
				) AS TestOrder
		FROM AdhocTestPointResult Po
		INNER JOIN AdhocTestPlanResult Pl ON Po.AdhocResultId = Pl.AdhocResultId
		) TEMP
	INNER JOIN AdhocTestPointResult ON AdhocTestPointResult.AdhocResultId = TEMP.AdhocResultId
		AND AdhocTestPointResult.AdhocMeasurementId = TEMP.AdhocMeasurementId

	-- Reset the Final Flag
	UPDATE AdhocTestPointResult
	SET IsFinal = 0
	
	-- Update the Final Flag
	UPDATE AdhocTestPointResult
	SET IsFinal = 1
	FROM (
		SELECT AdhocResultId,
			AdhocMeasurementId
		FROM (
			SELECT Po.AdhocResultId,
				AdhocMeasurementId,
				Row_number() OVER (
					PARTITION BY OrganizationId,
					(
						CASE 
							WHEN Po.TestPointId = 0
								OR Po.TestPointId IS NULL
								THEN ''AHC_'' + Po.TestPointName
							ELSE CAST(Po.TestPointId AS VARCHAR(20))
							END
						), -- TestPointId
					Po.AdhocResultId,
					TestMethodId ORDER BY AdhocMeasurementId DESC
					) AS ReverseTestOrder
			FROM AdhocTestPointResult Po
			INNER JOIN AdhocTestPlanResult Pl ON Po.AdhocResultId = Pl.AdhocResultId
			) Base
		WHERE ReverseTestOrder = 1
		) TEMP
	INNER JOIN AdhocTestPointResult ON AdhocTestPointResult.AdhocResultId = TEMP.AdhocResultId
		AND AdhocTestPointResult.AdhocMeasurementId = TEMP.AdhocMeasurementId

END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[UpdateTestOrderIsFinalInAdhocTestPointResult]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateTestOrderIsFinalInAdhocTestPointResult]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'


-- ==========================================================================================
-- Author		:	Krunal Vyas
-- Create date	:	10th May, 2018
-- Description	:	Update TestOrder and IsFinal for TestPointResult for given AdhocResultId
-- ==========================================================================================
CREATE Procedure [dbo].[UpdateTestOrderIsFinalInAdhocTestPointResult]
	@AdhocResultId int = 0
AS
BEGIN
		
		-- Update TestOrder
		UPDATE AdhocTestPointResult
		SET TestOrder = TEMP.TestOrder
		FROM (
			SELECT Po.AdhocResultId,
				AdhocMeasurementId,
				Row_number() OVER (
					PARTITION BY OrganizationId,
								CASE when Po.TestPointId = 0 or  Po.TestPointId is NULL
then 
''AHC_'' + Po.TestPointName 
else 
CAST(Po.TestPointId as varchar(20))
end 
,
								Po.AdhocResultId,
								TestMethodId 
					ORDER BY AdhocMeasurementId
					) AS TestOrder
			FROM AdhocTestPointResult Po
			INNER JOIN AdhocTestPlanResult Pl ON Po.AdhocResultId = Pl.AdhocResultId
			WHERE Po.AdhocResultId = CASE WHEN @AdhocResultId = 0 THEN Po.AdhocResultId ELSE @AdhocResultId END
			) TEMP
		INNER JOIN AdhocTestPointResult ON AdhocTestPointResult.AdhocResultId = TEMP.AdhocResultId
			AND AdhocTestPointResult.AdhocMeasurementId = TEMP.AdhocMeasurementId

		-- Reset the Final Flag
		UPDATE AdhocTestPointResult
		SET IsFinal = 0
		WHERE AdhocResultId = CASE WHEN @AdhocResultId = 0 THEN AdhocResultId ELSE @AdhocResultId END

		-- Update the Final Flag
		UPDATE AdhocTestPointResult
		SET IsFinal = 1
		FROM (
			SELECT AdhocResultId,
				AdhocMeasurementId
			FROM (
				SELECT Po.AdhocResultId,
					AdhocMeasurementId,
					Row_number() OVER (
						PARTITION BY OrganizationId,
						CASE when Po.TestPointId = 0 or  Po.TestPointId is NULL
then 
''AHC_'' + Po.TestPointName 
else 
CAST(Po.TestPointId as varchar(20))
end 
,
						Po.AdhocResultId,
						TestMethodId ORDER BY AdhocMeasurementId DESC
						) AS ReverseTestOrder
				FROM AdhocTestPointResult Po
				INNER JOIN AdhocTestPlanResult Pl ON Po.AdhocResultId = Pl.AdhocResultId
				Where Po.AdhocResultId = CASE WHEN @AdhocResultId = 0 THEN Po.AdhocResultId ELSE @AdhocResultId END
				) Base
			WHERE ReverseTestOrder = 1
			) TEMP
		INNER JOIN AdhocTestPointResult ON AdhocTestPointResult.AdhocResultId = TEMP.AdhocResultId
			AND AdhocTestPointResult.AdhocMeasurementId = TEMP.AdhocMeasurementId

END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[UpdateTestOrderIsFinalInTestPointResult]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateTestOrderIsFinalInTestPointResult]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'


-- =============================================
-- Author		:	Krunal Vyas
-- Create date	:	10th May, 2018
-- Description	:	Update TestOrder and IsFinal for TestPointResult for given ResultId
-- [UpdateTestOrderIsFinalInTestPointResult] 0
-- =============================================
CREATE Procedure [dbo].[UpdateTestOrderIsFinalInTestPointResult]
	@ResultId int = 0
AS
BEGIN
		
		-- Update TestOrder
		UPDATE TestPointResult
		SET TestOrder = TEMP.TestOrder
		FROM (
			SELECT Po.ResultId,
				MeasurementId,
				Row_number() OVER (
					PARTITION BY OrganizationId,
								TestPointId,
								Po.ResultId,
								TestMethodId 
					ORDER BY MeasurementId
					) AS TestOrder
			FROM TestPointResult Po
			INNER JOIN TestPlanResult Pl ON Po.ResultId = Pl.ResultId
			WHERE Po.ResultId = CASE WHEN @ResultId = 0 THEN Po.ResultId ELSE @ResultId END
			) TEMP
		INNER JOIN TestPointResult ON TestPointResult.ResultId = TEMP.ResultId
			AND TestPointResult.MeasurementId = TEMP.MeasurementId

		-- Reset the Final Flag
		UPDATE TestPointResult
		SET IsFinal = 0
		WHERE ResultId = CASE WHEN @ResultId = 0 THEN ResultId ELSE @ResultId END

		-- Update the Final Flag
		UPDATE TestPointResult
		SET IsFinal = 1
		FROM (
			SELECT ResultId,
				MeasurementId
			FROM (
				SELECT Po.ResultId,
					MeasurementId,
					Row_number() OVER (
						PARTITION BY OrganizationId,
						TestPointId,
						Po.ResultId,
						TestMethodId ORDER BY MeasurementId DESC
						) AS ReverseTestOrder
				FROM TestPointResult Po
				INNER JOIN TestPlanResult Pl ON Po.ResultId = Pl.ResultId
				Where Po.ResultId = CASE WHEN @ResultId = 0 THEN Po.ResultId ELSE @ResultId END
				) Base
			WHERE ReverseTestOrder = 1
			) TEMP
		INNER JOIN TestPointResult ON TestPointResult.ResultId = TEMP.ResultId
			AND TestPointResult.MeasurementId = TEMP.MeasurementId

END
' 
END
GO
/****** Object:  UserDefinedFunction [dbo].[fn_Split]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fn_Split]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'
CREATE  FUNCTION [dbo].[fn_Split](@text varchar(8000), @delimiter varchar(20) = '' '')
RETURNS @Strings TABLE
(   
  position int IDENTITY PRIMARY KEY,
  value varchar(8000)  
)
AS
BEGIN
DECLARE @index int
SET @index = -1
WHILE (LEN(@text) > 0)
  BEGIN 
    SET @index = CHARINDEX(@delimiter , @text) 
    IF (@index = 0) AND (LEN(@text) > 0) 
      BEGIN  
        INSERT INTO @Strings VALUES (@text)
          BREAK 
      END 
    IF (@index > 1) 
      BEGIN  
        INSERT INTO @Strings VALUES (LEFT(@text, @index - 1))  
        SET @text = RIGHT(@text, (LEN(@text) - @index)) 
      END 
    ELSE
      SET @text = RIGHT(@text, (LEN(@text) - @index))
    END
  RETURN
END

' 
END

GO
/****** Object:  UserDefinedFunction [dbo].[fnSplitter]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fnSplitter]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'
Create Function [dbo].[fnSplitter] (@IDs Varchar(100) )  
Returns @Tbl_IDs Table  (ID Int)  As  

BEGIN 
	-- Append comma
	Set @IDs =  @IDs + '','' 
	-- Indexes to keep the position of searching
	Declare @Pos1 Int
	Declare @pos2 Int

	-- Start from first character 
	Set @Pos1=1
	Set @Pos2=1

	While @Pos1<Len(@IDs)
	BEGIN
	  Set @Pos1 = CharIndex('','',@IDs,@Pos1)
	  Insert @Tbl_IDs Select  Cast(Substring(@IDs,@Pos2,@Pos1-@Pos2) As Int)
	  -- Go to next non comma character
	  Set @Pos2=@Pos1+1
	  -- Search from the next charcater
	  Set @Pos1 = @Pos1+1
	END 
	
Return
END
' 
END

GO
/****** Object:  UserDefinedFunction [dbo].[GetLoctaionHierarchyIds]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetLoctaionHierarchyIds]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'

	CREATE FUNCTION [dbo].[GetLoctaionHierarchyIds](@LocationPlantArray varchar(max), @OrganizationId int)
	RETURNS  @FinalPlantsIdtbl TABLE 
	(
		-- columns returned by the function
		FinalPlanId INT
	)
	AS
	BEGIN
	--DECLARE @FinalPlantsIdtbl AS TABLE (FinalPlanId INT);

	------------------split LocationPlants and store in @PlantsIdtbl table
	DECLARE @PlantsIdtbl AS TABLE (PlantId INT)
	INSERT INTO @PlantsIdtbl
	SELECT [value]
	FROM dbo.fn_Split(@LocationPlantArray, '','');

	WITH Locationtbl AS
	(
		SELECT *
			FROM LocationMaster WHERE ParentLocationId in (select PlantId from @PlantsIdtbl) and Status = 1 and LocationMaster.OrganizationId = @OrganizationId
		UNION ALL
		SELECT LocationMaster.* FROM LocationMaster  JOIN Locationtbl  ON LocationMaster.ParentLocationId = Locationtbl.LocationId where LocationMaster.Status = 1 and LocationMaster.OrganizationId = @OrganizationId
	)

	INSERT INTO @FinalPlantsIdtbl
	SELECT LocationId 
	FROM Locationtbl

	Insert INTO @FinalPlantsIdtbl
	SELECT PlantId 
	from @PlantsIdtbl

	OPTION(MAXRECURSION 32767)

	RETURN
	END


' 
END

GO
/****** Object:  UserDefinedFunction [dbo].[GetParentLocationName]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetParentLocationName]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'
CREATE function [dbo].[GetParentLocationName](@ChildLocationId int, @OrganizationId int)
RETURNS nvarchar(200)
as
begin
declare @ParentLocationName nvarchar(200);
;WITH CTE
as
(
	select * from LocationMaster
	where LocationId = @ChildLocationId and OrganizationId = @OrganizationId
	UNION ALL 
	SELECT lm.* FROM LocationMaster lm
	inner join cte c on lm.LocationId = c.ParentLocationId and lm.OrganizationId = c.OrganizationId and lm.OrganizationId = @OrganizationId and c.OrganizationId = @OrganizationId
)
--select top 1 @ParentLocationName  = STUFF((select '':'' + LocationName from CTE order by Level for XML path('''')), 1, 1, '''') from cte --where ParentLocationId = 0
select top 1 @ParentLocationName= STUFF((select '':'' + LocationName from CTE order by Level for XML path(''''),TYPE).value(''.'',''NVARCHAR(MAX)''), 1, 1, '''') from cte --where ParentLocationId = 0 
return @ParentLocationName
end' 
END

GO
/****** Object:  View [dbo].[DashBoardView]    Script Date: 6/19/2018 11:17:52 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[DashBoardView]'))
EXEC dbo.sp_executesql @statement = N'




-- Select * from [DashBoardView]
CREATE VIEW [dbo].[DashBoardView]
AS
SELECT ROW_NUMBER() OVER (
		ORDER BY ResultId
		) AS RowNo,
	OrganizationId,
	ResultId,
	MeasurementId,
	TestPlanId,
	TestPlanName,
	OpenedDate,
	TestPointId,
	TestPointName,
	TestPointUniqueId,
	TestMethodId,
	TestMethodVersion,
	TestMethodName,
	LocationId,
	LocationName,
	TesterId,
	TesterName,
	Result,
	ResultValue,
	ResultDate,
	CapaComments,
	PassThreshold,
	FailThreshold,
	Adhoc,
	Retest,
	Mapped,
	Edited,
	OriginalMeasurementId,
	CreatedDate,
	LastEditedBy,
	LastEditDate,
	Is3MSwab,
	UnitName,
	--Row_number() OVER (
	--	PARTITION BY OrganizationId,
	--	TestPointUniqueId,
	--	ResultId,
	--	TestMethodId ORDER BY MeasurementId
	--	) AS ReTestOrder,
	ReTestOrder,
	Archived,
	IsFinal
FROM (
	SELECT dbo.TestPlanResult.OrganizationId,
		dbo.TestPlanResult.ResultId,
		dbo.TestPointResult.MeasurementId,
		dbo.TestPlanResult.TestPlanId,
		dbo.TestPlanMaster.TestPlanName,
		dbo.TestPlanResult.OpenedDate,
		dbo.TestPointResult.TestPointId,
		dbo.TestPointMaster.TestPointName,
		CAST(dbo.TestPointResult.TestPointId AS VARCHAR(20)) AS TestPointUniqueId,
		dbo.TestPointResult.TestMethodId,
		dbo.TestPointResult.TestMethodVersion,
		dbo.TestPointResult.TestMethodName,
		dbo.TestPointResult.TestPointLocationId AS LocationId,
		dbo.TestPointResult.LocationName,
		dbo.TestPointResult.ResultTakenBy AS TesterId,
		dbo.TestPointResult.ResultTakenByName AS TesterName,
		dbo.TestPointResult.Result,
		CASE WHEN dbo.TestPointResult.ThresholdType = 1 THEN NULL ELSE dbo.TestPointResult.ResultValue END as ResultValue,
		dbo.TestPointResult.ResultDate,
		dbo.TestPointResult.CapaComments,
		CASE WHEN dbo.TestPointResult.ThresholdType = 1 THEN NULL ELSE dbo.TestPointResult.ATPPassThreshold END as PassThreshold,
        CASE WHEN dbo.TestPointResult.ThresholdType = 1 THEN NULL ELSE dbo.TestPointResult.ATPFailThreshold END as FailThreshold,
		dbo.TestPointResult.IsAdhoc AS Adhoc,
		dbo.TestPointResult.IsRetest AS Retest,
		''1'' AS Mapped,
		dbo.TestPointResult.IsEdited AS Edited,
		cast(dbo.TestPointResult.OriginalMeasurementId AS INT) AS OriginalMeasurementId,
		dbo.TestPointResult.CreatedDate,
		dbo.TestPointResult.LastEditedBy,
		dbo.TestPointResult.LastEditDate,
		dbo.TestPointResult.Is3MSwab,
		dbo.TestPointResult.UnitName,
		''0'' AS Archived,
		TestOrder as ReTestOrder,
		IsFinal
	FROM dbo.TestPlanResult 
		Inner join dbo.TestPointResult
			ON dbo.TestPlanResult.ResultId = dbo.TestPointResult.ResultId
		Inner join TestPlanMaster
			on TestPlanMaster.TestPlanId = dbo.TestPlanResult.TestPlanId
		Inner join TestPointMaster
			on TestPointMaster.TestPointId = dbo.TestPointResult.TestPointId

	UNION ALL
	
	SELECT dbo.AdhocTestPlanResult.OrganizationId,
		0 - dbo.AdhocTestPlanResult.AdhocResultId AS ResultId,
		dbo.AdhocTestPointResult.AdhocMeasurementId,
		dbo.AdhocTestPlanResult.TestPlanId,
		dbo.TestPlanMaster.TestPlanName,
		dbo.AdhocTestPlanResult.OpenedDate,
		dbo.AdhocTestPointResult.TestPointId,
		CASE 
			WHEN (dbo.AdhocTestPointResult.TestPointId = 0 or dbo.AdhocTestPointResult.TestPointId is NULL)
				THEN dbo.AdhocTestPointResult.TestPointName
			ELSE TestPointMaster.TestPointName
			END AS TestPointName,
		CASE 
			WHEN (dbo.AdhocTestPointResult.TestPointId = 0 or dbo.AdhocTestPointResult.TestPointId is NULL)
				THEN ''AHC_'' + dbo.AdhocTestPointResult.TestPointName
			ELSE CAST(dbo.AdhocTestPointResult.TestPointId AS VARCHAR(20))
		END AS TestPointUniqueId,
		dbo.AdhocTestPointResult.TestMethodId,
		dbo.AdhocTestPointResult.TestMethodVersion,
		dbo.AdhocTestPointResult.TestMethodName,
		dbo.AdhocTestPointResult.TestPointLocationId AS LocationId,
		CASE 
			WHEN (dbo.AdhocTestPointResult.TestPointLocationId = 0 or dbo.AdhocTestPointResult.TestPointLocationId is NULL)
				THEN ''No Location''
			ELSE dbo.AdhocTestPointResult.LocationName
			END AS LocationName,
		--''No Location'' AS LocationName,
		dbo.AdhocTestPointResult.ResultTakenBy AS TesterId,
		dbo.AdhocTestPointResult.ResultTakenByName AS TesterName,
		dbo.AdhocTestPointResult.Result,
		CASE WHEN dbo.AdhocTestPointResult.ThresholdType = 1 THEN NULL ELSE dbo.AdhocTestPointResult.ResultValue END as ResultValue,
		dbo.AdhocTestPointResult.ResultDate,
		dbo.AdhocTestPointResult.CapaComments,
		CASE WHEN dbo.AdhocTestPointResult.ThresholdType = 1 THEN NULL ELSE dbo.AdhocTestPointResult.ATPPassThreshold END as PassThreshold,
		CASE WHEN dbo.AdhocTestPointResult.ThresholdType = 1 THEN NULL ELSE dbo.AdhocTestPointResult.ATPFailThreshold END as FailThreshold,
		dbo.AdhocTestPointResult.IsAdhoc,
		dbo.AdhocTestPointResult.IsRetest,
		dbo.AdhocTestPointResult.IsMapped AS Mapped,
		dbo.AdhocTestPointResult.IsEdited,
		cast(dbo.AdhocTestPointResult.OriginalAdhocMeasurementId AS INT) AS OriginalMeasurementId,
		dbo.AdhocTestPointResult.CreatedDate,
		dbo.AdhocTestPointResult.LastEditedBy,
		dbo.AdhocTestPointResult.LastEditDate,
		dbo.AdhocTestPointResult.Is3MSwab,
		dbo.AdhocTestPointResult.UnitName,
		''0'' AS Archived,
		TestOrder as ReTestOrder,
		IsFinal
	FROM dbo.AdhocTestPlanResult 
		Inner join dbo.AdhocTestPointResult
			ON dbo.AdhocTestPlanResult.AdhocResultId = dbo.AdhocTestPointResult.AdhocResultId
		Inner join TestPlanMaster
			on TestPlanMaster.TestPlanId = dbo.AdhocTestPlanResult.TestPlanId
		Left join TestPointMaster
			on TestPointMaster.TestPointId = dbo.AdhocTestPointResult.TestPointId

	UNION ALL
	
	SELECT Spark_Archive.dbo.TestPlanResult.OrganizationId,
		Spark_Archive.dbo.TestPlanResult.ResultId,
		Spark_Archive.dbo.TestPointResult.MeasurementId,
		Spark_Archive.dbo.TestPlanResult.TestPlanId,
		dbo.TestPlanMaster.TestPlanName,
		Spark_Archive.dbo.TestPlanResult.OpenedDate,
		Spark_Archive.dbo.TestPointResult.TestPointId,
		dbo.TestPointMaster.TestPointName,
		CAST(Spark_Archive.dbo.TestPointResult.TestPointId AS VARCHAR(20)) AS TestPointUniqueId,
		Spark_Archive.dbo.TestPointResult.TestMethodId,
		Spark_Archive.dbo.TestPointResult.TestMethodVersion,
		Spark_Archive.dbo.TestPointResult.TestMethodName,
		Spark_Archive.dbo.TestPointResult.TestPointLocationId AS LocationId,
		Spark_Archive.dbo.TestPointResult.LocationName,
		Spark_Archive.dbo.TestPointResult.ResultTakenBy AS TesterId,
		Spark_Archive.dbo.TestPointResult.ResultTakenByName AS TesterName,
		Spark_Archive.dbo.TestPointResult.Result,
		CASE WHEN Spark_Archive.dbo.TestPointResult.ThresholdType = 1 THEN NULL ELSE Spark_Archive.dbo.TestPointResult.ResultValue END as ResultValue,
		Spark_Archive.dbo.TestPointResult.ResultDate,
		Spark_Archive.dbo.TestPointResult.CapaComments,
		CASE WHEN Spark_Archive.dbo.TestPointResult.ThresholdType = 1 THEN NULL ELSE Spark_Archive.dbo.TestPointResult.ATPPassThreshold END as PassThreshold,
		CASE WHEN Spark_Archive.dbo.TestPointResult.ThresholdType = 1 THEN NULL ELSE Spark_Archive.dbo.TestPointResult.ATPFailThreshold END as FailThreshold,
		Spark_Archive.dbo.TestPointResult.IsAdhoc AS Adhoc,
		Spark_Archive.dbo.TestPointResult.IsRetest AS Retest,
		''1'' AS Mapped,
		Spark_Archive.dbo.TestPointResult.IsEdited AS Edited,
		cast(Spark_Archive.dbo.TestPointResult.OriginalMeasurementId AS INT) AS OriginalMeasurementId,
		Spark_Archive.dbo.TestPointResult.CreatedDate,
		Spark_Archive.dbo.TestPointResult.LastEditedBy,
		Spark_Archive.dbo.TestPointResult.LastEditDate,
		Spark_Archive.dbo.TestPointResult.Is3MSwab,
		Spark_Archive.dbo.TestPointResult.UnitName,
		''1'' AS Archived,
		Spark_Archive.dbo.TestPointResult.TestOrder as ReTestOrder,
		IsFinal
	FROM Spark_Archive.dbo.TestPlanResult 
		Inner join Spark_Archive.dbo.TestPointResult
			ON Spark_Archive.dbo.TestPlanResult.ResultId = Spark_Archive.dbo.TestPointResult.ResultId
		Inner join TestPlanMaster
			on TestPlanMaster.TestPlanId = Spark_Archive.dbo.TestPlanResult.TestPlanId
		Inner join TestPointMaster
			on TestPointMaster.TestPointId = Spark_Archive.dbo.TestPointResult.TestPointId

	UNION ALL
	
	SELECT Spark_Archive.dbo.AdhocTestPlanResult.OrganizationId,
		0 - Spark_Archive.dbo.AdhocTestPlanResult.AdhocResultId AS ResultId,
		Spark_Archive.dbo.AdhocTestPointResult.AdhocMeasurementId,
		Spark_Archive.dbo.AdhocTestPlanResult.TestPlanId,
		dbo.TestPlanMaster.TestPlanName,
		Spark_Archive.dbo.AdhocTestPlanResult.OpenedDate,
		Spark_Archive.dbo.AdhocTestPointResult.TestPointId,
		CASE 
			WHEN (Spark_Archive.dbo.AdhocTestPointResult.TestPointId = 0 or Spark_Archive.dbo.AdhocTestPointResult.TestPointId is NULL)
				THEN Spark_Archive.dbo.AdhocTestPointResult.TestPointName
			ELSE dbo.TestPointMaster.TestPointName
			END AS TestPointName,
		CASE 
			WHEN (Spark_Archive.dbo.AdhocTestPointResult.TestPointId = 0 or Spark_Archive.dbo.AdhocTestPointResult.TestPointId is NULL)
				THEN ''AHC_'' + Spark_Archive.dbo.AdhocTestPointResult.TestPointName
			ELSE CAST(Spark_Archive.dbo.AdhocTestPointResult.TestPointId AS VARCHAR(20))
			END AS TestPointUniqueId,
		Spark_Archive.dbo.AdhocTestPointResult.TestMethodId,
		Spark_Archive.dbo.AdhocTestPointResult.TestMethodVersion,
		Spark_Archive.dbo.AdhocTestPointResult.TestMethodName,
		Spark_Archive.dbo.AdhocTestPointResult.TestPointLocationId AS LocationId,
		CASE 
			WHEN (Spark_Archive.dbo.AdhocTestPointResult.TestPointLocationId = 0 or Spark_Archive.dbo.AdhocTestPointResult.TestPointLocationId is NULL)
				THEN ''No Location''
			ELSE Spark_Archive.dbo.AdhocTestPointResult.LocationName
			END AS LocationName,
		--''No Location'' AS LocationName,
		Spark_Archive.dbo.AdhocTestPointResult.ResultTakenBy AS TesterId,
		Spark_Archive.dbo.AdhocTestPointResult.ResultTakenByName AS TesterName,
		Spark_Archive.dbo.AdhocTestPointResult.Result,
		CASE WHEN Spark_Archive.dbo.AdhocTestPointResult.ThresholdType = 1 THEN NULL ELSE Spark_Archive.dbo.AdhocTestPointResult.ResultValue END as ResultValue,
		Spark_Archive.dbo.AdhocTestPointResult.ResultDate,
		Spark_Archive.dbo.AdhocTestPointResult.CapaComments,
		CASE WHEN Spark_Archive.dbo.AdhocTestPointResult.ThresholdType = 1 THEN NULL ELSE Spark_Archive.dbo.AdhocTestPointResult.ATPPassThreshold END as PassThreshold,
		CASE WHEN Spark_Archive.dbo.AdhocTestPointResult.ThresholdType = 1 THEN NULL ELSE Spark_Archive.dbo.AdhocTestPointResult.ATPFailThreshold END as FailThreshold,
		Spark_Archive.dbo.AdhocTestPointResult.IsAdhoc,
		Spark_Archive.dbo.AdhocTestPointResult.IsRetest,
		Spark_Archive.dbo.AdhocTestPointResult.IsMapped AS Mapped,
		Spark_Archive.dbo.AdhocTestPointResult.IsEdited,
		cast(Spark_Archive.dbo.AdhocTestPointResult.OriginalAdhocMeasurementId AS INT) AS OriginalMeasurementId,
		Spark_Archive.dbo.AdhocTestPointResult.CreatedDate,
		Spark_Archive.dbo.AdhocTestPointResult.LastEditedBy,
		Spark_Archive.dbo.AdhocTestPointResult.LastEditDate,
		Spark_Archive.dbo.AdhocTestPointResult.Is3MSwab,
		Spark_Archive.dbo.AdhocTestPointResult.UnitName,
		''1'' AS Archived,
		Spark_Archive.dbo.AdhocTestPointResult.TestOrder as ReTestOrder,
		IsFinal
	FROM Spark_Archive.dbo.AdhocTestPlanResult
		inner join Spark_Archive.dbo.AdhocTestPointResult
			On Spark_Archive.dbo.AdhocTestPlanResult.AdhocResultId = Spark_Archive.dbo.AdhocTestPointResult.AdhocResultId
		Inner join dbo.TestPlanMaster
			on dbo.TestPlanMaster.TestPlanId = Spark_Archive.dbo.AdhocTestPlanResult.TestPlanId
		Left join dbo.TestPointMaster
			on dbo.TestPointMaster.TestPointId = Spark_Archive.dbo.AdhocTestPointResult.TestPointId
	) c

' 
GO

GO
/****** Object:  StoredProcedure [dbo].[USP_LUMINOMETER_PLANT_MAPPING]    Script Date: 1/23/2019 5:00:38 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[USP_LUMINOMETER_PLANT_MAPPING]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[USP_LUMINOMETER_PLANT_MAPPING]
GO
/****** Object:  StoredProcedure [dbo].[USP_LUMINOMETER_PLANT_MAPPING]    Script Date: 1/23/2019 5:00:38 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[USP_LUMINOMETER_PLANT_MAPPING]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'create Procedure [dbo].[USP_LUMINOMETER_PLANT_MAPPING] (@location_id varchar(max))
as
begin

------------------recursive query------------------

WITH ret AS(
        SELECT  ParentLocationId,LocationId
        FROM    LocationMaster
        WHERE   LocationId  in(select value from dbo.fn_Split(@location_id, '',''))
        UNION ALL
        SELECT   t.ParentLocationId,t.LocationId
        FROM    LocationMaster t INNER JOIN
                ret r ON t.ParentLocationId = r.LocationId
)

SELECT  * into #44
FROM    ret

--------------part 2--------------

select distinct  c.TestPlanId 
into #FINAL_TEST_PLAN_ID_FOR_UPDATE
from 
#44  a join TestPointMaster b
on a.LocationId=b.LocationId
join TestPlanTestPointMapping c
on b.TestPointId=c.TestPointId
join TestPlanMaster d
on c.TestPlanId=d.TestPlanId

select distinct a.TestPlanId 
from TestPlanMaster  a  JOIN  #FINAL_TEST_PLAN_ID_FOR_UPDATE B
ON A.TestPlanId=B.TestPlanId


End' 
END
GO
