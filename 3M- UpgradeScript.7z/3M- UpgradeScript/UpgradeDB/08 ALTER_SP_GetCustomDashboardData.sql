USE [Spark]
GO
/****** Object:  StoredProcedure [dbo].[GetCustomDashboardData]    Script Date: 6/11/2021 5:46:25 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 
/****** Object:  StoredProcedure [dbo].[GetDashboardData]    Script Date: 05/03/2020 4:27:40 PM ******/

ALTER Procedure [dbo].[GetCustomDashboardData]
(
	@OrganizationId INT,
	@StartDate DATETIME2,
	@EndDate DATETIME2,
	@TestTypes VARCHAR(Max),
	@samplePlans Varchar(Max),
	@LocationPlantArray Varchar(Max),
	@flag bit,
	@userId varchar(Max)
)
AS
BEGIN TRY
	BEGIN TRANSACTION;

SET NOCOUNT ON
SET ARITHABORT ON;

	DECLARE @AllTestPlans bit
	DECLARE @AllTestTypes bit
	DECLARE @AllLocations bit
	DECLARE @AllUserId bit
	DECLARE @AllLocationsFromUser INT
	Declare @AllLocationsFromDB INT
    Declare @UnplannedSelected INT


	------------------To avoid records of locations(plants) for which user dont have access we are removing "0" from LocationPlantArray------------------
Declare @Exclude varchar(2)='0'
Select @LocationPlantArray = reverse(stuff(reverse(stuff(replace(','+@LocationPlantArray+',',','+@Exclude+',',','),1,1,'')),1,1,''))
-----------------------------------------------------------------------------------------------------------------------------------------------------

	------------------split test types and store in #TestTypesIdtbl table
    CREATE TABLE #TestTypesIdtbl (TestTypeId INT)
	INSERT INTO #TestTypesIdtbl
	SELECT [value]
	FROM dbo.fn_Split(@TestTypes, ',')

	------------------split Sample Plans and store in #SamplePlansIdtbl table
	CREATE TABLE #SamplePlansIdtbl (SamplePlanId INT)
	INSERT INTO #SamplePlansIdtbl
	SELECT [value]
	FROM dbo.fn_Split(@samplePlans, ',')

	------------------split LocationPlants and store in #PlantsIdtbl table
	CREATE TABLE #PlantsIdtbl (PlantId INT)
	INSERT INTO #PlantsIdtbl
	SELECT [value]
	FROM dbo.fn_Split(@LocationPlantArray, ',')

	CREATE TABLE #UserIdIdtbl (UserId INT)
	INSERT INTO #UserIdIdtbl
	SELECT [value]
	FROM dbo.fn_Split(@userId, ',')
	select @AllUserId = case when count(1) >0 then 0 else 1 end from #UserIdIdtbl

	select @AllTestPlans = case when count(1) >0 then 0 else 1 end from #SamplePlansIdtbl
	select @AllTestTypes = case when count(1) >0 then 0 else 1 end from #TestTypesIdtbl
	Select @AllLocations = case when count(1) >0 then 0 else 1 end from #PlantsIdtbl
	Select @AllLocationsFromDB =  count(1) from LocationMaster where OrganizationId = @OrganizationId and ParentLocationId = 0
	Select @AllLocationsFromUser = count(1) from #PlantsIdtbl

	Select @UnplannedSelected = count(1) from #SamplePlansIdtbl where SamplePlanId = 1

    -----------------take parent plan Id from #PlantsIdtbl and retrive its all childs and store them into #FinalPlantsIdtbl and then add LocationPlants(first level plants in #FinalPlantsIdtbl table)
    CREATE TABLE #FinalPlantsIdtbl (FinalPlanId INT);
    CREATE TABLE #FinalAdhocPlantsIdtbl (FinalPlanId INT);

 

    if(@UnplannedSelected > 0)
    BEGIN
        Insert INTO #FinalAdhocPlantsIdtbl (FinalPlanId) Values(0) 
    END

	if(@AllLocations != 1)
	BEGIN
	
	WITH Locationtbl AS
	(
		SELECT LocationId
			FROM LocationMaster WHERE ParentLocationId in (select PlantId from #PlantsIdtbl) and Status = 1 and LocationMaster.OrganizationId = @OrganizationId
		UNION ALL
		SELECT LocationMaster.LocationId FROM LocationMaster  JOIN Locationtbl  ON LocationMaster.ParentLocationId = Locationtbl.LocationId where LocationMaster.Status = 1 and LocationMaster.OrganizationId = @OrganizationId
	)

	INSERT INTO #FinalPlantsIdtbl
	SELECT LocationId 
	FROM Locationtbl

	Insert INTO #FinalPlantsIdtbl
	SELECT PlantId 
	from #PlantsIdtbl

	Insert INTO #FinalAdhocPlantsIdtbl
    SELECT FinalPlanId
    from #FinalPlantsIdtbl

	OPTION(MAXRECURSION 32767)
	END

	---------------Filter data from DashboardView
	SELECT dbo.TestPlanResult.OrganizationId,
		dbo.TestPlanResult.ResultId,
		dbo.TestPointResult.MeasurementId,
		dbo.TestPlanResult.TestPlanId,
		dbo.TestPlanMaster.TestPlanName,
		dbo.TestPointMaster.TestPointName,
		CAST(dbo.TestPointResult.TestPointId AS VARCHAR(20)) AS TestPointUniqueId,
		dbo.TestPointResult.ResultTakenBy AS TesterId,
		dbo.TestPointResult.Result,
		dbo.TestPointResult.ResultDate,
		dbo.TestPointResult.IsRetest AS Retest,		
		dbo.TestPointResult.Is3MSwab,		
		TestOrder AS ReTestOrder,
		dbo.TestPointMaster.LocationId,
		dbo.OrganizationTestMethodVersions.TestMethodName,   --Added for testtype
        dbo.LocationMaster.Description As HierarchicalLocationName,
        dbo.OrganizationTestMethodMaster.[Order] As TestTypeOrder,
		CASE 
			WHEN (CharIndex('>',dbo.LocationMaster.Description) > 0)
				THEN  Substring(dbo.LocationMaster.Description,0,CharIndex('>',dbo.LocationMaster.Description))
			ELSE dbo.LocationMaster.Description
			END As LevelOneLocationName
	FROM dbo.TestPlanResult
		INNER JOIN dbo.TestPointResult ON dbo.TestPlanResult.ResultId = dbo.TestPointResult.ResultId
		Inner join dbo.TestPlanMaster on dbo.TestPlanMaster.TestPlanId = dbo.TestPlanResult.TestPlanId
		Inner join dbo.TestPointMaster on dbo.TestPointMaster.TestPointId = dbo.TestPointResult.TestPointId
		Inner join dbo.LocationMaster on dbo.LocationMaster.LocationId = dbo.TestPointMaster.LocationId and dbo.LocationMaster.OrganizationId = dbo.TestPointMaster.OrganizationId
        inner join dbo.OrganizationTestMethodMaster on dbo.TestPointResult.TestMethodId = dbo.OrganizationTestMethodMaster.TestMethodId
		Inner join dbo.OrganizationTestMethodVersions on dbo.OrganizationTestMethodVersions.TestMethodId =  dbo.TestPointResult.TestMethodId
	WHERE dbo.TestPlanResult.OrganizationId = @OrganizationId 
	and dbo.TestPointResult.ResultDate between @StartDate and @EndDate
	and (dbo.TestPointResult.TestMethodId in (select TestTypeId from #TestTypesIdtbl) or @AllTestTypes=1)
	and (dbo.TestPlanResult.TestPlanId in (select SamplePlanId from #SamplePlansIdtbl) or @AllTestPlans = 1) 
	and (dbo.TestPointResult.TestPointLocationId in (select FinalPlanId from #FinalPlantsIdtbl) or @AllLocations = 1) 
	AND (dbo.TestPointResult.ResultTakenBy in(SELECT userid FROM #UserIdIdtbl) or @AllUserId=1)
	AND dbo.OrganizationTestMethodVersions.IsCurrent = 1 
	UNION ALL

	SELECT dbo.AdhocTestPlanResult.OrganizationId,
		0 - dbo.AdhocTestPlanResult.AdhocResultId AS ResultId,
		dbo.AdhocTestPointResult.AdhocMeasurementId,
		dbo.AdhocTestPlanResult.TestPlanId,
		dbo.TestPlanMaster.TestPlanName,
		CASE 
			WHEN (dbo.AdhocTestPointResult.TestPointId = 0 or dbo.AdhocTestPointResult.TestPointId is NULL)
				THEN dbo.AdhocTestPointResult.TestPointName
			ELSE dbo.TestPointMaster.TestPointName
			END AS TestPointName,
		CASE 
			WHEN (dbo.AdhocTestPointResult.TestPointId = 0 or dbo.AdhocTestPointResult.TestPointId is NULL)
				THEN 'AHC_' + dbo.AdhocTestPointResult.TestPointName
			ELSE CAST(dbo.AdhocTestPointResult.TestPointId AS VARCHAR(20))
			END AS TestPointUniqueId,		
		dbo.AdhocTestPointResult.ResultTakenBy AS TesterId,
		dbo.AdhocTestPointResult.Result,		
		dbo.AdhocTestPointResult.ResultDate,
		dbo.AdhocTestPointResult.IsRetest,
		dbo.AdhocTestPointResult.Is3MSwab,
		TestOrder AS ReTestOrder,
		CASE 
			WHEN (dbo.AdhocTestPointResult.TestPointId = 0 or dbo.AdhocTestPointResult.TestPointId is NULL)
				THEN dbo.AdhocTestPointResult.TestPointLocationId
			ELSE dbo.TestPointMaster.LocationId
			END AS LocationId,
	    dbo.OrganizationTestMethodVersions.TestMethodName,   --Added for testtype
        dbo.LocationMaster.Description As HierarchicalLocationName,
        dbo.OrganizationTestMethodMaster.[Order] As TestTypeOrder,
		CASE 
			WHEN (dbo.AdhocTestPointResult.TestPointId = 0 or dbo.AdhocTestPointResult.TestPointId is NULL)
				THEN dbo.LocationMaster.Description
			ELSE Substring(dbo.LocationMaster.Description,0,CharIndex('>',dbo.LocationMaster.Description))
			END As LevelOneLocationName

	FROM dbo.AdhocTestPlanResult
		INNER JOIN dbo.AdhocTestPointResult ON dbo.AdhocTestPlanResult.AdhocResultId = dbo.AdhocTestPointResult.AdhocResultId
		Inner join dbo.TestPlanMaster on dbo.TestPlanMaster.TestPlanId = dbo.AdhocTestPlanResult.TestPlanId
		LEFT join dbo.TestPointMaster on dbo.TestPointMaster.TestPointId = dbo.AdhocTestPointResult.TestPointId
		LEFT join dbo.LocationMaster on dbo.LocationMaster.LocationId = dbo.AdhocTestPointResult.TestPointLocationId
        inner join dbo.OrganizationTestMethodMaster on dbo.AdhocTestPointResult.TestMethodId = dbo.OrganizationTestMethodMaster.TestMethodId
		Inner join dbo.OrganizationTestMethodVersions on dbo.OrganizationTestMethodVersions.TestMethodId =  dbo.AdhocTestPointResult.TestMethodId
	WHERE dbo.AdhocTestPlanResult.OrganizationId = @OrganizationId
		AND dbo.AdhocTestPointResult.ResultDate BETWEEN @StartDate AND @EndDate
		AND (dbo.AdhocTestPointResult.TestMethodId IN (SELECT TestTypeId FROM #TestTypesIdtbl) OR @AllTestTypes = 1)
		AND ( dbo.AdhocTestPlanResult.TestPlanId IN (SELECT SamplePlanId FROM #SamplePlansIdtbl) OR @AllTestPlans = 1)
		and (dbo.AdhocTestPointResult.TestPointLocationId in (select FinalPlanId from #FinalAdhocPlantsIdtbl) or @AllLocations = 1 or (@AllLocationsFromUser = @AllLocationsFromDB))
		AND (dbo.AdhocTestPointResult.ResultTakenBy in(SELECT userid FROM #UserIdIdtbl) or @AllUserId=1)
		AND dbo.OrganizationTestMethodVersions.IsCurrent = 1 
	UNION ALL

	SELECT Spark_Archive.dbo.TestPlanResult.OrganizationId,
		Spark_Archive.dbo.TestPlanResult.ResultId,
		Spark_Archive.dbo.TestPointResult.MeasurementId,
		Spark_Archive.dbo.TestPlanResult.TestPlanId,
		dbo.TestPlanMaster.TestPlanName,
		dbo.TestPointMaster.TestPointName,
		CAST(Spark_Archive.dbo.TestPointResult.TestPointId AS VARCHAR(20)) AS TestPointUniqueId,
		Spark_Archive.dbo.TestPointResult.ResultTakenBy AS TesterId,
		Spark_Archive.dbo.TestPointResult.Result,
		Spark_Archive.dbo.TestPointResult.ResultDate,
		Spark_Archive.dbo.TestPointResult.IsRetest AS Retest,
		Spark_Archive.dbo.TestPointResult.Is3MSwab,
		Spark_Archive.dbo.TestPointResult.TestOrder AS ReTestOrder,
		dbo.TestPointMaster.LocationId,
		dbo.OrganizationTestMethodVersions.TestMethodName,   --Added for testtype
        dbo.LocationMaster.Description As HierarchicalLocationName,
        dbo.OrganizationTestMethodMaster.[Order] As TestTypeOrder,
		CASE 
			WHEN (CharIndex('>',dbo.LocationMaster.Description) > 0)
				THEN  Substring(dbo.LocationMaster.Description,0,CharIndex('>',dbo.LocationMaster.Description))
			ELSE dbo.LocationMaster.Description
			END As LevelOneLocationName
	FROM Spark_Archive.dbo.TestPlanResult
		INNER JOIN Spark_Archive.dbo.TestPointResult ON Spark_Archive.dbo.TestPlanResult.ResultId = Spark_Archive.dbo.TestPointResult.ResultId
		Inner join dbo.TestPlanMaster on dbo.TestPlanMaster.TestPlanId = Spark_Archive.dbo.TestPlanResult.TestPlanId
		Inner join dbo.TestPointMaster on dbo.TestPointMaster.TestPointId = Spark_Archive.dbo.TestPointResult.TestPointId
		Inner join dbo.LocationMaster on dbo.LocationMaster.LocationId = dbo.TestPointMaster.LocationId and dbo.LocationMaster.OrganizationId = dbo.TestPointMaster.OrganizationId
        inner join dbo.OrganizationTestMethodMaster on Spark_Archive.dbo.TestPointResult.TestMethodId = dbo.OrganizationTestMethodMaster.TestMethodId
		Inner join dbo.OrganizationTestMethodVersions on dbo.OrganizationTestMethodVersions.TestMethodId =  Spark_Archive.dbo.TestPointResult.TestMethodId
	WHERE Spark_Archive.dbo.TestPlanResult.OrganizationId = @OrganizationId
		AND Spark_Archive.dbo.TestPointResult.ResultDate BETWEEN @StartDate AND @EndDate
		AND (Spark_Archive.dbo.TestPointResult.TestMethodId IN ( SELECT TestTypeId FROM #TestTypesIdtbl) OR @AllTestTypes = 1)
		AND ( Spark_Archive.dbo.TestPlanResult.TestPlanId IN ( SELECT SamplePlanId FROM #SamplePlansIdtbl) OR @AllTestPlans = 1)
		and (Spark_Archive.dbo.TestPointResult.TestPointLocationId in (select FinalPlanId from #FinalPlantsIdtbl) or @AllLocations = 1)
		AND (Spark_Archive.dbo.TestPointResult.ResultTakenBy in(SELECT userid FROM #UserIdIdtbl) or @AllUserId=1) 
		AND dbo.OrganizationTestMethodVersions.IsCurrent = 1
	UNION ALL

	 SELECT Spark_Archive.dbo.AdhocTestPlanResult.OrganizationId,
        0 - Spark_Archive.dbo.AdhocTestPlanResult.AdhocResultId AS ResultId,
        Spark_Archive.dbo.AdhocTestPointResult.AdhocMeasurementId,
        Spark_Archive.dbo.AdhocTestPlanResult.TestPlanId,
        dbo.TestPlanMaster.TestPlanName,
        CASE 
            WHEN (Spark_Archive.dbo.AdhocTestPointResult.TestPointId = 0 or Spark_Archive.dbo.AdhocTestPointResult.TestPointId is NULL)
                THEN Spark_Archive.dbo.AdhocTestPointResult.TestPointName
            ELSE dbo.TestPointMaster.TestPointName
            END AS TestPointName,
        CASE 
            WHEN (Spark_Archive.dbo.AdhocTestPointResult.TestPointId = 0 or Spark_Archive.dbo.AdhocTestPointResult.TestPointId is NULL)
                THEN 'AHC_' + Spark_Archive.dbo.AdhocTestPointResult.TestPointName
            ELSE CAST(Spark_Archive.dbo.AdhocTestPointResult.TestPointId AS VARCHAR(20))
            END AS TestPointUniqueId,
        Spark_Archive.dbo.AdhocTestPointResult.ResultTakenBy AS TesterId,
        Spark_Archive.dbo.AdhocTestPointResult.Result,
        Spark_Archive.dbo.AdhocTestPointResult.ResultDate,
        Spark_Archive.dbo.AdhocTestPointResult.IsRetest,
        Spark_Archive.dbo.AdhocTestPointResult.Is3MSwab,
        Spark_Archive.dbo.AdhocTestPointResult.TestOrder AS ReTestOrder,
        CASE 
            WHEN (Spark_Archive.dbo.AdhocTestPointResult.TestPointId = 0 or Spark_Archive.dbo.AdhocTestPointResult.TestPointId is NULL)
                THEN Spark_Archive.dbo.AdhocTestPointResult.TestPointLocationId
            ELSE dbo.TestPointMaster.LocationId
            END AS LoactionId,
        dbo.OrganizationTestMethodVersions.TestMethodName, -----Added testtype
        dbo.LocationMaster.Description As HierarchicalLocationName,
        dbo.OrganizationTestMethodMaster.[Order] As TestTypeOrder,
		CASE 
			WHEN (Spark_Archive.dbo.AdhocTestPointResult.TestPointId = 0 or Spark_Archive.dbo.AdhocTestPointResult.TestPointId is NULL)
				THEN dbo.LocationMaster.Description
			ELSE Substring(dbo.LocationMaster.Description,0,CharIndex('>',dbo.LocationMaster.Description))
			END As LevelOneLocationName

    FROM Spark_Archive.dbo.AdhocTestPlanResult
        INNER JOIN Spark_Archive.dbo.AdhocTestPointResult ON Spark_Archive.dbo.AdhocTestPlanResult.AdhocResultId = Spark_Archive.dbo.AdhocTestPointResult.AdhocResultId
        Inner join dbo.TestPlanMaster on dbo.TestPlanMaster.TestPlanId = Spark_Archive.dbo.AdhocTestPlanResult.TestPlanId
        Inner join dbo.TestPointMaster on dbo.TestPointMaster.TestPointId = Spark_Archive.dbo.AdhocTestPointResult.TestPointId
        Inner join dbo.LocationMaster on dbo.LocationMaster.LocationId = Spark_Archive.dbo.AdhocTestPointResult.TestPointLocationId
        Inner join dbo.OrganizationTestMethodMaster on Spark_Archive.dbo.AdhocTestPointResult.TestMethodId = dbo.OrganizationTestMethodMaster.TestMethodId
		Inner join dbo.OrganizationTestMethodVersions on dbo.OrganizationTestMethodVersions.TestMethodId =  Spark_Archive.dbo.AdhocTestPointResult.TestMethodId
	WHERE Spark_Archive.dbo.AdhocTestPlanResult.OrganizationId = @OrganizationId
		AND Spark_Archive.dbo.AdhocTestPointResult.ResultDate BETWEEN @StartDate AND @EndDate
		AND (Spark_Archive.dbo.AdhocTestPointResult.TestMethodId IN ( SELECT TestTypeId FROM #TestTypesIdtbl) OR @AllTestTypes = 1)
		AND ( Spark_Archive.dbo.AdhocTestPlanResult.TestPlanId IN ( SELECT SamplePlanId FROM #SamplePlansIdtbl) OR @AllTestPlans = 1)
		and (Spark_Archive.dbo.AdhocTestPointResult.TestPointLocationId in (select FinalPlanId from #FinalPlantsIdtbl union select 0) or @AllLocations = 1)
		AND (Spark_Archive.dbo.AdhocTestPointResult.ResultTakenBy in(SELECT userid FROM #UserIdIdtbl) or @AllUserId=1)
		AND dbo.OrganizationTestMethodVersions.IsCurrent = 1
	DROP TABLE #TestTypesIdtbl
	DROP TABLE #SamplePlansIdtbl
	DROP TABLE #FinalPlantsIdtbl
	DROP TABLE #UserIdIdtbl
	COMMIT TRANSACTION;
END TRY
BEGIN CATCH
	ROLLBACK TRANSACTION;
END CATCH;