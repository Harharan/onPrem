/*20C change: Update Result Date to local date and set UtcResultDate
This update will happen only when user upgrade from 20B or lower version to current version
*/
Use Spark
Go
declare @PackageVersion int
Declare @orgTimeZone nvarchar(100)
Declare @utcOffset int;
Select @orgTimeZone = TimezoneName from OrganizationConfiguration
select @utcOffset = UtcOffset from TimezoneMaster where Timezone = @orgTimeZone
Select @PackageVersion=(select top 1 REPLACE(PackageVersion, '.', '') from ApplicationInformation where IsUninstall= 1 order by id desc)
if(@PackageVersion<1501 or (@PackageVersion = 15022 and (select count(ResultId) from TestPointResult where UtcResultDate is null) > 0))
Begin
update TestPointResult set UtcResultDate = TestPointResult.ResultDate
update TestPointResult set ResultDate = DATEADD(MINUTE,@utcOffset,TestPointResult.ResultDate), TimeZoneName = @orgTimeZone
update AdhocTestPointResult set UtcResultDate = AdhocTestPointResult.ResultDate
update AdhocTestPointResult set ResultDate = DATEADD(MINUTE,@utcOffset,AdhocTestPointResult.ResultDate), TimeZoneName = @orgTimeZone
End
Use Spark_Archive
if(@PackageVersion<1501 or (@PackageVersion = 15022 and (select count(ResultId) from TestPointResult where UtcResultDate is null) > 0))
Begin
update TestPointResult set UtcResultDate = TestPointResult.ResultDate
update TestPointResult set ResultDate = DATEADD(MINUTE,@utcOffset,TestPointResult.ResultDate), TimeZoneName = @orgTimeZone
update AdhocTestPointResult set UtcResultDate = AdhocTestPointResult.ResultDate
update AdhocTestPointResult set ResultDate = DATEADD(MINUTE,@utcOffset,AdhocTestPointResult.ResultDate), TimeZoneName = @orgTimeZone
End
