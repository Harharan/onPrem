USE [Spark]
GO

/****** Object:  UserDefinedTableType [dbo].[TestPointIdList_Type]    Script Date: 01.27.2022 06:41:17 PM ******/
CREATE TYPE [dbo].[TestPointIdList_Type] AS TABLE(
	[LocationId] [int] NULL,
	[OrganizationId] [int] NULL
)
GO


