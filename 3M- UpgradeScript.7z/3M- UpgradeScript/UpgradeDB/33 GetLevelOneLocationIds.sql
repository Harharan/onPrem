USE [Spark]
GO

/****** Object:  UserDefinedFunction [dbo].[GetLevelOneLocationIds]    Script Date: 19-11-2020 22:05:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT *
           FROM   sys.objects
           WHERE  object_id = OBJECT_ID(N'[dbo].[GetLevelOneLocationIds]')
                  AND type IN ( N'FN', N'IF', N'TF', N'FS', N'FT' ))
  DROP FUNCTION [dbo].[GetLevelOneLocationIds]

GO 

CREATE FUNCTION [dbo].[GetLevelOneLocationIds](@LocationList varchar(max), @OrganizationId int)
RETURNS @FinalPlantsIdtbl TABLE 
(
    -- columns returned by the function
    FinalPlanId INT
)
AS
BEGIN

------------------split LocationPlants and store in @PlantsIdtbl table
DECLARE @LocationIdtbl AS TABLE (LocationId INT)
INSERT INTO @LocationIdtbl
SELECT [value]
FROM dbo.fn_Split(@LocationList, ',');

WITH Locationtbl AS
(
    SELECT *
        FROM LocationMaster WHERE LocationId in (select lm.ParentLocationId from @LocationIdtbl t Inner join LocationMaster lm on t.LocationId=lm.LocationId) and Status = 1 and LocationMaster.OrganizationId = @OrganizationId
    UNION ALL
    SELECT LocationMaster.* FROM LocationMaster JOIN Locationtbl  ON LocationMaster.LocationId = Locationtbl.ParentLocationId where LocationMaster.Status = 1 and LocationMaster.OrganizationId = @OrganizationId
)

INSERT INTO @FinalPlantsIdtbl
SELECT distinct LocationId 
FROM Locationtbl where ParentLocationId = 0
UNION
SELECT DISTINCT LocationId FROM LocationMaster WHERE ParentLocationId = 0 
and LocationId in (SELECT LocationId from @LocationIdtbl)


OPTION(MAXRECURSION 32767)

RETURN
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetLevelOneLocations]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GetLevelOneLocations]
GO

CREATE Procedure [dbo].[GetLevelOneLocations]
(
@OrganizationId INT,
@LocationList VARCHAR(MAX) 
)

AS
BEGIN

select FinalPlanId from dbo.[GetLevelOneLocationIds](@LocationList, @OrganizationId)
END



