USE [Spark];
GO

IF EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointMaster]')
AND name in ('TestPointName') 
)
BEGIN
ALTER TABLE [dbo].[TestPointMaster] ALTER COLUMN  TestPointName NVARCHAR(MAX)
Update [dbo].[TestPointMaster] SET ImageLastEditedDate = NULL WHERE TestPointImage IS NULL
END
Go

-- ALTER TABLE [dbo].[TestPointMaster] ALTER COLUMN  TestPointName NVARCHAR(MAX)
-- GO 


IF EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPlanMaster]')
AND name in ('TestPlanName') 
)
BEGIN
ALTER TABLE [dbo].[TestPlanMaster] ALTER COLUMN TestPlanName NVARCHAR(MAX)
END
Go

-- ALTER TABLE [dbo].[TestPlanMaster] ALTER COLUMN TestPlanName NVARCHAR(MAX)
-- GO


IF EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointResult]')
AND name in ('TestPointName') 
)
BEGIN
ALTER TABLE [dbo].[TestPointResult]  ALTER COLUMN TestPointName NVARCHAR(MAX)
END
Go

IF EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointResult]')
AND name in ('LocationName') 
)
BEGIN
ALTER TABLE [dbo].[TestPointResult]  ALTER COLUMN LocationName NVARCHAR(MAX)
END
Go





IF EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPlanResult]')
AND name in ('TestPlanName') 
)
BEGIN
ALTER TABLE [dbo].[TestPlanResult]  ALTER COLUMN TestPlanName NVARCHAR(MAX)
END
Go


IF EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[AdhocTestPlanResult]')
AND name in ('TestPlanName') 
)
BEGIN
ALTER TABLE [dbo].[AdhocTestPlanResult]  ALTER COLUMN TestPlanName NVARCHAR(MAX)
END
Go


IF EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]')
AND name in ('TestPointName') 
)
BEGIN
ALTER TABLE [dbo].[AdhocTestPointResult] ALTER COLUMN TestPointName NVARCHAR(MAX)
END
Go



IF EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]')
AND name in ('LocationName') 
)
BEGIN
ALTER TABLE [dbo].[AdhocTestPointResult] ALTER COLUMN LocationName NVARCHAR(MAX)  
END
Go


IF EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[LocationMaster]')
AND name in ('LocationName') 
)
BEGIN
ALTER TABLE [dbo].[LocationMaster] ALTER COLUMN LocationName NVARCHAR(MAX)  
END
Go

IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[LocationMaster]') 
AND name = 'StateId'
)
BEGIN
	ALTER TABLE [dbo].[LocationMaster] ADD  [StateId] [int] NULL 
END
GO

IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[LocationMaster]') 
AND name = 'CityId'
)
BEGIN
	ALTER TABLE [dbo].[LocationMaster] ADD  [CityId] [int] NULL
END
GO


IF EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[ScheduleDefinitionMaster]')
AND name in ('ScheduleName') 
)
BEGIN
ALTER TABLE [dbo].[ScheduleDefinitionMaster] ALTER COLUMN ScheduleName NVARCHAR(MAX)
END
Go



-- ALTER TABLE [dbo].[ScheduleDefinitionMaster] ALTER COLUMN ScheduleName NVARCHAR(MAX)
-- GO

IF EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[LuminometerMaster]')
AND name in ('OSVersion') 
)
BEGIN
ALTER TABLE [dbo].[LuminometerMaster] ALTER  COLUMN OSVersion nvarchar(50) 
END
Go

-- ALTER TABLE [dbo].[LuminometerMaster] ALTER  COLUMN OSVersion nvarchar(50) 
-- GO



IF EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[LuminometerMaster]')
AND name in ('FirmwareVersion') 
)
BEGIN
ALTER TABLE [dbo].[LuminometerMaster] ALTER  COLUMN FirmwareVersion nvarchar(50)
END
Go


-- ALTER TABLE [dbo].[LuminometerMaster] ALTER  COLUMN FirmwareVersion nvarchar(50)
-- GO

IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[OrganizationTestMethodMaster]') 
AND name = 'Order'
)
BEGIN
	ALTER TABLE [dbo].[OrganizationTestMethodMaster] ADD [Order] int null
END
GO

IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]') 
AND name = 'IsFinal'
)
BEGIN
	ALTER TABLE [dbo].[AdhocTestPointResult] ADD [IsFinal] bit null
END
GO

IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]') 
AND name = 'TestOrder'
)
BEGIN
	ALTER TABLE [dbo].[AdhocTestPointResult] ADD [TestOrder] int null
END
GO

IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointResult]') 
AND name = 'IsFinal'
)
BEGIN
	ALTER TABLE [dbo].[TestPointResult] ADD [IsFinal] bit null
END
GO

IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointResult]') 
AND name = 'TestOrder'
)
BEGIN
	ALTER TABLE [dbo].[TestPointResult] ADD [TestOrder] int null
END
GO


IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanResult]') AND name = N'NCI-TestPlanResult-Oid-RidTplid')
DROP INDEX [NCI-TestPlanResult-Oid-RidTplid] ON [dbo].[TestPlanResult]
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanResult]') AND name = N'NCI-TestPlanResult-Oid-RidTplid')
CREATE NONCLUSTERED INDEX [NCI-TestPlanResult-Oid-RidTplid] ON [dbo].[TestPlanResult]
(
	[OrganizationId] ASC
)
INCLUDE ( 	[ResultId],
	[TestPlanId]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPlanResult]') AND name = N'NCI-AdhocTestPlanResult-Oid-RidTplid')
DROP INDEX [NCI-AdhocTestPlanResult-Oid-RidTplid] ON [dbo].[AdhocTestPlanResult]
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPlanResult]') AND name = N'NCI-AdhocTestPlanResult-Oid-RidTplid')
CREATE NONCLUSTERED INDEX [NCI-AdhocTestPlanResult-Oid-RidTplid] ON [dbo].[AdhocTestPlanResult]
(
	[OrganizationId] ASC
)
INCLUDE ( 	[AdhocResultId],
	[TestPlanId]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPointResult]') AND name = N'NCI-TestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To')
DROP INDEX [NCI-TestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To] ON [dbo].[TestPointResult]
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPointResult]') AND name = N'NCI-TestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To')
CREATE NONCLUSTERED INDEX [NCI-TestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To] ON [dbo].[TestPointResult]
(
	[ResultDate] ASC
)
INCLUDE ( 	[ResultId],
	[MeasurementId],
	[TestPointId],
	[TestPointLocationId],
	[TestMethodId],
	[IsRetest],
	[Result],
	[ResultTakenBy],
	[Is3MSwab],
	[TestOrder]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]') AND name = N'NCI-AdhocTestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To')
DROP INDEX [NCI-AdhocTestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To] ON [dbo].[AdhocTestPointResult]
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]') AND name = N'NCI-AdhocTestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To')
CREATE NONCLUSTERED INDEX [NCI-AdhocTestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To] ON [dbo].[AdhocTestPointResult]
(
	[ResultDate] ASC
)
INCLUDE ( 	[AdhocResultId],
	[AdhocMeasurementId],
	[TestPointId],
	[TestPointLocationId],
	[TestMethodId],
	[IsRetest],
	[Result],
	[ResultTakenBy],
	[Is3MSwab],
	[TestOrder]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[UserMaster]') 
AND name = 'IsLoginRequired'
)
BEGIN
	ALTER TABLE [dbo].[UserMaster] ADD [IsLoginRequired] bit NOT NULL DEFAULT 1
END
GO

IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[UserMaster]') 
AND name = 'IsDashboardLoaded'
)
BEGIN
	ALTER TABLE [dbo].[UserMaster] ADD [IsDashboardLoaded] bit NULL
END
GO


Declare @PackageVersion INT = (select top 1 REPLACE(PackageVersion, '.', '') from ApplicationInformation where IsUninstall= 1 order by id desc)
if(@PackageVersion<1501)
BEGIN
UPDATE TestMethodMaster
SET TestMethodName = 'pH', ShortName = 'pH'
WHERE TestMethodId = 5


UPDATE TestMethodMaster
SET TestMethodName = 'AQF 100 (Water Free ATP)', ShortName = 'AQF'
WHERE TestMethodId = 2


UPDATE TestMethodMaster
SET TestMethodName = 'AQT 200 (Water Total ATP)', ShortName = 'AQT'
WHERE TestMethodId = 3



UPDATE TestMethodMaster
SET TestMethodName = 'UXL 100 (Surface ATP)', ShortName = 'UXL100'
WHERE TestMethodId = 1


UPDATE OrganizationTestMethodVersions
SET TestMethodName = 'AQF 100 (Water Free ATP)', ShortName = 'AQF'
WHERE TestMethodId = 2 and OrganizationId = 1


UPDATE OrganizationTestMethodVersions
SET TestMethodName = 'AQT 200 (Water Total ATP)', ShortName = 'AQT'
WHERE TestMethodId = 3 and OrganizationId = 1


UPDATE OrganizationTestMethodVersions
SET TestMethodName = 'UXL 100 (Surface ATP)', ShortName = 'UXL100'
WHERE TestMethodId = 1 and OrganizationId = 1;

END

update UserMaster 
set IsLoginRequired=0 
where LoginName is null and IsLoginRequired=1
GO

IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[FailedLoginAttempts]') 
AND name = 'AttemptType'
)
BEGIN
	ALTER TABLE [dbo].[FailedLoginAttempts] ADD [AttemptType] SMALLINT NOT NULL DEFAULT 1
END
GO

IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[OrganizationConfiguration]') 
AND name = 'DeleteObjects'
)
BEGIN
	ALTER TABLE [dbo].[OrganizationConfiguration] ADD [DeleteObjects] BIT NOT NULL DEFAULT 1
END
GO

IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[LuminometerMaster]') 
AND name = 'FirmwareVersionNew'
)
BEGIN
	ALTER TABLE [dbo].[LuminometerMaster] ADD [FirmwareVersionNew] NVARCHAR(50)
END
GO


IF NOT EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[TimezoneMaster]')
AND name in ('TimeZoneShortName','CountryName','UtcOffset') 
)
BEGIN
ALTER TABLE [Spark].[dbo].[TimezoneMaster] Add TimeZoneShortName nvarchar(30), CountryName nvarchar(2000), UtcOffset int;
END
Go

USE Spark_Archive
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointResult]')
AND name = 'UtcResultDate'
)
BEGIN
ALTER TABLE [Spark_Archive].[dbo].[TestPointResult] Add UtcResultDate datetime;
END
Go

USE Spark_Archive
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]')
AND name = 'UtcResultDate'
)
BEGIN
ALTER TABLE [Spark_Archive].[dbo].[AdhocTestPointResult] Add UtcResultDate datetime;
END
Go

USE Spark
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointResult]')
AND name = 'UtcResultDate'
)
BEGIN
ALTER TABLE [Spark].[dbo].[TestPointResult] Add UtcResultDate datetime;
END
Go

USE Spark
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]')
AND name = 'UtcResultDate'
)
BEGIN
ALTER TABLE [Spark].[dbo].[AdhocTestPointResult] Add UtcResultDate datetime;
END

IF NOT EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[ScheduleDefinitionMaster]')
AND name = 'ScheduleMonthlyOrder'
)
BEGIN
ALTER TABLE [Spark].[dbo].[ScheduleDefinitionMaster] Add ScheduleMonthlyOrder smallint;
END

IF NOT EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[ScheduleDefinitionMaster]')
AND name = 'ScheduleMonthlyPattern'
)
BEGIN
ALTER TABLE [Spark].[dbo].[ScheduleDefinitionMaster] Add ScheduleMonthlyPattern smallint;
END
Go


/*************************Timezoneshortcode column added*****************************/
Use [Spark]
Go


IF NOT EXISTS (SELECT * FROM sys.columns
WHERE object_id = OBJECT_ID(N'[dbo].[TestPointResult]')
AND name = 'TimeZoneShortCode'
)
BEGIN
alter table TestPointResult
add TimeZoneShortCode varchar(8)
END

IF NOT EXISTS (SELECT * FROM sys.columns
WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]')
AND name = 'TimeZoneShortCode'
)
BEGIN
alter table AdhocTestPointResult
add TimeZoneShortCode varchar(8)
END

IF NOT EXISTS (SELECT * FROM sys.columns
WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanTestPointMapping]')
AND name = 'LocationId'
)
BEGIN
Alter table [Spark].[dbo].[TestPlanTestPointMapping]
add LocationId int Null
END

Use [Spark_Archive]
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE object_id = OBJECT_ID(N'[Spark_Archive].[dbo].[AdhocTestPointResult]')
AND name = 'TimeZoneShortCode'
)
BEGIN
alter table [Spark_Archive].[dbo].AdhocTestPointResult
add TimeZoneShortCode varchar(8)
END

IF NOT EXISTS (SELECT * FROM sys.columns
WHERE object_id = OBJECT_ID(N'[Spark_Archive].[dbo].[TestPointResult]')
AND name = 'TimeZoneShortCode'
)
BEGIN
alter table [Spark_Archive].[dbo].TestPointResult
add TimeZoneShortCode varchar(8)
END
Go

Use [Spark]
Go
IF NOT EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[OrganizationMaster]')
AND name in ('IsHavingMultiLocationSamplePlan') 
)
BEGIN
ALTER TABLE [dbo].[OrganizationMaster] add IsHavingMultiLocationSamplePlan bit not null Default 0
END
Go
