USE Spark
Go
UPDATE [OrganizationConfiguration]
	   SET [OrganizationConfiguration].DeleteObjects = 1,
	   [OrganizationConfiguration].ChangeTestPointThreshold=1,
	   [OrganizationConfiguration].RequireStrongPassword =1
GO