 Use [Spark]
    Go
    IF NOT EXISTS (SELECT * FROM sys.columns
    WHERE object_id = OBJECT_ID(N'[dbo].[EntityLocationMapping]')
    AND name = 'PrimaryLocationId'
    )
    BEGIN
    ALTER TABLE [Spark].[dbo].EntityLocationMapping Add PrimaryLocationId int;
    END
--Script End for Primary Location Id adding column.

 

--Script Start for Entity Location Mapping Primary Location Id Entry
    Use [Spark]
    Go
    CREATE TABLE #EntityLocationTempTable (id INT, Locationid INT) 
    Insert into #EntityLocationTempTable 
           Select EntityID,Min(el.LocationId) as Locationid 
           from EntityLocationMapping el inner join locationmaster lm on  el.locationid=lm.locationid where lm.Status<>2
           group by EntityID

 

    Update entitylocationmappingtable 
    Set entitylocationmappingtable.primarylocationid=entitytemptable.Locationid
    From EntityLocationMapping entitylocationmappingtable 
    inner join #EntityLocationTempTable entitytemptable 
    on entitylocationmappingtable.EntityID=entitytemptable.id 
    Where entitylocationmappingtable.primarylocationid is null

 

    Drop table #EntityLocationTempTable