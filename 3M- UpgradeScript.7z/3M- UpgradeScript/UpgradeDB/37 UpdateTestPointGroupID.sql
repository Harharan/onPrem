Use Spark
Go
Create Table #Temp_GroupIdTP
(
Id Int Identity(1,1),
TP_GroupId Int
)

Insert Into #Temp_GroupIdTP
Select Distinct TestPointGroupId From TestPointMaster

Declare @Min Int,@Max Int
Select @Min=Min(TP_GroupId),@Max=Max(TP_GroupId) From #Temp_GroupIdTP
While(@Min<=@Max)
	Begin
		Declare @TP_GroupId Int
		Select @TP_GroupId=TP_GroupId From #Temp_GroupIdTP Where Id=@Min
		Select TestPointId,TestPointGroupId,TestPointName,[dbo].[GetParentLoctaionHierarchyIds](LocationId,1) ParentLocationId,LocationId 
		Into #TP_Master 
		From TestPointMaster Where TestPointGroupId=@TP_GroupId

		Create Table #TP_ParentLocId(Id Int Identity(1,1),ParentLocationId Int)
		Insert Into #TP_ParentLocId
		Select ParentLocationId From #TP_Master group by ParentLocationId

		If((SELECT @@ROWCOUNT)>1)
			Begin
				Declare @MinP Int,@MaxP Int,@ExitingMinP Int,@ParentLocationId Int,@TestPointGroupId Int
				Select @MinP=Min(Id),@MaxP=Max(Id),@ExitingMinP=Min(Id) From #TP_ParentLocId
				While(@MinP<=@MaxP)
					Begin						
						if(@ExitingMinP<@MinP)
							Begin
								Select @ParentLocationId=ParentLocationId From #TP_ParentLocId Where Id=@MinP
								Select @TestPointGroupId=(Max(TestPointGroupId)+1) From TestPointMaster
								
								Update TestPointMaster Set TestPointGroupId=@TestPointGroupId 
								Where TestPointGroupId=@TP_GroupId and [dbo].[GetParentLoctaionHierarchyIds](LocationId,1)=@ParentLocationId						
							End
						Set @MinP=@MinP+1
					End
			End
		Set @Min=@Min+1
		Drop Table #TP_Master
		Drop Table #TP_ParentLocId
	End
Drop Table #Temp_GroupIdTP