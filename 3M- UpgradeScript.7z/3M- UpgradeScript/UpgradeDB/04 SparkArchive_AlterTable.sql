USE [Spark_Archive];
GO


IF EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[AdhocTestPlanResult]')
AND name in ('TestPlanName') 
)
BEGIN
ALTER TABLE [dbo].[AdhocTestPlanResult]  ALTER COLUMN TestPlanName NVARCHAR(MAX)
END
Go

-- ALTER TABLE [dbo].[AdhocTestPlanResult]  ALTER COLUMN  TestPlanName NVARCHAR(MAX)
-- GO


IF EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]')
AND name in ('TestPointName') 
)
BEGIN
ALTER TABLE [dbo].[AdhocTestPointResult] ALTER COLUMN TestPointName NVARCHAR(MAX)
END
Go



IF EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]')
AND name in ('LocationName') 
)
BEGIN
ALTER TABLE [dbo].[AdhocTestPointResult] ALTER COLUMN LocationName NVARCHAR(MAX)  
END
Go

-- ALTER TABLE [dbo].[AdhocTestPointResult] ALTER COLUMN  TestPointName NVARCHAR(MAX)
-- ALTER TABLE [dbo].[AdhocTestPointResult] ALTER COLUMN  LocationName NVARCHAR(MAX)  
-- GO



IF EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPlanResult]')
AND name in ('TestPlanName') 
)
BEGIN
ALTER TABLE [dbo].[TestPlanResult]  ALTER COLUMN TestPlanName NVARCHAR(MAX)
END
Go

-- ALTER TABLE [dbo].[TestPlanResult]  ALTER COLUMN  TestPlanName NVARCHAR(MAX)
-- GO





IF EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointResult]')
AND name in ('TestPointName') 
)
BEGIN
ALTER TABLE [dbo].[TestPointResult]  ALTER COLUMN TestPointName NVARCHAR(MAX)
END
Go

IF EXISTS (SELECT * FROM sys.columns
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointResult]')
AND name in ('LocationName') 
)
BEGIN
ALTER TABLE [dbo].[TestPointResult]  ALTER COLUMN LocationName NVARCHAR(MAX)
END
Go

-- ALTER TABLE [dbo].[TestPointResult]  ALTER COLUMN  TestPointName NVARCHAR(MAX)
-- ALTER TABLE [dbo].[TestPointResult]  ALTER COLUMN LocationName NVARCHAR(MAX)
-- GO



IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]') 
AND name = 'IsFinal'
)
BEGIN
	ALTER TABLE [dbo].[AdhocTestPointResult] ADD [IsFinal] bit null
END
GO

IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]') 
AND name = 'TestOrder'
)
BEGIN
	ALTER TABLE [dbo].[AdhocTestPointResult] ADD [TestOrder] int null
END
GO

IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointResult]') 
AND name = 'IsFinal'
)
BEGIN
	ALTER TABLE [dbo].[TestPointResult] ADD [IsFinal] bit null
END
GO

IF NOT EXISTS (SELECT * FROM sys.columns 
WHERE  object_id = OBJECT_ID(N'[dbo].[TestPointResult]') 
AND name = 'TestOrder'
)
BEGIN
	ALTER TABLE [dbo].[TestPointResult] ADD [TestOrder] int null
END
GO


IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanResult]') AND name = N'NCI-TestPlanResult-Oid-RidTplid')
DROP INDEX [NCI-TestPlanResult-Oid-RidTplid] ON [dbo].[TestPlanResult]
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPlanResult]') AND name = N'NCI-TestPlanResult-Oid-RidTplid')
CREATE NONCLUSTERED INDEX [NCI-TestPlanResult-Oid-RidTplid] ON [dbo].[TestPlanResult]
(
	[OrganizationId] ASC
)
INCLUDE ( 	[ResultId],
	[TestPlanId]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPlanResult]') AND name = N'NCI-AdhocTestPlanResult-Oid-RidTplid')
DROP INDEX [NCI-AdhocTestPlanResult-Oid-RidTplid] ON [dbo].[AdhocTestPlanResult]
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPlanResult]') AND name = N'NCI-AdhocTestPlanResult-Oid-RidTplid')
CREATE NONCLUSTERED INDEX [NCI-AdhocTestPlanResult-Oid-RidTplid] ON [dbo].[AdhocTestPlanResult]
(
	[OrganizationId] ASC
)
INCLUDE ( 	[AdhocResultId],
	[TestPlanId]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPointResult]') AND name = N'NCI-TestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To')
DROP INDEX [NCI-TestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To] ON [dbo].[TestPointResult]
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TestPointResult]') AND name = N'NCI-TestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To')
CREATE NONCLUSTERED INDEX [NCI-TestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To] ON [dbo].[TestPointResult]
(
	[ResultDate] ASC
)
INCLUDE ( 	[ResultId],
	[MeasurementId],
	[TestPointId],
	[TestPointLocationId],
	[TestMethodId],
	[IsRetest],
	[Result],
	[ResultTakenBy],
	[Is3MSwab],
	[TestOrder]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]') AND name = N'NCI-AdhocTestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To')
DROP INDEX [NCI-AdhocTestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To] ON [dbo].[AdhocTestPointResult]
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AdhocTestPointResult]') AND name = N'NCI-AdhocTestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To')
CREATE NONCLUSTERED INDEX [NCI-AdhocTestPointResult-Rd-RidMidTpoidTpolidTmidIrRtbI3To] ON [dbo].[AdhocTestPointResult]
(
	[ResultDate] ASC
)
INCLUDE ( 	[AdhocResultId],
	[AdhocMeasurementId],
	[TestPointId],
	[TestPointLocationId],
	[TestMethodId],
	[IsRetest],
	[Result],
	[ResultTakenBy],
	[Is3MSwab],
	[TestOrder]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
