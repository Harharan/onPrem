USE [Spark];
GO

/****** Object:  Table [dbo].[UserDashboardFilters]    Script Date: 4/23/2018 8:27:27 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserDashboardFilters]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UserDashboardFilters](
	[UserId] [int] NOT NULL,
	[DashboardFilterXml] [nvarchar](max) NOT NULL,
	[locationHierarchy] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO

/****** Object:  Table [dbo].[LuminometerPlantMapping]    Script Date: 11/30/2018 4:51:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LuminometerPlantMapping]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[LuminometerPlantMapping](
		   [OrganizationId] [int] NOT NULL,
		   [LuminometerId] [int] NOT NULL,
		   [DeviceSerialNumber] [nvarchar](50) NOT NULL,
		   [LocationId] [int] NOT NULL,
		   [CreatedDate] [datetime] NOT NULL,
		   [CreatedBy] [int] NOT NULL,
		   [LastEditDate] [datetime] NULL,
		   [LastEditedBy] [int] NULL,
	CONSTRAINT [PK_LMPlantMapping] PRIMARY KEY CLUSTERED 
	(
		   [OrganizationId] ASC,
		   [LuminometerId] ASC,
		   [LocationId] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY]

	ALTER TABLE [dbo].[LuminometerPlantMapping]  WITH CHECK ADD  CONSTRAINT [FK_LMPlantLocationId] FOREIGN KEY([LocationId], [OrganizationId])
	REFERENCES [dbo].[LocationMaster] ([LocationId], [OrganizationId])

	ALTER TABLE [dbo].[LuminometerPlantMapping] CHECK CONSTRAINT [FK_LMPlantLocationId]

	ALTER TABLE [dbo].[LuminometerPlantMapping]  WITH CHECK ADD  CONSTRAINT [FK_LMPlantLuminometerId] FOREIGN KEY([LuminometerId])
	REFERENCES [dbo].[LuminometerMaster] ([LuminometerId])

	ALTER TABLE [dbo].[LuminometerPlantMapping] CHECK CONSTRAINT [FK_LMPlantLuminometerId]

	ALTER TABLE [dbo].[LuminometerPlantMapping]  WITH CHECK ADD  CONSTRAINT [FK_LMPlantOrganizationId] FOREIGN KEY([OrganizationId])
	REFERENCES [dbo].[OrganizationMaster] ([OrganizationId])

	ALTER TABLE [dbo].[LuminometerPlantMapping] CHECK CONSTRAINT [FK_LMPlantOrganizationId]

END
GO

IF OBJECT_ID ( '[dbo].[CustomParameterLocationMapping]', 'U' ) IS  NULL     
Begin
CREATE TABLE [dbo].[CustomParameterLocationMapping](
	[OrganizationId] [int] NOT NULL,
	[CategoryId] [int] NOT NULL,
	[ParameterId] [int] NOT NULL,
	[LocationId] [int] NOT NULL,
	[LocationLevel] [int] NULL
 CONSTRAINT [PK_CustomParameterLocationMapping] PRIMARY KEY CLUSTERED 
(
	[OrganizationId] ASC,
	[CategoryId] ASC,
	[ParameterId] ASC,
	[LocationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

End
GO

IF OBJECT_ID ( '[dbo].[CountryTimezoneMapping]', 'U' ) IS  NULL     
Begin
CREATE TABLE [dbo].[CountryTimezoneMapping](
	[MappingId] [int] IDENTITY(1,1) NOT NULL,
	[TimezoneId] [int] NULL,
	[CountryId] [int] NULL
) ON [PRIMARY]
End
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserTestPointFilters]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UserTestPointFilters](
	[UserId] [int] NOT NULL,
	[DateSelectedFilter] varchar(max),
PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
Go



/***********************  RoleFeaturesGroup   *************************/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RoleFeaturesGroup]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[RoleFeaturesGroup](
	[FeatureGroupId] [int] NOT NULL,
	[FeatureGroupName] [nvarchar](100) NOT NULL,
	[Order] [int] NOT NULL,

 CONSTRAINT [PK_RoleFeaturesGroup] PRIMARY KEY CLUSTERED 
(
	[FeatureGroupId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO


/***********************  RoleFeatureMaster   *************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RoleFeatureMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[RoleFeatureMaster](
	[FeatureId] [int] NOT NULL,
	[FeatureName] [nvarchar](100) NOT NULL,
	[FeatureGroupId] [int] NOT NULL,
	[Order] [int] NOT NULL,

 CONSTRAINT [PK_RoleFeatureMaster] PRIMARY KEY CLUSTERED 
(
	[FeatureId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO


/***********************  PermissionMaster   *************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PermissionMaster]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PermissionMaster](
	[Id] [int] NOT NULL,
	[OrganizationId] [int] NOT NULL,
	[RoleId] [int] NOT NULL,
	[FeatureId] [int] NOT NULL,
	[Permission] [int] NOT NULL,

 CONSTRAINT [PK_PermissionMaster] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO

/****** Object:  Table [dbo].[LocationPrefrence]    Script Date: 7/23/2021 9:55:20 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LocationPreference]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[LocationPreference](
		[OrganizationId] [int] NOT NULL,
		[LocationId] [int] NOT NULL,
		[DateFormat] [nvarchar](30) NULL,
		[NumberFormat] [smallint] NULL,
		[TemperatureUnit] [smallint] NOT NULL,
		[IsMilitaryTime] [bit] NULL,
		[SessionTimeout] [int] NULL,
		[RequirePasswordForDevice] [bit] NOT NULL,
		[MobileDataStoragePeriod] [smallint] NOT NULL,
	 CONSTRAINT [PK_LocationPreference] PRIMARY KEY CLUSTERED 
	(
		[LocationId] ASC,
		[OrganizationId] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY]

	ALTER TABLE [dbo].[LocationPreference]  WITH CHECK ADD  CONSTRAINT [FK_LocationPreference_LocationMaster] FOREIGN KEY([LocationId], [OrganizationId])
	REFERENCES [dbo].[LocationMaster] ([LocationId], [OrganizationId])

	ALTER TABLE [dbo].[LocationPreference] CHECK CONSTRAINT [FK_LocationPreference_LocationMaster]
END
GO

/****** Object:  Table [dbo].[Cities_Master]    Script Date: 7/30/2021 6:03:45 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Cities_Master]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[Cities_Master](
		[CityID] [int] NOT NULL,
		[Name] [nvarchar](255) NOT NULL,
		[StateId] [int] NOT NULL,
		[StateCode] [nvarchar](255) NOT NULL,
		[CountryId] [int] NOT NULL,
		[CountryCode] [char](2) NOT NULL
	) ON [PRIMARY]
END
GO

/****** Object:  Table [dbo].[States_Master]    Script Date: 7/30/2021 6:03:45 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[States_Master]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[States_Master](
		[StateId] [int] NOT NULL,
		[Name] [nvarchar](255) NOT NULL,
		[StateCode] [nvarchar](255) NULL,
		[ShortName] [nvarchar](255) NULL,
		[CountryId] [int] NOT NULL,
		[CountryCode] [char](2) NOT NULL
	) ON [PRIMARY]

END
GO

