IF OBJECT_ID ( '[dbo].[GetTestPointDetails]', 'P' ) IS NOT NULL   
    DROP PROCEDURE [dbo].[GetTestPointDetails]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****** Object:  StoredProcedure [dbo].[GetTestPointDetails]    Script Date: 05/03/2020 4:27:40 PM ******/
Create Procedure [dbo].[GetTestPointDetails]
(
--Declare 
@OrganizationId INT,
@LocationArray VARCHAR(MAX) 
)
--Set @OrganizationId=1
AS 
BEGIN
------------------split LocationPlants and store in @PlantsIdtbl table
DECLARE @PlantsIdtbl AS TABLE (PlantId INT)
INSERT INTO @PlantsIdtbl
SELECT [value]
FROM dbo.fn_Split(@LocationArray, ',')

DECLARE @AllLocations bit
Select @AllLocations = case when count(1) >0 then 0 else 1 end from @PlantsIdtbl

Declare @dependent bit

if(@AllLocations != 1)
BEGIN
Declare @LocationIdtbl as table (ID int)
Insert into @LocationIdtbl 
select FinalPlanId from dbo.[GetLoctaionHierarchyIds](@LocationArray,@OrganizationId)
END


Select
TPM.OrganizationId,
TPM.TestPointId,
TPM.TestPointName,
TPM.Status,
TPM.Description,
LM.LocationId,
TPM.TestPointVersion,
LM.LocationName,
TPM.CreatedDate,
LM.Status as LocationStatus,
OCF.ChangeTestPointThreshold,
ISNULL(TM.TestPlanName,'') SamplePlanName,

case when TM.TestPlanName is not null 
then CAST(1 AS BIT)
else 
case when exists (select Top 1 1 from TestPointResult  where TestPointResult.TestPointId = TPM.TestPointId ) then CAST(1 AS BIT) 
else CAST(0 AS BIT) end
end as IsDependent ,

case when exists (select Top 1 1 from TestPlanTestPointMapping where TestPlanTestPointMapping.TestPointId = TPM.TestPointId ) then CAST(1 AS BIT) else CAST(0 AS BIT) end as IsAssociatedToTestPlan ,

case when LM.Status=2 then '-' Else case when (select dbo.GetParentLocationName(LM.LocationId,TPM.OrganizationId)) is null then LM.LocationName else (select dbo.GetParentLocationName(LM.LocationId,TPM.OrganizationId)) end end as HierarchicalLocationName,

(select dbo.GetTestTypeNames(TPM.TestPointId,TPM.OrganizationId)) As AssociatedTestTypeName

from  TestPointMaster TPM
join LocationMaster LM on LM.LocationId = TPM.LocationId and LM.OrganizationId = TPM.OrganizationId
join OrganizationConfiguration OCF on OCF.OrganizationId = TPM.OrganizationId
left  join TestPlanTestPointMapping TPPM on TPPM.OrganizationId = TPM.OrganizationId and TPPM.TestPointId = TPM.TestPointId and TPPM.TestPointVersion = TPM.TestPointVersion
left  join TestPlanMaster TM on TM.OrganizationId = TPM.OrganizationId and TM.TestPlanId = TPPM.TestPlanId and TM.TestPlanVersion = TPPM.TestPlanVersion

where TPM.OrganizationId = @OrganizationId and TPM.Status !=3
and (TPM.LocationId in (select ID from @LocationIdtbl) or @AllLocations = 1) Order By TPM.Status, TPM.CreatedDate desc

END
Go