Use Spark
Go
UPDATE [Spark].[dbo].[UserMaster]
SET [UserMaster].PreferencesSet = 0
FROM [Spark].[dbo].[UserMaster] UM
INNER JOIN [Spark].[dbo].[UserPreferences] UP ON UM.UserID = UP.UserId
where UP.SecretAnswer is NULL;
Declare @InstalledVersion INT = (select top 1 REPLACE(PackageVersion, '.', '') from ApplicationInformation where IsUninstall= 1 order by id desc)
if(@InstalledVersion < 15022) -- update for versions before 20C
BEGIN
Insert Into CustomParameterLocationMapping
Select OTM.OrganizationId,otm.OrganizationCategoryId,otm.ParameterId,Lm.LocationId,null From OrganizationCustomParameterVersions OTM
cross join LocationMaster Lm
Left Join CustomParameterLocationMapping Em on Em.LocationId=Lm.LocationId and Em.ParameterId=OTM.ParameterId and Em.CategoryId=otm.OrganizationCategoryId
Where ParentLocationId=0 And Em.LocationId Is null And OTM.IsCurrent = 1 And OTM.[Status] != 3
 
Insert Into EntityLocationMapping(OrganizationId,
EntityType,EntityID,LocationId,LocationLevel)
Select OTM.OrganizationId,4,CommentId,Lm.LocationId,null From CapaComments OTM
cross join LocationMaster Lm
Left Join Entitylocationmapping Em on Em.LocationId=Lm.LocationId and Em.EntityID=OTM.CommentId and Em.EntityType=4
Where ParentLocationId=0 And Em.LocationId Is null
END 