USE [Spark]
GO
/****** Object:  StoredProcedure [dbo].[GetReportDataSet]    Script Date: 29-07-2020 15:44:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetReportDataSet]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GetReportDataSet]
GO

-- EXEC [GetReportDataSet] 1,'5/12/2018 6:00:00 AM','5/19/2018 5:59:59 AM','1,2,3,4,5','1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55','7,27,36,37,30,35'
-- EXEC [GetReportDataSet] 1,'2000-01-01','2018-05-31','','',''

create Procedure [dbo].[GetReportDataSet]
@OrganizationId int,
@StartDate DATETIME2,
@EndDate DATETIME2,
@TestPlanId nvarchar(max) = '',
@TestTypeId nvarchar(max) = '',
@LocationId nvarchar(max)  = '',
@TesterId varchar(max)  = '',
@Result varchar(max) = '',
@IncludeRetest bit = 1,
@ResultMin float = null,
@ResultMax float = null,
@Variable varchar(max) = ''
as
begin

declare @TestPlanIds as table(TestPlanId int)
declare @AllTestPlans bit

declare @TestTypeIds as table(TestTypeId int)
declare @AllTestTypes bit

declare @LocationIds as table(LocationId int)
declare @AllLocation bit

declare @TesterIds as table(TesterId int)
declare @AllTesterId bit

declare @Results as table(Result int)
declare @AllResult bit

declare @Variables as table(CategoryId int, ParameterId int)
declare @AllVariable bit

declare @TestResults as table(ResultId int, MeasurementId int)
declare @AllTestResults bit

insert into @TestPlanIds(TestPlanId)
select value
FROM dbo.fn_split(@TestPlanId,',')

insert into @TestTypeIds(TestTypeId)
SELECT Distinct value from dbo.fn_split(@TestTypeId, ',')

insert into @LocationIds(LocationId)
SELECT value from dbo.fn_split(@LocationId, ',')

insert into @TesterIds(TesterId)
SELECT value from dbo.fn_split(@TesterId, ',')

insert into @Results(Result)
SELECT value from dbo.fn_split(@Result, ',')

insert into @Variables(CategoryId,ParameterId)
SELECT SUBSTRING(value,1,(CHARINDEX(',',value)- 1)), SUBSTRING(value,(CHARINDEX(',',value)+1), LEN(value)) from dbo.fn_split(@Variable, '|')
--UNION ALL
--SELECT 0

--if exists (select TestTypeId from @TestTypeIds where TestTypeId = 5)
--BEGIN
--	INSERT INTO @TestTypeIds(TestTypeId)
--	select TestMethodId
--	FROM OrganizationTestMethodMaster 
--	where OrganizationId = @OrganizationId and TestMethodId > 5
--END

select @AllTestPlans = case when count(1) >0 then 1 else 0 end from @TestPlanIds
select @AllTestTypes = case when count(1) >0 then 1 else 0 end from @TestTypeIds
select @AllLocation = case when count(1) >0 then 1 else 0 end from @LocationIds
select @AllTesterId = case when count(1) >0 then 1 else 0 end from @TesterIds
select @AllResult = case when count(1) >0 then 1 else 0 end from @Results
select @AllVariable = case when count(1) >0 then 1 else 0 end from @Variables
--set @StartDate = LEFT(CONVERT(nvarchar,@StartDate,120),11) + N'00:00:00'
--set @EndDate = LEFT(CONVERT(nvarchar,@EndDate,120),11) + N'23:59:59'

IF(@AllVariable = 1)
BEGIN
	insert into @TestResults (ResultId, MeasurementId)
	Select Distinct ResultId, MeasurementId from
	(Select ResultId, MeasurementId 
		from TestResultCustomParameterMapping tr
			inner join @Variables v
				on v.CategoryId = tr.OrganizationCategoryId and v.ParameterId = tr.ParameterId
	--Union
	--Select ResultId, MeasurementId 
	--	from Spark_Archive.dbo.TestResultCustomParameterMapping tr
	--		inner join @Variables v
	--			on v.CategoryId = tr.OrganizationCategoryId and v.ParameterId = tr.ParameterId 
	) x
END

--Select * from @TestResults

select @AllTestResults = case when count(1) >0 then 1 else 0 end from @TestResults

SELECT 
	dbv.OrganizationId,
	dbv.ResultId,
	dbv.MeasurementId,
	dbv.TestPlanId,
	TestPlanName,
	OpenedDate,
	TestPointId,
	TestPointUniqueId,
	TestPointName,
	OTMM.TestType as TestMethodId, 
	OTMV.TestMethodVersion,
	Case When OTMM.TestType = 2 then OTMV.TestMethodName else OTMV.ShortName ENd as TestMethodName, 
	dbv.LocationId,
	dbv.LocationName,
	dbv.TesterId,
	UM.FirstName + ' ' + UM.LastName as TesterName,
	dbv.Result,
	ResultValue,
	ResultDate,
	CapaComments,
	dbv.PassThreshold,
	dbv.FailThreshold,
	dbv.MinRange,
	dbv.MaxRange,
	dbv.ThresholdType,
	Adhoc,
	Retest,
	Mapped,
	Edited,
	OriginalMeasurementId,
	dbv.CreatedDate,
	dbv.LastEditedBy,
	dbv.LastEditDate,
	ReTestOrder,
	RowNo,
	Is3MSwab,
	UnitName,
	Archived,
	IsFinal,
	TimeZoneName,
	TimeZoneShortName,
	TestMethodShortName,
	HierarchicalLocationName	 
Into #ResultSet
from DashBoardView dbv
		left join OrganizationTestMethodMaster OTMM on dbv.OrganizationId = OTMM.OrganizationID and dbv.TestMethodId = OTMM.TestMethodId
		left join OrganizationTestMethodVersions OTMV on OTMV.OrganizationId = OTMM.OrganizationID and OTMV.TestMethodId = OTMM.TestMethodId and OTMV.IsCurrent=1
		left join UserMaster UM on UM.UserId = dbv.TesterId -- To Be Removed
		--left join TestMethodMaster TMM on OTMM.TestMethodId = TMM.TestMethodId
		left join @TestPlanIds t on t.TestPlanId = dbv.TestPlanId
		left join @TestTypeIds tt on dbv.TestMethodId = tt.TestTypeId --OTMM.TestType = tt.TestTypeId
		left join @LocationIds l on dbv.LocationId = l.LocationId
		left join @TesterIds Tester on dbv.TesterId = Tester.TesterId
		left join @Results r on dbv.Result = r.Result
		left join @TestResults tr on dbv.ResultId = tr.ResultId and  dbv.MeasurementId = tr.MeasurementId
where dbv.OrganizationId = @OrganizationId 
and ResultDate between @StartDate and @EndDate
and (@AllTestPlans = 0 or t.TestPlanId is not null) 
and (@AllTestTypes = 0 or tt.TestTypeId is not null)
and (@AllLocation = 0 or l.LocationId is not null)
and (@AllTesterId = 0 or Tester.TesterId is not null)
and (@AllResult = 0 or r.Result is not null)
and (@AllTestResults = 0 or tr.ResultId is not null)
and dbv.Retest = case When @IncludeRetest = 1 then dbv.Retest else 0 End
and ((dbv.ResultValue is null and  @ResultMax is null and @ResultMin is null) 
					Or  dbv.ResultValue Between (case When @ResultMin is null then dbv.ResultValue else @ResultMin End)
										And (case When @ResultMax is null then dbv.ResultValue else @ResultMax End))

Select * from #ResultSet

Select case when (select dbo.GetParentLocationName(LocationId, OrganizationId)) is null then LocationName else (select dbo.GetParentLocationName(LocationId, OrganizationId)) end as LocationName
from (Select Distinct LocationId,OrganizationId,LocationName from #ResultSet) as Locations 

Select UM.FirstName + ' ' + UM.LastName as TesterName
from (Select Distinct TesterId from #ResultSet) as Testers 
inner join UserMaster UM on UM.UserId = Testers.TesterId

Declare @TotalTest int, @RetestFailCount int

Select 
	@TotalTest = Count(1) from #ResultSet

Select 
	@RetestFailCount = Count(1) from #ResultSet
Where Retest = 1 and Result = 3		

Select ReTestOrder as TestOrder, 
		Count(1) as TestCount,
		Count(case when Result = 0 then 1 else null END) UntestedCount,
		Count(case when Result = 1 then 1 else null END) PassCount,
		Count(case when Result = 2 then 1 else null END) CautionCount,
		Count(case when Result = 3 then 1 else null END) FailCount
into #TestOrderWise
from #ResultSet
Group By ReTestOrder

Select 
	TestCount as InitialTestsCount, 
	PassCount as InitialPassTestsCount,
	CautionCount as InitialCautionTestsCount,
	FailCount as InitialFailTestsCount,
	@RetestFailCount as RetestFailCount,
	@TotalTest as TotalTest
from #TestOrderWise
Where TestOrder = 1

Select
	TestOrder, 
	TestCount, 
	PassCount,
	CautionCount,
	FailCount,
	UntestedCount,
	CumulativePercentage = (Cast(TestCount as float) / ISNULL((
		select 
			--(Sum(a.TestCount) / isnull(Sum(b.TestCount),1))  
			Sum(b.TestCount)
		from #TestOrderWise b
		where (b.TestOrder + 1) = a.TestOrder
	),TestCount) ) * 100.00
from #TestOrderWise a

DROP TABLE #ResultSet
DROP TABLE #TestOrderWise

END
--Select Top 1 * from DashBoardView
