USE [Spark]
GO
IF OBJECT_ID ( '[dbo].[UpdateUsersPrimaryLocationsOnDelete]', 'P' ) IS NOT NULL   
    DROP PROCEDURE [dbo].[UpdateUsersPrimaryLocationsOnDelete]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE Procedure [dbo].[UpdateUsersPrimaryLocationsOnDelete]
	
AS
BEGIN
	UPDATE el 
		SET primarylocationid=(SELECT min(lm.locationid) from entitylocationmapping
								elm inner join locationmaster lm ON
								lm.locationid=elm.LocationId WHERE 
								lm.Status<>2 and el.EntityID = elm.EntityID)
			From locationmaster lm1 
			INNER JOIN entitylocationmapping el 
			ON lm1.locationid=el.primarylocationid
			WHERE lm1.Status = 2


	UPDATE el 
		SET PrimaryLocationId=(Select min(el1.PrimaryLocationId) from entitylocationmapping 
							el1 WHERE el1.entityid=el.entityid and el1.PrimaryLocationId is not null) 
		From entitylocationmapping el WHERE el.PrimaryLocationId is null
END
GO
