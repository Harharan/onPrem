USE Spark

IF (EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES
 WHERE TABLE_NAME = N'OrganizationCustomParameterVersions') AND EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'OrganizationCustomParameterMaster'))
BEGIN
Declare @PackageVersion INT = (select top 1 REPLACE(PackageVersion, '.', '') from ApplicationInformation where IsUninstall= 1 order by id desc)
if(@PackageVersion<1402)
	Begin
	  UPDATE [OrganizationCustomParameterVersions] SET Status = (CASE WHEN OCPM.IsApplicable = 0 THEN 2 ELSE OCPM.IsApplicable END)
	  From [OrganizationCustomParameterVersions] OCPV join [OrganizationCustomParameterMaster] OCPM on 
	  OCPV.OrganizationId = OCPM.OrganizationId and OCPV.OrganizationCategoryId = ocpm.OrganizationCategoryId and
	  OCPV.ParameterId = OCPM.ParameterId where OCPV.IsCurrent=1
	End
END
GO
IF (EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES
 WHERE TABLE_NAME = N'RolePermissions'))
BEGIN
Update RolePermissions set OpeningMode=2,Display=0 where MenuId=3 and CommonTaskId=1
End
Go

Begin Tran
DECLARE @erro_msg nvarchar(4000), @error_severity int, @error_state int;
Begin Try
declare @PackageVersion int
Select @PackageVersion=(select top 1 REPLACE(PackageVersion, '.', '') from ApplicationInformation where IsUninstall= 1 order by id desc)
if(@PackageVersion<1402)
Begin

--update OrganizationTestMethodVersions set ThresholdType = 1 where TestMethodId = 7 and IsCurrent = 1
update OrganizationTestMethodVersions set ThresholdType = 2 where TestMethodId in (1,2,3) and IsCurrent = 1

/****************************
20B: For ATP tests, if user has already set up pass/fail threshold over the default range 
Then set the Min and Max range according to the business rule of 1 less and 1 more respectively
********************************/
Update OrganizationTestMethodVersions
SET 
	MinRange = (case WHEN PassThreshold <= 0 THEN (PassThreshold - 1) ELSE 0  END ),
	MaxRange = (case when FailThreshold >= 1000 THEN (FailThreshold + 1) ELSE 1000 END)
where TestMethodId in (1,2,3) and IsCurrent = 1 and PassThreshold is not null;

/****************************
20B: In case for ATP types, there are no pass threshold defined,
set its value according to revised default values
********************************/
update OTMV
set PassThreshold = (CASE WHEN OTMM.IsApplicable = 0 THEN NULL ELSE 1 END),
FailThreshold = (CASE WHEN OTMM.IsApplicable = 0 THEN NULL ELSE 999 END),
MinRange = 0,
MaxRange = 1000
FROM OrganizationTestMethodVersions OTMV
INNER JOIN OrganizationTestMethodMaster OTMM on OTMM.TestMethodId = OTMV.TestMethodId and OTMV.IsCurrent = 1
where OTMV.TestMethodId in (1,2,3) and OTMV.IsCurrent = 1 and OTMV.PassThreshold is null;

/****************************
20B: adjust data to Business rule, MaxRange should be atleast 3 more than MinRange value
********************************/
Update OrganizationTestMethodVersions
SET 
	MaxRange = MinRange + 3
where TestMethodId in (1,2,3) and IsCurrent = 1 and 3 > (MaxRange - MinRange);

/*** For Custom type***/
/****************************
20B: In case for custom types, if pass threshold is crossing the default min and max range 
then set the min range and max range values*****/
Update OrganizationTestMethodVersions
SET 
	MinRange = (case WHEN PassThreshold <= 0 THEN (PassThreshold - 1) ELSE 0  END ),
	MaxRange = (case when FailThreshold >= 1000 THEN (FailThreshold + 1) ELSE 1000 END)
where TestMethodId > 7 and IsCurrent = 1 and PassThreshold is not null and ThresholdType = 2;

/****************************
20B: In case for custom types, if there are no pass threshold defined, 
set its value according to revised default values
********************************/
update OTMV
set PassThreshold = (CASE WHEN OTMM.IsApplicable = 0 THEN NULL ELSE 1 END),
FailThreshold = (CASE WHEN OTMM.IsApplicable = 0 THEN NULL ELSE 999 END),
MinRange = 0,
MaxRange = 1000
FROM OrganizationTestMethodVersions OTMV
INNER JOIN OrganizationTestMethodMaster OTMM on OTMM.TestMethodId = OTMV.TestMethodId and OTMV.IsCurrent = 1
where OTMV.TestMethodId > 7 and OTMV.IsCurrent = 1 and OTMV.PassThreshold is null and ThresholdType = 2;

/****************************
20B: adjust data to Business rule, MaxRange should be atleast 3 more than MinRange value
********************************/
Update OrganizationTestMethodVersions
SET 
	MaxRange = MinRange + 3
where TestMethodId > 7 and IsCurrent = 1 and 3 > (MaxRange - MinRange) and ThresholdType = 2;

/*** Custom End***/
/******Temperature start*****/
Update OrganizationTestMethodVersions
SET 
	MinRange = (case WHEN PassThreshold <= -20 THEN (PassThreshold - 1) ELSE -20  END ),
	MaxRange = (case when FailThreshold >= 200 THEN (FailThreshold + 1) ELSE 200 END)
where TestMethodId = 6 and IsCurrent = 1 and PassThreshold is not null and ThresholdType = 2;

/****************************
20B: In case for temperature types, there are no pass threshold defined, 
set its value according to revised default values
********************************/
update OTMV
set PassThreshold = (CASE WHEN OTMM.IsApplicable = 0 THEN NULL ELSE -19 END),
FailThreshold = (CASE WHEN OTMM.IsApplicable = 0 THEN NULL ELSE 199 END),
MinRange = -20,
MaxRange = 200
FROM OrganizationTestMethodVersions OTMV
INNER JOIN OrganizationTestMethodMaster OTMM on OTMM.TestMethodId = OTMV.TestMethodId and OTMV.IsCurrent = 1
where OTMV.TestMethodId = 6 and OTMV.IsCurrent = 1 and OTMV.PassThreshold is null and ThresholdType = 2;

/****************************
20B: adjust data to Business rule, MaxRange should be atleast 3 more than MinRange value
********************************/
Update OrganizationTestMethodVersions
SET 
	MaxRange = MinRange + 3
where TestMethodId = 6 and IsCurrent = 1 and 3 > (MaxRange - MinRange) and ThresholdType = 2;
/******Temperature end*****/

/* 
Migration of pH type to pass range invert type to apply new rules
For pH Test Type having earlier Numeric Pass Fail criteria should be changed to pass fail range (ThresholdType = 3)
Set the Max and Min Range value according to new business rule
*/
--UPDATE OTMV
--SET 
--    --OTMV.PassThresholdMax = OTMV.PassThreshold,
--    --OTMV.FailThresholdMin = TMM.FailThreshold,
--    OTMV.PassThreshold = COALESCE(OTMV.PassThreshold, TMM.PassThreshold),
--    OTMV.FailThreshold = COALESCE(OTMV.FailThreshold, TMM.FailThreshold),
--	OTMV.ThresholdType = 3,
--	OTMV.MinRange = (case WHEN ISNULL(OTMV.PassThreshold,TMM.PassThreshold) <= 0 THEN (OTMV.PassThreshold - 1) ELSE 0  END ), --Lowest possible value PassThreshold is 1 with default min range
--	OTMV.MaxRange = (case when ISNULL(OTMV.FailThreshold,TMM.FailThreshold) >= 1000 THEN (OTMV.FailThreshold + 1) ELSE 1000 END) --Heighest possible value PassThreshold is 999 with default max range
--FROM OrganizationTestMethodVersions OTMV
--INNER JOIN TestMethodMaster TMM on OTMV.TestMethodID = TMM.TestMethodID 
--WHERE OTMV.TestMethodID = 5 and OTMV.IsCurrent = 1 AND OTMV.ThresholdType = 2

/*20B: IN case of pH and Chemical residue, mark the test type inactive when earlier criteria was Numeric Pass Fail.
as per new requirements the Chemical Residue Test Type can only be Qualitative pass fail and pH can have pass range criteria*/
UPDATE OTMM
SET OTMM.IsApplicable = 0
FROM OrganizationTestMethodMaster OTMM
INNER JOIN OrganizationTestMethodVersions OTMV on OTMM.TestMethodId = OTMV.TestMethodId and OTMV.IsCurrent = 1
WHERE OTMM.IsApplicable = 1 AND OTMV.ThresholdType = 2 AND OTMV.TestMethodId in (5,7)

/*20B: IN case of pH and Chemical residue, reset the ThresholdType for pH and Chemical residue in case if it is Numeric Pass Fail in 20A.*/
update OrganizationTestMethodVersions set ThresholdType = -999, PassThreshold=NUll, FailThreshold=NUll 
where TestMethodId = 5 and IsCurrent=1 and ThresholdType = 2

update OrganizationTestMethodVersions set ThresholdType = 1, PassThreshold=NUll, FailThreshold=NUll 
where TestMethodId = 7 and IsCurrent=1 and ThresholdType = 2

/*20B: Once pH and Checmical Residue has been marked as In Active, ensure corresponding Test Point and Sample Plan also gets in active if that is the only 
item associated*/
UPDATE TestPointMaster
SET Status = 2
WHERE TestPointId in (
SELECT TestPointId
FROM TestPointMaster TPM WHERE TPM.Status = 1 AND NOT EXISTS 
		(SELECT 1 from TestPointTestMethodMapping TPTM 
		INNER JOIN OrganizationTestMethodMaster OTM on TPTM.TestMethodId = OTM.TestMethodId
		WHERE TPTM.TestPointId = TPM.TestPointId AND OTM.IsApplicable = 1))

UPDATE TestPlanMaster
SET Status = 0 
WHERE TestPlanId IN (
SELECT TestPlanID
FROM TestPlanMaster TPM 
WHERE TPM.TestPlanId>1 AND TPM.Status = 1 AND NOT EXISTS (
		SELECT 1 FROM TestPlanTestPointMapping TPTPM 
		INNER JOIN TestPointMaster TPM1 on TPTPM.TestPointId = TPM1.TestPointId 
		WHERE TPTPM.TestPlanId = TPM.TestPlanID AND TPM1.Status = 1))

/*20B: Update Results table with Min and Max Range Values*/
Update TestPointResult
SET 
	MinRange = (case WHEN COALESCE(ATPPassThreshold,9999) <= 0 
				THEN (ATPPassThreshold - 1) 
				ELSE 
				  ( CASE WHEN TestMethodId not in (4,6,7) THEN 0
					ELSE CASE WHEN TestMethodId = 6 THEN -20 
					END END 
				  )
				END ),
	MaxRange = (case when COALESCE(ATPFailThreshold,-9999) >= 1000 
				THEN (ATPFailThreshold + 1) 
				ELSE 
					(CASE WHEN TestMethodId not in (4,5,6,7) THEN 1000
					ELSE CASE WHEN TestMethodId = 5 THEN 14 
					ELSE CASE WHEN TestMethodId = 6 THEN 200 
					END END END)
				END)
FROM TestPointResult


Update AdhocTestPointResult
SET 
	MinRange = (case WHEN COALESCE(ATPPassThreshold,9999) <= 0 
				THEN (ATPPassThreshold - 1) 
				ELSE 
				  ( CASE WHEN TestMethodId not in (4,6,7) THEN 0
					ELSE CASE WHEN TestMethodId = 6 THEN -20 
					END END 
				  )
				END ),
	MaxRange = (case when COALESCE(ATPFailThreshold,-9999) >= 1000 
				THEN (ATPFailThreshold + 1) 
				ELSE 
					(CASE WHEN TestMethodId not in (4,5,6,7) THEN 1000
					ELSE CASE WHEN TestMethodId = 5 THEN 14
					ELSE CASE WHEN TestMethodId = 6 THEN 200 
					END END END)
				END)
FROM AdhocTestPointResult

/*20B: Update OrganizationTestMethodVersions table with ThresholdType = 3 For Non ATP Type*/
update OrganizationTestMethodVersions set ThresholdType = 3 where ThresholdType = 2 and TestMethodId not in (1,2,3,4,5,7) and IsCurrent=1
update TestPointTestMethodMapping set ThresholdType = 3 where ThresholdType = 2 and TestMethodId not in (1,2,3,4)

--Update hierarchy in location master table for upgrade
Update LM 
Set LM.Description = case when LM.ParentLocationId = 0 then LM.LocationName else (select dbo.GetParentLocationName(LM.LocationId,1)) end
From LocationMaster LM
End	

/*20C change: to keep the default values set for test methods for all locations*/
if(@PackageVersion < 1501)
Begin
update TestMethodMaster set PassThreshold = NULL, FailThreshold = NULL
update TestMethodMaster set ThresholdType = 2 where TestType=0
Update TestMethodMaster set ThresholdType = -999 where ShortName in ('pH','Temp')
Update TestMethodMaster set TestMethodName = 'AQF 100 (Water free ATP)' where ShortName = 'AQF'
Update TestMethodMaster set TestMethodName = 'AQT 200 (Water total ATP)' where ShortName = 'AQT'
Update TestMethodMaster set TestMethodName = 'Allergens' where ShortName = 'Chemical'
Update TestMethodMaster set TestMethodName = 'Visual inspection' where ShortName = 'VI'

Update OrganizationTestMethodVersions set TestMethodName = 'AQF 100 (Water free ATP)' where ShortName = 'AQF' and IsCurrent=1
Update OrganizationTestMethodVersions set TestMethodName = 'AQT 200 (Water total ATP)' where ShortName = 'AQT' and IsCurrent=1
Update OrganizationTestMethodVersions set TestMethodName = 'Allergens' where ShortName = 'Chemical'  and IsCurrent=1
Update OrganizationTestMethodVersions set TestMethodName = 'Visual inspection' where ShortName = 'VI' and IsCurrent=1
End

Update TestMethodMaster set TestMethodName = 'Allergens' where ShortName = 'Chemical'
Update OrganizationTestMethodVersions set TestMethodName = 'Allergens' where ShortName = 'Chemical'  and IsCurrent=1

--Organization category master 
If(not exists(Select * FRom OrganizationCategoryMaster Where OrganizationCategoryId=8))
Begin
insert into [OrganizationCategoryMaster]
([OrganizationCategoryId]
,[OrganizationId]
,[CategoryName]
,[IsUserDefine]
,[IsNumericType]) values(8,1,'OC',1,0)
End
	
Commit Tran
End Try
Begin Catch
 Rollback Tran
 Set @erro_msg = ERROR_MESSAGE()
 Set @error_severity = ERROR_SEVERITY()
 Set @error_state = ERROR_STATE()
 RAISERROR(@erro_msg,@error_severity,@error_state);
End Catch


Declare @InstalledPackageVersion nvarchar(20) = (select top 1 PackageVersion from ApplicationInformation where IsUninstall= 1 order by id desc)
/* Get index of second dot(.) in packageversion. */
declare @IndexOfSecondDot int =  charindex( '.', @InstalledPackageVersion, charindex( '.', @InstalledPackageVersion ) + 1 )
declare @Version nvarchar(10)= SUBSTRING(@InstalledPackageVersion, 0, @IndexOfSecondDot)
set @Version = REPLACE(@Version,'.','')
if(@version<16)
Begin
	Update UserMaster set ContractOrganization = -999 where status != 4
END

Update OrganizationTestMethodVersions set ShortName = 'OT' where ShortName in ('OT1','OT2','OT3','OT4')

/*20C change: Data correction for Adhoc retest result.
Null was getting inserted in previous versions for below fields 
if retest for unplanned test is taken from web app.*/
Use Spark_Archive
update ATPR set
TestPointId = 0,
TestPointVersion = 1,
TestPointLocationId = 0,
LocationName = 'UNPLANNED TEST',
UnitId = (select UnitId from AdhocTestPointResult where AdhocResultId = ATPR.AdhocResultId AND AdhocMeasurementId = 1),
UnitName = (select UnitName from AdhocTestPointResult where AdhocResultId = ATPR.AdhocResultId AND AdhocMeasurementId = 1)
from AdhocTestPointResult ATPR
where ATPR.TestPointId IS NULL

Use Spark
update ATPR set
TestPointId = 0,
TestPointVersion = 1,
TestPointLocationId = 0,
LocationName = 'UNPLANNED TEST',
UnitId = (select UnitId from AdhocTestPointResult where AdhocResultId = ATPR.AdhocResultId AND AdhocMeasurementId = 1),
UnitName = (select UnitName from AdhocTestPointResult where AdhocResultId = ATPR.AdhocResultId AND AdhocMeasurementId = 1)
from AdhocTestPointResult ATPR
where ATPR.TestPointId IS NULL

update TestPlanMaster set TestPlanName = 'Unplanned tests' where TestPlanId=1