IF EXISTS (SELECT * FROM   sys.objects
			WHERE  object_id = OBJECT_ID(N'[dbo].[ufn_GetParentLocationId]')
            AND type IN ( N'FN', N'IF', N'TF', N'FS', N'FT' ))
  DROP FUNCTION [dbo].[ufn_GetParentLocationId]
GO 


/****** Object:  UserDefinedFunction [dbo].[ufn_GetParentLocationId]    Script Date: 29-01-2021 17:33:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Create function [dbo].[ufn_GetParentLocationId](@ChildLocationId int, @OrgId int)
RETURNS int
as
begin
declare @ParentLocationID int;
;WITH CTE
as
(
	select * from LocationMaster
	where LocationId = @ChildLocationId and OrganizationId = @OrgId
	UNION ALL 
	SELECT lm.* FROM LocationMaster lm
	inner join cte c on lm.LocationId = c.ParentLocationId
	where lm.OrganizationId = @OrgId
)

select Top 1 @ParentLocationID =  LocationId from cte where ParentLocationId = 0

return @ParentLocationID
end
GO

