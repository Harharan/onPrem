USE [Spark]
GO

/****** Object:  StoredProcedure [dbo].[UpdateDataMappingsForNewLocations]  ******/
IF OBJECT_ID ( '[dbo].[UpdateDataMappingsForNewLocations]', 'P' ) IS NOT NULL   
    DROP PROCEDURE [dbo].[UpdateDataMappingsForNewLocations]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE Procedure [dbo].[UpdateDataMappingsForNewLocations]
(
	 @OrganizationId INT,
     @UserId INT ,
	 @ParentLocationIds VARCHAR(MAX) 
)
AS 
BEGIN
 
BEGIN TRY
	BEGIN TRANSACTION;

    -------- split Locations and store in @LocationsIdtbl table
		DECLARE @LocationsIdtbl AS TABLE (SerialNo INT identity(1, 1),PlantId INT)
		INSERT INTO @LocationsIdtbl
		SELECT [value]
		FROM dbo.fn_Split(@ParentLocationIds, ',')

		Declare @MaxLength INT 
		select @MaxLength = MAX(SerialNo) from @LocationsIdtbl
		declare @Counter int = 1

		WHILE(@Counter <= @MaxLength)																																																																																				while(@Counter <= @MaxLength)
		BEGIN

		declare @ParentId int
		select @ParentId = PlantId from  @LocationsIdtbl where SerialNo = @Counter 

		--Get all childs of parentlocation
		DECLARE @ChildLocationIds AS TABLE (Id INT)
		INSERT INTO @ChildLocationIds(Id)
		SELECT LM.LocationId from LocationMaster LM where LM.ParentLocationId = @ParentId


   --------Cleaning variable Mappings START ----------
		--Get all distinct Cleaning variables mapping for child locations
		declare @ParameterIds AS TABLE (Parameter_Id INT, Category_Id INT)
		INSERT INTO @ParameterIds(Parameter_Id, Category_Id)
		SELECT Distinct CPLM.ParameterId, CPLM.CategoryId from CustomParameterLocationMapping CPLM
		Where CPLM.LocationId in (select Id from @ChildLocationIds)

		--Remove all mappings--
		 Delete From CustomParameterLocationMapping Where LocationId In (select Id from @ChildLocationIds)

		--Insert new mappings--
		 Insert Into CustomParameterLocationMapping(OrganizationId,CategoryId,ParameterId,LocationId,LocationLevel)
		 Select @OrganizationId, parameter.Category_Id, parameter.Parameter_Id, @ParentId,null
		 From @ParameterIds parameter 


    -------- CAPA Comments mapping START ----------
		declare @Type_Comment int = 4

		--Get all distinct Comments mapping for child locations
		declare @CapacommentIds AS TABLE (Comment_Id INT)
		INSERT INTO @CapacommentIds(Comment_Id)
		SELECT Distinct ELM.EntityID from EntityLocationMapping ELM
		Where EntityType= @Type_Comment  and ELM.LocationId in (select Id from @ChildLocationIds)

		--Remove all mappings--
		 Delete From EntityLocationMapping Where EntityType= @Type_Comment and LocationId In (select Id from @ChildLocationIds)

		--Insert new mappings-
		 Insert Into EntityLocationMapping(OrganizationId, EntityType, EntityID, LocationId, LocationLevel, PrimaryLocationId)
		 Select @OrganizationId, @Type_Comment, comment.Comment_Id, @ParentId,null,null
		 From @CapacommentIds comment 


    -----------  User mapping START ------------
		declare @Type_User int = 1

		------Get all distinct user mapping for child locations
		CREATE TABLE #TempUsers (rowNo INT identity(1, 1),userId INT,primaryLocId INT Null)
		INSERT INTO #TempUsers(userId, primaryLocId)
		SELECT Distinct ELM.EntityID, ELM.PrimaryLocationId from EntityLocationMapping ELM
		WHERE  EntityType = @Type_User and ELM.LocationId in (select Id from @ChildLocationIds)


		--Remove all mappings--
		 Delete From EntityLocationMapping Where EntityType= @Type_User and LocationId In (select Id from @ChildLocationIds)

		--Insert new mappings--
		 declare @iterator int =1, @length int 
		 select @length = COUNT(*) from #TempUsers

		 while(@iterator<= @length)
		 begin

			  declare @user int, @primaryloc int, @isPrimary bit
				select @user = userId , @primaryloc = primaryLocId from #TempUsers where rowNo = @iterator      
				select @isPrimary = case when @primaryloc in (select Id from  @ChildLocationIds) then 1 else 0 end
				if(@isPrimary = 1)
				   begin
					 update #TempUsers set primaryLocId= @ParentId where userId=@user					
				   end
				else
				   begin
					 update #TempUsers set primaryLocId= null where userId=@user
				   end

			 set @iterator=@iterator+1  --increase the counter
		 end

		 --------Insert new records----
		 Insert Into EntityLocationMapping(OrganizationId,EntityType,EntityID,LocationId,LocationLevel,PrimaryLocationId)
		 Select  distinct @OrganizationId, @Type_User, UI.userId, @ParentId,null,UI.primaryLocId
		 From #TempUsers UI 


	--------- Luminometer mapping START ----------
		--Get all distinct luminometer mapping for child locations
		declare @LuminometerDetails AS TABLE (orgnizationId INT,luminometerId INT,serialNo nvarchar(50))
		INSERT INTO @LuminometerDetails(orgnizationId,luminometerId,serialNo)
		SELECT Distinct LPM.OrganizationId ,LPM.LuminometerId , LPM.DeviceSerialNumber from LuminometerPlantMapping LPM
		Where LPM.LocationId in (select Id from @ChildLocationIds)

		--Remove all mappings--
		 Delete From LuminometerPlantMapping Where LocationId In (select Id from @ChildLocationIds)

		--Insert new mappings--
		 Insert Into LuminometerPlantMapping(OrganizationId, LuminometerId, DeviceSerialNumber, LocationId, CreatedDate, CreatedBy, LastEditDate, LastEditedBy)
		 Select distinct LD.orgnizationId, LD.luminometerId,LD.serialNo, @ParentId, GETUTCDATE(), @UserId, GETUTCDATE(), @UserId
		 From @LuminometerDetails LD 


		 --Delete tables---
		 delete from @ChildLocationIds 
		 delete from @ParameterIds
		 delete from @CapacommentIds
		 delete from @LuminometerDetails
		 DROP TABLE #TempUsers

	--Increment the counter
	set @Counter = @Counter+1
	END --loop end--

    ---Update the primary location for all user records---------

		CREATE TABLE #EntityLocationTempTable (id INT, Locationid INT) 
		Insert into #EntityLocationTempTable 
        Select EntityID,Min(el.LocationId) as Locationid 
        from EntityLocationMapping el inner join locationmaster lm on  el.locationid=lm.locationid where lm.Status<>2
        group by EntityID

		Update entitylocationmappingtable 
		Set entitylocationmappingtable.primarylocationid=entitytemptable.Locationid
		From EntityLocationMapping entitylocationmappingtable 
		inner join #EntityLocationTempTable entitytemptable 
		on entitylocationmappingtable.EntityID=entitytemptable.id 
		Where entitylocationmappingtable.primarylocationid is null

		Drop table #EntityLocationTempTable

		------Clear all user's Dashboard Filters----
		truncate table UserDashboardFilters
		truncate table ReportFilterMaster

		------Update the flag in organizationMaster table---
		update OrganizationMaster set IsHavingMultiLocationSamplePlan= 0 where OrganizationId = @OrganizationId


		/*21A: Inactivate sample plan if it is having test points of multiple plants during upgrade*/
		Select TPTPM.TestPlanId,dbo.ufn_GetParentLocationId(TTPM.LocationId,1) as ParentID 
		into #TP_SPDetails From 
		TestPlanTestPointMapping TPTPM 
		Inner join TestPointMaster TTPM on TPTPM.TestPointId = TTPM.TestPointId
		Group by TestPlanId,dbo.ufn_GetParentLocationId(TTPM.LocationId,1)

		update TestPlanMaster set [Status] = 0 where TestPlanId in (Select TestPlanId--,Min(ParrentID)
		From #TP_SPDetails
		Group by TestPlanId
		Having Count(ParentID)>1) and [Status] = 1

		Drop Table #TP_SPDetails


		COMMIT TRANSACTION;
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION;
	END CATCH;
END

