USE [Spark]
GO

/****** Object:  UserDefinedFunction [dbo].[GetParentLoctaionHierarchyIds]    Script Date: 27-11-2020 14:35:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT *
           FROM   sys.objects
           WHERE  object_id = OBJECT_ID(N'[dbo].[GetParentLoctaionHierarchyIds]')
                  AND type IN ( N'FN', N'IF', N'TF', N'FS', N'FT' ))
  DROP FUNCTION [dbo].[GetParentLoctaionHierarchyIds]

GO 


Create FUNCTION [dbo].[GetParentLoctaionHierarchyIds](@LocationPlantArray varchar(max), @OrganizationId int)
RETURNS	INT
AS
BEGIN
DECLARE @FinalPlantsIdtbl INT;

------------------split LocationPlants and store in @PlantsIdtbl table
DECLARE @PlantsIdtbl AS TABLE (PlantId INT)
INSERT INTO @PlantsIdtbl
SELECT [value]
FROM dbo.fn_Split(@LocationPlantArray, ',');

;WITH CTE
as
(
	select * from LocationMaster
	where LocationId in(select PlantId From  @PlantsIdtbl) and OrganizationId = @OrganizationId
	UNION ALL 
	SELECT lm.* FROM LocationMaster lm
	inner join cte c on lm.LocationId = c.ParentLocationId and lm.OrganizationId = c.OrganizationId and lm.OrganizationId = @OrganizationId and c.OrganizationId = @OrganizationId
)

SELECT @FinalPlantsIdtbl=LocationId 
FROM CTE Where ParentLocationId=0

OPTION(MAXRECURSION 32767)

RETURN @FinalPlantsIdtbl
END

