USE [Spark]
GO
IF OBJECT_ID ( '[dbo].[EntityLocationMapping]', 'U' ) IS  NULL     
Begin
	CREATE TABLE [dbo].[EntityLocationMapping](
	[OrganizationId] [int] NOT NULL,
	[EntityType] [int] NOT NULL,
	[EntityID] [int] NOT NULL,
	[LocationId] [int] NOT NULL,
	[LocationLevel] [int] NULL,
	 CONSTRAINT [PK_EntityLocationMapping] PRIMARY KEY CLUSTERED 
	(
		[OrganizationId] ASC,
		[EntityType] ASC,
		[EntityID] ASC,
		[LocationId] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY]
End


GO

IF OBJECT_ID ( '[dbo].[USP_UserWiseLocationHierarchyIds]', 'P' ) IS NOT NULL   
    DROP PROCEDURE [dbo].[USP_UserWiseLocationHierarchyIds]
GO

CREATE Procedure [dbo].[USP_UserWiseLocationHierarchyIds]
--Declare 
@OrganizationId INT,
@UserId Int

--Set @OrganizationId=1
--Set @UserId=3
As
Begin
Set nocount on
------------------split LocationPlants and store in @PlantsIdtbl table
Declare @LocationArray Varchar(Max)
DECLARE @PlantsIdtbl AS TABLE (PlantId INT)

set @LocationArray=''
Select @LocationArray=@LocationArray+Convert(Varchar(5),LocationId)+',' From EntityLocationMapping Where OrganizationId=@OrganizationId and EntityID=@UserId
if(Len(@LocationArray)<>0)
	Begin
		Set @LocationArray=SUBSTRING(@LocationArray,0,Len(@LocationArray))
	End

INSERT INTO @PlantsIdtbl
SELECT [value]
FROM dbo.fn_Split(@LocationArray, ',')

DECLARE @AllLocations bit
Select @AllLocations = case when count(1) >0 then 0 else 1 end from @PlantsIdtbl



if(@AllLocations != 1)
BEGIN
Declare @LocationIdtbl as table (LocationId int)
Insert into @LocationIdtbl 
select FinalPlanId from dbo.[GetLoctaionHierarchyIds](@LocationArray,@OrganizationId)
END
Select * from @LocationIdtbl order by LocationId
--Select @LocationArray
End
GO
